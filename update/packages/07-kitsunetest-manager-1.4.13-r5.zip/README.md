# KitsuneTest Deployment Manager for Plesk

## Instalacja

1. Skopiuj wygenerowany ZIP na serwer Plesk.
2. Jako administrator otwórz **Extensions → My Extensions → Upload Extension** i wskaż ZIP.
3. W panelu **KitsuneTest Manager** skonfiguruj repozytorium, branch, ścieżkę `/opt/kitsunetest/source`, domenę oraz publiczne adresy HTTPS.
4. Ustaw niezależne, losowe sekrety JWT, szyfrowania, webhooka GitHub, PostgreSQL, Redis i MinIO. Wszystkie zapisują się przez `pm_Settings::setEncrypted` i nie trafiają do stanu ani logów.
5. Token Git jest opcjonalny dla repozytorium publicznego i również pozostaje zaszyfrowany.
6. Uruchom kolejno: **Sprawdź**, **Synchronizuj repozytorium**, **Wdróż**.

## Opcjonalna integracja Kitsune Suite

URL-e KitsuneHub/KitsuneColab i wspólny sekret włączają
automatyczne projekty oraz trwałe przekazywanie wyników testów. Puste pola
zachowują pełny tryb samodzielny. ID organizacji można dodać później dla
automatycznego tworzenia projektów. Zgoda na delegowany redeploy/backup z Huba jest
oddzielna i domyślnie wyłączona. Hub może wykryć ten plugin albo, gdy go brakuje,
zbudować go z repozytorium HTTPS i przekazać ustawienia pierwszej instalacji.
Później konfiguracją zarządza wyłącznie ten manager. Szczegóły zawiera dołączony
`KITSUNE_SUITE.md`.

Serwer wymaga Git, Docker Engine z Compose v2, Node.js 22.12+ i dostępu do repozytorium. Rozszerzenie działa wyłącznie na Plesku dla Linuksa.

## Operacje

- `status` — repozytorium, kontenery, backupy i ostatnia operacja;
- `sync`, `install`, `build`, `migrate` — przygotowanie wydania;
- `deploy`, `redeploy`, `rollback` — wdrożenie z healthcheckiem;
- `start`, `stop`, `restart`, `logs` — runtime;
- `backup`, `restore` — pełne odzyskiwanie przez `scripts/project-task.mjs`.

Przed operacją produkcyjną rozszerzenie atomowo tworzy `.env.production` oraz sekrety plikowe Compose z prawami `0600`. Restore wymaga jawnego potwierdzenia w formularzu. Dane demonstracyjne nie są seedowane z panelu produkcyjnego. Runner odrzuca ścieżki spoza `/opt/kitsunetest`, nie wykonuje poleceń przekazanych przez użytkownika i blokuje równoległe operacje przez `flock`.

## Pakowanie i weryfikacja lokalna

```bash
node scripts/validate-plesk-extension.mjs
node scripts/package-plesk-extension.mjs
```

Walidator sprawdza strukturę, manifest, składnię PHP i JavaScript. Instalacja w prawdziwym panelu Pleska wymaga osobnego testu na serwerze.
