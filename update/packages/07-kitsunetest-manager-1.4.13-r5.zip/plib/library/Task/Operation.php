<?php

class Modules_KitsunetestManager_Task_Operation extends pm_LongTask_Task
{
    public $trackProgress = true;

    public function run()
    {
        $runtimeConfig = (string) $this->getParam('runtimeConfig');
        if ($runtimeConfig === '') {
            throw new RuntimeException('Brak pliku konfiguracji operacji.');
        }
        $this->updateProgress(10);
        $result = pm_ApiCli::callSbin('kitsunetest-manager', ['--config', $runtimeConfig], pm_ApiCli::RESULT_FULL);
        $this->updateProgress(95);
        $stdout = trim((string) ($result['stdout'] ?? ''));
        $stderr = trim((string) ($result['stderr'] ?? ''));
        $this->setParam('output', mb_substr($stdout . ($stderr !== '' ? "\n" . $stderr : ''), -16000));
        if ((int) ($result['code'] ?? 1) !== 0) {
            throw new RuntimeException($stderr !== '' ? $stderr : 'Operacja KitsuneTest zakończyła się błędem.');
        }
        $this->updateProgress(100);
    }

    public function onError(Exception $exception) { $this->removeRuntimeConfig(); }
    public function onDone() { $this->removeRuntimeConfig(); }

    public function statusMessage()
    {
        switch ($this->getStatus()) {
            case static::STATUS_RUNNING: return 'KitsuneTest: operacja jest wykonywana…';
            case static::STATUS_DONE: return 'KitsuneTest: operacja zakończona.';
            case static::STATUS_ERROR: return 'KitsuneTest: operacja zakończona błędem.';
            default: return 'KitsuneTest: zadanie oczekuje.';
        }
    }

    private function removeRuntimeConfig()
    {
        $path = (string) $this->getParam('runtimeConfig');
        if ($path !== '' && is_file($path)) {
            @unlink($path);
        }
    }
}
