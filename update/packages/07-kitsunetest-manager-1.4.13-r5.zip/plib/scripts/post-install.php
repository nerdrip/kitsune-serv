<?php

pm_Context::init('kitsunetest-manager');

// A Hub long task deliberately uses umask 0077 for secrets. If that mask is
// inherited by Plesk during extension extraction, the panel cannot traverse
// plib/htdocs and therefore shows no name, Open action or navigation item.
// Repair only public extension code; pm_Context::getVarDir() remains private.
$productRoot = defined('PRODUCT_ROOT_D') ? PRODUCT_ROOT_D : '/usr/local/psa';
$repairCodeTree = static function ($root, $fileMode) {
    if (!file_exists($root)) return;
    if (is_link($root) || !is_dir($root)) {
        throw new RuntimeException('Unsafe KitsuneTest extension code tree: ' . $root);
    }
    @chmod($root, 0755);
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($iterator as $item) {
        if ($item->isLink()) {
            throw new RuntimeException('KitsuneTest extension code tree contains a symbolic link.');
        }
        @chmod($item->getPathname(), $item->isDir() ? 0755 : $fileMode);
    }
};
$repairCodeTree($productRoot . '/admin/plib/modules/kitsunetest-manager', 0644);
$repairCodeTree($productRoot . '/admin/htdocs/modules/kitsunetest-manager', 0644);
$repairCodeTree($productRoot . '/admin/sbin/modules/kitsunetest-manager', 0750);

require_once dirname(__DIR__) . '/library/Config.php';
$varDir = pm_Context::getVarDir();
if (!is_dir($varDir)) {
    mkdir($varDir, 0700, true);
}
@chmod($varDir, 0700);
foreach (Modules_KitsunetestManager_Config::defaults() as $key => $value) {
    if (pm_Settings::get($key) === null) {
        pm_Settings::set($key, (string) $value);
    }
}
Modules_KitsunetestManager_Config::importSuiteBootstrap();
Modules_KitsunetestManager_Config::refreshSuiteDiscovery();
$utility = $productRoot . '/admin/sbin/modules/kitsunetest-manager/kitsunetest-manager';
if (is_file($utility)) {
    @chmod($utility, 0750);
}
