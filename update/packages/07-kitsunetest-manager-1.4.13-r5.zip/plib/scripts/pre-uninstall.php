<?php

pm_Context::init('kitsunetest-manager');
$varDir = realpath(pm_Context::getVarDir());
if ($varDir !== false && strpos($varDir, '/usr/local/psa/var/modules/kitsunetest-manager') === 0) {
    foreach (glob($varDir . '/operation-*.json') ?: [] as $file) {
        @unlink($file);
    }
}
