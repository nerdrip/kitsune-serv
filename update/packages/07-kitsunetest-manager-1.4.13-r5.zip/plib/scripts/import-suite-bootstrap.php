<?php

pm_Context::init('kitsunetest-manager');

$configLibrary = dirname(__DIR__) . '/library/Config.php';
if (!class_exists('Modules_KitsunetestManager_Config', false)) {
    require_once $configLibrary;
}

if (!Modules_KitsunetestManager_Config::importSuiteBootstrap()) {
    throw new RuntimeException('Nie znaleziono oczekującego bootstrapu KitsuneTest.');
}
Modules_KitsunetestManager_Config::refreshSuiteDiscovery();
fwrite(STDOUT, "KitsuneTest Suite bootstrap imported.\n");
