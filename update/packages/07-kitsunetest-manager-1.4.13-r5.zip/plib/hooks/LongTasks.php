<?php

class Modules_KitsunetestManager_LongTasks extends pm_Hook_LongTasks
{
    public function getLongTasks()
    {
        return [new Modules_KitsunetestManager_Task_Operation()];
    }
}
