<?php

class Modules_KitsunetestManager_CustomButtons extends pm_Hook_CustomButtons
{
    public function getButtons()
    {
        if ($this->hubOwnsNavigation()) return [];
        return [[
            'place' => [
                self::PLACE_ADMIN_NAVIGATION,
                self::PLACE_HOSTING_PANEL_NAVIGATION,
            ],
            'section' => self::SECTION_NAV_SERVER_MANAGEMENT,
            'order' => 52,
            'title' => 'KitsuneTest Manager',
            'description' => 'Deploy, monitoring, backup i restore KitsuneTest',
            'icon' => pm_Context::getBaseUrl() . 'images/kitsunetest-menu.svg',
            'link' => pm_Context::getBaseUrl() . 'index.php/index/index',
            'newWindow' => false,
        ]];
    }

    private function hubOwnsNavigation()
    {
        try { return pm_Extension::getById('kitsuneserv-bridge')->isActive(); }
        catch (Throwable $exception) { return false; }
    }
}
