# KitsuneTest Deployment Manager

Panel administratora Pleska do wdrażania i obsługi samodzielnie hostowanej platformy KitsuneTest. Obsługuje zaszyfrowane sekrety runtime, zahartowany Docker Compose, repozytorium Git, migracje, stan usług, logi, backup, restore, retencję oraz rollback do poprzedniego sprawdzonego commita.
