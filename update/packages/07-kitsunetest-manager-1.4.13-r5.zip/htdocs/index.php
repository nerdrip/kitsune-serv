<?php

pm_Context::init('kitsunetest-manager');

$application = new pm_Application();
$application->run();
