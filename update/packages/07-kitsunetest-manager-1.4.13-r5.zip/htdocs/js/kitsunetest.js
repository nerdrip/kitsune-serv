(function () {
  'use strict';

  function initialize(root) {
    if (!root || root.getAttribute('data-kitsunetest-ready') === '1') return;
    root.setAttribute('data-kitsunetest-ready', '1');
    var tabs = root.querySelectorAll('[data-kitsune-tab]');
    Array.prototype.forEach.call(tabs, function (tab) {
      tab.addEventListener('click', function () {
        Array.prototype.forEach.call(tabs, function (item) {
          item.setAttribute('aria-selected', item === tab ? 'true' : 'false');
        });
        if (window.history && window.history.replaceState) {
          window.history.replaceState(null, '', '#' + tab.getAttribute('data-kitsune-tab'));
        }
      });
      tab.addEventListener('keydown', function (event) {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          tab.click();
        }
      });
    });
    var requested = window.location.hash.replace(/^#/, '');
    var requestedTab = root.querySelector('[data-kitsune-tab="' + requested + '"]');
    if (requestedTab) requestedTab.click();

    var proxyMode = root.querySelector('[name="proxyMode"]');
    var manualVhost = root.querySelector('[data-kitsunetest-manual-vhost]');
    function updateVhostHelp() {
      if (proxyMode && manualVhost) manualVhost.hidden = proxyMode.value !== 'manual';
    }
    if (proxyMode) proxyMode.addEventListener('change', updateVhostHelp);
    updateVhostHelp();
    Array.prototype.forEach.call(root.querySelectorAll('form'), function (form) {
      form.addEventListener('submit', function () {
        Array.prototype.forEach.call(form.querySelectorAll('button[type="submit"], input[type="submit"]'), function (button) {
          button.disabled = true;
          if ('value' in button) button.value = 'Uruchamianie…';
        });
      });
    });
  }

  function initializeAll() {
    Array.prototype.forEach.call(document.querySelectorAll('[data-kitsunetest-manager]'), initialize);
  }
  initializeAll();
  document.addEventListener('DOMContentLoaded', initializeAll);
  window.addEventListener('load', initializeAll);
  if (window.MutationObserver && document.documentElement) {
    new MutationObserver(initializeAll).observe(document.documentElement, { childList: true, subtree: true });
  }
})();
