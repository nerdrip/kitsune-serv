# KitsuneTest w Kitsune Suite

Puste URL-e Suite oznaczają pełny tryb samodzielny. Aby włączyć integrację,
ustaw bazowe URL-e HTTPS Huba/Colaba, ID istniejącej organizacji oraz wspólny,
losowy sekret (minimum 32 znaki), a następnie wykonaj deploy.

Test tworzy projekty powiązane z Hubem i przekazuje zakończone przebiegi trwałą
kolejką do Huba oraz Colaba. Issue utworzone przez Colab wraca do powiązanego
projektu Test.

Opcja sterowania z Huba jest niezależna od integracji API, domyślnie wyłączona i
tworzy profil `suite-control-profile.json` z prawami `0600`.

Jeśli plugin nie jest jeszcze zainstalowany, KitsuneHub może zbudować go z
repozytorium Testu przez HTTPS i przekazać konfigurację startową jednorazowym
`suite-bootstrap.json` (`0600`). Po imporcie plik jest usuwany. Jeśli Plesk
odtworzy wpis ZIP z trybem wynikającym z własnego `umask`, plugin najpierw
sprawdza prywatny katalog, dokładną ścieżkę i właściciela, po czym natychmiast
przywraca `0700`/`0600`. Jeśli Plesk
pominie lifecycle hook aktualizacji, Hub może uruchomić wyłącznie ograniczony
tryb `--import-suite-bootstrap` managera przez środowisko PHP SDK Pleska. Osobny manager
Testu nadal działa niezależnie. Jawna operacja repozytoryjna Huba uzgadnia
domenę, repozytorium, dostęp Git, wspólny sekret i zgodę na delegowanie, ale nie
zmienia istniejących sekretów aplikacji. Bezsekretowy `suite-discovery.json` udostępnia Hubowi tylko dane
potrzebne do wykrycia pluginu i jego publicznego API.
