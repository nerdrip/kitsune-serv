<?php

class IndexController extends pm_Controller_Action
{
    protected $_accessLevel = 'admin';

    public function init()
    {
        parent::init();
        $this->view->pageTitle = 'Nerd Apps Runtime Manager';
        $this->view->headLink()->appendStylesheet(
            pm_Context::getBaseUrl() . 'css/runtime.css?v=' . Modules_NerdAppsRuntimeManager_Config::EXTENSION_VERSION
        );
        $this->view->headLink()->appendStylesheet(pm_Context::getBaseUrl() . 'css/kitsune-platform.css?v=2');
        $this->view->headScript()->appendFile(pm_Context::getBaseUrl() . 'js/kitsune-platform.js?v=2');
        $this->view->suiteProduct = 'Nerd Apps Runtime Manager';
        $this->view->suiteVersion = Modules_NerdAppsRuntimeManager_Config::EXTENSION_VERSION;
        try { $this->view->suiteHubActive = pm_Extension::getById('kitsuneserv-bridge')->isActive(); }
        catch (Throwable $exception) { $this->view->suiteHubActive = false; }
    }

    public function indexAction()
    {
        $statusRefreshError = null;
        $hellboundStatusRefreshError = null;
        if (!$this->getRequest()->isPost()) {
            $statusRefreshError = $this->refreshStatus();
            $hellboundStatusRefreshError = $this->refreshHellboundStatus();
        }
        $state = Modules_NerdAppsRuntimeManager_Config::readState();
        $deploymentForm = $this->definitionForm('deployment', Modules_NerdAppsRuntimeManager_Config::deploymentDefinitions());
        $runtimeForm = $this->definitionForm('runtime', Modules_NerdAppsRuntimeManager_Config::runtimeDefinitions());
        $sitesConfigForm = $this->definitionForm('sites', Modules_NerdAppsRuntimeManager_Config::siteFormDefinitions());
        $operationForm = $this->operationForm();
        $sitesOperationForm = $this->sitesOperationForm();
        $hellboundConfigForm = $this->hellboundConfigForm();
        $hellboundOperationForm = $this->hellboundOperationForm();
        $extensionUpdate = (array) ($state['extensionUpdate'] ?? []);
        $remoteExtensionVersion = trim((string) ($extensionUpdate['remoteVersion'] ?? ''));
        $remoteExtensionCommit = trim((string) ($extensionUpdate['remoteCommit'] ?? ''));
        $canDeployExtension = preg_match('/^[a-f0-9]{40,64}$/', $remoteExtensionCommit)
            && $remoteExtensionVersion !== ''
            && version_compare($remoteExtensionVersion, Modules_NerdAppsRuntimeManager_Config::EXTENSION_VERSION, '>');
        $extensionCheckForm = $this->extensionUpdateForm('extension-check', true);
        $extensionDeployForm = $this->extensionUpdateForm('extension-update', $canDeployExtension);

        if ($this->getRequest()->isPost()) {
            $post = (array) $this->getRequest()->getPost();
            $type = (string) ($post['formType'] ?? '');
            if ($type === 'deployment') return $this->saveDefinitionForm($deploymentForm, $post, 'deployment');
            if ($type === 'runtime') return $this->saveDefinitionForm($runtimeForm, $post, 'runtime');
            if ($type === 'sites') return $this->saveDefinitionForm($sitesConfigForm, $post, 'sites');
            if ($type === 'operation') return $this->startOperation($operationForm, $post);
            if ($type === 'sites-operation') return $this->startSitesOperation($sitesOperationForm, $post);
            if ($type === 'hellbound-config') return $this->saveHellboundConfig($hellboundConfigForm, $post);
            if ($type === 'hellbound-operation') return $this->startHellboundOperation($hellboundOperationForm, $post);
            if ($type === 'extension-update') {
                $operation = (string) ($post['operation'] ?? '');
                $form = $operation === 'extension-check' ? $extensionCheckForm : $extensionDeployForm;
                return $this->startExtensionUpdate($form, $post);
            }
            return $this->fail('Nie rozpoznano formularza.');
        }

        $this->view->deploymentForm = $deploymentForm;
        $this->view->runtimeForm = $runtimeForm;
        $this->view->sitesConfigForm = $sitesConfigForm;
        $this->view->operationForm = $operationForm;
        $this->view->sitesOperationForm = $sitesOperationForm;
        $this->view->hellboundConfigForm = $hellboundConfigForm;
        $this->view->hellboundOperationForm = $hellboundOperationForm;
        $this->view->extensionCheckForm = $extensionCheckForm;
        $this->view->extensionDeployForm = $extensionDeployForm;
        $this->view->state = $state;
        $this->view->deploymentConfig = Modules_NerdAppsRuntimeManager_Config::deploymentValues();
        $this->view->runtimeConfig = Modules_NerdAppsRuntimeManager_Config::runtimeValues();
        $this->view->sitesConfig = Modules_NerdAppsRuntimeManager_Config::siteValues();
        $this->view->hellboundState = Modules_NerdAppsRuntimeManager_HellboundConfig::readState();
        $this->view->hellboundConfig = Modules_NerdAppsRuntimeManager_HellboundConfig::values();
        $this->view->hellboundEnvironmentConfigured = Modules_NerdAppsRuntimeManager_HellboundConfig::hasSecret('productionEnvironment');
        $this->view->products = Modules_NerdAppsRuntimeManager_Config::productCatalog();
        $this->view->statusRefreshError = $statusRefreshError;
        $this->view->hellboundStatusRefreshError = $hellboundStatusRefreshError;
        $this->view->extensionVersion = Modules_NerdAppsRuntimeManager_Config::EXTENSION_VERSION;
        $allowedTabs = ['status', 'operations', 'sites', 'apps', 'deployment', 'runtime', 'log'];
        $requestedTab = (string) $this->getRequest()->getParam('tab', '');
        if ($requestedTab === 'hellbound') $requestedTab = 'apps';
        $this->view->activeTab = in_array($requestedTab, $allowedTabs, true) ? $requestedTab : '';
    }

    private function definitionForm($kind, array $definitions)
    {
        if ($kind === 'deployment') $values = Modules_NerdAppsRuntimeManager_Config::deploymentValues();
        elseif ($kind === 'runtime') $values = Modules_NerdAppsRuntimeManager_Config::runtimeValues();
        else $values = Modules_NerdAppsRuntimeManager_Config::siteValues();
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'narm-' . $kind . '-form');
        $form->addElement('hidden', 'formType', ['value' => $kind]);
        $currentSection = null;
        foreach ($definitions as $name => $definition) {
            if ($definition['section'] !== $currentSection) {
                $currentSection = $definition['section'];
                $this->section($form, $kind . 'Section' . md5($currentSection), $currentSection);
            }
            $this->definitionElement($form, $name, $definition, $values[$name] ?? '');
        }
        $labels = ['deployment' => 'Zapisz wdrożenie', 'runtime' => 'Zapisz konfigurację runtime', 'sites' => 'Zapisz ekosystem stron'];
        $this->actionButton($form, $kind . 'Submit', $labels[$kind] ?? 'Zapisz', 'save');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function definitionElement(pm_Form_Simple $form, $name, array $definition, $value)
    {
        $type = (string) $definition['type'];
        $options = [
            'label' => $definition['label'],
            'value' => !empty($definition['secret']) ? '' : $value,
            'description' => (string) $definition['description'],
        ];
        if (in_array($type, ['plesk-main-domain', 'plesk-hosted-domain'], true)) {
            $domains = $this->domainOptions();
            if ($value !== '' && !isset($domains[$value])) $domains[$value] = $value . ' (zapisana)';
            $options['multiOptions'] = ['' => '— wybierz aktywną domenę z Pleska —'] + $domains;
            $options['required'] = true;
            $form->addElement('select', $name, $options);
            return;
        }
        if ($type === 'select' || $type === 'boolean') {
            $options['multiOptions'] = $type === 'boolean'
                ? ['true' => 'Tak', 'false' => 'Nie']
                : (array) $definition['options'];
            $form->addElement('select', $name, $options);
            return;
        }
        if ($type === 'textarea' || $type === 'textarea-secret') {
            $options['rows'] = $type === 'textarea-secret' ? 7 : 4;
            $options['class'] = 'f-middle-size narm-textarea';
            $form->addElement('textarea', $name, $options);
            return;
        }
        if ($type === 'password') {
            $hasSecret = in_array($name, ['gitToken', 'gitSshPrivateKey'], true)
                ? Modules_NerdAppsRuntimeManager_Config::hasDeploymentSecret($name)
                : Modules_NerdAppsRuntimeManager_Config::hasRuntimeSecret($name);
            if ($hasSecret) $options['description'] = 'Wartość jest zapisana i zaszyfrowana. Puste pole zachowuje ją bez zmian.';
            $form->addElement('password', $name, $options);
            return;
        }
        $validators = [];
        if ($type === 'service-host') $validators[] = ['Regex', true, ['pattern' => '/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/']];
        if ($type === 'path') $validators[] = ['Regex', true, ['pattern' => '#^/[A-Za-z0-9._/-]+$#']];
        if ($type === 'relative') $validators[] = ['Regex', true, ['pattern' => '#^[A-Za-z0-9._/-]+$#']];
        if ($type === 'ip') $validators[] = ['Ip', true];
        if ($type === 'port') $validators = [['Digits', true], ['Between', true, ['min' => 1, 'max' => 65535]]];
        if ($type === 'integer') $validators[] = ['Digits', true];
        if ($type === 'decimal') $validators[] = ['Regex', true, ['pattern' => '/^\d+(?:\.\d+)?$/']];
        if ($validators) $options['validators'] = $validators;
        $form->addElement('text', $name, $options);
    }

    private function operationForm()
    {
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'narm-operation-form');
        $form->addElement('hidden', 'formType', ['value' => 'operation']);
        $form->addElement('select', 'operation', [
            'label' => 'Operacja',
            'value' => 'check',
            'multiOptions' => [
                'check' => 'Sprawdź wymagania, repozytorium i health',
                'sync' => 'Pobierz aktualizację (fast-forward)',
                'deploy' => 'Wdróż lokalny kod',
                'sync-deploy' => 'Pobierz i wdróż aktualizację',
                'proxy' => 'Napraw host i reverse proxy serwera AI',
                'cors' => 'Automatycznie napraw CORS domeny',
                'restart' => 'Zastosuj konfigurację i odtwórz usługi',
                'start' => 'Uruchom usługi',
                'stop' => 'Zatrzymaj usługi',
                'ingest' => 'Przebuduj indeks RAG',
                'backup' => 'Wykonaj snapshot Qdrant',
                'logs' => 'Odśwież ostatnie logi',
            ],
        ]);
        $this->actionButton($form, 'operationSubmit', 'Uruchom operację', 'operation');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function extensionUpdateForm($operation, $enabled)
    {
        $isCheck = $operation === 'extension-check';
        $form = new pm_Form_Simple();
        $form->setAttrib('id', $isCheck ? 'narm-extension-check-form' : 'narm-extension-deploy-form');
        $form->addElement('hidden', 'formType', ['value' => 'extension-update']);
        $form->addElement('hidden', 'operation', ['value' => $operation]);
        $label = $isCheck ? 'Sprawdź aktualizacje' : 'Wdróż nową wersję';
        $disabled = $enabled ? '' : ' disabled="disabled" aria-disabled="true" title="Najpierw sprawdź repozytorium; wdrożenie będzie dostępne tylko dla nowszej wersji."';
        $class = $isCheck ? 'narm-secondary' : 'narm-primary';
        $form->addElement('simpleText', 'extensionUpdateSubmit', [
            'label' => '', 'escape' => false,
            'value' => '<button type="submit" class="' . $class . '" data-narm-action="' . htmlspecialchars($operation, ENT_QUOTES, 'UTF-8') . '"' . $disabled . '>' . $label . '</button>',
        ]);
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function sitesOperationForm()
    {
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'narm-sites-operation-form');
        $form->addElement('hidden', 'formType', ['value' => 'sites-operation']);
        $form->addElement('select', 'operation', [
            'label' => 'Operacja na domenach',
            'value' => 'sites-check',
            'multiOptions' => [
                'sites-check' => 'Audytuj bez zmian',
                'sites-sync' => 'Opublikuj strony i napraw subdomeny',
            ],
            'description' => 'Synchronizacja łączy publiczne domeny z CMS-em, ustawia TLS/HTTPS i tworzy brakujące subdomeny produktów. Nigdy niczego nie usuwa.',
        ]);
        $this->actionButton($form, 'sitesOperationSubmit', 'Uruchom operację domenową', 'sites');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function hellboundConfigForm()
    {
        $values = Modules_NerdAppsRuntimeManager_HellboundConfig::values();
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'narm-hellbound-config-form');
        $form->addElement('hidden', 'formType', ['value' => 'hellbound-config']);
        $fields = [
            'sourceSubdirectory' => ['Podkatalog Hellbound', 'text', 'W tym monorepozytorium: apps/hellbound.', true],
            'deploymentRoot' => ['Dedykowany katalog wdrożenia', 'text', 'Niezależny katalog wydań, danych i backupów.', true],
            'serverDomain' => ['Serwer Hellbound', 'text', 'Sam host, np. hellbound.api.nerd.rip. Plesk utworzy go automatycznie i skieruje do lokalnego serwera gry.', true],
            'composeProject' => ['Projekt Docker Compose', 'text', 'Stała nazwa zachowuje wolumeny między wydaniami.', true],
            'backupRetention' => ['Liczba backupów', 'text', 'Od 1 do 100.', true],
            'releaseRetention' => ['Liczba wydań', 'text', 'Od 2 do 20.', true],
            'productionEnvironment' => ['Bezpieczna konfiguracja serwera (.env)', 'textarea-large', Modules_NerdAppsRuntimeManager_HellboundConfig::hasSecret('productionEnvironment') ? 'Konfiguracja jest zapisana i zaszyfrowana przez Pleska. Pozostaw puste, aby jej nie zmieniać.' : 'Nie wpisuj haseł ręcznie: użyj przycisku generatora nad formularzem.', false],
        ];
        foreach ($fields as $name => $definition) {
            [$label, $type, $description, $required] = $definition;
            $options = ['label' => $label, 'value' => $name === 'productionEnvironment' ? '' : ($values[$name] ?? ''), 'description' => $description, 'required' => $required];
            if ($type === 'password') $form->addElement('password', $name, $options);
            elseif (strpos($type, 'textarea') === 0) { $options['rows'] = $type === 'textarea-large' ? 12 : 6; $options['class'] = 'f-middle-size narm-textarea'; $form->addElement('textarea', $name, $options); }
            else $form->addElement('text', $name, $options);
        }
        $this->actionButton($form, 'hellboundConfigSubmit', 'Zapisz konfigurację serwera', 'save');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function hellboundOperationForm()
    {
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'narm-hellbound-operation-form');
        $form->addElement('hidden', 'formType', ['value' => 'hellbound-operation']);
        $form->addElement('select', 'operation', [
            'label' => 'Co chcesz zrobić?', 'value' => 'deploy',
            'multiOptions' => [
                'deploy' => 'Wdróż bezpiecznie (zalecane)',
                'health' => 'Sprawdź, czy serwer Hellbound działa',
                'vhost' => 'Utwórz lub napraw host Pleska',
                'logs' => 'Pokaż logi wybranej usługi',
                'sync' => 'Pobierz aktualny kod z repozytorium',
                'build' => 'Tylko zbuduj nowe wydanie',
                'migrate' => 'Tylko uruchom migracje bazy',
                'start' => 'Uruchom ostatnie aktywne wydanie',
                'stop' => 'Zatrzymaj serwer bez usuwania danych',
                'backup' => 'Utwórz i zweryfikuj backup',
                'restore' => 'Przywróć dane z backupu',
                'rollback' => 'Wróć do poprzedniego wydania',
                'prune' => 'Usuń nadmiarowe stare backupy',
            ],
        ]);
        $form->addElement('text', 'backup', ['label' => 'ID backupu do przywrócenia', 'value' => '', 'description' => 'Skopiuj dokładne ID z listy backupów.']);
        $form->addElement('text', 'release', ['label' => 'ID wydania do przywrócenia', 'value' => '', 'description' => 'Skopiuj dokładne ID poprzedniego wydania.']);
        $form->addElement('text', 'keep', ['label' => 'Ile najnowszych backupów zachować', 'value' => Modules_NerdAppsRuntimeManager_HellboundConfig::values()['backupRetention']]);
        $form->addElement('select', 'service', ['label' => 'Usługa logów', 'value' => 'gateway', 'multiOptions' => ['gateway' => 'Gateway', 'nakama' => 'Nakama', 'postgres' => 'PostgreSQL', 'app-migrate' => 'Migracje aplikacji', 'nakama-migrate' => 'Migracje Nakama']]);
        $form->addElement('text', 'lines', ['label' => 'Liczba linii', 'value' => '200']);
        $form->addElement('text', 'confirm', ['label' => 'Potwierdzenie operacji wysokiego ryzyka', 'value' => '', 'description' => 'Panel pokaże wymagany tekst tylko przy restore, rollback albo czyszczeniu backupów.']);
        $this->actionButton($form, 'hellboundOperationSubmit', 'Uruchom wybraną operację', 'hellbound');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function saveDefinitionForm(pm_Form_Simple $form, array $post, $kind)
    {
        $tab = $kind;
        if (!$form->isValid($post)) return $this->fail('Sprawdź zaznaczone pola formularza.', $tab);
        try {
            $values = $form->getValues();
            if ($kind === 'deployment') {
                $this->validateDeployment($values);
                Modules_NerdAppsRuntimeManager_Config::saveDeployment($values);
                if (($values['proxyMode'] ?? 'manual') === 'managed') {
                    $runtimeConfig = Modules_NerdAppsRuntimeManager_Config::createRuntimeConfig('ai-vhost');
                    $task = new Modules_NerdAppsRuntimeManager_Task_Operate();
                    $task->setParam('runtimeConfig', $runtimeConfig);
                    $task->setParam('operation', 'ai-vhost');
                    $task->setParam('scope', 'runtime');
                    (new pm_LongTask_Manager())->start($task);
                    $this->_status->addMessage('info', 'Zapisano konfigurację. Plesk tworzy lub naprawia teraz host serwera AI i jego reverse proxy.');
                    return $this->redirectResponse($tab);
                }
            } elseif ($kind === 'runtime') {
                Modules_NerdAppsRuntimeManager_Config::saveRuntime($values);
            } else {
                $values = $this->validateSites($values);
                Modules_NerdAppsRuntimeManager_Config::saveSites($values);
            }
            $this->_status->addMessage('info', 'Konfiguracja została zapisana. Zastosuje ją następne wdrożenie lub restart.');
        } catch (Throwable $exception) {
            $this->_status->addMessage('error', $exception->getMessage());
        }
        return $this->redirectResponse($tab);
    }

    private function startSitesOperation(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) return $this->fail('Wybierz audyt albo synchronizację domen.', 'sites');
        $operation = (string) $form->getValue('operation');
        if (!in_array($operation, ['sites-check', 'sites-sync'], true)) return $this->fail('Nieznana operacja domenowa.', 'sites');
        try {
            $runtimeConfig = Modules_NerdAppsRuntimeManager_Config::createRuntimeConfig($operation);
            $task = new Modules_NerdAppsRuntimeManager_Task_Operate();
            $task->setParam('runtimeConfig', $runtimeConfig);
            $task->setParam('operation', $operation);
            $task->setParam('scope', 'runtime');
            (new pm_LongTask_Manager())->start($task);
            $this->_status->addMessage('info', $operation === 'sites-sync' ? 'Bezpieczna synchronizacja domen trafiła do kolejki.' : 'Audyt domen trafił do kolejki.');
        } catch (Throwable $exception) {
            $this->_status->addMessage('error', $exception->getMessage());
        }
        return $this->redirectResponse('sites');
    }

    private function saveHellboundConfig(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) return $this->fail('Sprawdź konfigurację Hellbound.', 'apps');
        try {
            $values = $form->getValues();
            $target = Modules_NerdAppsRuntimeManager_Config::serviceHostTarget($values['serverDomain'] ?? '', 'serwera Hellbound');
            $aiHost = strtolower(trim((string) (Modules_NerdAppsRuntimeManager_Config::deploymentValues()['domain'] ?? '')));
            $cmsHost = strtolower(trim((string) (Modules_NerdAppsRuntimeManager_Config::siteValues()['contentDomain'] ?? '')));
            if (in_array($target['domain'], array_filter([$aiHost, $cmsHost]), true)) {
                throw new RuntimeException('Serwer Hellbound musi mieć osobny host, inny niż serwer AI i WordPress/CMS.');
            }
            Modules_NerdAppsRuntimeManager_HellboundConfig::save($values);
            $runtimeConfig = Modules_NerdAppsRuntimeManager_HellboundConfig::createRuntimeConfig('vhost');
            $task = new Modules_NerdAppsRuntimeManager_Task_Operate();
            $task->setParam('runtimeConfig', $runtimeConfig);
            $task->setParam('operation', 'vhost');
            $task->setParam('scope', 'hellbound');
            (new pm_LongTask_Manager())->start($task);
            $this->_status->addMessage('info', 'Konfiguracja Hellbound została zapisana. Plesk tworzy lub naprawia host serwera gry; sekrety pozostają zaszyfrowane.');
        } catch (Throwable $exception) {
            $this->_status->addMessage('error', $this->safeError($exception));
        }
        return $this->redirectResponse('apps');
    }

    private function startHellboundOperation(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) return $this->fail('Sprawdź parametry operacji Hellbound.', 'apps');
        $operation = (string) $form->getValue('operation');
        $arguments = [];
        if ($operation === 'restore') $arguments = ['backup' => $form->getValue('backup'), 'confirm' => $form->getValue('confirm')];
        elseif ($operation === 'rollback') $arguments = ['release' => $form->getValue('release'), 'confirm' => $form->getValue('confirm')];
        elseif ($operation === 'prune') $arguments = ['keep' => $form->getValue('keep'), 'confirm' => $form->getValue('confirm')];
        elseif ($operation === 'logs') $arguments = ['service' => $form->getValue('service'), 'lines' => $form->getValue('lines')];
        try {
            $runtimeConfig = Modules_NerdAppsRuntimeManager_HellboundConfig::createRuntimeConfig($operation, $arguments);
            $task = new Modules_NerdAppsRuntimeManager_Task_Operate();
            $task->setParam('runtimeConfig', $runtimeConfig);
            $task->setParam('operation', $operation);
            $task->setParam('scope', 'hellbound');
            (new pm_LongTask_Manager())->start($task);
            $this->_status->addMessage('info', 'Chroniona operacja Hellbound trafiła do kolejki Pleska.');
        } catch (Throwable $exception) {
            $this->_status->addMessage('error', $this->safeError($exception));
        }
        return $this->redirectResponse('apps');
    }

    private function startOperation(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) return $this->fail('Wybierz prawidłową operację.', 'operations');
        $operation = (string) $form->getValue('operation');
        $allowed = ['check', 'sync', 'deploy', 'sync-deploy', 'proxy', 'cors', 'restart', 'start', 'stop', 'ingest', 'backup', 'logs'];
        if (!in_array($operation, $allowed, true)) return $this->fail('Nieznana operacja.', 'operations');
        try {
            $runtimeConfig = Modules_NerdAppsRuntimeManager_Config::createRuntimeConfig($operation);
            $task = new Modules_NerdAppsRuntimeManager_Task_Operate();
            $task->setParam('runtimeConfig', $runtimeConfig);
            $task->setParam('operation', $operation);
            $task->setParam('scope', 'runtime');
            (new pm_LongTask_Manager())->start($task);
            $this->_status->addMessage('info', 'Operacja została dodana do kolejki Pleska.');
        } catch (Throwable $exception) {
            $this->_status->addMessage('error', 'Nie udało się uruchomić operacji: ' . $exception->getMessage());
        }
        return $this->redirectResponse('operations');
    }

    private function startExtensionUpdate(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) return $this->fail('Nie udało się potwierdzić operacji aktualizacji.', 'status');
        $operation = (string) $form->getValue('operation');
        if (!in_array($operation, ['extension-check', 'extension-update'], true)) {
            return $this->fail('Nieznana operacja aktualizacji rozszerzenia.', 'status');
        }
        $options = [];
        if ($operation === 'extension-update') {
            $extensionUpdate = (array) (Modules_NerdAppsRuntimeManager_Config::readState()['extensionUpdate'] ?? []);
            $remoteVersion = trim((string) ($extensionUpdate['remoteVersion'] ?? ''));
            $remoteCommit = trim((string) ($extensionUpdate['remoteCommit'] ?? ''));
            if (!preg_match('/^[a-f0-9]{40,64}$/', $remoteCommit)
                || $remoteVersion === ''
                || !version_compare($remoteVersion, Modules_NerdAppsRuntimeManager_Config::EXTENSION_VERSION, '>')) {
                return $this->fail('Najpierw sprawdź repozytorium. Wdrożyć można wyłącznie nowszą, poprawnie oznaczoną wersję.', 'status');
            }
            $options['expectedExtensionCommit'] = $remoteCommit;
        }
        try {
            $runtimeConfig = Modules_NerdAppsRuntimeManager_Config::createRuntimeConfig($operation, $options);
            $task = new Modules_NerdAppsRuntimeManager_Task_Operate();
            $task->setParam('runtimeConfig', $runtimeConfig);
            $task->setParam('operation', $operation);
            $task->setParam('scope', 'extension');
            (new pm_LongTask_Manager())->start($task);
            $message = $operation === 'extension-check'
                ? 'Sprawdzenie wersji w repozytorium trafiło do kolejki Pleska.'
                : 'Bezpieczna aktualizacja rozszerzenia trafiła do kolejki. Po zakończeniu odśwież panel.';
            $this->_status->addMessage('info', $message);
        } catch (Throwable $exception) {
            $this->_status->addMessage('error', 'Nie udało się uruchomić aktualizacji: ' . $this->safeError($exception));
        }
        return $this->redirectResponse('status');
    }

    private function refreshStatus()
    {
        $runtimeConfig = null;
        try {
            $runtimeConfig = Modules_NerdAppsRuntimeManager_Config::createRuntimeConfig('status');
            $result = pm_ApiCli::callSbin('nerd-apps-runtime-manager', ['--config', $runtimeConfig], pm_ApiCli::RESULT_FULL);
            if ((int) ($result['code'] ?? 1) !== 0) return trim((string) ($result['stderr'] ?? $result['stdout'] ?? 'Błąd odświeżania.'));
            return null;
        } catch (Throwable $exception) {
            return $exception->getMessage();
        } finally {
            if ($runtimeConfig && is_file($runtimeConfig)) @unlink($runtimeConfig);
        }
    }

    private function refreshHellboundStatus()
    {
        $runtimeConfig = null;
        try {
            $runtimeConfig = Modules_NerdAppsRuntimeManager_HellboundConfig::createRuntimeConfig('status');
            $result = pm_ApiCli::callSbin('nerd-apps-runtime-manager', ['--scope', 'hellbound', '--config', $runtimeConfig], pm_ApiCli::RESULT_FULL);
            if ((int) ($result['code'] ?? 1) !== 0) return 'Nie udało się odświeżyć Hellbound; pokazuję ostatni bezpieczny snapshot.';
            return null;
        } catch (Throwable $exception) {
            return 'Stan Hellbound będzie dostępny po zapisaniu repozytorium i poprawnej konfiguracji hosta.';
        } finally {
            if ($runtimeConfig && is_file($runtimeConfig)) @unlink($runtimeConfig);
        }
    }

    private function validateDeployment(array $values)
    {
        if (!preg_match('/^(https:\/\/|ssh:\/\/|git@)/', (string) ($values['repositoryUrl'] ?? ''))) {
            throw new RuntimeException('Repozytorium musi używać HTTPS albo SSH.');
        }
        if (preg_match('#^https://[^/@]+@#', (string) ($values['repositoryUrl'] ?? ''))) {
            throw new RuntimeException('Dane logowania Git wpisz w szyfrowanych polach, nie w URL repozytorium.');
        }
        if (!preg_match('/^(?![-.])(?!.*\.\.)(?!.*@\{)[A-Za-z0-9._\/-]+$/', (string) ($values['repositoryBranch'] ?? ''))) {
            throw new RuntimeException('Nieprawidłowa nazwa gałęzi.');
        }
        foreach (['repositoryPath', 'runtimePath', 'dataPath', 'backupPath'] as $field) {
            $path = rtrim((string) ($values[$field] ?? ''), '/');
            if (!preg_match('#^/[A-Za-z0-9._/-]+$#', $path) || in_array('..', explode('/', $path), true) || substr_count($path, '/') < 2) {
                throw new RuntimeException('Niebezpieczna ścieżka: ' . $field . '.');
            }
        }
        $repository = rtrim((string) $values['repositoryPath'], '/');
        $runtime = rtrim((string) $values['runtimePath'], '/');
        $data = rtrim((string) $values['dataPath'], '/');
        $backup = rtrim((string) $values['backupPath'], '/');
        $paths = [$repository, $runtime, $data, $backup];
        for ($left = 0; $left < count($paths); $left++) {
            for ($right = $left + 1; $right < count($paths); $right++) {
                if ($paths[$left] === $paths[$right]
                    || strpos($paths[$left] . '/', $paths[$right] . '/') === 0
                    || strpos($paths[$right] . '/', $paths[$left] . '/') === 0) {
                    throw new RuntimeException('Katalogi repozytorium, runtime, danych i backupów nie mogą się pokrywać ani zawierać nawzajem.');
                }
            }
        }
        if (($values['proxyMode'] ?? 'manual') === 'managed' && trim((string) ($values['domain'] ?? '')) === '') throw new RuntimeException('Wybierz domenę dla zarządzanego proxy.');
        if (($values['proxyMode'] ?? 'manual') === 'managed') {
            $target = Modules_NerdAppsRuntimeManager_Config::serviceHostTarget($values['domain'] ?? '', 'serwera AI');
            $hellboundHost = strtolower(trim((string) (Modules_NerdAppsRuntimeManager_HellboundConfig::values()['serverDomain'] ?? '')));
            $cmsHost = strtolower(trim((string) (Modules_NerdAppsRuntimeManager_Config::siteValues()['contentDomain'] ?? '')));
            if (in_array($target['domain'], array_filter([$hellboundHost, $cmsHost]), true)) {
                throw new RuntimeException('Serwer AI musi mieć osobny host, inny niż serwer Hellbound i WordPress/CMS.');
            }
        }
    }

    private function validateSites(array $values)
    {
        return [
            'contentDomain' => (string) ($values['contentDomain'] ?? ''),
            'studioDomain' => (string) ($values['studioDomain'] ?? ''),
            'projectsDomain' => (string) ($values['projectsDomain'] ?? ''),
        ];
    }

    private function safeError(Throwable $exception)
    {
        $message = preg_replace('/(?:Bearer\s+|token[=:]\s*|password[=:]\s*)\S+/i', '$1[REDACTED]', $exception->getMessage());
        return mb_substr((string) $message, 0, 1000);
    }

    private function domainOptions()
    {
        $options = [];
        try {
            foreach ((array) pm_Domain::getAllDomains() as $domain) {
                if (!$domain instanceof pm_Domain || !$domain->hasHosting() || !$domain->isActive() || $domain->isSuspended() || $domain->isDisabled()) continue;
                $name = strtolower((string) $domain->getName());
                if ($name !== '') $options[$name] = $name;
            }
        } catch (Throwable $exception) {}
        natcasesort($options);
        return $options;
    }

    private function section(pm_Form_Simple $form, $name, $title)
    {
        $form->addElement('simpleText', $name, [
            'label' => '', 'escape' => false,
            'value' => '<div class="narm-form-section"><strong>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</strong></div>',
        ]);
    }

    private function actionButton(pm_Form_Simple $form, $name, $label, $kind)
    {
        $form->addElement('simpleText', $name, [
            'label' => '', 'escape' => false,
            'value' => '<button type="submit" class="narm-primary" data-narm-action="' . htmlspecialchars($kind, ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</button>',
        ]);
    }

    private function fail($message, $tab = 'status')
    {
        $this->_status->addMessage('error', $message);
        return $this->redirectResponse($tab);
    }

    private function redirectResponse($tab = 'status')
    {
        $url = pm_Context::getActionUrl('index', 'index');
        $separator = strpos($url, '?') === false ? '?' : '&';
        $this->_helper->json(['redirect' => $url . $separator . 'tab=' . rawurlencode((string) $tab)]);
    }
}
