# Historia zmian

## 1.5.11-4 — 2026-08-21

- Self-update synchronizuje repozytorium KitsuneColab i instaluje rozszerzenie z `tools/plesk-extension/kitsunecolab-manager`.

## 1.5.11-2 — 2026-08-20

- Rozszerzenie otrzymało unikalny identyfikator `kitsunecolab-manager`, który nie koliduje z innymi managerami.
- Dodano wspólny wygląd Suite i nawigację przejmowaną przez aktywny Kitsune Hub.

## 1.5.11 — 2026-08-12

- `minio-init` zakończony kodem `0` jest pokazywany jako poprawne zadanie jednorazowe i nie obniża zdrowia wdrożenia.
- Status usług rozróżnia zakończenie inicjalizacji od awarii kontenera.

## 1.5.10 — 2026-08-12

- Zakładki działają natywnie przez HTML/CSS również po nawigacji AJAX Pleska.
- Stan operacyjny jest publikowany atomowo z prawami `0640` dla konta `psaadm`.
- Odczyt stanu bezpiecznie odrzuca linki symboliczne i nieczytelne pliki.

## 1.5.9 — 2026-08-12

- Profile sterowania i wykrywania Suite są publikowane przez prywatny plik
  tymczasowy i atomową podmianę. Plugin potrafi dzięki temu zastąpić stary plik
  `0600` pozostawiony przez instalator z niewłaściwym właścicielem.
- Przed podmianą i po niej sprawdzane są katalog, właściciel, typ pliku, symlinki
  oraz tryb dostępu; sekrety nigdy nie trafiają do pliku o szerokich prawach.

## 1.5.8 — 2026-08-12

- Import konfiguracji z Huba naprawia tryb jednorazowego bootstrapu na `0600`,
  gdy Plesk rozpakował wpis ZIP z własnym `umask`. Import nadal odrzuca symlinki,
  obcego właściciela, ścieżkę spoza prywatnego `var`, zbyt duży plik oraz
  nieaktualny albo nieprawidłowy payload.

## 1.5.7 — 2026-08-12

- Hook po instalacji naprawia prawa publicznych drzew kodu `plib`, `htdocs` i
  `sbin`, jeśli instalację uruchomił proces z prywatnym `umask`. Panel Pleska
  może ponownie odczytać nazwę, akcję Open, kontroler oraz wpis menu.
- Prywatny katalog `var` i zapisane sekrety nie są objęte normalizacją i nadal
  używają praw `0700`/`0600`.

## 1.5.6 — 2026-08-12

- Inicjalizacja oraz backup/restore MinIO używają separatora kończącego
  parsowanie opcji klienta `mc`. Sekrety zaczynające się od `-` nie są już
  interpretowane jako flagi polecenia, także w operacjach uruchamianych przez
  samodzielny manager Pleska.

## 1.5.5 — 2026-08-11

- Wdrożenie uzgadnia hasło roli PostgreSQL z aktualną, szyfrowaną
  konfiguracją pluginu przed migracjami. Ponowna instalacja rozszerzenia nie
  powoduje już błędu Prisma `P1000`, gdy zachowano istniejący wolumen danych.
- Rollback przywraca również hasło oczekiwane przez poprzednie wydanie, bez
  usuwania bazy ani wolumenu.
- Dodano natywne ikony katalogu Extensions Pleska w rozmiarach 32/64/128 px.
- Poprawiono kod kategorii Pleska na `developer` oraz adresy projektu i
  zgłoszeń w metadanych paczki.

## 1.5.4 — 2026-08-11

- Wydanie naprawcze wymusza pełną aktualizację plików kontrolera WWW i hooka
  menu Pleska na serwerach, na których pozostała częściowa instalacja 1.5.2.
- Manager zachowuje kanoniczną trasę MVC oraz wpisy menu dla widoku
  administratora i trybu Power User.

## 1.5.3 — 2026-08-11

- Workspace Huba są odwzorowywane jako zarządzane organizacje podrzędne, a
  zsynchronizowane projekty i role mogą być zmieniane wyłącznie w Hubie.
- Lokalne organizacje, projekty i konta pozostają niezależne i w pełni
  edytowalne; konta federacyjne są jednoznacznie oznaczone jako Hub SSO.
- Wpis menu używa kanonicznej trasy SDK Pleska, a bootstrap przyjmuje nazwę
  nadrzędnej organizacji Suite.

## 1.5.2 — 2026-08-11

- Manager rejestruje wpis w menu przez router akcji SDK Pleska, zgodnie z
  działającymi rozszerzeniami serwera.
- Usunięto niezgodne łączenie miejsca Narzędzia i ustawienia z sekcją
  nawigacji serwera, które mogło odrzucać cały wpis menu.

## 1.5.1 — 2026-08-11

- SSO kanonizuje publiczny adres API i nigdy nie generuje `/api/api`.
- Przekierowania startu i callbacku są wysyłane jawnie jako HTTP 302, również
  na wersjach Fastify używanych przez aktualny Plesk deployment.
- Manifest Suite raportuje wersję produktu i dokładny commit wdrożenia.
- Skrót do managera używa oficjalnego bazowego URL-a Pleska i jest widoczny w
  nawigacji administratora, Power User oraz Narzędziach i ustawieniach.

## 1.5.0 — 2026-08-11

- Dodano logowanie z aktywnej sesji KitsuneHub przez jednorazowy kod i PKCE.
- Konta z Huba są tożsamościami federacyjnymi bez lokalnego hasła; niezależne
  konta Colaba nie uzyskują przez to dostępu do Huba.
- Rola i status administratora są synchronizowane przy logowaniu, a pusta
  konfiguracja organizacji tworzy tenant `kitsune-suite`.
- Bootstrap Huba przekazuje wymagane URL-e i sekret również przy automatycznej
  instalacji pluginu z repozytorium.

## 1.4.3-1 — 2026-08-11

- Automatyczny wybór i zapamiętywanie wolnych portów hosta dla PostgreSQL, Redis, MinIO, API i panelu.
- Porty danych są przekazywane do Docker Compose, dzięki czemu wdrożenie nie koliduje z usługami serwera ani KitsuneTest.

## 1.4.2-2 — 2026-08-11

- uprzywilejowany manager udostępnia ścisły tryb
  `--import-suite-bootstrap`, który ładuje SDK Pleska, inicjalizuje kontekst
  KitsuneColab i importuje oczekujący bootstrap bez zależności od zachowania
  lifecycle hooka podczas aktualizacji rozszerzenia,
- import nadal przechodzi pełną walidację czasu, produktu, praw pliku i sekretów,
  po czym odświeża profile Suite i usuwa jednorazowy plik.
- launcher managera jest oznaczony w repozytorium jako wykonywalny, więc
  instalacja nie zależy od `chmod` wykonywanego przez lifecycle hook Pleska.

## 1.4.1-1 — 2026-08-11

- dodano trwały skrypt `import-suite-bootstrap.php`, który Hub może uruchomić
  po aktualizacji niezależnie od jednorazowego lifecycle hooka Pleska,
- importer inicjalizuje kontekst KitsuneColab, zapisuje zaszyfrowane ustawienia,
  odświeża profil wykrywania i usuwa wykorzystany bootstrap.

## 1.4.0-1 — 2026-08-11

- repozytoryjna aktualizacja z Huba ponownie uzgadnia dostęp Git i wspólny
  sekret, ale zachowuje istniejące sekrety aplikacji,
- dodano rzeczywistą automatyczną konfigurację jednej domeny Pleska dla panelu,
  API i WebSocketów oraz bezpieczny rollback konfiguracji nginx,
- tryb ręczny pokazuje gotowy kod vhosta bez konfliktowego `location /`,
- techniczne ID organizacji i właściciela nie blokują pierwszego wdrożenia;
  można uzupełnić je później dla automatycznego tworzenia projektów i issue.

## 1.3.0-1 — 2026-08-09

- dodano bezpieczny, jednorazowy import konfiguracji startowej przekazanej przez
  KitsuneHub podczas instalacji pluginu z repozytorium,
- plugin publikuje chroniony profil wykrywania bez sekretów, dzięki któremu Hub
  rozpoznaje właściciela konfiguracji, repozytorium, branch i publiczny adres API,
- istniejące ustawienia i sekrety samodzielnego pluginu mają pierwszeństwo i nie
  są nadpisywane przez kolejne aktualizacje inicjowane z Huba,
- poprawiono ścieżkę uprzywilejowanego managera używaną po instalacji Pleska.

## 1.2.0-1 — 2026-08-09

- dodano niezależny plugin Plesk gotowy do opcjonalnej orkiestracji z KitsuneHub,
- dodano szyfrowaną konfigurację Kitsune Suite, manifest API i automatyczne
  tworzenie projektów połączonych z Hubem,
- nieudane przebiegi KitsuneTest mogą tworzyć idempotentne bugi w Colabie, a
  trwały outbox przekazuje ich status do Huba,
- delegowanie deployu i backupu z Huba jest domyślnie wyłączone i wymaga
  chronionego profilu `0600`,
- sekret Suite jest maskowany w logach i nie trafia do publicznego stanu.

## 1.1.0-1

- rozszerzono backup o PostgreSQL, MinIO, manifest i sumy SHA-256,
- dodano bezpieczne odtwarzanie najnowszej kopii z jawnym potwierdzeniem i healthcheckiem,
- rozdzielono stan ostatniego backupu od katalogu automatycznego rollbacku wdrożenia,
- dodano retencję kopii oraz konfigurację metryk, SMTP, limitów storage/API/pluginów i retencji danych,
- wzmocniono ochronę pliku stanu do praw `0600`.

## 1.0.0-1

- dodano panel administratora z zakładkami Stan, Operacje, Konfiguracja i Dziennik,
- dodano bezpieczne uwierzytelnianie Git HTTPS i SSH,
- dodano wdrażanie Docker Compose z migracją, healthcheckiem i automatycznym rollbackiem,
- dodano start, stop, restart oraz kopię zapasową PostgreSQL,
- dodano szyfrowane przechowywanie JWT, haseł bazy, MinIO i danych dostępowych Git,
- dodano wykrywanie wersji lokalnej, zdalnej i wdrożonej oraz stanów kontenerów.
