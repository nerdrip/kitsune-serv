<?php

pm_Context::init('kitsuneartifactory-manager');

$application = new pm_Application();
$application->run();
