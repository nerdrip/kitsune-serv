# Kitsune Artifactory Manager

Plesk administrator extension for HTTPS/SSH Git synchronization, automatic domain and nginx configuration, locked builds, Docker lifecycle management, update checks, rollback, and integrity-checked database/storage backups.
