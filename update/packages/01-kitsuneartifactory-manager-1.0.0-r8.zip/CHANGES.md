# Changelog

## 1.0.0-8 — 2026-08-21

- Added complete HTTPS/SSH Git configuration with encrypted tokens and deploy keys, automatic strict `known_hosts`, and remote revision checks.
- Added an active Plesk-domain dropdown and managed HTTPS nginx reverse proxy with safe rollback on reconfiguration failure.
- Public URL and default administrator email are derived from the selected domain; database, JWT, metrics and encryption secrets are generated automatically.
- Added automatic Plesk/system Node.js discovery and a one-time generated initial administrator password.

## 1.0.0-7 — 2026-08-21

- Corrected every Plesk SDK class prefix to `Modules_KitsuneartifactoryManager_*` so library and task autoloading works.

## 1.0.0-6 — 2026-08-21

- Fixed the Plesk entrypoint so opening the extension starts its MVC application instead of displaying a navigation placeholder.

## 1.0.0-5 — 2026-08-21

- SSH self-update now discovers and privately persists host keys on first use, then enforces strict host verification.

## 1.0.0-4 — 2026-08-21

- Standalone self-update now synchronizes and packages the configured product repository instead of reading the KitsuneServ bundle manifest.

## 1.0.0-2 — 2026-08-20

- Added the shared Kitsune Plesk Suite shell and a direct route back to central management.
- The standalone menu entry is hidden only while an active Kitsune Hub owns navigation.

## 1.0.0 — 2026-07-17

- Initial production package for Kitsune Artifactory.
- Encrypted Plesk settings for Git and application secrets.
- Serialized long-running operations with masked logs and bounded history.
- Deploy, health check, rollback, full backup, verified restore, and retention controls.
