<?php

class Modules_KitsuneartifactoryManager_Config
{
    private const SECRET_FIELDS = [
        'gitToken' => 'secret_git_token',
        'gitSshPrivateKey' => 'secret_git_ssh_private_key',
        'jwtSecret' => 'secret_jwt',
        'adminPassword' => 'secret_admin_password',
        'databasePassword' => 'secret_database_password',
        'metricsToken' => 'secret_metrics_token',
        'encryptionKey' => 'secret_encryption_key',
        's3AccessKey' => 'secret_s3_access_key',
        's3SecretKey' => 'secret_s3_secret_key',
    ];

    private const GENERATED_SECRETS = [
        'jwtSecret' => 48,
        'databasePassword' => 32,
        'metricsToken' => 32,
        'encryptionKey' => 48,
    ];

    public static function defaults()
    {
        return [
            'repositoryUrl' => 'ssh://git@git.servx.site:32785/boberski/kitsuneartifactory.git',
            'repositoryBranch' => 'main',
            'gitUsername' => 'x-access-token',
            'gitSshKnownHosts' => '',
            'installPath' => '/opt/kitsune-artifactory',
            'publicDomain' => '',
            'proxyMode' => 'managed',
            'publicUrl' => '',
            'bindAddress' => '127.0.0.1',
            'port' => '4000',
            'adminEmail' => '',
            'adminUsername' => 'admin',
            'databaseHost' => 'postgres',
            'databasePort' => '5432',
            'databaseName' => 'kitsune',
            'databaseUser' => 'kitsune',
            'storageDriver' => 'local',
            'storageLocalPath' => '/opt/kitsune-artifactory-data/storage',
            's3Endpoint' => '',
            's3Region' => 'us-east-1',
            's3Bucket' => 'kitsune-artifacts',
            'backupDir' => '/opt/kitsune-backups',
            'backupRetention' => '7',
        ];
    }

    public static function values()
    {
        $values = [];
        foreach (self::defaults() as $key => $default) $values[$key] = (string) pm_Settings::get($key, $default);
        return $values;
    }

    /** Saves configuration and returns secrets which must be shown to the administrator once. */
    public static function save(array $values)
    {
        $generated = [];
        foreach (self::defaults() as $key => $default) {
            if (array_key_exists($key, $values)) {
                $value = $key === 'gitSshKnownHosts' ? self::normalizeMultiline($values[$key]) : trim((string) $values[$key]);
                pm_Settings::set($key, $value);
            }
        }
        foreach (self::SECRET_FIELDS as $field => $setting) {
            $value = trim((string) ($values[$field] ?? ''));
            if ($field === 'gitSshPrivateKey') $value = self::normalizeMultiline($value);
            if ($value !== '') pm_Settings::setEncrypted($setting, $value);
        }
        foreach (self::GENERATED_SECRETS as $field => $bytes) {
            if (self::secret($field) === '') pm_Settings::setEncrypted(self::SECRET_FIELDS[$field], self::randomSecret($bytes));
        }
        if (self::secret('adminPassword') === '') {
            $generated['adminPassword'] = self::randomSecret(24);
            pm_Settings::setEncrypted(self::SECRET_FIELDS['adminPassword'], $generated['adminPassword']);
        }
        return $generated;
    }

    public static function discoverSshKnownHosts($repositoryUrl)
    {
        $url = trim((string) $repositoryUrl);
        $host = '';
        $port = 22;
        if (preg_match('#^git@([A-Za-z0-9.-]+):#', $url, $matches)) {
            $host = $matches[1];
        } else {
            $parts = parse_url($url);
            if (is_array($parts) && strtolower((string) ($parts['scheme'] ?? '')) === 'ssh') {
                $host = (string) ($parts['host'] ?? '');
                if (isset($parts['port'])) $port = (int) $parts['port'];
            }
        }
        if (!preg_match('/^[A-Za-z0-9.-]+$/', $host) || $port < 1 || $port > 65535) {
            throw new RuntimeException('Nieprawidłowy host lub port SSH w adresie repozytorium.');
        }
        $descriptors = [0 => ['file', '/dev/null', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
        $process = proc_open(['ssh-keyscan', '-T', '15', '-p', (string) $port, $host], $descriptors, $pipes, null, null, ['bypass_shell' => true]);
        if (!is_resource($process)) throw new RuntimeException('Nie można uruchomić ssh-keyscan.');
        $output = stream_get_contents($pipes[1]);
        $error = stream_get_contents($pipes[2]);
        fclose($pipes[1]);
        fclose($pipes[2]);
        $exitCode = proc_close($process);
        $expected = $port === 22 ? $host : '[' . $host . ']:' . $port;
        $accepted = [];
        foreach (preg_split('/\r?\n/', (string) $output) ?: [] as $line) {
            $line = trim($line);
            if (preg_match('/^([^ \t]+)[ \t]+(ssh-ed25519|ecdsa-sha2-nistp(?:256|384|521)|ssh-rsa)[ \t]+[A-Za-z0-9+\/]+={0,3}$/', $line, $match) && hash_equals($expected, $match[1])) $accepted[] = $line;
        }
        if ($exitCode !== 0 || !$accepted) throw new RuntimeException('ssh-keyscan nie zwrócił poprawnego klucza hosta' . ($error ? ': ' . mb_substr(trim($error), -300) : '.'));
        return implode("\n", array_values(array_unique($accepted)));
    }

    public static function hasSecret($field)
    {
        return self::secret($field) !== '';
    }

    public static function createRuntimeConfig($action, array $parameters = [])
    {
        $varDir = rtrim((string) pm_Context::getVarDir(), '/\\');
        if (!is_dir($varDir) && !mkdir($varDir, 0700, true) && !is_dir($varDir)) throw new RuntimeException('Cannot create the extension work directory.');
        @chmod($varDir, 0700);
        $real = realpath($varDir);
        if ($real === false) throw new RuntimeException('Cannot resolve the extension work directory.');
        $config = self::withManagedVhostPath(self::values());
        foreach (self::SECRET_FIELDS as $field => $setting) $config[$field] = self::secret($field);
        $config['action'] = (string) $action;
        $config['parameters'] = $parameters;
        $config['varDir'] = $real;
        $config['requestedAt'] = gmdate('c');
        $file = $real . '/operation-' . bin2hex(random_bytes(16)) . '.json';
        $json = json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        $previous = umask(0077);
        try {
            if ($json === false || file_put_contents($file, $json, LOCK_EX) === false) throw new RuntimeException('Cannot write the operation configuration.');
            @chmod($file, 0600);
        } finally { umask($previous); }
        return $file;
    }

    public static function state()
    {
        $file = pm_Context::getVarDir() . '/state.json';
        if (!is_file($file)) return ['updatedAt' => null, 'lastOperation' => null, 'lastSuccess' => null, 'lastError' => null, 'commit' => null, 'previousCommit' => null, 'services' => [], 'backups' => [], 'log' => []];
        $decoded = json_decode((string) file_get_contents($file), true);
        return is_array($decoded) ? $decoded : [];
    }

    private static function withManagedVhostPath(array $values)
    {
        if (($values['proxyMode'] ?? 'manual') !== 'managed') return $values;
        $name = strtolower(trim((string) ($values['publicDomain'] ?? '')));
        if ($name === '') return $values;
        try {
            $domain = pm_Domain::getByName($name);
            if (!$domain instanceof pm_Domain || !$domain->hasHosting() || !$domain->isActive() || $domain->isSuspended() || $domain->isDisabled()) throw new RuntimeException('Wybrana domena nie ma aktywnego hostingu Pleska.');
            $values['pleskVhostSystemPath'] = (string) $domain->getVhostSystemPath();
        } catch (Throwable $exception) {
            throw new RuntimeException('Nie można skonfigurować vhosta dla domeny ' . $name . '.', 0, $exception);
        }
        return $values;
    }

    private static function normalizeMultiline($value)
    {
        $value = str_replace(["\r\n", "\r"], "\n", (string) $value);
        if (strncmp($value, "\xEF\xBB\xBF", 3) === 0) $value = substr($value, 3);
        return trim($value);
    }

    private static function randomSecret($bytes)
    {
        return rtrim(strtr(base64_encode(random_bytes((int) $bytes)), '+/', '-_'), '=');
    }

    private static function secret($field)
    {
        $setting = self::SECRET_FIELDS[$field] ?? null;
        if ($setting === null) return '';
        try { return (string) pm_Settings::getDecrypted($setting); } catch (Exception $exception) { return ''; }
    }
}
