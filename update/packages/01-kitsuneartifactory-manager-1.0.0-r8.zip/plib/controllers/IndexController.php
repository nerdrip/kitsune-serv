<?php

class IndexController extends pm_Controller_Action
{
    protected $_accessLevel = 'admin';

    public function init()
    {
        parent::init();
        $this->view->pageTitle = 'Kitsune Artifactory Manager';
        $this->view->headLink()->appendStylesheet(pm_Context::getBaseUrl() . 'css/kitsune.css?v=1.0.0');
        $this->view->headLink()->appendStylesheet(pm_Context::getBaseUrl() . 'css/kitsune-platform.css?v=2');
        $this->view->headScript()->appendFile(pm_Context::getBaseUrl() . 'js/kitsune.js?v=1.0.0');
        $this->view->headScript()->appendFile(pm_Context::getBaseUrl() . 'js/kitsune-platform.js?v=2');
        $this->view->suiteProduct = 'Kitsune Artifactory Manager';
        $this->view->suiteVersion = '1.0.0-r8';
        try { $this->view->suiteHubActive = pm_Extension::getById('kitsuneserv-bridge')->isActive(); }
        catch (Throwable $exception) { $this->view->suiteHubActive = false; }
    }

    public function indexAction()
    {
        $configForm = $this->createConfigForm();
        $operationForm = $this->createOperationForm();
        if ($this->getRequest()->isPost()) {
            $post = $this->getRequest()->getPost();
            if (($post['formType'] ?? '') === 'config') $this->processConfig($configForm, $post);
            if (($post['formType'] ?? '') === 'operation') $this->processOperation($operationForm, $post);
        }
        $this->view->configForm = $configForm;
        $this->view->operationForm = $operationForm;
        $this->view->state = Modules_KitsuneartifactoryManager_Config::state();
    }

    private function createConfigForm()
    {
        $v = Modules_KitsuneartifactoryManager_Config::values();
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kitsune-config-form');
        $form->addElement('hidden', 'formType', ['value' => 'config']);

        $form->addElement('text', 'repositoryUrl', [
            'label' => 'Adres repozytorium Git', 'value' => $v['repositoryUrl'], 'required' => true,
            'description' => 'HTTPS albo SSH. Domyślnie wskazuje główne repozytorium KitsuneArtifactory.',
            'validators' => [['StringLength', true, ['min' => 5, 'max' => 1000]]],
        ]);
        $form->addElement('text', 'repositoryBranch', [
            'label' => 'Gałąź / tag', 'value' => $v['repositoryBranch'], 'required' => true,
            'validators' => [['Regex', true, ['pattern' => '/^(?![-.])(?!.*\.\.)(?!.*@\{)[A-Za-z0-9._\/-]+$/']]],
        ]);
        $form->addElement('text', 'gitUsername', [
            'label' => 'Użytkownik Git HTTPS', 'value' => $v['gitUsername'],
            'description' => 'Dla tokenu GitHub zwykle x-access-token. Przy SSH pole jest ignorowane.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 255]]],
        ]);
        $form->addElement('password', 'gitToken', [
            'label' => 'Token / hasło Git HTTPS', 'value' => '',
            'description' => Modules_KitsuneartifactoryManager_Config::hasSecret('gitToken') ? 'Token jest zaszyfrowany. Puste pole zachowa wartość.' : 'Potrzebny tylko dla prywatnego repozytorium HTTPS.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 1900]]],
        ]);
        $form->addElement('textarea', 'gitSshPrivateKey', [
            'label' => 'Prywatny klucz wdrożeniowy SSH', 'value' => '', 'rows' => 7,
            'class' => 'f-middle-size kitsune-secret-textarea',
            'description' => Modules_KitsuneartifactoryManager_Config::hasSecret('gitSshPrivateKey') ? 'Klucz jest zaszyfrowany. Puste pole zachowa wartość.' : 'Wklej deploy key tylko do odczytu, bez hasła.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 8000]]],
        ]);
        $form->addElement('textarea', 'gitSshKnownHosts', [
            'label' => 'Klucze hosta SSH', 'value' => $v['gitSshKnownHosts'], 'rows' => 4,
            'description' => 'Pozostaw puste: plugin pobierze i zapisze klucze hosta automatycznie. Weryfikacja SSH zawsze pozostaje ścisła.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 8000]]],
        ]);

        $domains = $this->domainOptions();
        $form->addElement('select', 'publicDomain', [
            'label' => 'Domena Artifactory', 'value' => $v['publicDomain'], 'required' => true,
            'multiOptions' => ['' => '— wybierz aktywną domenę Pleska —'] + $domains,
            'description' => 'Publiczny URL HTTPS, CORS i konfiguracja vhosta zostaną wyliczone automatycznie.',
        ]);
        $form->addElement('select', 'proxyMode', [
            'label' => 'Reverse proxy Pleska', 'value' => $v['proxyMode'],
            'multiOptions' => ['managed' => 'Automatycznie przez plugin', 'manual' => 'Konfiguracja ręczna'],
            'description' => 'Tryb automatyczny utrzymuje bezpieczny vhost nginx i odświeża konfigurację domeny.',
        ]);
        $form->addElement('text', 'adminEmail', [
            'label' => 'E-mail administratora', 'value' => $v['adminEmail'],
            'description' => 'Puste pole zostanie automatycznie ustawione na admin@wybrana-domena.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 254]]],
        ]);
        $form->addElement('text', 'adminUsername', [
            'label' => 'Login administratora', 'value' => $v['adminUsername'], 'required' => true,
            'validators' => [['Regex', true, ['pattern' => '/^[A-Za-z0-9._-]{2,64}$/']]],
        ]);
        $form->addElement('password', 'adminPassword', [
            'label' => 'Hasło administratora', 'value' => '',
            'description' => Modules_KitsuneartifactoryManager_Config::hasSecret('adminPassword') ? 'Hasło jest zaszyfrowane. Puste pole zachowa wartość.' : 'Puste pole wygeneruje bezpieczne hasło i pokaże je jeden raz po zapisie.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 1900]]],
        ]);

        $form->addElement('select', 'storageDriver', [
            'label' => 'Magazyn artefaktów', 'value' => $v['storageDriver'],
            'multiOptions' => ['local' => 'Lokalny trwały wolumen', 's3' => 'S3 / MinIO'],
        ]);
        foreach ([
            'storageLocalPath' => ['Ścieżka lokalnego magazynu', true],
            's3Endpoint' => ['Endpoint S3 (opcjonalny)', false],
            's3Region' => ['Region S3', true],
            's3Bucket' => ['Bucket S3', true],
        ] as $name => $definition) {
            $form->addElement('text', $name, ['label' => $definition[0], 'value' => $v[$name], 'required' => $definition[1], 'validators' => [['StringLength', true, ['min' => $definition[1] ? 1 : 0, 'max' => 1000]]]]);
        }
        foreach (['s3AccessKey' => 'Klucz dostępu S3', 's3SecretKey' => 'Sekretny klucz S3'] as $name => $label) {
            $form->addElement('password', $name, [
                'label' => $label, 'value' => '',
                'description' => Modules_KitsuneartifactoryManager_Config::hasSecret($name) ? 'Wartość jest zaszyfrowana. Puste pole zachowa ją.' : 'Wymagane tylko przy magazynie S3.',
                'validators' => [['StringLength', true, ['min' => 0, 'max' => 1900]]],
            ]);
        }

        foreach ([
            'installPath' => ['Katalog instalacji', '#^/(?:opt|srv|var/www/vhosts)/[A-Za-z0-9._/-]+$#'],
            'backupDir' => ['Katalog kopii', '#^/(?:opt|srv|var/www/vhosts)/[A-Za-z0-9._/-]+$#'],
            'bindAddress' => ['Adres nasłuchu', '/^127\.0\.0\.1$/'],
            'port' => ['Port aplikacji', '/^[0-9]{1,5}$/'],
            'backupRetention' => ['Liczba kopii', '/^[0-9]{1,3}$/'],
        ] as $name => $definition) {
            $form->addElement('text', $name, ['label' => $definition[0], 'value' => $v[$name], 'required' => true, 'validators' => [['Regex', true, ['pattern' => $definition[1]]]]]);
        }
        $form->addElement('submit', 'save', ['label' => 'Zapisz bezpieczną konfigurację']);
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function createOperationForm()
    {
        $state = Modules_KitsuneartifactoryManager_Config::state();
        $backups = ['' => 'Wybierz kopię'];
        foreach (($state['backups'] ?? []) as $backup) if (!empty($backup['name'])) $backups[$backup['name']] = $backup['name'] . ' (' . (string) ($backup['size'] ?? 0) . ' B)';
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kitsune-operation-form');
        $form->addElement('hidden', 'formType', ['value' => 'operation']);
        $form->addElement('select', 'operation', [
            'label' => 'Operacja', 'value' => 'status', 'required' => true,
            'multiOptions' => [
                'status' => 'Sprawdź stan usług', 'check' => 'Sprawdź repozytorium i aktualizacje', 'sync' => 'Pobierz najnowszy kod z Git', 'install' => 'Zainstaluj zależności',
                'build' => 'Zbuduj artefakty produkcyjne', 'migrate' => 'Wykonaj migracje bazy', 'seed' => 'Wykonaj idempotentny seed',
                'deploy' => 'Pobierz i wdróż', 'redeploy' => 'Ponownie wdróż lokalny kod', 'start' => 'Uruchom usługi',
                'stop' => 'Zatrzymaj usługi', 'restart' => 'Uruchom ponownie', 'healthcheck' => 'Test zdrowia',
                'logs' => 'Pobierz ostatnie logi', 'backup' => 'Utwórz zweryfikowaną kopię', 'restore' => 'Odtwórz kopię',
                'rollback' => 'Wróć do poprzedniego commita',
            ],
        ]);
        $form->addElement('select', 'backup', ['label' => 'Kopia do odtworzenia', 'multiOptions' => $backups, 'decorators' => [['ViewHelper'], ['Description'], ['HtmlTag', ['tag' => 'div', 'data-backup-select' => '1']]]]);
        $form->addElement('text', 'confirmation', ['label' => 'Potwierdzenie', 'description' => 'Dla odtwarzania wpisz dokładnie RESTORE.', 'decorators' => [['ViewHelper'], ['Description'], ['HtmlTag', ['tag' => 'div', 'data-restore-confirm' => '1']]]]);
        $form->addElement('submit', 'run', ['label' => 'Uruchom operację']);
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function processConfig(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) return;
        $values = $form->getValues();
        $url = trim((string) ($values['repositoryUrl'] ?? ''));
        if (!preg_match('#^(https://[^\s]+|ssh://[^\s]+|git@[A-Za-z0-9._-]+:[^\s]+)$#i', $url)) return $this->reject($form, 'repositoryUrl', 'Adres repozytorium musi używać HTTPS albo SSH.');
        $domain = strtolower(trim((string) ($values['publicDomain'] ?? '')));
        if (!isset($this->domainOptions()[$domain])) return $this->reject($form, 'publicDomain', 'Wybierz aktywną domenę z listy Pleska.');
        $values['publicDomain'] = $domain;
        $values['publicUrl'] = 'https://' . $domain;
        if (trim((string) ($values['adminEmail'] ?? '')) === '') $values['adminEmail'] = 'admin@' . $domain;
        if (!filter_var((string) $values['adminEmail'], FILTER_VALIDATE_EMAIL)) return $this->reject($form, 'adminEmail', 'Podaj poprawny adres e-mail.');
        if ((int) $values['port'] < 1 || (int) $values['port'] > 65535) return $this->reject($form, 'port', 'Port musi mieścić się w zakresie 1–65535.');
        if ((int) $values['backupRetention'] < 1 || (int) $values['backupRetention'] > 365) return $this->reject($form, 'backupRetention', 'Liczba kopii musi mieścić się w zakresie 1–365.');
        $privateKey = trim((string) ($values['gitSshPrivateKey'] ?? ''));
        if ($privateKey !== '' && !preg_match('/^-----BEGIN (OPENSSH|RSA|EC|DSA) PRIVATE KEY-----[\s\S]+-----END \1 PRIVATE KEY-----$/', str_replace(["\r\n", "\r"], "\n", $privateKey))) {
            return $this->reject($form, 'gitSshPrivateKey', 'Wklej pełny prywatny klucz SSH w formacie OpenSSH/PEM.');
        }
        $usesSsh = preg_match('#^(ssh://|git@)#i', $url) === 1;
        if ($usesSsh && $privateKey === '' && !Modules_KitsuneartifactoryManager_Config::hasSecret('gitSshPrivateKey')) return $this->reject($form, 'gitSshPrivateKey', 'Prywatne repozytorium SSH wymaga deploy key.');
        if ($usesSsh && trim((string) ($values['gitSshKnownHosts'] ?? '')) === '') {
            try { $values['gitSshKnownHosts'] = Modules_KitsuneartifactoryManager_Config::discoverSshKnownHosts($url); }
            catch (Throwable $exception) { return $this->reject($form, 'gitSshKnownHosts', 'Nie udało się automatycznie zapisać klucza hosta: ' . $exception->getMessage()); }
        }
        if (($values['storageDriver'] ?? '') === 's3') {
            foreach (['s3AccessKey', 's3SecretKey'] as $field) {
                if (trim((string) ($values[$field] ?? '')) === '' && !Modules_KitsuneartifactoryManager_Config::hasSecret($field)) return $this->reject($form, $field, 'Magazyn S3 wymaga zapisania tego klucza.');
            }
        }
        $generated = Modules_KitsuneartifactoryManager_Config::save($values);
        $message = 'Konfiguracja została zapisana. URL, proxy Pleska, known_hosts oraz sekrety techniczne skonfigurowano automatycznie.';
        if (!empty($generated['adminPassword'])) $message .= ' Jednorazowe hasło administratora (skopiuj teraz): ' . $generated['adminPassword'];
        $this->_status->addMessage('info', $message);
        $this->_helper->redirector('index');
    }

    private function processOperation(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) return;
        $operation = (string) $form->getValue('operation');
        $allowed = ['status', 'check', 'sync', 'install', 'build', 'migrate', 'seed', 'deploy', 'redeploy', 'start', 'stop', 'restart', 'healthcheck', 'logs', 'backup', 'restore', 'rollback'];
        if (!in_array($operation, $allowed, true)) throw new InvalidArgumentException('Unknown operation.');
        $parameters = [];
        if ($operation === 'restore') {
            if ((string) $form->getValue('confirmation') !== 'RESTORE') return $this->reject($form, 'confirmation', 'Odtwarzanie wymaga dokładnego potwierdzenia RESTORE.');
            $parameters['confirmation'] = 'RESTORE';
            $parameters['backup'] = basename((string) $form->getValue('backup'));
            if ($parameters['backup'] === '') return $this->reject($form, 'backup', 'Wybierz kopię z listy.');
        }
        $runtime = Modules_KitsuneartifactoryManager_Config::createRuntimeConfig($operation, $parameters);
        $task = new Modules_KitsuneartifactoryManager_Task_Operation();
        $task->setParam('runtimeConfig', $runtime);
        (new pm_LongTask_Manager())->start($task);
        $this->_status->addMessage('info', 'Operacja została dodana do bezpiecznej kolejki Pleska.');
        $this->_helper->redirector('index');
    }

    private function domainOptions()
    {
        $options = [];
        try {
            foreach ((array) pm_Domain::getAllDomains() as $domain) {
                if (!$domain instanceof pm_Domain || !$domain->hasHosting() || !$domain->isActive() || $domain->isSuspended() || $domain->isDisabled()) continue;
                $name = strtolower(trim((string) $domain->getName()));
                if (preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/', $name)) $options[$name] = $name;
            }
        } catch (Throwable $exception) { /* Plesk exposes no active hosting domains yet. */ }
        natcasesort($options);
        return $options;
    }

    private function reject(pm_Form_Simple $form, $field, $message)
    {
        $element = $form->getElement($field);
        if ($element) $element->addError($message);
        $this->_status->addMessage('error', $message);
        return null;
    }
}
