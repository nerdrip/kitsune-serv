<?php
class Modules_KitsuneartifactoryManager_LongTasks extends pm_Hook_LongTasks
{
    public function getLongTasks() { return [new Modules_KitsuneartifactoryManager_Task_Operation()]; }
}
