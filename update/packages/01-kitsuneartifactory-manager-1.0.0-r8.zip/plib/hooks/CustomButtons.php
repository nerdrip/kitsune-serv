<?php
class Modules_KitsuneartifactoryManager_CustomButtons extends pm_Hook_CustomButtons
{
    public function getButtons()
    {
        if ($this->hubOwnsNavigation()) return [];
        return [[
            'place' => [self::PLACE_ADMIN_NAVIGATION, self::PLACE_HOSTING_PANEL_NAVIGATION],
            'section' => self::SECTION_NAV_SERVER_MANAGEMENT,
            'order' => 50,
            'title' => 'Kitsune Artifactory',
            'description' => 'Deploy and operate Kitsune Artifactory',
            'icon' => pm_Context::getBaseUrl() . 'images/kitsuneartifactory-menu.svg',
            'link' => pm_Context::getActionUrl('index', 'index'),
            'newWindow' => false,
        ]];
    }

    private function hubOwnsNavigation()
    {
        try { return pm_Extension::getById('kitsuneserv-bridge')->isActive(); }
        catch (Throwable $exception) { return false; }
    }
}
