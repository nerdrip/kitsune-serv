<?php

class Modules_KitsunetabManager_Config
{
    const EXTENSION_VERSION = '0.4.0';
    const EXTENSION_RELEASE = '4';
    private static $secretKeys = ['gitToken', 'gitSshPrivateKey', 'jwtSecret', 'bootstrapAdminPassword'];

    public static function defaults()
    {
        return [
            'repositoryUrl' => '',
            'repositoryBranch' => 'main',
            'repositoryPath' => '/opt/kitsunetab/source',
            'deployPath' => '/opt/kitsunetab/source/deploy',
            'dataPath' => '/var/lib/kitsunetab',
            'backupPath' => '/var/backups/kitsunetab',
            'backupMirrorPath' => '',
            'backupKeep' => '14',
            'backupIntervalHours' => '24',
            'snapshotDays' => '90',
            'snapshotLimit' => '500',
            'rateLimitMax' => '300',
            'memoryLimit' => '512m',
            'cpuLimit' => '1.0',
            'proxyMode' => 'managed',
            'domain' => '',
            'publicUrl' => '',
            'httpPort' => '13210',
            'adminEmails' => '',
            'registrationEnabled' => 'true',
            'bootstrapAdminEnabled' => 'false',
            'bootstrapAdminEmail' => '',
            'bootstrapAdminDisplayName' => 'Administrator',
            'gitUsername' => '',
            'gitSshKnownHosts' => '',
            'corsOrigins' => 'chrome-extension://*,moz-extension://*',
        ];
    }

    public static function values()
    {
        $values = [];
        foreach (self::defaults() as $key => $default) {
            $stored = pm_Settings::get($key);
            $values[$key] = $stored === null ? $default : (string) $stored;
        }
        return $values;
    }

    public static function save(array $values)
    {
        foreach (self::defaults() as $key => $default) {
            if (!array_key_exists($key, $values)) continue;
            $value = trim((string) $values[$key]);
            if ($key === 'gitSshKnownHosts') $value = str_replace(["\r\n", "\r"], "\n", $value);
            pm_Settings::set($key, $value);
        }
        foreach (self::$secretKeys as $key) {
            $value = trim((string) ($values[$key] ?? ''));
            if ($key === 'gitSshPrivateKey') $value = str_replace(["\r\n", "\r"], "\n", $value);
            if ($value !== '') pm_Settings::setEncrypted($key, $value);
        }
    }

    public static function hasSecret($key)
    {
        try { return trim((string) pm_Settings::getDecrypted($key)) !== ''; }
        catch (Throwable $exception) { return false; }
    }

    public static function ensureJwtSecret()
    {
        $secret = self::getSecret('jwtSecret');
        if (strlen($secret) >= 32) return $secret;
        $secret = rtrim(strtr(base64_encode(random_bytes(48)), '+/', '-_'), '=');
        pm_Settings::setEncrypted('jwtSecret', $secret);
        return $secret;
    }

    private static function getSecret($key)
    {
        try { return (string) pm_Settings::getDecrypted($key); }
        catch (Throwable $exception) { return ''; }
    }

    public static function statePath()
    {
        return pm_Context::getVarDir() . '/state.json';
    }

    public static function readState()
    {
        $path = self::statePath();
        $empty = [
            'updatedAt' => null, 'lastOperation' => null, 'lastSuccess' => null, 'lastError' => null,
            'repository' => [], 'deployment' => [], 'services' => [], 'docker' => [], 'readiness' => [],
            'proxy' => [], 'data' => [], 'backups' => [], 'backupMirror' => [], 'bootstrapAdmin' => [], 'statusErrors' => [], 'log' => [],
        ];
        if (!is_file($path)) return $empty;
        $decoded = json_decode((string) file_get_contents($path), true);
        return is_array($decoded) ? array_replace($empty, $decoded) : $empty;
    }

    public static function createRuntimeConfig($operation, array $extra = [])
    {
        $allowed = ['status', 'check', 'sync', 'deploy', 'sync-deploy', 'restart', 'start', 'stop', 'backup', 'restore'];
        if (!in_array((string) $operation, $allowed, true)) throw new RuntimeException('Nieznana operacja KitsuneTab.');
        $varDir = pm_Context::getVarDir();
        if (!is_dir($varDir) && !mkdir($varDir, 0700, true)) throw new RuntimeException('Nie można utworzyć katalogu roboczego rozszerzenia.');
        @chmod($varDir, 0700);
        $resolved = realpath($varDir);
        if ($resolved === false) throw new RuntimeException('Nie można rozwiązać katalogu roboczego rozszerzenia.');
        $varDir = $resolved;
        $values = self::values();
        if (in_array((string) $operation, ['deploy', 'sync-deploy', 'start'], true)) self::assertHostedDomain($values['domain']);
        $config = array_merge($values, [
            'operation' => (string) $operation,
            'gitToken' => self::getSecret('gitToken'),
            'gitSshPrivateKey' => self::getSecret('gitSshPrivateKey'),
            'jwtSecret' => self::ensureJwtSecret(),
            'bootstrapAdminPassword' => self::getSecret('bootstrapAdminPassword'),
            'statePath' => self::statePath(),
        ], $extra);
        $path = $varDir . '/operation-' . bin2hex(random_bytes(12)) . '.json';
        $json = json_encode($config, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($json === false || file_put_contents($path, $json, LOCK_EX) === false) throw new RuntimeException('Nie można zapisać konfiguracji operacji.');
        @chmod($path, 0600);
        return $path;
    }

    public static function assertHostedDomain($name)
    {
        $name = strtolower(trim((string) $name));
        try { $domain = pm_Domain::getByName($name); }
        catch (Throwable $exception) { throw new RuntimeException('Wybrana domena Pleska jest niedostępna: ' . $name, 0, $exception); }
        if (!$domain instanceof pm_Domain || !$domain->hasHosting() || !$domain->isActive() || $domain->isSuspended() || $domain->isDisabled()) {
            throw new RuntimeException('Wybrana domena musi być aktywna i mieć hosting WWW: ' . $name . '.');
        }
        return $domain;
    }
}
