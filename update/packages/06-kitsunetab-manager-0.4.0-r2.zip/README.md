# KitsuneTab Deployment Manager 0.4.0

Wymagania: Plesk Obsidian 18.0.41+ na Linuksie, Git, klient OpenSSH,
Docker Engine z Compose v2,
domena z aktywnym hostingiem i certyfikatem TLS oraz dostęp administratora Pleska.

Paczka instalacyjna ma `meta.xml` w katalogu głównym:

```bash
plesk bin extension -i KitsuneTab-Plesk-Manager-0.4.0-YYYYMMDD-HHMMSS.zip
```

Panel jest podzielony na pięć zakładek: stan systemu, wdrożenie, konfigurację,
dane i backup oraz dziennik. Pokazuje oddzielnie kontener API i automat backupów,
readiness bazy, wersje Docker/Compose, lokalny i zdalny commit, konfigurację proxy,
rozmiar bazy oraz wynik weryfikacji każdej kopii.

Repozytorium prywatne może używać tokenu HTTPS albo klucza SSH deploy. Klucz
prywatny jest szyfrowany przez Pleska, zapisywany do pliku `0600` tylko na czas
polecenia Git i sprawdzany przez `ssh-keygen`. Dla SSH można opcjonalnie przypiąć
wcześniej zweryfikowany wpis `known_hosts`; gdy pole pozostanie puste, używany jest
systemowy magazyn hostów. Manager zawsze włącza ścisłą kontrolę klucza hosta.

W konfiguracji podaj repozytorium, gałąź, domenę i katalogi. Kod może znajdować się np.
w `/opt/kitsunetab/source`, ale dane (`/var/lib/kitsunetab`) i backupy
(`/var/backups/kitsunetab`) muszą być poza repozytorium. Manager publikuje
kontener tylko na `127.0.0.1` i dodaje oznaczony blok reverse proxy do konfiguracji
nginx domeny. W przypadku błędu konfiguracja nginx jest automatycznie cofana.

Alternatywny tryb ręcznego vhosta nie zapisuje nic w konfiguracji domeny. Panel
generuje kompletny, kopiowalny blok dla `vhost_nginx.conf` / pola „Dodatkowe
dyrektywy nginx” z aktualną domeną i portem. Po ręcznym wklejeniu konfiguracji
manager wykrywa jej oznaczony blok podczas odświeżania stanu.

Z panelu można również ustawić limity RAM i CPU, retencję migawek sesji, limit
migawek na konto i rate limit API. Formularz sprawdza konfigurację w przeglądarce
i ponownie po stronie Pleska, zanim zapisze ustawienia.

Opcjonalny bootstrap pierwszego administratora działa przed publicznym uruchomieniem
kontenerów. Tworzy konto i przestrzeń Inbox wyłącznie w pustej bazie. Nie nadpisuje
istniejącego hasła, a gdy baza zawiera inne konta, bezpiecznie pomija operację.
Hasło pozostaje zaszyfrowane w Plesku; jednorazowy plik wejściowy jest montowany
tylko w katalogu danych i usuwany natychmiast po wykonaniu. Po utworzeniu konta przełącz „Publiczna rejestracja kont”
na „Wyłączona” i ponownie wdróż albo uruchom usługę; API wymusi blokadę rejestracji,
a panel WWW usunie przycisk zakładania konta.

Panel pozwala też utworzyć backup online oraz przywrócić wskazaną kopię. Restore
wymaga zaznaczenia potwierdzenia, sprawdza manifest i sumę SHA-256, tworzy kopię
bezpieczeństwa, zatrzymuje usługę i atomowo podmienia bazę przed health checkiem.
Nieudany healthcheck automatycznie przywraca lokalną bazę sprzed operacji. Interwał
automatycznych backupów i retencję ustawia się bezpośrednio w panelu.

Opcjonalne pole „Drugi cel backupów” przyjmuje niezależny katalog pod `/mnt`,
`/media`, `/srv`, `/home`, `/opt`, `/var/lib` albo `/var/backups`. Może to być
zamontowany dysk, NFS lub storage dostawcy. Po wykonaniu lokalnej kopii manager
sprawdza SQLite `quick_check`, rozmiar i SHA-256, kopiuje oba pliki do katalogu
tymczasowego drugiego celu, weryfikuje je ponownie i dopiero wtedy publikuje kopię
atomowym `rename`. Oba miejsca używają tej samej retencji.

Przed aktualizacją manager zachowuje identyfikator działającego obrazu oraz
poprzednie środowisko Compose. Jeżeli nowy kontener nie przejdzie readiness,
poprzedni obraz jest ponownie tagowany, kontenery są odtwarzane z wymuszeniem, a panel
zapisuje wynik rollbacku wraz z przyczyną nieudanego wdrożenia.

Sekrety Git i JWT są przechowywane przez `pm_Settings::setEncrypted`. Token Git
nie trafia do adresu repozytorium ani argumentów procesu. Aktualizacja używa
wyłącznie `merge --ff-only` i zatrzymuje się, jeśli lokalna kopia ma zmiany.
JWT secret jest generowany automatycznie z 48 losowych bajtów podczas instalacji
lub pierwszego uruchomienia i nie wymaga ręcznego kopiowania do formularza.

Usunięcie rozszerzenia nie usuwa kontenerów, danych, backupów ani repozytorium.
