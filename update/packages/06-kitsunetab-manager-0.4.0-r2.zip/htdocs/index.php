<?php

pm_Context::init('kitsunetab-manager');
$application = new pm_Application();
$application->run();

