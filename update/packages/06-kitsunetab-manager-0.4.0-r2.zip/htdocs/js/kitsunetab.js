(function () {
  'use strict';

  var tabStorageKey = 'kitsunetab-manager-tab';

  function one(selector, root) {
    return (root || document).querySelector(selector);
  }

  function all(selector, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(selector));
  }

  function value(form, name) {
    var field = one('[name="' + name + '"]', form);
    return field ? String(field.value || '').trim() : '';
  }

  function rememberTab(name) {
    try { window.sessionStorage.setItem(tabStorageKey, name); } catch (error) {}
  }

  function activateTab(shell, name, focus) {
    var target = one('[data-ktm-tab="' + name + '"]', shell);
    if (!target) return;
    all('[data-ktm-tab]', shell).forEach(function (tab) {
      var selected = tab === target;
      tab.classList.toggle('is-active', selected);
      tab.setAttribute('aria-selected', selected ? 'true' : 'false');
      tab.setAttribute('tabindex', selected ? '0' : '-1');
    });
    all('[data-ktm-panel]', shell).forEach(function (panel) {
      var selected = panel.getAttribute('data-ktm-panel') === name;
      panel.classList.toggle('is-active', selected);
      panel.hidden = !selected;
    });
    rememberTab(name);
    if (focus) target.focus();
  }

  function initTabs(shell) {
    var tabs = all('[data-ktm-tab]', shell);
    if (!tabs.length) return;
    var requested = shell.getAttribute('data-ktm-active-tab');
    var remembered = '';
    try { remembered = window.sessionStorage.getItem(tabStorageKey) || ''; } catch (error) {}
    activateTab(shell, requested || remembered || 'status', false);
    tabs.forEach(function (tab, index) {
      tab.addEventListener('click', function () {
        activateTab(shell, tab.getAttribute('data-ktm-tab'), false);
      });
      tab.addEventListener('keydown', function (event) {
        var next = null;
        if (event.key === 'ArrowRight') next = (index + 1) % tabs.length;
        if (event.key === 'ArrowLeft') next = (index + tabs.length - 1) % tabs.length;
        if (event.key === 'Home') next = 0;
        if (event.key === 'End') next = tabs.length - 1;
        if (next === null) return;
        event.preventDefault();
        activateTab(shell, tabs[next].getAttribute('data-ktm-tab'), true);
      });
    });
  }

  function updateButton(select, button, labels) {
    if (!select || !button) return;
    button.textContent = labels[select.value] || 'Uruchom operację';
  }

  function initOperationForm() {
    var form = document.getElementById('ktm-operation-form');
    if (!form) return;
    var select = one('[name="operation"]', form);
    var button = document.getElementById('ktm-operation-submit');
    var labels = {
      check: 'Sprawdź repozytorium',
      sync: 'Pobierz kod',
      deploy: 'Wdróż obecną wersję',
      'sync-deploy': 'Pobierz i wdróż'
    };
    function refresh() { updateButton(select, button, labels); }
    select.addEventListener('change', refresh);
    refresh();
    form.addEventListener('submit', function (event) {
      if (select.value === 'deploy' || select.value === 'sync-deploy') {
        var label = select.options[select.selectedIndex].text;
        if (!window.confirm('Uruchomić „' + label + '”? Przed przebudową zostanie utworzony backup bezpieczeństwa.')) event.preventDefault();
      }
    });
  }

  function initServiceForm() {
    var form = document.getElementById('ktm-service-form');
    if (!form) return;
    var select = one('[name="serviceOperation"]', form);
    var button = document.getElementById('ktm-service-submit');
    var labels = { start: 'Uruchom usługi', restart: 'Uruchom ponownie API', stop: 'Zatrzymaj cały stos' };
    function refresh() { updateButton(select, button, labels); }
    select.addEventListener('change', refresh);
    refresh();
    form.addEventListener('submit', function (event) {
      if ((select.value === 'restart' || select.value === 'stop') && !window.confirm(labels[select.value] + '?')) event.preventDefault();
    });
  }

  function setRestoreVisibility(form) {
    var operation = one('[name="maintenanceOperation"]', form);
    var backup = one('[name="backupName"]', form);
    var confirm = one('[name="confirmRestore"]', form);
    var button = document.getElementById('ktm-maintenance-submit');
    var restoring = operation && operation.value === 'restore';
    [backup, confirm].forEach(function (field) {
      if (!field) return;
      var row = field.closest('.form-row') || field.parentElement;
      if (row) row.hidden = !restoring;
      field.disabled = !restoring;
    });
    if (button) button.textContent = restoring ? 'Przywróć wybrany backup' : 'Utwórz backup online';
  }

  function initMaintenanceForm() {
    var form = document.getElementById('ktm-maintenance-form');
    if (!form) return;
    var operation = one('[name="maintenanceOperation"]', form);
    operation.addEventListener('change', function () { setRestoreVisibility(form); });
    setRestoreVisibility(form);
    form.addEventListener('submit', function (event) {
      if (operation.value !== 'restore') return;
      var backup = value(form, 'backupName');
      var confirmed = one('[name="confirmRestore"]', form);
      if (!backup) {
        event.preventDefault();
        window.alert('Najpierw wybierz backup do przywrócenia.');
        return;
      }
      if (!confirmed || !confirmed.checked) {
        event.preventDefault();
        window.alert('Zaznacz jawne potwierdzenie przywrócenia bazy.');
        return;
      }
      if (!window.confirm('Przywrócić backup „' + backup + '”? Bieżąca baza zostanie zastąpiona po wykonaniu kopii bezpieczeństwa.')) event.preventDefault();
    });
  }

  function clearErrors(form, summary) {
    all('.client-invalid', form).forEach(function (field) { field.classList.remove('client-invalid'); });
    all('.ktm-field-error', form).forEach(function (error) { error.remove(); });
    if (summary) {
      summary.hidden = true;
      summary.innerHTML = '';
    }
  }

  function addError(form, errors, name, message) {
    if (!errors[name]) errors[name] = [];
    errors[name].push(message);
    var field = one('[name="' + name + '"]', form);
    if (!field || field.classList.contains('client-invalid')) return;
    field.classList.add('client-invalid');
    var note = document.createElement('span');
    note.className = 'ktm-field-error';
    note.textContent = message;
    field.insertAdjacentElement('afterend', note);
  }

  function normalizePath(path) {
    return path.replace(/\/+$/, '');
  }

  function validSafePath(path) {
    return /^\/(?:home|mnt|media|opt|srv|var\/lib|var\/backups)\/[A-Za-z0-9._/-]+$/.test(path) && path.split('/').indexOf('..') === -1;
  }

  function validateConfig(form) {
    var summary = one('[data-ktm-config-errors]');
    clearErrors(form, summary);
    var errors = {};
    var repositoryUrl = value(form, 'repositoryUrl');
    var branch = value(form, 'repositoryBranch');
    var repository = normalizePath(value(form, 'repositoryPath'));
    var deploy = normalizePath(value(form, 'deployPath'));
    var data = normalizePath(value(form, 'dataPath'));
    var backup = normalizePath(value(form, 'backupPath'));
    var mirror = normalizePath(value(form, 'backupMirrorPath'));
    var domain = value(form, 'domain').toLowerCase();
    var publicUrl = value(form, 'publicUrl').replace(/\/+$/, '');
    var proxyMode = value(form, 'proxyMode');

    if (!/^(https:\/\/|ssh:\/\/|git@)/.test(repositoryUrl)) addError(form, errors, 'repositoryUrl', 'Użyj adresu HTTPS lub SSH.');
    if (!/^(?![-.])(?!.*\.\.)(?!.*@\{)[A-Za-z0-9._/-]+$/.test(branch)) addError(form, errors, 'repositoryBranch', 'Nazwa gałęzi jest nieprawidłowa.');
    ['repositoryPath', 'deployPath', 'dataPath', 'backupPath'].forEach(function (name) {
      if (!validSafePath(normalizePath(value(form, name)))) addError(form, errors, name, 'Podaj bezpieczną ścieżkę bezwzględną.');
    });
    if (mirror && !validSafePath(mirror)) addError(form, errors, 'backupMirrorPath', 'Podaj bezpieczną ścieżkę bezwzględną.');
    if (deploy !== repository + '/deploy') addError(form, errors, 'deployPath', 'Katalog Compose musi być równy katalogowi kodu z /deploy.');
    if (data === repository || data.indexOf(repository + '/') === 0) addError(form, errors, 'dataPath', 'Dane muszą znajdować się poza repozytorium.');
    if (backup === repository || backup.indexOf(repository + '/') === 0) addError(form, errors, 'backupPath', 'Backupy muszą znajdować się poza repozytorium.');
    if (mirror) {
      [repository, data, backup].forEach(function (reserved) {
        if (mirror === reserved || mirror.indexOf(reserved + '/') === 0 || reserved.indexOf(mirror + '/') === 0) addError(form, errors, 'backupMirrorPath', 'Drugi cel musi być niezależnym katalogiem.');
      });
    }
    if (!/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(domain)) addError(form, errors, 'domain', 'Wybierz prawidłową domenę.');
    if (publicUrl !== 'https://' + domain) addError(form, errors, 'publicUrl', 'URL musi mieć postać https://' + domain + '.');
    if (['managed', 'manual'].indexOf(proxyMode) === -1) addError(form, errors, 'proxyMode', 'Wybierz automatyczny albo ręczny vhost.');

    var ranges = {
      httpPort: [1024, 65535],
      backupKeep: [1, 365],
      backupIntervalHours: [1, 168],
      snapshotDays: [1, 3650],
      snapshotLimit: [10, 10000],
      rateLimitMax: [10, 100000]
    };
    Object.keys(ranges).forEach(function (name) {
      var raw = value(form, name);
      var number = Number(raw);
      if (!/^\d+$/.test(raw) || number < ranges[name][0] || number > ranges[name][1]) addError(form, errors, name, 'Dozwolony zakres: ' + ranges[name][0] + '–' + ranges[name][1] + '.');
    });
    if (!/^\d+(?:\.\d+)?[kKmMgG]?$/.test(value(form, 'memoryLimit'))) addError(form, errors, 'memoryLimit', 'Użyj np. 512m albo 1g.');
    var cpu = Number(value(form, 'cpuLimit'));
    if (!Number.isFinite(cpu) || cpu <= 0 || cpu > 64) addError(form, errors, 'cpuLimit', 'Wpisz liczbę od 0 do 64.');

    value(form, 'adminEmails').split(',').map(function (item) { return item.trim(); }).filter(Boolean).forEach(function (email) {
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) addError(form, errors, 'adminEmails', 'Nieprawidłowy adres: ' + email + '.');
    });
    value(form, 'corsOrigins').split(',').map(function (item) { return item.trim(); }).filter(Boolean).forEach(function (origin) {
      if (!/^(?:https?:\/\/[^\s,]+|chrome-extension:\/\/\*|moz-extension:\/\/\*)$/.test(origin)) addError(form, errors, 'corsOrigins', 'Nieprawidłowe źródło: ' + origin + '.');
    });
    var sshKey = value(form, 'gitSshPrivateKey');
    var shell = form.closest('.ktm-shell');
    if (sshKey && sshKey.indexOf('PRIVATE KEY') === -1) addError(form, errors, 'gitSshPrivateKey', 'Wklej prywatny klucz PEM/OpenSSH.');

    if (value(form, 'bootstrapAdminEnabled') === 'true') {
      var bootstrapEmail = value(form, 'bootstrapAdminEmail');
      var bootstrapName = value(form, 'bootstrapAdminDisplayName');
      var bootstrapPassword = value(form, 'bootstrapAdminPassword');
      var hasSavedPassword = shell && shell.getAttribute('data-ktm-has-bootstrap-password') === '1';
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(bootstrapEmail)) addError(form, errors, 'bootstrapAdminEmail', 'Podaj prawidłowy e-mail administratora.');
      if (!bootstrapName || bootstrapName.length > 120) addError(form, errors, 'bootstrapAdminDisplayName', 'Nazwa musi mieć od 1 do 120 znaków.');
      if (bootstrapPassword && (bootstrapPassword.length < 10 || bootstrapPassword.length > 256)) addError(form, errors, 'bootstrapAdminPassword', 'Hasło musi mieć od 10 do 256 znaków.');
      if (!bootstrapPassword && !hasSavedPassword) addError(form, errors, 'bootstrapAdminPassword', 'Ustaw hasło pierwszego administratora.');
    }

    var names = Object.keys(errors);
    if (!names.length) return true;
    if (summary) {
      summary.hidden = false;
      summary.innerHTML = '<strong>Popraw ' + names.length + ' ' + (names.length === 1 ? 'pole' : 'pola') + ' przed zapisem.</strong>';
    }
    var first = one('.client-invalid', form);
    if (first) first.focus();
    return false;
  }

  function setBootstrapVisibility(form) {
    var enabled = value(form, 'bootstrapAdminEnabled') === 'true';
    ['bootstrapAdminEmail', 'bootstrapAdminDisplayName', 'bootstrapAdminPassword'].forEach(function (name) {
      var field = one('[name="' + name + '"]', form);
      var row = field && field.closest('.form-row');
      if (row) row.hidden = !enabled;
    });
    var card = one('[data-ktm-bootstrap-card]');
    if (card) {
      card.hidden = !enabled;
      var email = one('[data-ktm-bootstrap-email]', card);
      if (email && value(form, 'bootstrapAdminEmail')) email.textContent = value(form, 'bootstrapAdminEmail').toLowerCase();
    }
  }

  function manualVhostBlock(port) {
    var upstream = 'http://127.0.0.1:' + port;
    return [
      '# BEGIN KITSUNETAB MANUAL REVERSE PROXY',
      'location ~ ^/.* {',
      '    proxy_pass ' + upstream + ';',
      '    proxy_http_version 1.1;',
      '    proxy_set_header Host $host;',
      '    proxy_set_header X-Real-IP $remote_addr;',
      '    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;',
      '    proxy_set_header X-Forwarded-Proto $scheme;',
      '    proxy_set_header Upgrade $http_upgrade;',
      '    proxy_set_header Connection "upgrade";',
      '    proxy_connect_timeout 10s;',
      '    proxy_read_timeout 300s;',
      '    proxy_send_timeout 300s;',
      '    proxy_buffering off;',
      '    client_max_body_size 2m;',
      '}',
      '# END KITSUNETAB MANUAL REVERSE PROXY'
    ].join('\n');
  }

  function refreshManualVhost(form) {
    var card = one('[data-ktm-manual-vhost]');
    if (!card) return;
    var manual = value(form, 'proxyMode') === 'manual';
    var domain = value(form, 'domain').toLowerCase() || 'twoja-domena.example';
    var port = value(form, 'httpPort') || '13210';
    card.hidden = !manual;
    all('[data-ktm-vhost-domain]', card).forEach(function (target) { target.textContent = domain; });
    var path = one('[data-ktm-vhost-path]', card);
    if (path) path.textContent = '/var/www/vhosts/system/' + domain + '/conf/vhost_nginx.conf';
    var code = one('[data-ktm-vhost-code]', card);
    if (code) code.textContent = manualVhostBlock(port);
  }

  function initConfigForm() {
    var form = document.getElementById('ktm-config-form');
    if (!form) return;
    var repository = one('[name="repositoryPath"]', form);
    var deploy = one('[name="deployPath"]', form);
    var domain = one('[name="domain"]', form);
    var publicUrl = one('[name="publicUrl"]', form);
    var proxyMode = one('[name="proxyMode"]', form);
    var httpPort = one('[name="httpPort"]', form);
    var bootstrapEnabled = one('[name="bootstrapAdminEnabled"]', form);
    var bootstrapEmail = one('[name="bootstrapAdminEmail"]', form);
    var lastGeneratedUrl = publicUrl ? publicUrl.value : '';
    if (repository && deploy) repository.addEventListener('change', function () {
      deploy.value = normalizePath(repository.value) + '/deploy';
    });
    if (domain && publicUrl) domain.addEventListener('change', function () {
      var next = domain.value ? 'https://' + domain.value.toLowerCase() : '';
      if (!publicUrl.value || publicUrl.value === lastGeneratedUrl) publicUrl.value = next;
      lastGeneratedUrl = next;
      refreshManualVhost(form);
    });
    if (proxyMode) proxyMode.addEventListener('change', function () { refreshManualVhost(form); });
    if (httpPort) httpPort.addEventListener('input', function () { refreshManualVhost(form); });
    if (bootstrapEnabled) bootstrapEnabled.addEventListener('change', function () { setBootstrapVisibility(form); });
    if (bootstrapEmail) bootstrapEmail.addEventListener('input', function () { setBootstrapVisibility(form); });
    setBootstrapVisibility(form);
    refreshManualVhost(form);
    form.addEventListener('submit', function (event) {
      if (!validateConfig(form)) event.preventDefault();
    });
  }

  function initUtilities(shell) {
    all('[data-ktm-refresh]', shell).forEach(function (button) {
      button.addEventListener('click', function () {
        rememberTab('status');
        button.disabled = true;
        button.textContent = 'Odświeżanie…';
        window.location.reload();
      });
    });
    all('[data-ktm-copy-log]', shell).forEach(function (button) {
      button.addEventListener('click', function () {
        var log = one('[data-ktm-log]', shell);
        if (!log) return;
        var text = log.textContent || '';
        var copied = function () {
          var previous = button.textContent;
          button.textContent = 'Skopiowano';
          window.setTimeout(function () { button.textContent = previous; }, 1600);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(copied);
        else {
          var selection = window.getSelection();
          var range = document.createRange();
          range.selectNodeContents(log);
          selection.removeAllRanges();
          selection.addRange(range);
          try { document.execCommand('copy'); copied(); } catch (error) {}
          selection.removeAllRanges();
        }
      });
    });
    all('[data-ktm-copy-vhost]', shell).forEach(function (button) {
      button.addEventListener('click', function () {
        var code = one('[data-ktm-vhost-code]', shell);
        if (!code) return;
        var copied = function () {
          var previous = button.textContent;
          button.textContent = 'Skopiowano';
          window.setTimeout(function () { button.textContent = previous; }, 1600);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(code.textContent || '').then(copied);
        else {
          var range = document.createRange();
          range.selectNodeContents(code);
          var selection = window.getSelection();
          selection.removeAllRanges();
          selection.addRange(range);
          try { document.execCommand('copy'); copied(); } catch (error) {}
          selection.removeAllRanges();
        }
      });
    });
  }

  function initialize() {
    var shell = one('.ktm-shell');
    if (!shell || shell.getAttribute('data-ktm-initialized') === '1') return;
    shell.setAttribute('data-ktm-initialized', '1');
    initTabs(shell);
    initOperationForm();
    initServiceForm();
    initMaintenanceForm();
    initConfigForm();
    initUtilities(shell);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize);
  else initialize();
}());
