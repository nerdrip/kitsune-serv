# Changelog

## 0.4.0-2 — 2026-08-20

- Added the shared Kitsune Plesk Suite presentation and central management link.
- Keeps standalone navigation when Hub is absent and yields it to an active Kitsune Hub.

## 0.4.0

- Release aligned with KitsuneTab 0.4.0.
- Deployment health reports the new release and database migrations through schema 15.
- Supports zero-knowledge session columns, collaboration presence/comments and signed integration events.

## 0.3.0

- Release 6 adds a separately mounted backup mirror with staged copy, repeated SHA-256 verification and atomic publication.
- SQLite backups now run `quick_check` and record the database schema version before becoming eligible for restore or mirroring.
- Failed deployments automatically force-recreate the previous healthy image with the previous Compose environment.
- Release 5 rebuilds the page against the native KitsunePNC/Plesk form layout and removes the 185 px custom-card collapse.
- CSS and JavaScript now use a release-aware cache key, so Plesk upgrades cannot mix old assets with new markup.
- The automatic JWT status tile was removed; the secret remains generated and encrypted without adding noise to the form.
- Manual nginx configuration is a full-width panel directly below the configuration form with live domain/port updates.
- Release 4 generates and encrypts the JWT secret automatically and removes the manual secret field.
- Manual proxy code remains visible after server-side validation errors.
- SSH `known_hosts` pinning is optional, matching the other managers; system host keys remain strict by default.
- Plesk validation messages use compact native-looking cards.
- Release 3 fixes the real Plesk form grid: full-width section headers, wide controls and structured path cards.
- Private Git repositories can authenticate with an encrypted SSH deploy key and pinned `known_hosts`.
- Optional first-administrator bootstrap creates an account only in an empty database and never replaces credentials.
- Release 7 adds an enforced public-registration switch shared by Plesk, the API and the web login screen.
- Release 8 starts the API before its dependent backup sidecar, preserves detailed startup logs and fixes the slim runtime server bundle.
- Managed and manual nginx vhost modes with a live, copyable manual configuration card.
- Rebuilt the Plesk manager as a five-tab operations console aligned with the other deployment extensions.
- Separate API and backup-sidecar cards, Docker/Compose versions, readiness, proxy flow and repository divergence status.
- Fast backup inventory with cached SHA-256 verification, database metadata and restore selection directly from disk.
- Dedicated code deployment, runtime controls, data maintenance and diagnostics with persistent tab navigation.
- Client- and server-side validation for paths, domain/URL, CORS, resources, retention and secrets.
- Runtime RAM, CPU, snapshot retention and rate-limit settings are now written to the private deployment environment.
- Release aligned with KitsuneTab 0.3.0 and its Workona migration workflow.
- Browser-side capture, advanced search and multi-format tab export included in packaged releases.
- Cross-space My Tasks view with due dates is available through the updated API and extension.
- Existing verified restore, safety backup and rollback guarantees remain unchanged.

## 0.2.0

- Verified restore with an explicit confirmation, manifest and SHA-256 validation.
- Automatic safety backup and atomic SQLite database replacement during restore.
- Automatic rollback to the pre-restore database when restored data fails readiness.
- Scheduled backup sidecar with configurable retention.
- Deployment dashboard with last backup/restore state and improved health reporting.
- Server and browser-extension release aligned on version 0.2.0.

## 0.1.0

- Initial Git and Docker Compose deployment workflow.
- Encrypted Git/JWT secrets and safe fast-forward updates.
- Plesk nginx proxy management with rollback.
- Online SQLite backups, health checks and service controls.
