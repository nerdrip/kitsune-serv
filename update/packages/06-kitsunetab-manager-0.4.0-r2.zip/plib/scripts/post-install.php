<?php

pm_Context::init('kitsunetab-manager');
require_once dirname(__DIR__) . '/library/Config.php';
$varDir = pm_Context::getVarDir();
if (!is_dir($varDir)) mkdir($varDir, 0700, true);
@chmod($varDir, 0700);
foreach (Modules_KitsunetabManager_Config::defaults() as $key => $value) {
    if (pm_Settings::get($key) === null) pm_Settings::set($key, (string) $value);
}
Modules_KitsunetabManager_Config::ensureJwtSecret();
$productRoot = defined('PRODUCT_ROOT_D') ? PRODUCT_ROOT_D : '/usr/local/psa';
$utility = $productRoot . '/admin/bin/modules/kitsunetab-manager/kitsunetab-manager';
if (is_file($utility)) @chmod($utility, 0750);
