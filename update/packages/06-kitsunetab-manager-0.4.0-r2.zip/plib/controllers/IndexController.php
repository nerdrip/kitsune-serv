<?php

class IndexController extends pm_Controller_Action
{
    protected $_accessLevel = 'admin';

    public function init()
    {
        parent::init();
        $this->view->pageTitle = 'KitsuneTab Deployment Manager';
        $this->view->headLink()->appendStylesheet(
            pm_Context::getBaseUrl() . 'css/kitsunetab.css?v=' . Modules_KitsunetabManager_Config::EXTENSION_VERSION . '-' . Modules_KitsunetabManager_Config::EXTENSION_RELEASE
        );
        $this->view->headLink()->appendStylesheet(pm_Context::getBaseUrl() . 'css/kitsune-platform.css?v=1');
        $this->view->headScript()->appendFile(pm_Context::getBaseUrl() . 'js/kitsune-platform.js?v=1');
        $this->view->suiteProduct = 'KitsuneTab Manager';
        $this->view->suiteVersion = Modules_KitsunetabManager_Config::EXTENSION_VERSION;
        try { $this->view->suiteHubActive = pm_Extension::getById('kitsuneserv-bridge')->isActive(); }
        catch (Throwable $exception) { $this->view->suiteHubActive = false; }
    }

    public function indexAction()
    {
        $isPost = $this->getRequest()->isPost();
        $submitted = $isPost ? (array) $this->getRequest()->getPost() : [];
        $state = Modules_KitsunetabManager_Config::readState();
        $statusRefreshError = null;
        if (!$isPost) {
            $statusRefreshError = $this->refreshStatus();
            $state = Modules_KitsunetabManager_Config::readState();
        }
        $configForm = $this->configForm();
        $operationForm = $this->operationForm();
        $serviceForm = $this->serviceForm();
        $maintenanceForm = $this->maintenanceForm($state);

        if ($isPost) {
            $post = $submitted;
            $type = (string) ($post['formType'] ?? '');
            if ($type === 'config') {
                $this->view->activeTab = 'config';
                if ($this->saveConfig($configForm, $post)) return;
            }
            if ($type === 'operation') {
                $this->view->activeTab = 'deploy';
                if ($this->startOperation($operationForm, $post)) return;
            }
            if ($type === 'service') {
                $this->view->activeTab = 'deploy';
                if ($this->startServiceOperation($serviceForm, $post)) return;
            }
            if ($type === 'maintenance') {
                $this->view->activeTab = 'data';
                if ($this->startMaintenance($maintenanceForm, $post, $state)) return;
            }
        }

        if ($isPost) $statusRefreshError = $this->refreshStatus();
        $this->view->statusRefreshError = $statusRefreshError;
        $this->view->configForm = $configForm;
        $this->view->operationForm = $operationForm;
        $this->view->serviceForm = $serviceForm;
        $this->view->maintenanceForm = $maintenanceForm;
        $viewConfig = Modules_KitsunetabManager_Config::values();
        if ($isPost && ($submitted['formType'] ?? '') === 'config') {
            foreach (Modules_KitsunetabManager_Config::defaults() as $key => $default) {
                if (isset($submitted[$key]) && is_scalar($submitted[$key])) $viewConfig[$key] = trim((string) $submitted[$key]);
            }
        }
        $this->view->config = $viewConfig;
        $this->view->state = Modules_KitsunetabManager_Config::readState();
        $this->view->hasGitToken = Modules_KitsunetabManager_Config::hasSecret('gitToken');
        $this->view->hasSshKey = Modules_KitsunetabManager_Config::hasSecret('gitSshPrivateKey');
        $this->view->hasJwtSecret = Modules_KitsunetabManager_Config::hasSecret('jwtSecret');
        $this->view->hasBootstrapPassword = Modules_KitsunetabManager_Config::hasSecret('bootstrapAdminPassword');
        $this->view->extensionVersion = Modules_KitsunetabManager_Config::EXTENSION_VERSION;
        $this->view->assetVersion = Modules_KitsunetabManager_Config::EXTENSION_VERSION . '-' . Modules_KitsunetabManager_Config::EXTENSION_RELEASE;
    }

    private function configForm()
    {
        $v = Modules_KitsunetabManager_Config::values();
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'ktm-config-form');
        $form->addElement('hidden', 'formType', ['value' => 'config']);

        $this->section($form, 'repositorySection', 'Kod i trwałe dane', 'Kod może być aktualizowany, ale baza SQLite i backupy muszą pozostać poza repozytorium.');
        $this->text($form, 'repositoryUrl', 'Repozytorium Git', $v['repositoryUrl'], true, 'HTTPS albo SSH do repozytorium KitsuneTab.');
        $this->text($form, 'repositoryBranch', 'Gałąź wdrożeniowa', $v['repositoryBranch'], true, 'Zwykle main. Manager dopuszcza wyłącznie fast-forward.');
        $this->path($form, 'repositoryPath', 'Katalog kodu', $v['repositoryPath'], 'Np. /opt/kitsunetab/source.');
        $this->path($form, 'deployPath', 'Katalog Docker Compose', $v['deployPath'], 'Dokładnie katalog kodu z dopiskiem /deploy.');
        $this->path($form, 'dataPath', 'Katalog danych', $v['dataPath'], 'Baza SQLite; poza repozytorium.');
        $this->path($form, 'backupPath', 'Katalog backupów', $v['backupPath'], 'Zweryfikowane kopie bazy; poza repozytorium.');
        $this->text($form, 'backupMirrorPath', 'Drugi cel backupów', $v['backupMirrorPath'], false, 'Opcjonalny katalog na innym dysku, montażu NFS lub storage Pleska, np. /mnt/backup/kitsunetab. Każda zweryfikowana kopia zostanie tam atomowo zreplikowana.');
        $form->addElement('text', 'backupKeep', ['label' => 'Zachowuj backupów', 'value' => $v['backupKeep'], 'description' => 'Od 1 do 365 kopii.', 'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 365]]]]);
        $form->addElement('text', 'backupIntervalHours', ['label' => 'Automatyczny backup co', 'value' => $v['backupIntervalHours'], 'description' => 'Liczba godzin od 1 do 168.', 'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 168]]]]);

        $this->section($form, 'networkSection', 'Domena i połączenia rozszerzeń', 'Plesk kończy TLS, a prywatny kontener nasłuchuje wyłącznie na 127.0.0.1.');
        $form->addElement('select', 'proxyMode', [
            'label' => 'Konfiguracja reverse proxy',
            'value' => $v['proxyMode'],
            'multiOptions' => [
                'managed' => 'Automatyczna — manager zapisuje vhost_nginx.conf',
                'manual' => 'Ręczna — pokaż gotowy blok nginx do wklejenia',
            ],
            'description' => 'Tryb ręczny nigdy nie modyfikuje konfiguracji domeny. Gotowy kod pojawi się pod formularzem.',
        ]);
        $domains = $this->domainOptions($v['domain']);
        if ($domains) {
            $form->addElement('select', 'domain', ['label' => 'Domena KitsuneTab', 'value' => $v['domain'], 'multiOptions' => $domains, 'required' => true, 'description' => 'Aktywna domena Pleska z hostingiem i certyfikatem TLS.']);
        } else {
            $this->text($form, 'domain', 'Domena KitsuneTab', $v['domain'], true, 'Musi istnieć w Plesku i mieć aktywny hosting.');
        }
        $this->text($form, 'publicUrl', 'Publiczny URL API', $v['publicUrl'], true, 'Dokładnie https://wybrana-domena bez końcowego ukośnika.');
        $form->addElement('text', 'httpPort', ['label' => 'Lokalny port API', 'value' => $v['httpPort'], 'description' => 'Port 127.0.0.1 używany przez reverse proxy Pleska.', 'validators' => [['Digits', true], ['Between', true, ['min' => 1024, 'max' => 65535]]]]);
        $this->text($form, 'corsOrigins', 'Źródła CORS', $v['corsOrigins'], true, 'Lista po przecinku. Zachowaj chrome-extension://* i moz-extension://*.');
        $this->text($form, 'adminEmails', 'Administratorzy aplikacji', $v['adminEmails'], false, 'Adresy kont administracyjnych rozdzielone przecinkami.');

        $this->section($form, 'bootstrapSection', 'Pierwszy administrator', 'Opcjonalnie utwórz pierwsze konto przed publicznym uruchomieniem serwera. Mechanizm nigdy nie nadpisuje konta ani hasła i odmawia dodania kolejnego użytkownika.');
        $form->addElement('select', 'registrationEnabled', [
            'label' => 'Publiczna rejestracja kont',
            'value' => $v['registrationEnabled'],
            'multiOptions' => ['false' => 'Wyłączona — tylko konta zarządzane przez administratora', 'true' => 'Włączona — każdy może utworzyć konto'],
            'description' => 'Po utworzeniu pierwszego administratora zalecamy ją wyłączyć. Logowanie i istniejące konta pozostaną aktywne.',
        ]);
        $form->addElement('select', 'bootstrapAdminEnabled', [
            'label' => 'Utwórz pierwsze konto',
            'value' => $v['bootstrapAdminEnabled'],
            'multiOptions' => ['false' => 'Nie — rejestracja z rozszerzenia', 'true' => 'Tak — jednorazowy bootstrap z Pleska'],
        ]);
        $this->text($form, 'bootstrapAdminEmail', 'E-mail pierwszego administratora', $v['bootstrapAdminEmail'], false, 'Zostanie dodany do administratorów dopiero po utworzeniu albo odnalezieniu tego konta w bazie.');
        $this->text($form, 'bootstrapAdminDisplayName', 'Nazwa wyświetlana administratora', $v['bootstrapAdminDisplayName'], false, 'Od 1 do 120 znaków.');
        $form->addElement('password', 'bootstrapAdminPassword', [
            'label' => 'Hasło pierwszego administratora',
            'value' => '',
            'description' => Modules_KitsunetabManager_Config::hasSecret('bootstrapAdminPassword') ? 'Zaszyfrowane. Puste pole zachowa wartość; istniejące konto nigdy nie otrzyma nowego hasła.' : 'Minimum 10 znaków. Hasło trafia do jednorazowego pliku wewnątrz katalogu danych i jest usuwane natychmiast po bootstrapie.',
            'validators' => [['StringLength', true, ['max' => 256]]],
        ]);

        $this->section($form, 'runtimeSection', 'Retencja i limity serwera', 'Ustawienia są zapisywane do prywatnego pliku .env podczas wdrożenia.');
        $form->addElement('text', 'snapshotDays', ['label' => 'Retencja migawek (dni)', 'value' => $v['snapshotDays'], 'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 3650]]]]);
        $form->addElement('text', 'snapshotLimit', ['label' => 'Limit migawek na konto', 'value' => $v['snapshotLimit'], 'description' => 'Domyślnie 500. Najstarsze są usuwane po zapisaniu nowej migawki.', 'validators' => [['Digits', true], ['Between', true, ['min' => 10, 'max' => 10000]]]]);
        $form->addElement('text', 'rateLimitMax', ['label' => 'Limit żądań / minutę', 'value' => $v['rateLimitMax'], 'validators' => [['Digits', true], ['Between', true, ['min' => 10, 'max' => 100000]]]]);
        $this->text($form, 'memoryLimit', 'Limit RAM kontenera', $v['memoryLimit'], true, 'Np. 512m albo 1g.');
        $this->text($form, 'cpuLimit', 'Limit CPU', $v['cpuLimit'], true, 'Np. 1.0 albo 2.5.');

        $this->section($form, 'secretSection', 'Git i sekrety', 'Poświadczenia Git są opcjonalne. JWT secret jest generowany automatycznie i pozostaje zaszyfrowany w ustawieniach Pleska.');
        $this->text($form, 'gitUsername', 'Użytkownik Git HTTPS', $v['gitUsername'], false, 'Używany z tokenem dla prywatnego repozytorium.');
        $form->addElement('password', 'gitToken', ['label' => 'Token Git', 'value' => '', 'description' => Modules_KitsunetabManager_Config::hasSecret('gitToken') ? 'Zaszyfrowany. Puste pole zachowa wartość.' : 'Opcjonalny dla repozytorium publicznego.']);
        $form->addElement('textarea', 'gitSshKnownHosts', [
            'label' => 'SSH known_hosts',
            'value' => $v['gitSshKnownHosts'],
            'rows' => 4,
            'description' => 'Opcjonalna przypięta lista hostów, np. wynik ssh-keyscan sprawdzony z dokumentacją dostawcy. Puste pole użyje systemowego known_hosts.',
            'validators' => [['StringLength', true, ['max' => 262144]]],
        ]);
        $form->addElement('textarea', 'gitSshPrivateKey', [
            'label' => 'Klucz SSH deploy',
            'value' => '',
            'rows' => 7,
            'description' => Modules_KitsunetabManager_Config::hasSecret('gitSshPrivateKey') ? 'Zaszyfrowany przez Pleska. Puste pole zachowa obecny klucz.' : 'Prywatny klucz tylko do odczytu, bez hasła. Akceptowany dla adresów ssh:// oraz git@host:repo.',
            'validators' => [['StringLength', true, ['max' => 131072]]],
        ]);
        Modules_KitsunetabManager_Config::ensureJwtSecret();
        $this->actionButton($form, 'configAction', 'Zapisz konfigurację', 'save', 'ktm-config-submit');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function operationForm()
    {
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'ktm-operation-form');
        $form->addElement('hidden', 'formType', ['value' => 'operation']);
        $form->addElement('select', 'operation', [
            'label' => 'Operacja na kodzie',
            'multiOptions' => [
                'check' => 'Sprawdź repozytorium i dostępny commit',
                'sync' => 'Pobierz kod (tylko fast-forward)',
                'deploy' => 'Wdróż kod obecny na serwerze',
                'sync-deploy' => 'Pobierz najnowszy kod i wdróż',
            ],
            'description' => 'Istniejące wdrożenie otrzyma backup bezpieczeństwa przed przebudową.',
        ]);
        $this->actionButton($form, 'operationAction', 'Sprawdź repozytorium', 'deploy', 'ktm-operation-submit');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function serviceForm()
    {
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'ktm-service-form');
        $form->addElement('hidden', 'formType', ['value' => 'service']);
        $form->addElement('select', 'serviceOperation', [
            'label' => 'Sterowanie usługami',
            'multiOptions' => ['start' => 'Uruchom API i automat backupów', 'restart' => 'Uruchom ponownie API', 'stop' => 'Zatrzymaj cały stos'],
            'description' => 'Restart nie przebudowuje obrazu. Stop zatrzymuje API oraz automat backupów.',
        ]);
        $this->actionButton($form, 'serviceAction', 'Uruchom usługi', 'service', 'ktm-service-submit');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function maintenanceForm(array $state)
    {
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'ktm-maintenance-form');
        $form->addElement('hidden', 'formType', ['value' => 'maintenance']);
        $form->addElement('select', 'maintenanceOperation', ['label' => 'Operacja na danych', 'multiOptions' => ['backup' => 'Utwórz backup online', 'restore' => 'Przywróć wybrany backup'], 'description' => 'Restore weryfikuje manifest i SHA-256 oraz tworzy kopię bezpieczeństwa.']);
        $options = ['' => '— wybierz backup —'];
        foreach ((array) ($state['backups'] ?? []) as $backup) {
            $name = basename((string) ($backup['path'] ?? $backup['name'] ?? ''));
            if (!preg_match('/^\d{8}T\d{6}Z$/', $name)) continue;
            $label = (string) ($backup['createdAt'] ?? $name);
            if (!empty($backup['bytes'])) $label .= ' · ' . $this->formatBytes((int) $backup['bytes']);
            $label .= !empty($backup['verified']) ? ' · suma OK' : ' · wymaga weryfikacji';
            $options[$name] = $label;
        }
        $form->addElement('select', 'backupName', ['label' => 'Backup do przywrócenia', 'multiOptions' => $options, 'description' => 'Lista pochodzi bezpośrednio ze skonfigurowanego katalogu backupów.']);
        $form->addElement('checkbox', 'confirmRestore', ['label' => 'Potwierdzenie restore', 'value' => '0', 'description' => 'Rozumiem, że bieżąca baza zostanie zastąpiona po utworzeniu backupu bezpieczeństwa.']);
        $this->actionButton($form, 'maintenanceAction', 'Utwórz backup', 'backup', 'ktm-maintenance-submit');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function saveConfig(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) return $this->rejectForm($form, 'konfiguracji');
        $v = $form->getValues();
        $repository = rtrim((string) $v['repositoryPath'], '/');
        foreach (['repositoryPath', 'deployPath', 'dataPath', 'backupPath'] as $field) {
            if (!$this->safePath((string) $v[$field])) return $this->rejectField($form, $field, 'Podaj bezpieczną ścieżkę bezwzględną pod /home, /opt, /srv, /var/lib albo /var/backups.');
        }
        if (rtrim((string) $v['deployPath'], '/') !== $repository . '/deploy') return $this->rejectField($form, 'deployPath', 'Wpisz dokładnie ' . $repository . '/deploy.');
        foreach (['dataPath', 'backupPath'] as $field) {
            $candidate = rtrim((string) $v[$field], '/');
            if ($candidate === $repository || strpos($candidate . '/', $repository . '/') === 0) return $this->rejectField($form, $field, 'Dane i backupy muszą znajdować się poza katalogiem kodu.');
        }
        $mirror = rtrim((string) ($v['backupMirrorPath'] ?? ''), '/');
        if ($mirror !== '') {
            if (!$this->safePath($mirror)) return $this->rejectField($form, 'backupMirrorPath', 'Podaj bezpieczną ścieżkę pod /home, /mnt, /media, /opt, /srv, /var/lib albo /var/backups.');
            foreach ([$repository, rtrim((string) $v['dataPath'], '/'), rtrim((string) $v['backupPath'], '/')] as $reserved) {
                if ($mirror === $reserved || strpos($mirror . '/', $reserved . '/') === 0 || strpos($reserved . '/', $mirror . '/') === 0) return $this->rejectField($form, 'backupMirrorPath', 'Drugi cel musi być niezależnym katalogiem, a nie rodzicem lub podkatalogiem kodu, danych albo podstawowych backupów.');
            }
        }
        if (!preg_match('/^(https:\/\/|ssh:\/\/|git@)/', (string) $v['repositoryUrl'])) return $this->rejectField($form, 'repositoryUrl', 'Adres musi zaczynać się od https://, ssh:// albo git@.');
        if (!preg_match('/^(?![-.])(?!.*\.\.)(?!.*@\{)[A-Za-z0-9._\/-]+$/', (string) $v['repositoryBranch'])) return $this->rejectField($form, 'repositoryBranch', 'Nazwa gałęzi jest nieprawidłowa.');
        $domain = strtolower(trim((string) $v['domain']));
        $publicUrl = rtrim((string) $v['publicUrl'], '/');
        $parts = parse_url($publicUrl);
        if (!preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/', $domain)
            || !is_array($parts) || ($parts['scheme'] ?? '') !== 'https' || strtolower((string) ($parts['host'] ?? '')) !== $domain
            || !empty($parts['path']) || isset($parts['query']) || isset($parts['fragment'])) {
            return $this->rejectField($form, 'publicUrl', 'Wpisz dokładnie https://' . $domain . ' bez ścieżki i parametrów.');
        }
        try { Modules_KitsunetabManager_Config::assertHostedDomain($domain); }
        catch (Throwable $exception) { return $this->rejectField($form, 'domain', $exception->getMessage()); }
        if (!in_array((string) ($v['proxyMode'] ?? ''), ['managed', 'manual'], true)) return $this->rejectField($form, 'proxyMode', 'Wybierz automatyczną albo ręczną konfigurację reverse proxy.');
        if (!in_array((string) ($v['registrationEnabled'] ?? ''), ['true', 'false'], true)) return $this->rejectField($form, 'registrationEnabled', 'Wybierz, czy publiczna rejestracja ma być włączona.');
        foreach (preg_split('/\s*,\s*/', trim((string) $v['adminEmails']), -1, PREG_SPLIT_NO_EMPTY) as $email) {
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return $this->rejectField($form, 'adminEmails', 'Nieprawidłowy adres: ' . $email . '.');
        }
        foreach (preg_split('/\s*,\s*/', trim((string) $v['corsOrigins']), -1, PREG_SPLIT_NO_EMPTY) as $origin) {
            if (!preg_match('#^(?:https?://[^\s,]+|chrome-extension://\*|moz-extension://\*)$#', $origin)) return $this->rejectField($form, 'corsOrigins', 'Nieprawidłowe źródło CORS: ' . $origin . '.');
        }
        if (!preg_match('/^\d+(?:\.\d+)?[kKmMgG]?$/', (string) $v['memoryLimit'])) return $this->rejectField($form, 'memoryLimit', 'Użyj wartości np. 512m albo 1g.');
        $cpu = filter_var($v['cpuLimit'], FILTER_VALIDATE_FLOAT);
        if ($cpu === false || $cpu <= 0 || $cpu > 64) return $this->rejectField($form, 'cpuLimit', 'Wpisz liczbę większą od 0 i nie większą niż 64.');
        $sshKey = trim((string) ($v['gitSshPrivateKey'] ?? $post['gitSshPrivateKey'] ?? ''));
        if ($sshKey !== '' && strpos($sshKey, 'PRIVATE KEY') === false) return $this->rejectField($form, 'gitSshPrivateKey', 'Wklej prawidłowy prywatny klucz SSH w formacie PEM/OpenSSH.');
        if (($v['bootstrapAdminEnabled'] ?? 'false') === 'true') {
            $bootstrapEmail = strtolower(trim((string) $v['bootstrapAdminEmail']));
            $bootstrapName = trim((string) $v['bootstrapAdminDisplayName']);
            $bootstrapPassword = trim((string) ($v['bootstrapAdminPassword'] ?? $post['bootstrapAdminPassword'] ?? ''));
            if (!filter_var($bootstrapEmail, FILTER_VALIDATE_EMAIL)) return $this->rejectField($form, 'bootstrapAdminEmail', 'Podaj prawidłowy e-mail pierwszego administratora.');
            if ($bootstrapName === '' || mb_strlen($bootstrapName) > 120) return $this->rejectField($form, 'bootstrapAdminDisplayName', 'Nazwa administratora musi mieć od 1 do 120 znaków.');
            if ($bootstrapPassword !== '' && (strlen($bootstrapPassword) < 10 || strlen($bootstrapPassword) > 256)) return $this->rejectField($form, 'bootstrapAdminPassword', 'Hasło musi mieć od 10 do 256 znaków.');
            if ($bootstrapPassword === '' && !Modules_KitsunetabManager_Config::hasSecret('bootstrapAdminPassword')) return $this->rejectField($form, 'bootstrapAdminPassword', 'Ustaw hasło pierwszego administratora.');
            $v['bootstrapAdminEmail'] = $bootstrapEmail;
        }
        $v['domain'] = $domain;
        $v['publicUrl'] = $publicUrl;
        try { Modules_KitsunetabManager_Config::save($v); }
        catch (Throwable $exception) { $this->_status->addMessage('error', 'Nie zapisano konfiguracji: ' . $exception->getMessage()); return false; }
        $this->_status->addMessage('info', 'Konfiguracja została zapisana. Wdróż system, aby zastosować ustawienia środowiska.');
        $this->respondWithRedirect();
        return true;
    }

    private function startOperation(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) return $this->rejectForm($form, 'operacji');
        $operation = (string) $form->getValue('operation');
        if (!in_array($operation, ['check', 'sync', 'deploy', 'sync-deploy'], true)) return $this->rejectField($form, 'operation', 'Wybierz prawidłową operację na kodzie.');
        return $this->queueOperation($operation, [], 'Operacja została dodana do kolejki Pleska.');
    }

    private function startServiceOperation(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) return $this->rejectForm($form, 'sterowania usługą');
        $operation = (string) $form->getValue('serviceOperation');
        if (!in_array($operation, ['start', 'restart', 'stop'], true)) return $this->rejectField($form, 'serviceOperation', 'Wybierz start, restart albo stop.');
        return $this->queueOperation($operation, [], 'Operacja na usługach została dodana do kolejki Pleska.');
    }

    private function startMaintenance(pm_Form_Simple $form, array $post, array $state)
    {
        if (!$form->isValid($post)) return $this->rejectForm($form, 'operacji na danych');
        $operation = (string) $form->getValue('maintenanceOperation');
        if (!in_array($operation, ['backup', 'restore'], true)) return $this->rejectField($form, 'maintenanceOperation', 'Wybierz backup albo restore.');
        $name = trim((string) $form->getValue('backupName'));
        if ($operation === 'restore') {
            $known = [];
            foreach ((array) ($state['backups'] ?? []) as $backup) $known[basename((string) ($backup['path'] ?? $backup['name'] ?? ''))] = true;
            if ($name === '' || empty($known[$name])) return $this->rejectField($form, 'backupName', 'Wybierz istniejący backup z listy.');
            if ((string) $form->getValue('confirmRestore') !== '1') return $this->rejectField($form, 'confirmRestore', 'Zaznacz jawne potwierdzenie przywrócenia bazy.');
        }
        return $this->queueOperation($operation, ['backupName' => $name], $operation === 'backup' ? 'Backup został dodany do kolejki Pleska.' : 'Restore został dodany do kolejki Pleska.');
    }

    private function queueOperation($operation, array $extra, $message)
    {
        try {
            $runtime = Modules_KitsunetabManager_Config::createRuntimeConfig($operation, $extra);
            $task = new Modules_KitsunetabManager_Task_Operate();
            $task->setParam('runtimeConfig', $runtime);
            (new pm_LongTask_Manager())->start($task);
            $this->_status->addMessage('info', $message);
        } catch (Throwable $exception) { $this->_status->addMessage('error', $exception->getMessage()); return false; }
        $this->respondWithRedirect();
        return true;
    }

    private function refreshStatus()
    {
        $runtime = null;
        try {
            $runtime = Modules_KitsunetabManager_Config::createRuntimeConfig('status');
            $result = pm_ApiCli::callSbin('kitsunetab-manager', ['--config', $runtime], pm_ApiCli::RESULT_FULL);
            if ((int) ($result['code'] ?? 1) !== 0) {
                $detail = trim((string) ($result['stderr'] ?? $result['stdout'] ?? ''));
                return $detail !== '' ? mb_substr($detail, -2000) : 'Narzędzie statusu zakończyło się błędem.';
            }
            return null;
        } catch (Throwable $exception) { return mb_substr($exception->getMessage(), -2000); }
        finally { if ($runtime && is_file($runtime)) @unlink($runtime); }
    }

    private function rejectForm(pm_Form_Simple $form, $context)
    {
        $messages = [];
        foreach ((array) $form->getMessages() as $field => $errors) {
            if (!$errors) continue;
            $element = $form->getElement($field);
            $messages[] = ($element ? trim(strip_tags((string) $element->getLabel())) : $field) . ': ' . implode(', ', array_values((array) $errors));
        }
        $this->_status->addMessage('error', 'Nie zapisano ' . $context . '. ' . ($messages ? implode('; ', $messages) : 'Sprawdź oznaczone pola.'));
        return false;
    }

    private function rejectField(pm_Form_Simple $form, $field, $message)
    {
        $element = $form->getElement($field);
        if ($element) $element->addError($message);
        $this->_status->addMessage('error', 'Nie zapisano formularza. ' . $message);
        return false;
    }

    private function respondWithRedirect()
    {
        $this->_helper->json(['redirect' => pm_Context::getActionUrl('index', 'index')]);
    }

    private function safePath($path)
    {
        return is_string($path) && !in_array('..', explode('/', $path), true) && preg_match('#^/(?:home|mnt|media|opt|srv|var/lib|var/backups)/[A-Za-z0-9._/-]+$#', $path);
    }

    private function domainOptions($saved)
    {
        $options = [];
        try {
            foreach ((array) pm_Domain::getAllDomains() as $domain) {
                if (!$domain instanceof pm_Domain || !$domain->hasHosting() || !$domain->isActive() || $domain->isSuspended() || $domain->isDisabled()) continue;
                $name = strtolower(trim((string) $domain->getName()));
                if (preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/', $name)) $options[$name] = $name;
            }
        } catch (Throwable $exception) {}
        if ($saved !== '' && !isset($options[$saved])) $options[$saved] = $saved . ' (zapisana konfiguracja)';
        natcasesort($options);
        return $options;
    }

    private function section(pm_Form_Simple $form, $name, $title, $description)
    {
        $form->addElement('simpleText', $name, ['label' => '', 'escape' => false, 'value' => '<div class="ktm-form-section"><strong>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</strong><span>' . htmlspecialchars($description, ENT_QUOTES, 'UTF-8') . '</span></div>']);
    }

    private function actionButton(pm_Form_Simple $form, $name, $label, $kind, $id)
    {
        $form->addElement('simpleText', $name, ['label' => '', 'escape' => false, 'value' => '<div class="ktm-action-row"><button type="submit" class="ktm-primary-action" data-ktm-action="' . htmlspecialchars($kind, ENT_QUOTES, 'UTF-8') . '" id="' . htmlspecialchars($id, ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</button></div>']);
    }

    private function path(pm_Form_Simple $form, $name, $label, $value, $description)
    {
        $this->text($form, $name, $label, $value, true, $description);
    }

    private function text(pm_Form_Simple $form, $name, $label, $value, $required, $description)
    {
        $form->addElement('text', $name, ['label' => $label, 'value' => $value, 'required' => $required, 'description' => $description, 'validators' => [['StringLength', true, ['max' => 2000]]]]);
    }

    private function formatBytes($bytes)
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $value = max(0, (float) $bytes);
        $index = 0;
        while ($value >= 1024 && $index < count($units) - 1) { $value /= 1024; $index++; }
        return number_format($value, $index === 0 ? 0 : 1, ',', ' ') . ' ' . $units[$index];
    }
}
