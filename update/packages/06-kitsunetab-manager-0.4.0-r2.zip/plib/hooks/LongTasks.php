<?php

class Modules_KitsunetabManager_LongTasks extends pm_Hook_LongTasks
{
    public function getLongTasks()
    {
        return [new Modules_KitsunetabManager_Task_Operate()];
    }
}

