# KitsuneTab Deployment Manager

Installs, updates, backs up and monitors a private KitsuneTab server from Plesk.
It keeps application data outside the Git checkout, stores secrets through the
encrypted Plesk settings API and configures a managed nginx reverse proxy.

