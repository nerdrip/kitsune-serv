# Kitsune Suite — konfiguracja managera

## Konta i logowanie

Po wdrożeniu użytkownik otwiera menu konta w KitsuneHub i wybiera Colab albo
Test. Hub wystawia jednorazowy kod PKCE, a satelita tworzy lub odświeża konto
federacyjne i jego rolę. Lokalne konto założone bezpośrednio w satelicie nadal
działa samodzielnie i nie daje dostępu do Huba. Konta nie są automatycznie
łączone po samym e-mailu.

Puste ID organizacji jest poprawną konfiguracją początkową: pierwszy login
tworzy tenant `kitsune-suite`. Wpisz techniczne ID wyłącznie, jeśli logowanie ma
trafiać do istniejącej organizacji.

Colab i Test są samodzielne. Integracja uruchamia się dopiero po ustawieniu ich
bazowych URL-i HTTPS oraz wspólnego sekretu o długości minimum 32 znaków.

1. Hub automatycznie wykrywa już zainstalowany plugin produktu i uznaje jego
   osobny manager za właściciela konfiguracji.
2. Gdy pluginu brakuje, Hub pokazuje konfigurację startową. Podaj repozytorium,
   branch, ścieżki aplikacji, URL-e oraz wspólny sekret, aby zbudować i
   zainstalować plugin bezpośrednio z repozytorium.
3. Konfiguracja jest osadzana w generowanej paczce jako chroniony, jednorazowy
   `var/suite-bootstrap.json`. Hook `post-install` importuje go i usuwa. Jawne
   ponowienie instalacji z repozytorium uzgadnia konfigurację także dla już
   zainstalowanej wersji, podnosząc wyłącznie numer wydania paczki Pleska. Nadal
   można użyć ręcznie zbudowanego ZIP-a. Jeśli Plesk pominie lifecycle hook,
   Hub wywoła ograniczony importer managera produktu przez własne środowisko
   PHP SDK Pleska i sprawdzi wynik.
4. Otwórz osobny manager produktu i opcjonalnie zaznacz **Zezwól Hubowi na
   wdrożenie**. Bez tego Hub wykrywa API, ale nie może delegować deployu ani
   backupu.
5. Wdróż API i uruchom **Audyt Kitsune Suite**.

Projekt utworzony w Hubie jest provisionowany w obu skonfigurowanych produktach.
Test publikuje wynik do Huba i Colaba, nieudany wynik tworzy pojedynczy bug w
Colabie, a issue wraca do Huba i Testu. Dostawy są idempotentne i mają retry.

Hasła i sesje pozostają osobne. Konto federacyjne satelity nie ma lokalnego
hasła, jest powiązane stabilnym identyfikatorem Huba, a jego rola jest
odświeżana przy każdym logowaniu. Wspólny sekret chroni zarówno zdarzenia
serwer–serwer, jak i serwerową wymianę jednorazowego kodu SSO; nie jest hasłem
użytkownika. Kont lokalnych o tym samym e-mailu system celowo nie łączy
automatycznie.

Wykrywanie używa bezsekretowego `suite-discovery.json`, a delegowanie osobnego
`suite-control-profile.json`; oba mają prawa `0600`. Operacje otrzymują własny,
jednorazowy plik. Puste URL-e zachowują pełny tryb samodzielny.
