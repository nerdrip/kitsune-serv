<?php

class Modules_KitsunepncManager_LongTasks extends pm_Hook_LongTasks
{
    public function getLongTasks()
    {
        return [new Modules_KitsunepncManager_Task_Operate()];
    }
}
