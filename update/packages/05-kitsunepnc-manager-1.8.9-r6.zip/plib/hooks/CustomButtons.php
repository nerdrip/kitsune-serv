<?php

class Modules_KitsunepncManager_CustomButtons extends pm_Hook_CustomButtons
{
    public function getButtons()
    {
        if ($this->hubOwnsNavigation()) return [];
        return [[
            'place' => [
                self::PLACE_ADMIN_NAVIGATION,
                self::PLACE_HOSTING_PANEL_NAVIGATION,
            ],
            'section' => self::SECTION_NAV_SERVER_MANAGEMENT,
            'order' => 55,
            'title' => 'KitsunePNC Manager',
            'description' => 'Deploy, backup and restore KitsunePNC',
            'icon' => pm_Context::getBaseUrl() . 'images/kitsunepnc-menu.svg',
            // Plesk's documented extension entry route. Keeping the complete
            // route here avoids context-dependent relative URLs when this
            // extension installs another manager in the same request.
            'link' => pm_Context::getBaseUrl() . 'index.php/index/index',
            'newWindow' => false,
        ]];
    }

    private function hubOwnsNavigation()
    {
        try { return pm_Extension::getById('kitsuneserv-bridge')->isActive(); }
        catch (Throwable $exception) { return false; }
    }
}
