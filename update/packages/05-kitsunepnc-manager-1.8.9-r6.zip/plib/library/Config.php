<?php

class Modules_KitsunepncManager_Config
{
    public const EXTENSION_VERSION = '1.8.9';

    private const SECRETS = [
        'gitToken' => 'secret_git_token',
        'gitSshPrivateKey' => 'secret_git_ssh_private_key',
        'jwtSecret' => 'secret_jwt',
        'jwtRefreshSecret' => 'secret_jwt_refresh',
        'dataEncryptionKey' => 'secret_data_encryption',
        'metricsToken' => 'secret_metrics_token',
        'smtpPass' => 'secret_smtp_password',
        'suiteSharedSecret' => 'secret_suite_shared_secret',
        'colabGitToken' => 'secret_colab_git_token',
        'colabGitSshPrivateKey' => 'secret_colab_git_ssh_private_key',
        'testGitToken' => 'secret_test_git_token',
        'testGitSshPrivateKey' => 'secret_test_git_ssh_private_key',
    ];

    public static function defaults()
    {
        return [
            'repositoryUrl' => '',
            'repositoryBranch' => 'main',
            'repositoryPath' => '/opt/kitsunepnc/source',
            'deployPath' => '/opt/kitsunepnc/source/deploy',
            'dataPath' => '/var/lib/kitsunepnc',
            'backupPath' => '/var/backups/kitsunepnc',
            'backupKeep' => '14',
            'domain' => 'hub.example.com',
            'publicUrl' => 'https://hub.example.com',
            'proxyMode' => 'docker',
            'bindAddress' => '127.0.0.1',
            'httpPort' => '18080',
            'httpsPort' => '18443',
            'adminEmails' => '',
            'colabApiUrl' => '',
            'testApiUrl' => '',
            'suiteOrganizationName' => 'Kitsune Suite',
            'suiteWorkspaceId' => '',
            'suiteActorId' => '',
            'colabRepositoryUrl' => '',
            'colabRepositoryBranch' => 'main',
            'colabRepositoryPath' => '/opt/kitsunecolab/source',
            'colabDeployPath' => '/opt/kitsunecolab/app',
            'colabBackupPath' => '/opt/kitsunecolab/backups',
            'colabPublicWebUrl' => 'https://colab.example.com',
            'colabPublicDomain' => '',
            'colabApiDomain' => '',
            'colabOrganizationId' => '',
            'colabOwnerId' => '',
            'colabGitUsername' => 'x-access-token',
            'colabGitSshKnownHosts' => '',
            'testRepositoryUrl' => '',
            'testRepositoryBranch' => 'main',
            'testRepositoryPath' => '/opt/kitsunetest/source',
            'testPublicDomain' => 'tests.example.com',
            'testPublicWebUrl' => 'https://tests.example.com',
            'testApiDomain' => '',
            'testHealthUrl' => 'https://tests.example.com/readyz',
            'testOrganizationId' => '',
            'testGitUsername' => 'x-access-token',
            'testGitSshKnownHosts' => '',
            'gitUsername' => 'x-access-token',
            'gitSshKnownHosts' => '',
            'requireEmailVerification' => 'false',
            'smtpHost' => '',
            'smtpPort' => '587',
            'smtpUser' => '',
            'smtpFrom' => 'KitsuneHub <noreply@example.com>',
            'smtpSecure' => 'false',
        ];
    }

    public static function values()
    {
        $result = [];
        foreach (self::defaults() as $key => $default) {
            $result[$key] = (string) pm_Settings::get($key, $default);
        }
        return $result;
    }

    public static function save(array $values)
    {
        foreach (self::defaults() as $key => $default) {
            if (array_key_exists($key, $values)) {
                $value = trim((string) $values[$key]);
                if (in_array($key, ['gitSshKnownHosts', 'colabGitSshKnownHosts', 'testGitSshKnownHosts'], true)) {
                    $value = self::normalizeMultiline($value);
                }
                pm_Settings::set($key, $value);
            }
        }
        foreach (self::SECRETS as $field => $setting) {
            if (isset($values[$field]) && trim((string) $values[$field]) !== '') {
                pm_Settings::setEncrypted($setting, self::normalizeSecret($field, $values[$field]));
            }
        }
        // The Hub must be deployable without asking an administrator to invent
        // cryptographic material. Existing values are never replaced.
        foreach (['jwtSecret', 'jwtRefreshSecret', 'dataEncryptionKey', 'metricsToken'] as $field) {
            if (self::secret($field) === '') {
                pm_Settings::setEncrypted(self::SECRETS[$field], self::randomSecret(64));
            }
        }
        self::ensureSuiteSharedSecret();
    }

    public static function ensureSuiteSharedSecret()
    {
        if (self::secret('suiteSharedSecret') === '') {
            pm_Settings::setEncrypted(self::SECRETS['suiteSharedSecret'], self::randomSecret(64));
        }
    }

    public static function discoverSshKnownHosts($repositoryUrl)
    {
        $url = trim((string) $repositoryUrl);
        $host = '';
        $port = 22;
        if (preg_match('#^git@([A-Za-z0-9.-]+):#', $url, $matches)) {
            $host = $matches[1];
        } else {
            $parts = parse_url($url);
            if (is_array($parts) && ($parts['scheme'] ?? '') === 'ssh' && ($parts['user'] ?? '') === 'git') {
                $host = (string) ($parts['host'] ?? '');
                if (isset($parts['port'])) $port = (int) $parts['port'];
            }
        }
        if (!preg_match('/^[A-Za-z0-9.-]+$/', $host) || $port < 1 || $port > 65535) {
            throw new RuntimeException('nieprawidłowy host lub port SSH w adresie repozytorium');
        }
        $command = 'ssh-keyscan -T 8 -p ' . (int) $port . ' ' . escapeshellarg($host) . ' 2>/dev/null';
        $pipes = [];
        $process = proc_open($command, [['pipe', 'r'], ['pipe', 'w'], ['pipe', 'w']], $pipes);
        if (!is_resource($process)) throw new RuntimeException('nie można uruchomić ssh-keyscan');
        fclose($pipes[0]);
        $output = stream_get_contents($pipes[1]);
        $error = stream_get_contents($pipes[2]);
        fclose($pipes[1]);
        fclose($pipes[2]);
        $exitCode = proc_close($process);
        $knownHosts = self::normalizeMultiline($output);
        if ($exitCode !== 0 || $knownHosts === '' || strpos($knownHosts, 'ssh-') === false) {
            throw new RuntimeException('ssh-keyscan nie zwrócił klucza' . ($error ? ': ' . mb_substr(trim($error), -300) : ''));
        }
        return $knownHosts;
    }

    public static function hasSecret($field)
    {
        return self::secret($field) !== '';
    }

    public static function createRuntimeConfig($operation, array $extra = [])
    {
        $allowed = ['status', 'check', 'sync', 'deploy', 'sync-deploy', 'backup', 'restore', 'self-update-check', 'self-update-install', 'suite-check', 'suite-install', 'suite-install-repo', 'suite-install-deploy', 'suite-deploy', 'suite-backup'];
        if (!in_array($operation, $allowed, true)) {
            throw new RuntimeException('Unknown KitsunePNC operation.');
        }
        $varDir = rtrim((string) pm_Context::getVarDir(), '/\\');
        if (!is_dir($varDir) && !mkdir($varDir, 0700, true) && !is_dir($varDir)) {
            throw new RuntimeException('Cannot create extension state directory.');
        }
        @chmod($varDir, 0700);
        $realVarDir = realpath($varDir);
        if ($realVarDir === false) {
            throw new RuntimeException('Cannot resolve extension state directory.');
        }
        $varDir = $realVarDir;

        $values = self::values();
        $payload = array_merge($values, [
            'operation' => $operation,
            'gitToken' => self::secret('gitToken'),
            'gitSshPrivateKey' => self::secret('gitSshPrivateKey'),
            'jwtSecret' => self::secret('jwtSecret'),
            'jwtRefreshSecret' => self::secret('jwtRefreshSecret'),
            'dataEncryptionKey' => self::secret('dataEncryptionKey'),
            'metricsToken' => self::secret('metricsToken'),
            'smtpPass' => self::secret('smtpPass'),
            'suiteSharedSecret' => self::secret('suiteSharedSecret'),
            'colabGitToken' => self::secret('colabGitToken'),
            'colabGitSshPrivateKey' => self::secret('colabGitSshPrivateKey'),
            'testGitToken' => self::secret('testGitToken'),
            'testGitSshPrivateKey' => self::secret('testGitSshPrivateKey'),
            'requestedAt' => gmdate('c'),
            'extensionVersion' => self::EXTENSION_VERSION,
            'extensionVarDir' => $varDir,
        ], $extra);

        $selectedModules = (array) ($extra['modules'] ?? []);
        if (in_array($operation, ['deploy', 'sync-deploy'], true)
            && in_array('web-editor', $selectedModules, true)
            && ($values['proxyMode'] ?? 'docker') === 'managed') {
            $domain = self::hostedDomain($values['domain']);
            $payload['pleskVhostSystemPath'] = (string) $domain->getVhostSystemPath();
        }

        $path = $varDir . '/operation-' . bin2hex(random_bytes(12)) . '.json';
        $previous = umask(0077);
        try {
            $json = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            if ($json === false || file_put_contents($path, $json, LOCK_EX) === false) {
                throw new RuntimeException('Cannot write operation configuration.');
            }
            @chmod($path, 0600);
        } finally {
            umask($previous);
        }
        return $path;
    }

    public static function suiteBootstrapConfig($product)
    {
        $values = self::values();
        $shared = self::secret('suiteSharedSecret');
        if ($product === 'colab') {
            return [
                'repositoryUrl' => $values['colabRepositoryUrl'],
                'repositoryBranch' => $values['colabRepositoryBranch'],
                'repositoryPath' => $values['colabRepositoryPath'],
                'gitUsername' => $values['colabGitUsername'],
                'gitSshKnownHosts' => $values['colabGitSshKnownHosts'],
                'deployPath' => $values['colabDeployPath'],
                'backupPath' => $values['colabBackupPath'],
                'publicDomain' => $values['colabPublicDomain'],
                'proxyMode' => 'managed',
                'publicWebUrl' => $values['colabPublicWebUrl'],
                'publicApiUrl' => $values['colabApiUrl'],
                'suiteHubUrl' => $values['publicUrl'],
                'suiteTestUrl' => $values['testApiUrl'],
                'suiteOrganizationId' => $values['colabOrganizationId'],
                'suiteOrganizationName' => $values['suiteOrganizationName'],
                'suiteOwnerId' => $values['colabOwnerId'],
                'suiteControlEnabled' => '1',
                'gitToken' => self::secret('colabGitToken'),
                'gitSshPrivateKey' => self::secret('colabGitSshPrivateKey'),
                'suiteSharedSecret' => $shared,
                'postgresPassword' => self::randomSecret(48),
                'jwtSecret' => self::randomSecret(64),
                'metricsToken' => self::randomSecret(48),
                's3AccessKey' => 'kitsune' . bin2hex(random_bytes(8)),
                's3SecretKey' => self::randomSecret(48),
            ];
        }
        if ($product === 'test') {
            return [
                'repositoryUrl' => $values['testRepositoryUrl'],
                'repositoryBranch' => $values['testRepositoryBranch'],
                'repositoryPath' => $values['testRepositoryPath'],
                'gitUsername' => $values['testGitUsername'],
                'publicDomain' => $values['testPublicDomain'],
                'proxyMode' => 'managed',
                'apiPublicUrl' => $values['testApiUrl'],
                'webPublicUrl' => $values['testPublicWebUrl'],
                'healthUrl' => $values['testHealthUrl'],
                'suiteHubUrl' => $values['publicUrl'],
                'suiteColabUrl' => $values['colabApiUrl'],
                'suiteOrganizationId' => $values['testOrganizationId'],
                'suiteOrganizationName' => $values['suiteOrganizationName'],
                'suiteControlEnabled' => '1',
                'gitToken' => self::secret('testGitToken'),
                'gitSshKnownHosts' => $values['testGitSshKnownHosts'],
                'gitSshPrivateKey' => self::secret('testGitSshPrivateKey'),
                'suiteSharedSecret' => $shared,
                'jwtSecret' => self::randomSecret(64),
                'masterKey' => self::randomSecret(64),
                'githubWebhookSecret' => self::randomSecret(64),
                'databasePassword' => self::randomSecret(48),
                'redisPassword' => self::randomSecret(48),
                'minioAccessKey' => 'kitsune' . bin2hex(random_bytes(8)),
                'minioSecretKey' => self::randomSecret(48),
            ];
        }
        throw new InvalidArgumentException('Unknown Kitsune Suite product.');
    }

    public static function readState()
    {
        $empty = [
            'updatedAt' => null,
            'lastOperation' => null,
            'lastSuccess' => null,
            'lastError' => null,
            'commit' => null,
            'deployedCommit' => null,
            'applicationVersion' => null,
            'repository' => [],
            'localModules' => [],
            'availableModules' => [],
            'deployedModules' => [],
            'statusErrors' => [
                'repository' => null,
                'docker' => null,
            ],
            'services' => [],
            'docker' => [],
            'proxy' => [],
            'suite' => [
                'checkedAt' => null,
                'products' => [],
                'lastOperation' => null,
                'lastError' => null,
            ],
            'log' => [],
        ];
        $path = pm_Context::getVarDir() . '/state.json';
        if (!is_file($path)) return $empty;
        $decoded = json_decode((string) file_get_contents($path), true);
        return is_array($decoded) ? array_replace_recursive($empty, $decoded) : $empty;
    }

    private static function hostedDomain($name)
    {
        $name = strtolower(trim((string) $name));
        try {
            $domain = pm_Domain::getByName($name);
        } catch (Throwable $exception) {
            throw new RuntimeException('Selected Plesk domain is unavailable: ' . $name, 0, $exception);
        }
        if (!$domain instanceof pm_Domain || !$domain->hasHosting() || !$domain->isActive() || $domain->isSuspended() || $domain->isDisabled()) {
            throw new RuntimeException('Selected Plesk domain must be active and have web hosting: ' . $name);
        }
        return $domain;
    }

    private static function secret($field)
    {
        $setting = self::SECRETS[$field] ?? null;
        if ($setting === null) return '';
        try { return (string) pm_Settings::getDecrypted($setting); }
        catch (Exception $exception) { return ''; }
    }

    private static function normalizeSecret($field, $value)
    {
        $value = self::normalizeMultiline($value);
        if (in_array($field, ['gitSshPrivateKey', 'colabGitSshPrivateKey', 'testGitSshPrivateKey'], true) && strpos($value, 'PRIVATE KEY') === false) {
            throw new RuntimeException('Invalid SSH private key.');
        }
        return $value;
    }

    private static function normalizeMultiline($value)
    {
        $value = str_replace(["\r\n", "\r"], "\n", (string) $value);
        if (strncmp($value, "\xEF\xBB\xBF", 3) === 0) {
            $value = substr($value, 3);
        }
        return trim($value);
    }

    private static function randomSecret($bytes)
    {
        return rtrim(strtr(base64_encode(random_bytes((int) $bytes)), '+/', '-_'), '=');
    }
}
