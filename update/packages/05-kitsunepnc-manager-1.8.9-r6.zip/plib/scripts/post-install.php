<?php

pm_Context::init('kitsunepnc-manager');
require_once dirname(__DIR__) . '/library/Config.php';
$varDir = pm_Context::getVarDir();
if (!is_dir($varDir)) mkdir($varDir, 0700, true);
@chmod($varDir, 0700);
$currentState = Modules_KitsunepncManager_Config::readState();
if (pm_Settings::get('proxyMode') === null && !empty($currentState['proxy']['configuredAt'])) {
    pm_Settings::set('proxyMode', 'managed');
}
foreach (Modules_KitsunepncManager_Config::defaults() as $key => $value) {
    if (pm_Settings::get($key) === null) pm_Settings::set($key, (string) $value);
}
$productRoot = defined('PRODUCT_ROOT_D') ? PRODUCT_ROOT_D : '/usr/local/psa';
$utility = $productRoot . '/admin/sbin/modules/kitsunepnc-manager/kitsunepnc-manager';
if (is_file($utility)) @chmod($utility, 0750);
