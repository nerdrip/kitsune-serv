# KitsunePNC Deployment Manager 1.8.9 dla Pleska

Rozszerzenie jest przeznaczone dla administratora **Plesk Obsidian 18.0.41+ na
Linuxie**. Zarządza dedykowaną kopią wdrożeniową KitsunePNC; nie należy używać tego
katalogu do pracy developerskiej.

## Wymagania

- Plesk Obsidian 18.0.41 lub nowszy;
- `git` oraz Docker Engine z Compose v2; Node.js, pnpm, Python i kompilatory nie
  są wymagane na hoście produkcyjnym, ponieważ build i narzędzia danych działają
  w kontrolowanych obrazach Docker;
- administrator Pleska i dostęp do repozytorium;
- domena z certyfikatem TLS oraz rozszerzenie Docker Pleska, jeśli wybierasz
  zalecany tryb Docker Proxy Rules.

## Instalacja

Paczka ZIP ma `meta.xml` w katalogu głównym. Można ją wysłać w **Rozszerzenia →
Moje rozszerzenia** albo zainstalować przez SSH:

```bash
plesk bin extension -i /root/KitsunePNC-Plesk-Manager-1.8.9-YYYYMMDD-HHMMSS.zip
```

Aktualizacja: `plesk bin extension -g PACZKA.zip`. Usunięcie rozszerzenia nie usuwa
repozytorium, danych, backupów, kontenerów ani wolumenów.

Zadania rozszerzenia nie używają hostowego `pnpm`. Dockerfile serwera i edytora
budują zależności w Node 20. Backup i restore korzystają z tego samego obrazu
`collab-server` w jednorazowym kontenerze bez sieci i bez dostępu do innych
katalogów serwera.

Manager ustawia `deploy/Caddyfile` na `0644` przed buildem, a Dockerfile wymusza
ten sam tryb w obrazie. Plik nie zawiera sekretów; zmiana zapobiega błędowi
`permission denied`, gdy repozytorium zostało sklonowane przez zadanie z
`umask 0077`.

## Konfiguracja

1. Podaj repozytorium HTTPS/SSH, branch i dedykowany katalog, np. `/home/pnc/source`
   albo `/opt/kitsunepnc/source`.
2. `deployPath` musi wskazywać jego podkatalog `deploy`.
3. Dane i backupy trzymaj poza repozytorium, np. `/var/lib/kitsunepnc` i
   `/var/backups/kitsunepnc`.
4. Ustaw istniejącą domenę Pleska, publiczny URL HTTPS, lokalne porty oraz
   konkretne adresy `ADMIN_EMAILS`.
5. Wygeneruj cztery różne sekrety: JWT, refresh JWT, szyfrowanie danych i metryki
   (każdy co najmniej 32 znaki).
6. Jeśli konta mają wymagać aktywacji e-mail, skonfiguruj SMTP.
7. Dla prywatnego Git użyj tokenu HTTPS albo read-only deploy key SSH. Sekrety są
   przechowywane przez `pm_Settings::setEncrypted`.

Token HTTPS trafia do tymczasowego `GIT_ASKPASS`, nie do URL ani argumentów. Klucz
SSH istnieje jako plik `0600` tylko na czas operacji, używa `IdentitiesOnly` i
`StrictHostKeyChecking=yes`.

## Kitsune Suite

Zakładka **Kitsune Suite** wykrywa osobne rozszerzenia KitsuneColab i
KitsuneTest i sprawdza ich manifesty API. Jeśli pluginu brakuje, pokazuje jego
konfigurację i potrafi zbudować oraz zainstalować go bezpośrednio z podanego
repozytorium; gotowy ZIP pozostaje obsługiwany. Po instalacji osobny manager
produktu przejmuje ustawienia, a Hub nie nadpisuje ich przy aktualizacji. Po
ustawieniu URL-i i wspólnego sekretu Hub automatycznie tworzy odpowiadające
projekty i odbiera issue oraz wyniki testów. Delegowany deploy i backup wymagają
osobnego opt-in w managerze danego produktu. Szczegóły opisuje dołączony
`KITSUNE_SUITE.md`.

## Aktualizacja i wdrożenie

- **Sprawdź** — pobiera informacje o `origin`, ale nie zmienia lokalnego kodu ani
  działających kontenerów.
- **Zaktualizuj lokalną kopię** — `fetch` i `merge --ff-only`; lokalne zmiany
  blokują operację, a działające moduły nie są restartowane.
- **Wdróż** — buduje tylko zaznaczone moduły z lokalnej kopii kodu.
- **Pobierz i wdróż** — łączy bezpieczny fast-forward z selektywnym wdrożeniem.
- **Serwer współpracy** obejmuje `collab-server` i `worker`, ponieważ oba używają
  tego samego obrazu. Jego aktualizacja tworzy backup istniejącej bazy.
- **Edytor webowy** obejmuje kontener `web` i może być aktualizowany niezależnie.
- Start, stop, restart i surowe logi kontenerów obsługuje rozszerzenie Docker
  Pleska; nie są duplikowane w managerze aplikacji.

## Dane i backup

- **Backup** — SQLite oraz blob storage, manifest wersji, rozmiary i SHA-256.
- **Restore** — wymaga ścieżki pod katalogiem backupów i tekstu
  `RESTORE:<nazwa-katalogu>`, weryfikuje całą kopię, zatrzymuje API, migruje,
  uruchamia usługi i sprawdza readiness.

Operacje są serializowane przez `flock`. Log ma maksymalnie 300 wierszy, a wartości
sekretów są maskowane przed zapisaniem.

## Platforma, reverse proxy i dane

Compose uruchamia API, worker i edytor webowy. Kontener web jest przypięty tylko
do `127.0.0.1`. Zalecany tryb publikuje go przez **Docker Proxy Rules** w domenie
Pleska: reguła `/`, kontener `web`, mapowanie wewnętrznego portu 80 na stały port
hosta (domyślnie 18080). Alternatywny tryb zapisuje zarządzany fragment
`vhost_nginx.conf` i uruchamia `httpdmng --reconfigure-domain`.
Automatyczny fragment nie tworzy gołego `location /`; używa osobnej reguły
regexowej, pomija `/.well-known` i przerywa operację, jeśli wykryje istniejący
konflikt w dodatkowej konfiguracji vhosta.

Dashboard pokazuje osobno dwa moduły wdrożeniowe. Każdy porównuje wersję wdrożoną,
wersję lokalnej kopii oraz wersję dostępną w `origin`. Niżej widoczne są trzy
kontenery wraz ze stanem procesu, healthcheckiem, obrazem, wersją i portami. Osobne
zmienne `KPC_SERVER_VERSION` i `KPC_WEB_VERSION` zapobiegają przypadkowej zmianie
niewybranego modułu. Stan trwały jest przechowywany przez bind mount z
`KPC_DATA_DIR`. Backup off-site powinien zostać dodatkowo zaszyfrowany poza
rozszerzeniem.

Kontener `web` sprawdza własny endpoint Caddy `/healthz`; gotowość API oraz
workera jest mierzona osobno. Jeśli `docker compose up --wait` nie powiedzie się,
zadanie pokazuje tabelę stanu i końcówkę logów usług. Sam błąd startu nie usuwa
bazy, blobów, konfiguracji ani backupów.

Pełna polska instrukcja instalacji, tworzenia kont, zaproszeń i odbioru znajduje
się w [`docs/PLESK_COLLABORATION.md`](../../../docs/PLESK_COLLABORATION.md).

## Walidacja lokalna

```bash
pnpm package:plesk
```

Pakowacz sprawdza strukturę, XML, JavaScript, PHP, końce linii skryptu `sbin`,
zawartość ZIP-a i tworzy osobny plik `.sha256`. Ta walidacja nie zastępuje próby
instalacji na testowym Plesku.
