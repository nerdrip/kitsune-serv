(() => {
  function initializeTabs() {
    const tabs = Array.from(document.querySelectorAll('[data-kpc-tab]'));
    const panels = Array.from(document.querySelectorAll('[data-kpc-panel]'));
    if (!tabs.length || !panels.length) return;

    const activate = (name, remember) => {
      let found = false;
      panels.forEach((panel) => {
        const active = panel.getAttribute('data-kpc-panel') === name;
        panel.hidden = !active;
        if (active) found = true;
      });
      if (!found) return activate('status', remember);
      tabs.forEach((tab) => {
        const active = tab.getAttribute('data-kpc-tab') === name;
        tab.classList.toggle('is-active', active);
        tab.setAttribute('aria-selected', active ? 'true' : 'false');
        tab.setAttribute('tabindex', active ? '0' : '-1');
      });
      if (remember) {
        try {
          window.sessionStorage.setItem('kitsunepnc-manager-tab', name);
        } catch (_error) {
          /* storage is optional */
        }
      }
    };

    tabs.forEach((tab) => {
      tab.addEventListener('click', () => {
        activate(tab.getAttribute('data-kpc-tab'), true);
      });
      tab.addEventListener('keydown', (event) => {
        if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
        event.preventDefault();
        const index = tabs.indexOf(tab);
        const direction = event.key === 'ArrowRight' ? 1 : -1;
        const target = tabs[(index + direction + tabs.length) % tabs.length];
        target.focus();
        activate(target.getAttribute('data-kpc-tab'), true);
      });
    });

    const requested = document.querySelector('.kpc-shell')?.getAttribute('data-kpc-active-tab');
    let initial = requested || 'status';
    if (!requested) {
      try {
        initial = window.sessionStorage.getItem('kitsunepnc-manager-tab') || initial;
      } catch (_error) {
        /* storage is optional */
      }
    }
    activate(initial, false);
  }

  function initializeOperations() {
    const form = document.querySelector('#kpc-operation-form');
    const operation = form?.querySelector('[name="operation"]');
    const submit = form?.querySelector('[type="submit"]');
    if (!form || !operation) return;

    const labels = {
      check: 'Sprawdź repozytorium i wersje',
      sync: 'Zaktualizuj lokalną kopię kodu',
      deploy: 'Wdróż wybrane moduły',
      'sync-deploy': 'Pobierz i wdróż wybrane moduły',
    };
    const update = () => {
      const value = operation.value;
      const deploys = value === 'deploy' || value === 'sync-deploy';
      const sectionRow = form.querySelector('.kpc-form-section')?.closest('.form-row');
      if (sectionRow) sectionRow.hidden = !deploys;
      for (const name of ['moduleServer', 'moduleWeb']) {
        const row = form.querySelector(`[name="${name}"]`)?.closest('.form-row');
        if (row) row.hidden = !deploys;
      }
      if (submit) {
        submit.textContent = labels[value] || 'Uruchom operację';
      }
    };

    operation.addEventListener('change', update);
    form.addEventListener('submit', () => {
      if (!submit) return;
      try {
        window.sessionStorage.setItem('kitsunepnc-manager-tab', 'deploy');
      } catch (_error) {
        /* storage is optional */
      }
      submit.disabled = true;
      submit.textContent = 'Dodawanie zadania do kolejki…';
    });
    update();

    const refresh = document.querySelector('[data-kpc-refresh]');
    if (refresh) {
      refresh.addEventListener('click', () => {
        refresh.disabled = true;
        refresh.textContent = 'Odświeżanie…';
        try {
          window.sessionStorage.setItem('kitsunepnc-manager-tab', 'status');
        } catch (_error) {
          /* storage is optional */
        }
        window.location.reload();
      });
    }
  }

  function initializeMaintenance() {
    const form = document.querySelector('#kpc-maintenance-form');
    const operation = form?.querySelector('[name="maintenanceOperation"]');
    const restorePath = form?.querySelector('[name="restorePath"]');
    const confirmation = form?.querySelector('[name="confirmation"]');
    const submit = form?.querySelector('[type="submit"]');
    if (!form || !operation) return;
    const update = () => {
      const restoring = operation.value === 'restore';
      for (const input of [restorePath, confirmation]) {
        const row = input?.closest('.form-row');
        if (row) row.hidden = !restoring;
        if (input) input.required = restoring;
      }
      if (submit)
        submit.textContent = restoring ? 'Przywróć wskazany backup' : 'Utwórz pełny backup';
    };
    operation.addEventListener('change', update);
    form.addEventListener('submit', (event) => {
      if (
        operation.value === 'restore' &&
        !window.confirm(
          'Przywrócić wskazany backup? Bieżące dane zostaną zastąpione zawartością kopii.',
        )
      ) {
        event.preventDefault();
        return;
      }
      if (submit) {
        submit.disabled = true;
        submit.textContent =
          operation.value === 'restore'
            ? 'Dodawanie restore do kolejki…'
            : 'Dodawanie backupu do kolejki…';
      }
      try {
        window.sessionStorage.setItem('kitsunepnc-manager-tab', 'data');
      } catch (_error) {
        /* storage is optional */
      }
    });
    update();
  }

  function initializeConfigValidation() {
    const form = document.querySelector('#kpc-config-form');
    const summary = document.querySelector('[data-kpc-config-errors]');
    if (!form || !summary) return;
    const field = (name) => form.elements.namedItem(name);
    const value = (name) => String(field(name)?.value || '').trim();
    const pathPattern = /^\/(?:home|opt|srv|var\/lib|var\/backups)\/[A-Za-z0-9._/-]+$/;
    const add = (errors, name, message) => errors.push({ field: name, message });
    const fieldLabel = (name) => {
      const input = field(name);
      const label = input?.closest('.form-row')?.querySelector('label');
      return String(label?.textContent || name)
        .replace(/\s*\*\s*$/, '')
        .trim();
    };

    const repositoryInput = field('repositoryPath');
    const deployInput = field('deployPath');
    const domainInput = field('domain');
    const publicUrlInput = field('publicUrl');
    const proxyModeInput = field('proxyMode');
    const manualVhost = form.querySelector('[data-kpc-manual-vhost]');
    const vhostCode = form.querySelector('[data-kpc-vhost-code]');
    const suiteDomainPlan = form.querySelector('[data-kpc-suite-domain-plan]');
    const defaultsButton = form.querySelector('[data-kpc-fill-defaults]');
    let previousRepositoryPath = value('repositoryPath').replace(/\/+$/, '');
    repositoryInput?.addEventListener('input', () => {
      const nextRepositoryPath = value('repositoryPath').replace(/\/+$/, '');
      const currentDeployPath = value('deployPath').replace(/\/+$/, '');
      if (!currentDeployPath || currentDeployPath === `${previousRepositoryPath}/deploy`) {
        deployInput.value = nextRepositoryPath ? `${nextRepositoryPath}/deploy` : '';
      }
      previousRepositoryPath = nextRepositoryPath;
    });

    const syncPublicUrl = () => {
      const domain = value('domain').toLowerCase();
      if (domain && publicUrlInput) publicUrlInput.value = `https://${domain}`;
    };
    const baseDomain = (domain) => {
      const labels = String(domain || '').toLowerCase().split('.').filter(Boolean);
      return labels.length > 2 ? labels.slice(1).join('.') : labels.join('.');
    };
    const setSelectIfAvailable = (name, candidates) => {
      const input = field(name);
      if (!input || input.tagName !== 'SELECT') return '';
      const candidate = candidates.find((item) => Array.from(input.options).some((option) => option.value === item));
      if (candidate) input.value = candidate;
      return String(input.value || '');
    };
    const syncSuiteUrls = (suggestDomains) => {
      const hubDomain = value('domain').toLowerCase();
      const base = baseDomain(hubDomain);
      if (!base) return;
      const colabWeb = suggestDomains ? setSelectIfAvailable('colabPublicDomain', [`colab.${base}`]) : value('colabPublicDomain');
      const colabApi = colabWeb;
      const testWeb = suggestDomains ? setSelectIfAvailable('testPublicDomain', [`test.${base}`, `tests.${base}`]) : value('testPublicDomain');
      const testApi = testWeb;
      // A missing matching subdomain means "propose it", never erase an
      // administrator's existing manual URL.
      const write = (name, url) => { const input = field(name); if (input && url) input.value = url; };
      write('colabPublicWebUrl', colabWeb ? `https://${colabWeb}` : '');
      write('colabApiUrl', colabApi ? `https://${colabApi}` : '');
      write('testPublicWebUrl', testWeb ? `https://${testWeb}` : '');
      write('testApiUrl', testApi ? `https://${testApi}` : '');
      write('testHealthUrl', testApi ? `https://${testApi}/readyz` : '');
      if (suiteDomainPlan) {
        const line = (title, found, suggested) => found
          ? `<li><b>${title}:</b> https://${found}</li>`
          : `<li><b>${title}:</b> utwórz w Plesku <code>${suggested}</code></li>`;
        suiteDomainPlan.innerHTML = `<strong>Plan adresów Suite dla ${hubDomain}</strong><span>Po zmianie domeny wybieramy istniejące subdomeny; brakujące są pokazane jako propozycje do utworzenia.</span><ul>${line('Hub', hubDomain, hubDomain)}${line('Colab', colabWeb, `colab.${base}`)}${line('API Colaba', colabApi, `api.colab.${base}`)}${line('KitsuneTest', testWeb, `test.${base}`)}${line('API Test', testApi, `api.test.${base}`)}</ul>`;
      }
    };
    const updateManualVhost = () => {
      const manual = proxyModeInput?.value === 'docker';
      if (manualVhost) manualVhost.hidden = !manual;
      if (!manual || !vhostCode) return;
      const port = value('httpPort') || '18080';
      vhostCode.textContent = `# BEGIN KITSUNEPNC MANAGED REVERSE PROXY\nlocation ~ ^/(?!\\.well-known(?:/|$)).* {\n    proxy_pass http://127.0.0.1:${port};\n    proxy_http_version 1.1;\n    proxy_set_header Host $host;\n    proxy_set_header X-Real-IP $remote_addr;\n    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;\n    proxy_set_header X-Forwarded-Proto $scheme;\n    proxy_set_header Upgrade $http_upgrade;\n    proxy_set_header Connection "upgrade";\n    proxy_read_timeout 300s;\n    proxy_buffering off;\n    client_max_body_size 60m;\n}\n# END KITSUNEPNC MANAGED REVERSE PROXY`;
    };
    domainInput?.addEventListener('change', () => { syncPublicUrl(); syncSuiteUrls(true); });
    ['colabPublicDomain', 'testPublicDomain'].forEach((name) => field(name)?.addEventListener('change', () => syncSuiteUrls(false)));
    proxyModeInput?.addEventListener('change', updateManualVhost);
    field('httpPort')?.addEventListener('input', updateManualVhost);
    defaultsButton?.addEventListener('click', () => {
      const defaults = {
        repositoryPath: '/opt/kitsunepnc/source',
        deployPath: '/opt/kitsunepnc/source/deploy',
        dataPath: '/var/lib/kitsunepnc',
        backupPath: '/var/backups/kitsunepnc',
        backupKeep: '14',
        httpPort: '18080',
        httpsPort: '18443',
        repositoryBranch: 'main',
      };
      Object.entries(defaults).forEach(([name, fallback]) => {
        const input = field(name);
        if (input && !String(input.value || '').trim()) input.value = fallback;
      });
      syncPublicUrl();
      syncSuiteUrls(true);
      defaultsButton.textContent = 'Domyślne wartości uzupełnione';
    });

    syncSuiteUrls(false);
    updateManualVhost();

    const validate = () => {
      const errors = [];
      const repositoryUrl = value('repositoryUrl');
      const repositoryPath = value('repositoryPath').replace(/\/+$/, '');
      const deployPath = value('deployPath').replace(/\/+$/, '');
      const dataPath = value('dataPath').replace(/\/+$/, '');
      const backupPath = value('backupPath').replace(/\/+$/, '');
      const domain = value('domain').toLowerCase();
      const publicUrl = value('publicUrl').replace(/\/+$/, '');
      const httpPort = Number(value('httpPort'));
      const httpsPort = Number(value('httpsPort'));
      const backupKeep = Number(value('backupKeep'));
      const smtpPort = Number(value('smtpPort'));
      if (!/^(https:\/\/|ssh:\/\/|git@)/.test(repositoryUrl)) {
        add(errors, 'repositoryUrl', 'Adres musi zaczynać się od https://, ssh:// albo git@.');
      }
      if (!/^(?![-.])(?!.*\.\.)(?!.*@\{)[A-Za-z0-9._/-]+$/.test(value('repositoryBranch'))) {
        add(
          errors,
          'repositoryBranch',
          'Nazwa gałęzi nie może zawierać spacji, sekwencji .. ani @{.',
        );
      }
      for (const [name, path] of [
        ['repositoryPath', repositoryPath],
        ['deployPath', deployPath],
        ['dataPath', dataPath],
        ['backupPath', backupPath],
      ]) {
        if (!pathPattern.test(path) || path.split('/').includes('..')) {
          add(
            errors,
            name,
            'Użyj pełnej ścieżki zaczynającej się od /home, /opt, /srv, /var/lib albo /var/backups, bez segmentu "..".',
          );
        }
      }
      if (deployPath !== `${repositoryPath}/deploy`) {
        add(errors, 'deployPath', `Wpisz dokładnie ${repositoryPath}/deploy.`);
      }
      for (const [name, path] of [
        ['dataPath', dataPath],
        ['backupPath', backupPath],
      ]) {
        if (path === repositoryPath || path.startsWith(`${repositoryPath}/`)) {
          add(errors, name, 'Dane i backupy muszą znajdować się poza katalogiem kodu.');
        }
      }
      if (!Number.isInteger(backupKeep) || backupKeep < 1 || backupKeep > 365) {
        add(errors, 'backupKeep', 'Wpisz liczbę od 1 do 365.');
      }
      if (!/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(domain)) {
        add(errors, 'domain', 'Wybierz albo wpisz poprawną domenę, np. hub.example.com.');
      }
      if (publicUrl !== `https://${domain}`) {
        add(errors, 'publicUrl', `Wpisz dokładnie https://${domain} bez dodatkowej ścieżki.`);
      }
      if (!Number.isInteger(httpPort) || httpPort < 1024 || httpPort > 65535) {
        add(errors, 'httpPort', 'Wpisz wolny port od 1024 do 65535.');
      }
      if (!Number.isInteger(httpsPort) || httpsPort < 1024 || httpsPort > 65535) {
        add(errors, 'httpsPort', 'Wpisz wolny port od 1024 do 65535.');
      } else if (httpPort === httpsPort) {
        add(errors, 'httpsPort', 'Port HTTPS musi różnić się od portu HTTP.');
      }
      if (!Number.isInteger(smtpPort) || smtpPort < 1 || smtpPort > 65535) {
        add(errors, 'smtpPort', 'Wpisz port od 1 do 65535.');
      }
      if (value('requireEmailVerification') === 'true' && !value('smtpHost')) {
        add(errors, 'smtpHost', 'Serwer SMTP jest wymagany przy włączonej weryfikacji e-mail.');
      }
      for (const email of value('adminEmails')
        .split(',')
        .map((item) => item.trim())
        .filter(Boolean)) {
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
          add(errors, 'adminEmails', `Nieprawidłowy adres: ${email}. Adresy rozdziel przecinkami.`);
          break;
        }
      }
      const secrets = ['jwtSecret', 'jwtRefreshSecret', 'dataEncryptionKey', 'metricsToken']
        .map((name) => ({ name, value: value(name) }))
        .filter((item) => item.value !== '');
      for (const secret of secrets) {
        if (secret.value.length < 32) {
          add(
            errors,
            secret.name,
            `Sekret musi mieć co najmniej 32 znaki; obecnie ma ${secret.value.length}.`,
          );
        }
      }
      if (new Set(secrets.map((item) => item.value)).size !== secrets.length) {
        add(errors, 'jwtSecret', 'Każdy z czterech sekretów musi mieć inną wartość.');
      }
      if (value('gitSshPrivateKey') && !value('gitSshPrivateKey').includes('PRIVATE KEY')) {
        add(
          errors,
          'gitSshPrivateKey',
          'Wklej kompletny klucz prywatny PEM/OpenSSH albo pozostaw pole puste.',
        );
      }
      return errors;
    };

    form.addEventListener('submit', (event) => {
      form
        .querySelectorAll('.kpc-client-invalid')
        .forEach((row) => row.classList.remove('kpc-client-invalid'));
      form
        .querySelectorAll('[aria-invalid="true"]')
        .forEach((input) => input.removeAttribute('aria-invalid'));
      form.querySelectorAll('.kpc-field-error').forEach((message) => message.remove());
      const errors = validate();
      if (!errors.length) { summary.hidden = true; return; }
      const heading = document.createElement('strong');
      heading.textContent = `Sprawdzanie po stronie serwera potwierdzi zapis. Zwróć uwagę na ${errors.length === 1 ? 'to pole' : `${errors.length} pól`}:`;
      const list = document.createElement('ul');
      for (const error of errors) {
        const item = document.createElement('li');
        item.textContent = `${fieldLabel(error.field)}: ${error.message}`;
        list.appendChild(item);
        const input = field(error.field);
        input?.setAttribute('aria-invalid', 'true');
        input?.closest('.form-row')?.classList.add('kpc-client-invalid');
        if (input) {
          const inlineMessage = document.createElement('div');
          inlineMessage.className = 'kpc-field-error';
          inlineMessage.textContent = error.message;
          input.insertAdjacentElement('afterend', inlineMessage);
        }
      }
      summary.replaceChildren(heading, list);
      summary.hidden = false;
      try {
        window.sessionStorage.setItem('kitsunepnc-manager-tab', 'config');
      } catch (_error) {
        /* storage is optional */
      }
    });
  }

  function initializeLogCopy() {
    const button = document.querySelector('[data-kpc-copy-log]');
    const log = document.querySelector('[data-kpc-log]');
    if (!button || !log) {
      if (button) button.hidden = true;
      return;
    }
    button.addEventListener('click', () => {
      const value = log.textContent || '';
      const completed = () => {
        button.textContent = 'Skopiowano';
        window.setTimeout(() => {
          button.textContent = 'Kopiuj dziennik';
        }, 1600);
      };
      if (navigator.clipboard?.writeText) {
        navigator.clipboard
          .writeText(value)
          .then(completed)
          .catch(() => {});
        return;
      }
      const textarea = document.createElement('textarea');
      textarea.value = value;
      textarea.setAttribute('readonly', 'readonly');
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      if (document.execCommand('copy')) completed();
      document.body.removeChild(textarea);
    });
  }

  function initializeSuite() {
    const form = document.querySelector('#kpc-suite-form');
    if (!form) return;
    const operation = form.querySelector('[name="suiteOperation"]');
    const packageField = form.querySelector('[name="suitePackage"]');
    if (!operation || !packageField) return;
    const row = packageField.closest('.form-row, .form-group, .field-row, li, div');
    const update = () => {
      const installing = operation.value === 'suite-install';
      packageField.required = installing;
      packageField.disabled = !installing;
      if (row) row.hidden = !installing;
    };
    operation.addEventListener('change', update);
    update();
  }

  function initialize() {
    initializeTabs();
    initializeOperations();
    initializeMaintenance();
    initializeConfigValidation();
    initializeSuite();
    initializeLogCopy();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize);
  else initialize();
})();
