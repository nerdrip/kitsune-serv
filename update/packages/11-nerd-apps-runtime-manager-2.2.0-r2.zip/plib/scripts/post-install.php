<?php

pm_Context::init('nerd-apps-runtime-manager');
$configLibrary = dirname(__DIR__) . '/library/Config.php';
require_once $configLibrary;
$varDir = pm_Context::getVarDir();
if (!is_dir($varDir)) mkdir($varDir, 0700, true);
@chmod($varDir, 0700);
foreach (Modules_NerdAppsRuntimeManager_Config::deploymentDefaults() as $key => $value) {
    if (pm_Settings::get('deploy_' . $key) === null) pm_Settings::set('deploy_' . $key, (string) $value);
}
foreach (Modules_NerdAppsRuntimeManager_Config::runtimeDefaults() as $key => $value) {
    if (pm_Settings::get('runtime_' . $key) === null) pm_Settings::set('runtime_' . $key, (string) $value);
}
foreach (Modules_NerdAppsRuntimeManager_Config::siteDefaults() as $key => $value) {
    if (pm_Settings::get('sites_' . $key) === null) pm_Settings::set('sites_' . $key, (string) $value);
}
$productRoot = defined('PRODUCT_ROOT_D') ? PRODUCT_ROOT_D : '/usr/local/psa';
foreach (['nerd-apps-runtime-manager'] as $helper) {
    $utility = $productRoot . '/admin/bin/modules/nerd-apps-runtime-manager/' . $helper;
    if (!is_file($utility)) throw new RuntimeException('Plesk nie zainstalował helpera ' . $helper . '.');
    @chmod($utility, 0750);
}
