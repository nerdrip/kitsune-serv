<?php

pm_Context::init('nerd-apps-runtime-manager');
try { (new pm_LongTask_Manager())->cancelAllTasks(); } catch (Exception $exception) {}
foreach (glob(pm_Context::getVarDir() . '/operation-*.json') ?: [] as $path) @unlink($path);
foreach (glob(pm_Context::getVarDir() . '/apps/hellbound/operation-*.json') ?: [] as $path) @unlink($path);
// Repository, runtime, persistent data and Docker volumes intentionally remain untouched.
