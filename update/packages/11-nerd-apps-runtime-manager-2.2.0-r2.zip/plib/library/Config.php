<?php

class Modules_NerdAppsRuntimeManager_Config
{
    public const EXTENSION_VERSION = '2.2.0';

    public static function productCatalog()
    {
        return [
            'rollbound' => [
                'name' => 'Rollbound',
                'source' => 'apps/rollbound',
                'modules' => ['app', 'shared', 'bot', 'benchmark'],
                'backend' => 'runtime',
                'description' => 'Pełna aplikacja, wspólny kod i bot korzystający z Nerd Apps Runtime.',
            ],
            'rollbound-light' => [
                'name' => 'Rollbound Light',
                'source' => 'apps/rollbound/light',
                'modules' => ['light'],
                'backend' => 'runtime',
                'description' => 'Lekki klient korzystający z tego samego runtime i autoryzacji NUA.',
            ],
            'sheetbound' => [
                'name' => 'Sheetbound',
                'source' => 'apps/sheetbound',
                'modules' => ['app', 'benchmark'],
                'backend' => 'runtime',
                'description' => 'Aplikacja postaci, rekordy i katalog scenariuszy przez wspólną platformę.',
            ],
            'hellbound' => [
                'name' => 'Signum Temporis: Hellbound',
                'source' => 'apps/hellbound',
                'modules' => ['app', 'core/domain', 'server', 'benchmark'],
                'backend' => 'hellbound',
                'description' => 'Klient i chroniony stos serwerowy z wydaniami, backupem oraz rollbackiem.',
            ],
            'lifebound' => [
                'name' => 'LifeBound: Atlas Temporis',
                'source' => 'apps/lifebound',
                'modules' => ['app'],
                'backend' => 'runtime',
                'description' => 'Local-first RPG codziennego życia z synchronizacją Atlasu i serwerowo weryfikowanymi zakupami.',
            ],
        ];
    }

    private const DEPLOYMENT_SECRETS = [
        'gitToken' => 'secret_git_token',
        'gitSshPrivateKey' => 'secret_git_ssh_private_key',
    ];

    private const RUNTIME_SECRETS = [
        'OPENAI_API_KEY' => 'secret_runtime_openai_api_key',
        'API_KEYS' => 'secret_runtime_api_keys',
        'NUA_TICKET_SECRETS' => 'secret_runtime_nua_ticket_secrets',
        'QDRANT_API_KEY' => 'secret_runtime_qdrant_api_key',
    ];

    public static function deploymentDefinitions()
    {
        return [
            'repositoryUrl' => self::field('Repozytorium Git', 'Repozytorium', '', 'text', 'HTTPS lub SSH do repozytorium dicex.'),
            'repositoryBranch' => self::field('Repozytorium Git', 'Gałąź', 'main'),
            'repositoryPath' => self::field('Repozytorium Git', 'Lokalna kopia repozytorium', '/opt/nerd-apps/source', 'path'),
            'sourceSubdirectory' => self::field('Repozytorium Git', 'Podkatalog runtime', 'apps/rollbound/bot', 'relative'),
            'gitUsername' => self::field('Repozytorium Git', 'Użytkownik Git HTTPS', 'x-access-token'),
            'gitToken' => self::field('Repozytorium Git', 'Token / hasło Git', '', 'password', 'Puste pole zachowuje zaszyfrowaną wartość.', true),
            'gitSshPrivateKey' => self::field('Repozytorium Git', 'Prywatny deploy key SSH', '', 'textarea-secret', 'Opcjonalny klucz tylko do odczytu.', true),
            'gitSshKnownHosts' => self::field('Repozytorium Git', 'SSH known_hosts', '', 'textarea'),
            'runtimePath' => self::field('Wdrożenie', 'Katalog wdrożenia', '/opt/nerd-apps/runtime', 'path'),
            'dataPath' => self::field('Wdrożenie', 'Katalog danych trwałych', '/opt/nerd-apps/data', 'path'),
            'backupPath' => self::field('Wdrożenie', 'Katalog backupów', '/opt/nerd-apps/backups', 'path'),
            'backupRetention' => self::field('Wdrożenie', 'Liczba backupów', '10', 'integer'),
            'bindAddress' => self::field('Wdrożenie', 'Adres nasłuchu', '127.0.0.1', 'ip'),
            'apiPort' => self::field('Wdrożenie', 'Port serwera AI', '8000', 'port'),
            'apiCpus' => self::field('Zasoby Docker', 'CPU serwera AI', '2.0', 'decimal'),
            'apiMemory' => self::field('Zasoby Docker', 'RAM serwera AI', '4g'),
            'qdrantCpus' => self::field('Zasoby Docker', 'CPU Qdrant', '2.0', 'decimal'),
            'qdrantMemory' => self::field('Zasoby Docker', 'RAM Qdrant', '2g'),
            'ollamaCpus' => self::field('Zasoby Docker', 'CPU Ollama', '8.0', 'decimal'),
            'ollamaMemory' => self::field('Zasoby Docker', 'RAM Ollama', '12g'),
            'proxyMode' => self::field('Publikacja serwera AI', 'Host i reverse proxy', 'managed', 'select', 'W trybie automatycznym plugin tworzy brakujący host Pleska i kieruje go do lokalnego runtime.', false, [
                'managed' => 'Utwórz host i zarządzaj nginx automatycznie',
                'manual' => 'Konfiguruję host i nginx ręcznie',
            ]),
            'domain' => self::field('Publikacja serwera AI', 'Serwer AI', 'ai.api.nerd.rip', 'service-host', 'Sam host, bez https:// i ścieżki. Nie musi jeszcze istnieć — plugin utworzy go pod aktywną domeną Pleska.'),
        ];
    }

    public static function runtimeDefinitions()
    {
        return [
            'RUNTIME_ENVIRONMENT' => self::field('Runtime', 'Środowisko', 'production', 'select', '', false, ['production' => 'production', 'staging' => 'staging', 'development' => 'development']),
            'LOG_LEVEL' => self::field('Runtime', 'Poziom logów', 'INFO', 'select', '', false, ['DEBUG' => 'DEBUG', 'INFO' => 'INFO', 'WARNING' => 'WARNING', 'ERROR' => 'ERROR']),
            'QDRANT_URL' => self::field('Qdrant', 'URL Qdrant', 'http://qdrant:6333'),
            'QDRANT_API_KEY' => self::field('Qdrant', 'Klucz Qdrant', '', 'password', 'Opcjonalny, przechowywany szyfrowano.', true),
            'QDRANT_IMAGE' => self::field('Qdrant', 'Obraz Docker', 'qdrant/qdrant:v1.18.2-unprivileged'),
            'QDRANT_COLLECTION' => self::field('Qdrant', 'Kolekcja', 'rollbound_docs'),
            'QDRANT_TIMEOUT_SECONDS' => self::field('Qdrant', 'Timeout [s]', '5', 'decimal'),
            'OLLAMA_BASE_URL' => self::field('Ollama', 'URL Ollama', 'http://ollama:11434'),
            'OLLAMA_IMAGE' => self::field('Ollama', 'Obraz Docker', 'ollama/ollama:0.31.1'),
            'OLLAMA_MODEL' => self::field('Ollama', 'Model', 'llama3.1:8b'),
            'TOP_K' => self::field('Retrieval', 'Liczba fragmentów TOP_K', '10', 'integer'),
            'MAX_CONTEXT_CHARS' => self::field('Retrieval', 'Maksymalny kontekst', '3800', 'integer'),
            'MIN_SOURCE_SCORE' => self::field('Retrieval', 'Minimalny score', '0.55', 'decimal'),
            'MIN_SOURCE_SCORE_CURRENT' => self::field('Retrieval', 'Score CURRENT', '0.55', 'decimal'),
            'MIN_SOURCE_SCORE_SECRET' => self::field('Retrieval', 'Score SECRET', '0.40', 'decimal'),
            'MIN_SOURCE_SCORE_TIME_LOCKED' => self::field('Retrieval', 'Score TIME_LOCKED', '0.40', 'decimal'),
            'MIN_SOURCE_SCORE_FUTURE' => self::field('Retrieval', 'Score FUTURE', '0.45', 'decimal'),
            'CHUNK_CHARS' => self::field('Retrieval', 'Rozmiar fragmentu', '650', 'integer'),
            'CHUNK_OVERLAP' => self::field('Retrieval', 'Nakładanie fragmentów', '90', 'integer'),
            'AUTH_REQUIRED' => self::field('Uwierzytelnianie', 'Wymagaj uwierzytelnienia', 'true', 'boolean'),
            'ALLOWED_APP_IDS' => self::field('Uwierzytelnianie', 'Dozwolone aplikacje', 'rollbound,rollbound-light,sheetbound,lifebound'),
            'API_KEYS' => self::field('Uwierzytelnianie', 'Klucze administracyjne API', '', 'password', 'Lista po przecinku; szyfrowana.', true),
            'NUA_TICKET_SECRETS' => self::field('Uwierzytelnianie', 'Sekrety biletów NUA', '', 'password', 'Kolejność: stary,nowy podczas rotacji.', true),
            'NUA_TICKET_AUDIENCE' => self::field('Uwierzytelnianie', 'Audience NUA', 'nerd-apps-runtime'),
            'NUA_TICKET_ISSUER' => self::field('Uwierzytelnianie', 'Issuer NUA', 'https://api.nerd.rip'),
            'ALLOW_DEBUG_OVERRIDES' => self::field('Uwierzytelnianie', 'Pozwól na debug overrides', 'false', 'boolean'),
            'CORS_ORIGINS' => self::field('HTTP', 'Dozwolone originy CORS', 'https://api.nerd.rip'),
            'RATE_LIMIT_REQUESTS' => self::field('Limity', 'Żądania w oknie', '30', 'integer'),
            'RATE_LIMIT_WINDOW_SECONDS' => self::field('Limity', 'Długość okna [s]', '60', 'integer'),
            'RATE_LIMIT_MAX_CLIENTS' => self::field('Limity', 'Maks. klientów w pamięci', '10000', 'integer'),
            'OPENAI_API_KEY' => self::field('OpenAI i obrazy', 'Klucz OpenAI', '', 'password', 'Szyfrowany przez Pleska.', true),
            'OPENAI_BASE_URL' => self::field('OpenAI i obrazy', 'Bazowy URL OpenAI', 'https://api.openai.com/v1'),
            'OPENAI_MODEL' => self::field('OpenAI i obrazy', 'Model czatu', 'gpt-4o-mini'),
            'OPENAI_IMAGE_MODEL' => self::field('OpenAI i obrazy', 'Model obrazów', 'gpt-image-2'),
            'OPENAI_IMAGE_SIZE' => self::field('OpenAI i obrazy', 'Rozmiar obrazu', '1024x1536', 'select', '', false, ['1024x1536' => '1024x1536 (portret)', '1536x1024' => '1536x1024 (poziomo)', '1024x1024' => '1024x1024 (kwadrat)', 'auto' => 'auto']),
            'OPENAI_IMAGE_QUALITY' => self::field('OpenAI i obrazy', 'Jakość obrazu', 'medium', 'select', '', false, ['low' => 'low', 'medium' => 'medium', 'high' => 'high', 'auto' => 'auto']),
            'OPENAI_IMAGE_FORMAT' => self::field('OpenAI i obrazy', 'Format obrazu', 'png', 'select', '', false, ['png' => 'png', 'jpeg' => 'jpeg', 'webp' => 'webp']),
            'OPENAI_IMAGE_COMPRESSION' => self::field('OpenAI i obrazy', 'Kompresja JPEG/WebP [%]', '90', 'integer'),
            'OPENAI_IMAGE_TIMEOUT_SECONDS' => self::field('OpenAI i obrazy', 'Timeout generowania [s]', '180', 'integer'),
            'OPENAI_IMAGE_MAX_BYTES' => self::field('OpenAI i obrazy', 'Maks. rozmiar obrazu [B]', '12582912', 'integer'),
            'OPENAI_MAX_RETRIES' => self::field('OpenAI i obrazy', 'Maks. ponowień', '5', 'integer'),
            'OPENAI_BACKOFF_SECONDS' => self::field('OpenAI i obrazy', 'Backoff [s]', '1.0', 'decimal'),
            'OPENAI_CHAT_DAILY_LIMIT' => self::field('OpenAI i obrazy', 'Dzienny limit czatu / podmiot', '100', 'integer'),
            'OPENAI_IMAGE_DAILY_LIMIT' => self::field('OpenAI i obrazy', 'Dzienny limit obrazów / podmiot', '10', 'integer'),
            'IDEMPOTENCY_TTL_SECONDS' => self::field('OpenAI i obrazy', 'TTL idempotencji [s]', '900', 'integer'),
            'IDEMPOTENCY_MAX_ITEMS' => self::field('OpenAI i obrazy', 'Maks. wpisów idempotencji', '2000', 'integer'),
            'IDEMPOTENCY_MAX_RESPONSE_BYTES' => self::field('OpenAI i obrazy', 'Maks. pamięci odpowiedzi [B]', '67108864', 'integer'),
            'CACHE_TTL_SECONDS' => self::field('Cache', 'TTL odpowiedzi [s]', '900', 'integer'),
            'CACHE_MAX_ITEMS' => self::field('Cache', 'Maks. odpowiedzi', '5000', 'integer'),
            'RETRIEVAL_CACHE_TTL_SECONDS' => self::field('Cache', 'TTL retrieval [s]', '300', 'integer'),
            'RETRIEVAL_CACHE_MAX_ITEMS' => self::field('Cache', 'Maks. retrieval', '20000', 'integer'),
            'EMBED_CACHE_TTL_SECONDS' => self::field('Cache', 'TTL embeddingów [s]', '900', 'integer'),
            'EMBED_CACHE_MAX_ITEMS' => self::field('Cache', 'Maks. embeddingów', '20000', 'integer'),
            'CONVERSATION_MAX_SESSIONS' => self::field('Rozmowy', 'Maks. sesji', '1000', 'integer'),
            'CONVERSATION_MAX_TURNS' => self::field('Rozmowy', 'Maks. tur w pamięci', '10', 'integer'),
            'CONVERSATION_RETENTION_DAYS' => self::field('Rozmowy', 'Retencja [dni]', '7', 'integer'),
            'SESSION_MESSAGE_LIMIT' => self::field('Rozmowy', 'Limit wiadomości sesji', '20', 'integer'),
            'OFF_TOPIC_THRESHOLD' => self::field('Rozmowy', 'Próg off-topic', '3', 'integer'),
        ];
    }

    public static function siteDefinitions()
    {
        return [
            'studioDomain' => self::field('Domeny', 'Domena studia', '9tails.dev', 'domain', 'Niezależna strona marki; synchronizacja jej nie modyfikuje.'),
            'projectsDomain' => self::field('Domeny', 'Domena rodziny projektów', 'bound.9tails.dev', 'domain', 'Publiczny hub aplikacji i domena bazowa stron produktów.'),
            'contentDomain' => self::field('Domeny', 'Domena CMS / API', 'api.nerd.rip', 'domain', 'WordPress z wtyczką Nerd Universal Apps; jedyne miejsce edycji treści.'),
            'productManifestUrl' => self::field('WordPress', 'Manifest produktów', 'https://api.nerd.rip/wp-json/nerd-apps/v1/product-sites/manifest', 'url', 'Publiczny manifest wtyczki Nerd Universal Apps.'),
            'wordpressAdminUrl' => self::field('WordPress', 'Panel treści', 'https://api.nerd.rip/wp-admin/admin.php?page=nua-product-sites', 'url', 'Skrót do edytora stron produktowych.'),
            'productSlugs' => self::field('Produkty', 'Awaryjna lista subdomen', "roll\nrolllight\nsheet\nlife\nhell", 'textarea', 'Po jednym slugu w wierszu. Używana tylko, gdy manifest jest niedostępny.'),
            'projectsDocumentRoot' => self::field('Hosting', 'Wspólny document root', '/httpdocs', 'path', 'Katalog względem webspace Pleska; wszystkie subdomeny wskazują na ten WordPress.'),
            'studioVhostPath' => self::field('Hosting', 'Vhost studia', '', 'path'),
            'projectsVhostPath' => self::field('Hosting', 'Vhost hubu', '', 'path'),
            'projectsParentDomain' => self::field('Hosting', 'Domena nadrzędna hubu', '9tails.dev', 'domain'),
            'projectsSubdomainPrefix' => self::field('Hosting', 'Nazwa subdomeny hubu', 'bound', 'text'),
        ];
    }

    public static function siteFormDefinitions()
    {
        $definitions = self::siteDefinitions();
        return [
            'contentDomain' => array_replace($definitions['contentDomain'], [
                'section' => 'Trzy role domen',
                'label' => '1. WordPress / edycja treści',
                'type' => 'plesk-hosted-domain',
                'description' => 'Domena z WordPressem i Nerd Universal Apps, np. api.nerd.rip. Tutaj logujesz się i edytujesz wszystkie treści.',
            ]),
            'projectsDomain' => array_replace($definitions['projectsDomain'], [
                'section' => 'Trzy role domen',
                'label' => '2. Publiczny hub aplikacji',
                'type' => 'plesk-hosted-domain',
                'description' => 'Publiczna strona rodziny aplikacji, np. bound.9tails.dev. Pod nią powstaną też subdomeny produktów.',
            ]),
            'studioDomain' => array_replace($definitions['studioDomain'], [
                'section' => 'Trzy role domen',
                'label' => '3. Publiczna strona studia',
                'type' => 'plesk-hosted-domain',
                'description' => 'Publiczna strona marki, np. 9tails.dev. Wyświetla treść studia przygotowaną w WordPressie na domenie CMS.',
            ]),
        ];
    }

    public static function deploymentDefaults() { return self::defaults(self::deploymentDefinitions()); }
    public static function runtimeDefaults() { return self::defaults(self::runtimeDefinitions()); }
    public static function siteDefaults() { return self::defaults(self::siteDefinitions()); }
    public static function deploymentValues() { return self::values('deploy_', self::deploymentDefinitions()); }
    public static function runtimeValues() { return self::values('runtime_', self::runtimeDefinitions()); }
    public static function siteValues() { return self::values('sites_', self::siteDefinitions()); }

    public static function saveDeployment(array $values)
    {
        self::saveValues('deploy_', self::deploymentDefinitions(), $values, self::DEPLOYMENT_SECRETS);
    }

    public static function saveRuntime(array $values)
    {
        self::saveValues('runtime_', self::runtimeDefinitions(), $values, self::RUNTIME_SECRETS);
    }

    public static function saveSites(array $values)
    {
        self::saveValues('sites_', self::siteDefinitions(), self::normalizeSites($values), []);
    }

    public static function normalizeSites(array $values)
    {
        $content = self::hostedDomain($values['contentDomain'] ?? '', 'WordPressa / CMS');
        $projects = self::hostedDomain($values['projectsDomain'] ?? '', 'publicznego hubu aplikacji');
        $studio = self::hostedDomain($values['studioDomain'] ?? '', 'publicznej strony studia');
        $contentName = strtolower((string) $content->getName());
        $projectsName = strtolower((string) $projects->getName());
        $studioName = strtolower((string) $studio->getName());
        if (count(array_unique([$contentName, $projectsName, $studioName])) !== 3) {
            throw new RuntimeException('Domena CMS, hub aplikacji i strona studia muszą być trzema różnymi hostami.');
        }

        try { $documentRoot = (string) $projects->getDocumentRoot(true); }
        catch (Throwable $exception) { throw new RuntimeException('Plesk nie zwrócił katalogu WWW wybranej domeny WordPressa.', 0, $exception); }
        $documentRoot = '/' . ltrim(rtrim(str_replace('\\', '/', trim($documentRoot)), '/'), '/');
        if (!preg_match('#^/[A-Za-z0-9._/-]+$#', $documentRoot) || in_array('..', explode('/', $documentRoot), true)) {
            throw new RuntimeException('Katalog WWW zwrócony przez Pleska jest nieprawidłowy.');
        }

        $defaults = self::siteDefaults();
        [$projectsParentDomain, $projectsSubdomainPrefix] = self::pleskSubdomainTarget($projectsName);
        return [
            'studioDomain' => $studioName,
            'projectsDomain' => $projectsName,
            'contentDomain' => $contentName,
            'productManifestUrl' => 'https://' . $contentName . '/wp-json/nerd-apps/v1/product-sites/manifest',
            'wordpressAdminUrl' => 'https://' . $contentName . '/wp-admin/admin.php?page=nua-product-sites',
            'productSlugs' => $defaults['productSlugs'],
            'projectsDocumentRoot' => $documentRoot,
            'studioVhostPath' => (string) $studio->getVhostSystemPath(),
            'projectsVhostPath' => (string) $projects->getVhostSystemPath(),
            'projectsParentDomain' => $projectsParentDomain,
            'projectsSubdomainPrefix' => $projectsSubdomainPrefix,
        ];
    }

    public static function sharedRepositoryConfig()
    {
        $deployment = self::deploymentValues();
        foreach (self::DEPLOYMENT_SECRETS as $field => $setting) {
            $deployment[$field] = self::secret(self::DEPLOYMENT_SECRETS, $field);
        }
        return [
            'repositoryUrl' => (string) ($deployment['repositoryUrl'] ?? ''),
            'repositoryBranch' => (string) ($deployment['repositoryBranch'] ?? 'main'),
            'repositoryPath' => (string) ($deployment['repositoryPath'] ?? '/opt/nerd-apps/source'),
            'gitUsername' => (string) ($deployment['gitUsername'] ?? 'x-access-token'),
            'gitToken' => (string) ($deployment['gitToken'] ?? ''),
            'gitSshPrivateKey' => (string) ($deployment['gitSshPrivateKey'] ?? ''),
            'gitSshKnownHosts' => (string) ($deployment['gitSshKnownHosts'] ?? ''),
        ];
    }

    public static function hasDeploymentSecret($field) { return self::secret(self::DEPLOYMENT_SECRETS, $field) !== ''; }
    public static function hasRuntimeSecret($field) { return self::secret(self::RUNTIME_SECRETS, $field) !== ''; }

    public static function createRuntimeConfig($operation, array $options = [])
    {
        $varDir = rtrim((string) pm_Context::getVarDir(), '/\\');
        if (!is_dir($varDir) && !mkdir($varDir, 0700, true) && !is_dir($varDir)) {
            throw new RuntimeException('Nie udało się utworzyć katalogu roboczego rozszerzenia.');
        }
        @chmod($varDir, 0700);
        $deployment = self::deploymentValues();
        foreach (self::DEPLOYMENT_SECRETS as $field => $setting) {
            $deployment[$field] = self::secret(self::DEPLOYMENT_SECRETS, $field);
        }
        $runtime = self::runtimeValues();
        foreach (self::RUNTIME_SECRETS as $field => $setting) {
            $runtime[$field] = self::secret(self::RUNTIME_SECRETS, $field);
        }
        $extensionOperation = in_array((string) $operation, ['extension-check', 'extension-update'], true);
        if ((!$extensionOperation && ($deployment['proxyMode'] ?? 'manual') === 'managed') || (string) $operation === 'cors') {
            $deployment = array_replace($deployment, self::serviceHostTarget($deployment['domain'] ?? '', 'serwera AI'));
        }
        $expectedExtensionCommit = trim((string) ($options['expectedExtensionCommit'] ?? ''));
        if ($expectedExtensionCommit !== '' && !preg_match('/^[a-f0-9]{40,64}$/', $expectedExtensionCommit)) {
            throw new RuntimeException('Nieprawidłowy commit oczekiwanej aktualizacji rozszerzenia.');
        }
        $payload = [
            'managerVersion' => self::EXTENSION_VERSION,
            'operation' => (string) $operation,
            'deployment' => $deployment,
            'runtime' => $runtime,
            'sites' => self::siteValues(),
            'extensionUpdate' => [
                'installedVersion' => self::EXTENSION_VERSION,
                'expectedCommit' => $expectedExtensionCommit,
            ],
            'statePath' => $varDir . '/state.json',
            'requestedAt' => gmdate('c'),
        ];
        $path = $varDir . '/operation-' . bin2hex(random_bytes(12)) . '.json';
        $json = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $oldUmask = umask(0077);
        try {
            if ($json === false || file_put_contents($path, $json, LOCK_EX) === false) {
                throw new RuntimeException('Nie udało się zapisać konfiguracji operacji.');
            }
            @chmod($path, 0600);
        } finally {
            umask($oldUmask);
        }
        return $path;
    }

    public static function readState()
    {
        $path = pm_Context::getVarDir() . '/state.json';
        if (!is_file($path)) return self::emptyState();
        $decoded = json_decode((string) file_get_contents($path), true);
        return is_array($decoded) ? array_replace_recursive(self::emptyState(), $decoded) : self::emptyState();
    }

    private static function field($section, $label, $default, $type = 'text', $description = '', $secret = false, array $options = [])
    {
        return compact('section', 'label', 'default', 'type', 'description', 'secret', 'options');
    }

    private static function defaults(array $definitions)
    {
        $result = [];
        foreach ($definitions as $key => $definition) $result[$key] = (string) $definition['default'];
        return $result;
    }

    private static function values($prefix, array $definitions)
    {
        $result = [];
        foreach ($definitions as $key => $definition) {
            if (!empty($definition['secret'])) {
                $result[$key] = '';
            } else {
                $result[$key] = (string) pm_Settings::get($prefix . $key, $definition['default']);
            }
        }
        return $result;
    }

    private static function saveValues($prefix, array $definitions, array $values, array $secretMap)
    {
        foreach ($definitions as $key => $definition) {
            if (!empty($definition['secret'])) continue;
            if (!array_key_exists($key, $values)) continue;
            $value = (string) $values[$key];
            if (($definition['type'] ?? '') === 'textarea') $value = trim(str_replace(["\r\n", "\r"], "\n", $value));
            else $value = trim($value);
            if (strpos($value, "\0") !== false || (($definition['type'] ?? '') !== 'textarea' && preg_match('/[\r\n]/', $value))) {
                throw new RuntimeException('Pole ' . $definition['label'] . ' zawiera niedozwolony znak.');
            }
            pm_Settings::set($prefix . $key, $value);
        }
        foreach ($secretMap as $field => $setting) {
            $value = trim((string) ($values[$field] ?? ''));
            if ($field === 'gitSshPrivateKey') $value = str_replace(["\r\n", "\r"], "\n", $value);
            if ($value !== '') pm_Settings::setEncrypted($setting, $value);
        }
    }

    private static function secret(array $map, $field)
    {
        $setting = $map[$field] ?? null;
        if ($setting === null) return '';
        try { return (string) pm_Settings::getDecrypted($setting); }
        catch (Exception $exception) { return ''; }
    }

    private static function hostedDomain($name, $purpose = 'reverse proxy')
    {
        $name = strtolower(trim((string) $name));
        if ($name === '') throw new RuntimeException('Wybierz domenę Pleska dla ' . $purpose . '.');
        try { $domain = pm_Domain::getByName($name); }
        catch (Throwable $exception) { throw new RuntimeException('Domena Pleska jest niedostępna: ' . $name, 0, $exception); }
        if (!$domain instanceof pm_Domain || !$domain->hasHosting() || !$domain->isActive() || $domain->isSuspended() || $domain->isDisabled()) {
            throw new RuntimeException('Domena musi być aktywna i posiadać hosting WWW.');
        }
        return $domain;
    }

    public static function serviceHostTarget($domainName, $purpose)
    {
        $domainName = strtolower(trim((string) $domainName));
        if (!preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/', $domainName)) {
            throw new RuntimeException('Wpisz prawidłowy host dla ' . $purpose . ', np. ai.api.nerd.rip.');
        }
        [$parent, $prefix] = self::pleskSubdomainTarget($domainName, $purpose);
        return [
            'domain' => $domainName,
            'pleskParentDomain' => $parent,
            'pleskSubdomain' => $prefix,
            'vhostSystemPath' => '/var/www/vhosts/system/' . $domainName,
            'vhostDocumentRoot' => '/httpdocs',
        ];
    }

    private static function pleskSubdomainTarget($domainName, $purpose = 'wybranego hosta')
    {
        $domainName = strtolower((string) $domainName);
        $bestParent = '';
        try {
            foreach ((array) pm_Domain::getAllDomains(true) as $candidate) {
                if (!$candidate instanceof pm_Domain || !$candidate->hasHosting() || !$candidate->isActive()
                    || $candidate->isSuspended() || $candidate->isDisabled()) continue;
                $name = strtolower((string) $candidate->getName());
                $suffix = '.' . $name;
                if ($domainName === $name || (strlen($domainName) > strlen($suffix) && substr($domainName, -strlen($suffix)) === $suffix)) {
                    if (strlen($name) > strlen($bestParent)) $bestParent = $name;
                }
            }
        } catch (Throwable $exception) {
            throw new RuntimeException('Nie udało się ustalić domeny nadrzędnej Pleska.', 0, $exception);
        }
        if ($bestParent === '') throw new RuntimeException('Host ' . $domainName . ' dla ' . $purpose . ' nie należy do żadnej aktywnej domeny z hostingiem w Plesku.');
        $prefix = $domainName === $bestParent ? '' : substr($domainName, 0, -strlen('.' . $bestParent));
        if ($prefix !== '' && !preg_match('/^[a-z0-9](?:[a-z0-9.-]{0,251}[a-z0-9])?$/', $prefix)) {
            throw new RuntimeException('Nazwa hosta dla ' . $purpose . ' jest nieprawidłowa.');
        }
        return [$bestParent, $prefix];
    }

    private static function emptyState()
    {
        return [
            'updatedAt' => null,
            'lastOperation' => null,
            'lastSuccess' => null,
            'lastError' => null,
            'repository' => ['branch' => null, 'localCommit' => null, 'remoteCommit' => null, 'updateAvailable' => null, 'dirty' => null],
            'extensionUpdate' => ['installedVersion' => self::EXTENSION_VERSION, 'remoteVersion' => null, 'remoteCommit' => null, 'updateAvailable' => null, 'status' => 'unchecked', 'checkedAt' => null, 'deployedAt' => null, 'error' => null],
            'deployment' => ['version' => null, 'commit' => null, 'deployedAt' => null],
            'services' => [],
            'serviceHosts' => [],
            'health' => ['status' => 'unknown', 'detail' => null],
            'sites' => [],
            'log' => [],
        ];
    }
}
