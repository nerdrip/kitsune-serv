<?php

class Modules_NerdAppsRuntimeManager_HellboundConfig
{
    private const SECRET_FIELDS = [
        'productionEnvironment' => 'hb_secret_production_environment',
    ];

    private const OPERATIONS = [
        'status', 'sync', 'build', 'migrate', 'deploy', 'health', 'start', 'stop',
        'logs', 'backup', 'restore', 'rollback', 'prune', 'vhost',
    ];

    public static function defaults()
    {
        return [
            'sourceSubdirectory' => 'apps/hellbound',
            'deploymentRoot' => '/opt/nerd-apps/hellbound',
            'serverDomain' => 'hellbound.api.nerd.rip',
            'composeProject' => 'hellbound-production',
            'backupRetention' => '14',
            'releaseRetention' => '5',
        ];
    }

    public static function values()
    {
        $values = [];
        foreach (self::defaults() as $key => $default) {
            $values[$key] = (string) pm_Settings::get('hb_' . $key, $default);
        }
        $storedDomain = trim((string) pm_Settings::get('hb_serverDomain', ''));
        if ($storedDomain === '') {
            $legacyUrl = trim((string) pm_Settings::get('hb_publicUrl', ''));
            $legacyHost = $legacyUrl !== '' ? parse_url($legacyUrl, PHP_URL_HOST) : null;
            if (is_string($legacyHost) && $legacyHost !== '') $values['serverDomain'] = strtolower($legacyHost);
        }
        return $values;
    }

    public static function save(array $input)
    {
        $values = self::validateValues($input);
        foreach (self::defaults() as $key => $default) {
            pm_Settings::set('hb_' . $key, $values[$key]);
        }
        foreach (self::SECRET_FIELDS as $field => $storageKey) {
            $secret = self::normalizeSecret($field, $input[$field] ?? '');
            if ($secret !== '') {
                pm_Settings::setEncrypted($storageKey, $secret);
            }
        }
        return $values;
    }

    public static function hasSecret($field)
    {
        if (!isset(self::SECRET_FIELDS[$field])) {
            return false;
        }
        return self::readSecret(self::SECRET_FIELDS[$field]) !== '';
    }

    public static function createRuntimeConfig($operation, array $arguments = [])
    {
        $operation = (string) $operation;
        if (!in_array($operation, self::OPERATIONS, true)) {
            throw new InvalidArgumentException('Unsupported operation.');
        }
        $validatedArguments = self::validateOperationArguments($operation, $arguments);
        $values = self::validateValues(self::values());
        $target = Modules_NerdAppsRuntimeManager_Config::serviceHostTarget($values['serverDomain'], 'serwera Hellbound');
        $values['publicUrl'] = 'https://' . $values['serverDomain'];
        $values['pleskParentDomain'] = $target['pleskParentDomain'];
        $values['pleskSubdomain'] = $target['pleskSubdomain'];
        $values['vhostSystemPath'] = $target['vhostSystemPath'];
        $values['vhostDocumentRoot'] = $target['vhostDocumentRoot'];
        $repository = Modules_NerdAppsRuntimeManager_Config::sharedRepositoryConfig();
        $values = array_replace($values, array_intersect_key($repository, array_flip(['repositoryUrl', 'repositoryBranch', 'repositoryPath', 'gitUsername', 'gitSshKnownHosts'])));
        $payload = [
            'schemaVersion' => 1,
            'operation' => $operation,
            'arguments' => $validatedArguments,
            'config' => $values,
            'secrets' => [
                'gitToken' => (string) ($repository['gitToken'] ?? ''),
                'gitSshPrivateKey' => self::normalizePrivateKey($repository['gitSshPrivateKey'] ?? ''),
                'productionEnvironment' => self::normalizeEnvironment(self::readSecret(self::SECRET_FIELDS['productionEnvironment'])),
            ],
            'varDir' => self::varDir(),
            'createdAt' => gmdate('c'),
        ];
        if (!in_array($operation, ['status', 'vhost'], true) && $payload['config']['repositoryUrl'] === '') {
            throw new RuntimeException('Configure the repository URL first.');
        }
        if (in_array($operation, ['build', 'migrate', 'deploy', 'start', 'backup', 'restore', 'rollback'], true)
            && $payload['secrets']['productionEnvironment'] === '') {
            throw new RuntimeException('Najpierw skonfiguruj środowisko produkcyjne Hellbound: w sekcji „1. Przygotuj serwer” kliknij „Wygeneruj bezpieczną konfigurację”, zapisz ustawienia, a następnie ponów deploy.');
        }

        $varDir = self::varDir();
        if (!is_dir($varDir) && !mkdir($varDir, 0700, true) && !is_dir($varDir)) {
            throw new RuntimeException('Unable to create extension runtime directory.');
        }
        chmod($varDir, 0700);
        $path = $varDir . '/operation-' . bin2hex(random_bytes(16)) . '.json';
        $encoded = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $handle = fopen($path, 'x');
        if ($handle === false) {
            throw new RuntimeException('Unable to create the operation configuration.');
        }
        try {
            chmod($path, 0600);
            if (fwrite($handle, $encoded . "\n") === false) {
                throw new RuntimeException('Unable to write the operation configuration.');
            }
        } finally {
            fclose($handle);
        }
        return $path;
    }

    public static function readState()
    {
        $path = self::varDir() . '/state.json';
        if (!is_file($path) || filesize($path) > 262144) {
            return self::emptyState();
        }
        $decoded = json_decode((string) file_get_contents($path), true);
        return is_array($decoded) ? array_replace_recursive(self::emptyState(), $decoded) : self::emptyState();
    }

    private static function validateValues(array $input)
    {
        $defaults = self::defaults();
        $values = [];
        foreach ($defaults as $key => $default) {
            $values[$key] = trim((string) ($input[$key] ?? $default));
        }
        if (!preg_match('#^[A-Za-z0-9._/-]{1,180}$#', $values['sourceSubdirectory'])
            || in_array('..', explode('/', str_replace('\\', '/', $values['sourceSubdirectory'])), true)
            || trim($values['sourceSubdirectory'], '/.') === '') {
            throw new InvalidArgumentException('Source subdirectory must be a safe relative repository path.');
        }
        $values['sourceSubdirectory'] = trim($values['sourceSubdirectory'], '/');
        self::validateDeploymentRoot($values['deploymentRoot']);
        $values['serverDomain'] = strtolower($values['serverDomain']);
        if (!preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/', $values['serverDomain'])) {
            throw new InvalidArgumentException('Host serwera Hellbound jest nieprawidłowy. Wpisz samą domenę, bez https:// i ścieżki.');
        }
        $values['publicUrl'] = 'https://' . $values['serverDomain'];
        if (!preg_match('/^[a-z0-9][a-z0-9_-]{0,62}$/', $values['composeProject'])) {
            throw new InvalidArgumentException('Compose project name is invalid.');
        }
        foreach (['backupRetention' => [1, 100], 'releaseRetention' => [2, 20]] as $field => $range) {
            if (!ctype_digit($values[$field])) {
                throw new InvalidArgumentException($field . ' must be an integer.');
            }
            $number = (int) $values[$field];
            if ($number < $range[0] || $number > $range[1]) {
                throw new InvalidArgumentException($field . ' is outside its allowed range.');
            }
            $values[$field] = (string) $number;
        }
        return $values;
    }

    private static function validateRepositoryUrl($value)
    {
        if (preg_match('/^git@[A-Za-z0-9.-]+:[A-Za-z0-9._\/-]+(?:\.git)?$/', $value)) {
            return;
        }
        $parts = parse_url($value);
        if (!is_array($parts) || !in_array(strtolower((string) ($parts['scheme'] ?? '')), ['https', 'ssh'], true)
            || empty($parts['host']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])) {
            throw new InvalidArgumentException('Repository URL must use HTTPS or SSH without embedded secrets, query or fragment.');
        }
        if (($parts['scheme'] ?? '') === 'https' && isset($parts['user'])) {
            throw new InvalidArgumentException('HTTPS repository credentials must not be embedded in the URL.');
        }
        if (!preg_match('/^[A-Za-z0-9.-]+$/', (string) $parts['host']) || empty($parts['path']) || strlen($value) > 1000) {
            throw new InvalidArgumentException('Repository URL is invalid.');
        }
    }

    private static function validateDeploymentRoot($value)
    {
        if (!preg_match('#^/(?:[A-Za-z0-9._-]+/)*[A-Za-z0-9._-]+$#', $value)
            || strpos($value, '/./') !== false || strpos($value, '/../') !== false || strlen($value) > 500) {
            throw new InvalidArgumentException('Deployment root must be a normalized absolute Linux path.');
        }
        $blocked = ['/', '/bin', '/boot', '/dev', '/etc', '/home', '/opt', '/proc', '/root', '/run', '/sbin', '/srv', '/sys', '/tmp', '/usr', '/var', '/usr/local/psa'];
        if (in_array(rtrim($value, '/'), $blocked, true)) {
            throw new InvalidArgumentException('Deployment root is too broad or reserved.');
        }
    }

    private static function validateHttpsOrigin($value)
    {
        $parts = parse_url($value);
        if (!is_array($parts) || strtolower((string) ($parts['scheme'] ?? '')) !== 'https' || empty($parts['host'])
            || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])
            || (($parts['path'] ?? '') !== '' && ($parts['path'] ?? '') !== '/')) {
            throw new InvalidArgumentException('Public URL must be an HTTPS origin without credentials, path, query or fragment.');
        }
    }

    private static function validateOperationArguments($operation, array $arguments)
    {
        $allowed = [];
        if ($operation === 'restore') {
            $allowed = ['backup', 'confirm'];
            $backup = trim((string) ($arguments['backup'] ?? ''));
            if (!preg_match('/^hellbound-\d{8}T\d{6}Z(?:-[a-z0-9][a-z0-9-]{0,23})?$/', $backup)
                || (string) ($arguments['confirm'] ?? '') !== 'RESTORE:' . $backup) {
                throw new InvalidArgumentException('Restore requires the exact backup ID and confirmation.');
            }
            $arguments = ['backup' => $backup, 'confirm' => 'RESTORE:' . $backup];
        } elseif ($operation === 'rollback') {
            $allowed = ['release', 'confirm'];
            $release = trim((string) ($arguments['release'] ?? ''));
            if (!preg_match('/^release-\d{8}T\d{6}Z-[a-f0-9]{12}$/', $release)
                || (string) ($arguments['confirm'] ?? '') !== 'ROLLBACK:' . $release) {
                throw new InvalidArgumentException('Rollback requires the exact release ID and confirmation.');
            }
            $arguments = ['release' => $release, 'confirm' => 'ROLLBACK:' . $release];
        } elseif ($operation === 'prune') {
            $allowed = ['keep', 'confirm'];
            $keep = (int) ($arguments['keep'] ?? 0);
            if ($keep < 1 || $keep > 100 || (string) ($arguments['confirm'] ?? '') !== 'PRUNE:' . $keep) {
                throw new InvalidArgumentException('Backup pruning requires an exact retention confirmation.');
            }
            $arguments = ['keep' => $keep, 'confirm' => 'PRUNE:' . $keep];
        } elseif ($operation === 'logs') {
            $allowed = ['service', 'lines'];
            $service = (string) ($arguments['service'] ?? 'gateway');
            $lines = (int) ($arguments['lines'] ?? 200);
            if (!in_array($service, ['gateway', 'nakama', 'postgres', 'app-migrate', 'nakama-migrate'], true)
                || $lines < 1 || $lines > 1000) {
                throw new InvalidArgumentException('Log service or line count is invalid.');
            }
            $arguments = ['service' => $service, 'lines' => $lines];
        }
        foreach (array_keys($arguments) as $key) {
            if (!in_array($key, $allowed, true)) {
                throw new InvalidArgumentException('Unexpected operation argument.');
            }
        }
        return $arguments;
    }

    private static function normalizeSecret($field, $value)
    {
        $value = (string) $value;
        if (strpos($value, "\0") !== false) {
            throw new InvalidArgumentException('Secret contains a null byte.');
        }
        $limits = ['gitToken' => 4096, 'gitSshPrivateKey' => 16384, 'productionEnvironment' => 32768];
        if (strlen($value) > ($limits[$field] ?? 4096)) {
            throw new InvalidArgumentException('Secret exceeds its size limit.');
        }
        if ($field === 'gitSshPrivateKey') {
            return self::normalizePrivateKey($value);
        }
        if ($field === 'productionEnvironment') {
            return self::normalizeEnvironment($value);
        }
        return trim($value);
    }

    private static function readSecret($storageKey)
    {
        try {
            return (string) pm_Settings::getDecrypted($storageKey);
        } catch (Exception $exception) {
            return '';
        }
    }

    private static function normalizePrivateKey($value)
    {
        return trim(str_replace(["\r\n", "\r"], "\n", (string) $value));
    }

    private static function normalizeEnvironment($value)
    {
        return trim(str_replace(["\r\n", "\r"], "\n", (string) $value));
    }

    private static function varDir()
    {
        $path = rtrim((string) pm_Context::getVarDir(), '/\\') . '/hellbound';
        if (!is_dir($path) && !mkdir($path, 0700, true) && !is_dir($path)) {
            throw new RuntimeException('Unable to create the isolated Hellbound runtime directory.');
        }
        @chmod($path, 0700);
        return $path;
    }

    private static function emptyState()
    {
        return [
            'schemaVersion' => 1,
            'updatedAt' => null,
            'lastOperation' => null,
            'lastSuccess' => null,
            'lastError' => null,
            'repository' => ['branch' => null, 'localCommit' => null, 'remoteCommit' => null],
            'release' => ['current' => null, 'previous' => null, 'candidate' => null],
            'services' => [],
            'serviceHost' => [],
            'backups' => [],
            'log' => [],
        ];
    }
}
