<?php

final class HellboundContract
{
    public const RELEASE_PATTERN = '/^release-\d{8}T\d{6}Z-[a-f0-9]{12}$/';
    public const BACKUP_PATTERN = '/^hellbound-\d{8}T\d{6}Z(?:-[a-z0-9][a-z0-9-]{0,23})?$/';

    public static function deploymentRoot($value)
    {
        $value = trim((string) $value);
        if (!preg_match('#^/(?:[A-Za-z0-9._-]+/)*[A-Za-z0-9._-]+$#', $value)
            || strpos($value, '/./') !== false || strpos($value, '/../') !== false || strlen($value) > 500) {
            throw new InvalidArgumentException('Deployment root must be a normalized absolute Linux path.');
        }
        $blocked = ['/', '/bin', '/boot', '/dev', '/etc', '/home', '/opt', '/proc', '/root', '/run', '/sbin', '/srv', '/sys', '/tmp', '/usr', '/var', '/usr/local/psa'];
        if (in_array(rtrim($value, '/'), $blocked, true)) {
            throw new InvalidArgumentException('Deployment root is too broad or reserved.');
        }
        return rtrim($value, '/');
    }

    public static function repositoryUrl($value)
    {
        $value = trim((string) $value);
        if (preg_match('/^git@[A-Za-z0-9.-]+:[A-Za-z0-9._\/-]+(?:\.git)?$/', $value)) {
            return $value;
        }
        $parts = parse_url($value);
        if (!is_array($parts) || !in_array(strtolower((string) ($parts['scheme'] ?? '')), ['https', 'ssh'], true)
            || empty($parts['host']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])) {
            throw new InvalidArgumentException('Repository URL must use HTTPS or SSH without embedded secrets.');
        }
        if (($parts['scheme'] ?? '') === 'https' && isset($parts['user'])) {
            throw new InvalidArgumentException('HTTPS repository credentials cannot be embedded in the URL.');
        }
        if (!preg_match('/^[A-Za-z0-9.-]+$/', (string) $parts['host']) || empty($parts['path']) || strlen($value) > 1000) {
            throw new InvalidArgumentException('Repository URL is invalid.');
        }
        return $value;
    }

    public static function branch($value)
    {
        $value = trim((string) $value);
        if (!preg_match('/^(?![-.])(?!.*\.\.)(?!.*@\{)[A-Za-z0-9._\/-]{1,180}$/', $value)) {
            throw new InvalidArgumentException('Repository branch is invalid.');
        }
        return $value;
    }

    public static function sourceSubdirectory($value)
    {
        $value = trim(str_replace('\\', '/', (string) $value), '/');
        if (!preg_match('#^[A-Za-z0-9._/-]{1,180}$#', $value)
            || in_array('..', explode('/', $value), true)
            || trim($value, '/.') === '') {
            throw new InvalidArgumentException('Source subdirectory must be a safe relative repository path.');
        }
        return $value;
    }

    public static function publicOrigin($value)
    {
        $value = rtrim(trim((string) $value), '/');
        $parts = parse_url($value);
        if (!is_array($parts) || strtolower((string) ($parts['scheme'] ?? '')) !== 'https' || empty($parts['host'])
            || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])
            || (($parts['path'] ?? '') !== '')) {
            throw new InvalidArgumentException('Public URL must be an HTTPS origin.');
        }
        return $value;
    }

    public static function releaseId($value)
    {
        $value = trim((string) $value);
        if (!preg_match(self::RELEASE_PATTERN, $value)) {
            throw new InvalidArgumentException('Release ID is invalid.');
        }
        return $value;
    }

    public static function backupId($value)
    {
        $value = trim((string) $value);
        if (!preg_match(self::BACKUP_PATTERN, $value)) {
            throw new InvalidArgumentException('Backup ID is invalid.');
        }
        return $value;
    }

    public static function composeProject($value)
    {
        $value = trim((string) $value);
        if (!preg_match('/^[a-z0-9][a-z0-9_-]{0,62}$/', $value)) {
            throw new InvalidArgumentException('Compose project name is invalid.');
        }
        return $value;
    }

    public static function productionEnvironment($source, $publicOrigin)
    {
        $allowed = [
            'POSTGRES_DB', 'POSTGRES_USER', 'POSTGRES_PASSWORD', 'HELLBOUND_ENV',
            'HELLBOUND_CONTENT_VERSION', 'HELLBOUND_HTTP_PORT', 'HELLBOUND_PUBLIC_URL',
            'HELLBOUND_OPS_TOKEN', 'HELLBOUND_NAKAMA_URL', 'HELLBOUND_MAX_BODY_BYTES',
            'HELLBOUND_RATE_LIMIT_PER_MINUTE', 'HELLBOUND_TRUSTED_PROXY_CIDRS',
            'HELLBOUND_STORAGE_PATHS', 'HELLBOUND_NUA_REQUIRED',
            'HELLBOUND_NUA_TICKET_SECRETS', 'HELLBOUND_NUA_TICKET_ISSUER',
            'HELLBOUND_NUA_TICKET_AUDIENCE',
            'NAKAMA_RUNTIME_HTTP_KEY', 'NAKAMA_SESSION_ENCRYPTION_KEY',
            'NAKAMA_SESSION_REFRESH_ENCRYPTION_KEY', 'NAKAMA_SOCKET_SERVER_KEY',
            'NAKAMA_CONSOLE_USERNAME', 'NAKAMA_CONSOLE_PASSWORD', 'NAKAMA_CONSOLE_SIGNING_KEY',
        ];
        $environment = [];
        foreach (preg_split('/\r?\n/', (string) $source) as $number => $line) {
            $line = trim($line);
            if ($line === '' || substr($line, 0, 1) === '#') {
                continue;
            }
            if (!preg_match('/^([A-Z][A-Z0-9_]*)=(.*)$/', $line, $matches) || !in_array($matches[1], $allowed, true)) {
                throw new InvalidArgumentException('Production environment line ' . ($number + 1) . ' is invalid or not allowlisted.');
            }
            if (array_key_exists($matches[1], $environment)) {
                throw new InvalidArgumentException('Production environment repeats ' . $matches[1] . '.');
            }
            $value = trim($matches[2]);
            if (strlen($value) >= 2 && (($value[0] === '"' && substr($value, -1) === '"') || ($value[0] === "'" && substr($value, -1) === "'"))) {
                $value = substr($value, 1, -1);
            }
            if (strpos($value, "\0") !== false || strpos($value, "\n") !== false || strlen($value) > 8192) {
                throw new InvalidArgumentException('Production environment contains an invalid value.');
            }
            $environment[$matches[1]] = $value;
        }
        $required = [
            'POSTGRES_DB', 'POSTGRES_USER', 'POSTGRES_PASSWORD', 'HELLBOUND_ENV',
            'HELLBOUND_CONTENT_VERSION', 'HELLBOUND_OPS_TOKEN',
            'HELLBOUND_NUA_REQUIRED', 'HELLBOUND_NUA_TICKET_SECRETS',
            'HELLBOUND_NUA_TICKET_ISSUER', 'HELLBOUND_NUA_TICKET_AUDIENCE',
            'NAKAMA_RUNTIME_HTTP_KEY', 'NAKAMA_SESSION_ENCRYPTION_KEY',
            'NAKAMA_SESSION_REFRESH_ENCRYPTION_KEY', 'NAKAMA_SOCKET_SERVER_KEY',
            'NAKAMA_CONSOLE_USERNAME', 'NAKAMA_CONSOLE_PASSWORD', 'NAKAMA_CONSOLE_SIGNING_KEY',
        ];
        foreach ($required as $name) {
            if (!isset($environment[$name]) || $environment[$name] === '') {
                throw new InvalidArgumentException('Production environment is missing ' . $name . '.');
            }
        }
        if ($environment['HELLBOUND_ENV'] !== 'production') {
            throw new InvalidArgumentException('HELLBOUND_ENV must be production.');
        }
        if ($environment['HELLBOUND_NUA_REQUIRED'] !== 'true') {
            throw new InvalidArgumentException('HELLBOUND_NUA_REQUIRED must be true in production.');
        }
        if ($environment['HELLBOUND_NUA_TICKET_AUDIENCE'] !== 'signum-hellbound') {
            throw new InvalidArgumentException('HELLBOUND_NUA_TICKET_AUDIENCE must be signum-hellbound.');
        }
        $issuer = parse_url($environment['HELLBOUND_NUA_TICKET_ISSUER']);
        if (!is_array($issuer) || strtolower((string) ($issuer['scheme'] ?? '')) !== 'https' || empty($issuer['host'])
            || isset($issuer['user']) || isset($issuer['pass']) || isset($issuer['query']) || isset($issuer['fragment'])) {
            throw new InvalidArgumentException('HELLBOUND_NUA_TICKET_ISSUER must be a public HTTPS URL.');
        }
        // The explicit "Serwer Hellbound" field is the single source of truth. This also
        // migrates an already encrypted environment when the administrator changes the host.
        $environment['HELLBOUND_PUBLIC_URL'] = $publicOrigin;
        if (!preg_match('/^[A-Za-z0-9_-]{1,63}$/', $environment['POSTGRES_DB'])
            || !preg_match('/^[A-Za-z0-9_.-]{1,63}$/', $environment['POSTGRES_USER'])) {
            throw new InvalidArgumentException('PostgreSQL database or user name is invalid.');
        }
        $password = $environment['POSTGRES_PASSWORD'];
        $opsToken = $environment['HELLBOUND_OPS_TOKEN'];
        if (strlen($password) < 32 || in_array(strtolower($password), ['localdb', 'postgres', 'password'], true)) {
            throw new InvalidArgumentException('POSTGRES_PASSWORD must be a non-default value of at least 32 characters.');
        }
        if (strlen($opsToken) < 32 || $opsToken === 'local-ops-only-change-before-remote-use' || hash_equals($password, $opsToken)) {
            throw new InvalidArgumentException('HELLBOUND_OPS_TOKEN must be a distinct non-default value of at least 32 characters.');
        }
        if (!preg_match('/^[A-Za-z0-9_-]{32,128}$/', $password) || !preg_match('/^[A-Za-z0-9_-]{32,128}$/', $opsToken)) {
            throw new InvalidArgumentException('Database and operations secrets must be URL-safe tokens between 32 and 128 characters.');
        }
        if (!preg_match('/^[A-Za-z0-9_.-]{3,63}$/', $environment['NAKAMA_CONSOLE_USERNAME'])
            || strtolower($environment['NAKAMA_CONSOLE_USERNAME']) === 'admin') {
            throw new InvalidArgumentException('NAKAMA_CONSOLE_USERNAME must be a non-default account name.');
        }
        $nakamaSecrets = [
            $environment['NAKAMA_RUNTIME_HTTP_KEY'], $environment['NAKAMA_SESSION_ENCRYPTION_KEY'],
            $environment['NAKAMA_SESSION_REFRESH_ENCRYPTION_KEY'], $environment['NAKAMA_SOCKET_SERVER_KEY'],
            $environment['NAKAMA_CONSOLE_PASSWORD'], $environment['NAKAMA_CONSOLE_SIGNING_KEY'],
        ];
        $nuaSecrets = array_values(array_filter(array_map('trim', explode(',', $environment['HELLBOUND_NUA_TICKET_SECRETS']))));
        if (empty($nuaSecrets)) {
            throw new InvalidArgumentException('At least one NUA ticket secret is required.');
        }
        foreach ($nuaSecrets as $secret) {
            if (!preg_match('/^[A-Za-z0-9_-]{32,128}$/', $secret)) {
                throw new InvalidArgumentException('Every NUA ticket secret must be a URL-safe token between 32 and 128 characters.');
            }
        }
        foreach ($nakamaSecrets as $secret) {
            if (!preg_match('/^[A-Za-z0-9_-]{32,128}$/', $secret)) {
                throw new InvalidArgumentException('Every Nakama secret must be a URL-safe token between 32 and 128 characters.');
            }
        }
        $allSecrets = array_merge([$password, $opsToken], $nakamaSecrets, $nuaSecrets);
        if (count(array_unique($allSecrets)) !== count($allSecrets)) {
            throw new InvalidArgumentException('Production database, operations, Nakama and NUA secrets must all be distinct.');
        }
        return $environment;
    }

    public static function redact($value, array $secrets)
    {
        $result = (string) $value;
        usort($secrets, function ($left, $right) { return strlen($right) <=> strlen($left); });
        foreach ($secrets as $secret) {
            if (is_string($secret) && strlen($secret) >= 4) {
                $result = str_replace($secret, '[REDACTED]', $result);
            }
        }
        $result = preg_replace('/(Bearer\s+)[A-Za-z0-9._~+\/-]+=*/i', '$1[REDACTED]', $result);
        $result = preg_replace('#(postgres(?:ql)?://[^:\s/@]+:)[^@\s/]+@#i', '$1[REDACTED]@', $result);
        $result = preg_replace('/([?&](?:token|key|secret|password)=)[^&\s]+/i', '$1[REDACTED]', $result);
        return (string) $result;
    }
}

final class HellboundManager
{
    private const BEGIN_VHOST = '# BEGIN NERD APPS HELLBOUND SERVER';
    private const END_VHOST = '# END NERD APPS HELLBOUND SERVER';
    private $operation;
    private $arguments;
    private $config;
    private $secrets;
    private $varDir;
    private $root;
    private $sourceDir;
    private $productSubdirectory;
    private $releasesDir;
    private $sharedDir;
    private $statePath;
    private $lockHandle;
    private $environment;
    private $redactionSecrets = [];
    private $log = [];
    private $serviceHostState = null;

    public function __construct(array $payload, $varDir)
    {
        if (($payload['schemaVersion'] ?? null) !== 1 || !is_array($payload['config'] ?? null)
            || !is_array($payload['secrets'] ?? null) || !is_array($payload['arguments'] ?? null)) {
            throw new InvalidArgumentException('Operation configuration schema is invalid.');
        }
        $allowedOperations = ['status', 'sync', 'build', 'migrate', 'deploy', 'health', 'start', 'stop', 'logs', 'backup', 'restore', 'rollback', 'prune', 'vhost'];
        $this->operation = (string) ($payload['operation'] ?? '');
        if (!in_array($this->operation, $allowedOperations, true)) {
            throw new InvalidArgumentException('Operation is not allowlisted.');
        }
        $this->arguments = $payload['arguments'];
        $this->config = $payload['config'];
        $this->secrets = $payload['secrets'];
        $this->varDir = $varDir;
        $this->root = HellboundContract::deploymentRoot($this->config['deploymentRoot'] ?? '');
        $this->sourceDir = (string) ($this->config['repositoryPath'] ?? '');
        if (!preg_match('#^/[A-Za-z0-9._/-]+$#', $this->sourceDir) || in_array('..', explode('/', $this->sourceDir), true)) {
            throw new InvalidArgumentException('Shared repository path is invalid.');
        }
        $this->sourceDir = rtrim($this->sourceDir, '/');
        $this->releasesDir = $this->root . '/releases';
        $this->sharedDir = $this->root . '/shared';
        $this->statePath = $this->varDir . '/state.json';
        $repositoryOptional = in_array($this->operation, ['status', 'vhost'], true);
        $this->config['repositoryUrl'] = $repositoryOptional && empty($this->config['repositoryUrl'])
            ? '' : HellboundContract::repositoryUrl($this->config['repositoryUrl'] ?? '');
        $this->config['repositoryBranch'] = HellboundContract::branch($this->config['repositoryBranch'] ?? '');
        $this->productSubdirectory = HellboundContract::sourceSubdirectory($this->config['sourceSubdirectory'] ?? 'apps/hellbound');
        $this->config['publicUrl'] = HellboundContract::publicOrigin($this->config['publicUrl'] ?? '');
        $this->config['serverDomain'] = strtolower(trim((string) ($this->config['serverDomain'] ?? '')));
        $publicHost = strtolower((string) parse_url($this->config['publicUrl'], PHP_URL_HOST));
        if (!preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/', $this->config['serverDomain'])
            || $publicHost !== $this->config['serverDomain']) {
            throw new InvalidArgumentException('Hellbound server host and public URL do not match.');
        }
        $this->config['composeProject'] = HellboundContract::composeProject($this->config['composeProject'] ?? '');
        $this->validateRetention();
        $this->redactionSecrets = array_values(array_filter([
            (string) ($this->secrets['gitToken'] ?? ''),
            (string) ($this->secrets['gitSshPrivateKey'] ?? ''),
        ]));
        $this->environment = [];
        if ($this->operation !== 'vhost' && trim((string) ($this->secrets['productionEnvironment'] ?? '')) !== '') {
            $this->environment = HellboundContract::productionEnvironment(
                $this->secrets['productionEnvironment'],
                $this->config['publicUrl']
            );
            $this->redactionSecrets = array_merge($this->redactionSecrets, array_values($this->environment));
        }
    }

    public function run()
    {
        $mutating = $this->operation !== 'status' && $this->operation !== 'health' && $this->operation !== 'logs';
        if ($mutating) {
            $this->acquireLock();
        }
        try {
            if (!in_array($this->operation, ['status', 'vhost'], true)) {
                $this->ensureDeploymentRoot();
            }
            if (in_array($this->operation, ['deploy', 'start', 'restore', 'rollback'], true)) {
                $this->configurePleskVhost();
            }
            $this->log('Starting ' . $this->operation . '.');
            $result = $this->dispatch();
            $state = $this->snapshot();
            $state['lastOperation'] = $this->operation;
            $state['lastSuccess'] = gmdate('c');
            $state['lastError'] = null;
            $state['log'] = $this->mergedLog($state['log'] ?? []);
            $this->writeState($state);
            return ['ok' => true, 'operation' => $this->operation, 'result' => $result, 'state' => $state];
        } catch (Throwable $exception) {
            $message = HellboundContract::redact($exception->getMessage(), $this->redactionSecrets);
            $this->log('ERROR: ' . $message);
            $state = $this->loadState();
            $state['updatedAt'] = gmdate('c');
            $state['lastOperation'] = $this->operation;
            $state['lastError'] = mb_substr($message, 0, 2000);
            $state['log'] = $this->mergedLog($state['log'] ?? []);
            $this->writeState($state);
            throw new RuntimeException($message, 0, $exception);
        } finally {
            if (is_resource($this->lockHandle)) {
                flock($this->lockHandle, LOCK_UN);
                fclose($this->lockHandle);
            }
        }
    }

    private function dispatch()
    {
        switch ($this->operation) {
            case 'status': return ['refreshed' => true];
            case 'sync': return $this->syncRepository();
            case 'build': return $this->buildRelease();
            case 'migrate': return $this->runCurrent(['server:migrate'], 900);
            case 'deploy': return $this->deploy();
            case 'health': return $this->runCurrent(['smoke:quick', '--base-url', $this->config['publicUrl']], 120);
            case 'start': return $this->runCurrent(['server:deploy', '--base-url', $this->config['publicUrl']], 900);
            case 'stop': return $this->runCurrent(['server:stop'], 300);
            case 'logs': return $this->logs();
            case 'backup': return $this->runCurrent(['backup:create', '--label', 'plesk'], 1800);
            case 'restore': return $this->restore();
            case 'rollback': return $this->rollback();
            case 'prune': return $this->pruneBackups();
            case 'vhost': return $this->configurePleskVhost();
        }
        throw new LogicException('Unreachable operation.');
    }

    private function validateRetention()
    {
        foreach (['backupRetention' => [1, 100], 'releaseRetention' => [2, 20]] as $field => $range) {
            $value = (string) ($this->config[$field] ?? '');
            if (!ctype_digit($value) || (int) $value < $range[0] || (int) $value > $range[1]) {
                throw new InvalidArgumentException($field . ' is outside its allowed range.');
            }
            $this->config[$field] = (int) $value;
        }
    }

    private function configurePleskVhost()
    {
        $domain = $this->config['serverDomain'];
        $parent = strtolower(trim((string) ($this->config['pleskParentDomain'] ?? '')));
        $prefix = trim((string) ($this->config['pleskSubdomain'] ?? ''));
        if (!preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/', $parent)
            || ($prefix !== '' && !preg_match('/^[a-z0-9](?:[a-z0-9.-]{0,251}[a-z0-9])?$/', $prefix))
            || $domain !== ($prefix === '' ? $parent : $prefix . '.' . $parent)) {
            throw new RuntimeException('Plesk parent/subdomain mapping for the Hellbound server is invalid. Save the configuration again.');
        }
        $this->command(['plesk', 'bin', 'domain', '--info', $parent], $this->varDir, [], 60, false);
        $created = false;
        $hostType = 'site';
        if ($prefix !== '') {
            try {
                $this->command(['plesk', 'bin', 'subdomain', '--info', $domain], $this->varDir, [], 60, false);
            } catch (Throwable $exception) {
                $created = true;
            }
            $arguments = ['plesk', 'bin', 'subdomain', $created ? '-c' : '-u', $prefix, '-domain', $parent, '-www-root', '/httpdocs', '-php', 'false', '-ssl', 'true', '-ssl-redirect', 'true'];
            if ($created) array_push($arguments, '-notify', 'false');
            $this->command($arguments, $this->varDir, [], 120, false);
            $hostType = 'subdomain';
        } else {
            $isSubdomain = false;
            try {
                $this->command(['plesk', 'bin', 'subdomain', '--info', $domain], $this->varDir, [], 60, false);
                $isSubdomain = true;
            } catch (Throwable $ignored) {}
            if ($isSubdomain) {
                $this->command(['plesk', 'bin', 'subdomain', '-u', $domain, '-php', 'false', '-ssl', 'true', '-ssl-redirect', 'true'], $this->varDir, [], 120, false);
                $hostType = 'subdomain';
            } else {
                $this->command(['plesk', 'bin', 'site', '-u', $domain, '-ssl', 'true', '-ssl-redirect', 'true'], $this->varDir, [], 120, false);
            }
        }

        $vhost = rtrim(str_replace('\\', '/', (string) ($this->config['vhostSystemPath'] ?? '')), '/');
        $expected = '/var/www/vhosts/system/' . $domain;
        if ($vhost !== $expected) throw new RuntimeException('Hellbound vhost path does not match the configured server host.');
        for ($attempt = 0; $attempt < 20 && !is_dir($vhost . '/conf'); $attempt++) usleep(250000);
        if (!is_dir($vhost . '/conf')) throw new RuntimeException('Plesk did not create the Hellbound vhost directory.');

        $portValue = (string) ($this->environment['HELLBOUND_HTTP_PORT'] ?? '8080');
        if (!ctype_digit($portValue) || (int) $portValue < 1 || (int) $portValue > 65535) {
            throw new RuntimeException('HELLBOUND_HTTP_PORT must be a valid TCP port.');
        }
        $port = (int) $portValue;
        $path = $vhost . '/conf/vhost_nginx.conf';
        $original = is_file($path) ? (string) file_get_contents($path) : '';
        $pattern = '/\n?' . preg_quote(self::BEGIN_VHOST, '/') . '.*?' . preg_quote(self::END_VHOST, '/') . '\n?/s';
        $current = preg_replace($pattern, "\n", $original);
        if ($current === null) throw new RuntimeException('Unable to prepare the Hellbound nginx configuration.');
        $block = self::BEGIN_VHOST . "\n"
            . "location ~ ^/(?!\\.well-known(?:/|$)).*$ {\n"
            . "    proxy_pass http://127.0.0.1:" . $port . ";\n"
            . "    proxy_http_version 1.1;\n"
            . "    proxy_set_header Host \$host;\n"
            . "    proxy_set_header X-Real-IP \$remote_addr;\n"
            . "    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;\n"
            . "    proxy_set_header X-Forwarded-Proto \$scheme;\n"
            . "    proxy_set_header Upgrade \$http_upgrade;\n"
            . "    proxy_set_header Connection \"upgrade\";\n"
            . "    proxy_connect_timeout 30s;\n"
            . "    proxy_send_timeout 120s;\n"
            . "    proxy_read_timeout 120s;\n"
            . "    proxy_buffering off;\n"
            . "    client_max_body_size 16m;\n"
            . "}\n" . self::END_VHOST . "\n";
        $next = $path . '.hellbound-next-' . bin2hex(random_bytes(5));
        if (file_put_contents($next, rtrim((string) $current) . "\n\n" . $block, LOCK_EX) === false) {
            throw new RuntimeException('Unable to write the Hellbound nginx staging file.');
        }
        @chmod($next, is_file($path) ? (fileperms($path) & 0777) : 0644);
        if (!rename($next, $path)) { @unlink($next); throw new RuntimeException('Unable to activate the Hellbound nginx configuration.'); }
        try {
            $this->command(['plesk', 'sbin', 'httpdmng', '--reconfigure-domain', $domain], $this->varDir, [], 180, false);
            $this->command(['/usr/local/psa/admin/bin/nginx-config', '-t'], $this->varDir, [], 60, false);
        } catch (Throwable $exception) {
            if ($original === '') @unlink($path);
            else file_put_contents($path, $original, LOCK_EX);
            try { $this->command(['plesk', 'sbin', 'httpdmng', '--reconfigure-domain', $domain], $this->varDir, [], 180, false); }
            catch (Throwable $ignored) {}
            throw new RuntimeException('Hellbound vhost failed validation and was rolled back: ' . $exception->getMessage(), 0, $exception);
        }
        $this->serviceHostState = [
            'domain' => $domain,
            'parentDomain' => $parent,
            'type' => $hostType,
            'created' => $created,
            'target' => '127.0.0.1:' . $port,
            'configuredAt' => gmdate('c'),
        ];
        $this->log(($created ? 'Created' : 'Updated') . ' Plesk host ' . $domain . ' for the Hellbound server.');
        return $this->serviceHostState;
    }

    private function acquireLock()
    {
        $path = $this->varDir . '/operation.lock';
        $this->lockHandle = fopen($path, 'c');
        if ($this->lockHandle === false) {
            throw new RuntimeException('Unable to create the operation lock.');
        }
        chmod($path, 0600);
        if (!flock($this->lockHandle, LOCK_EX | LOCK_NB)) {
            throw new RuntimeException('Another Hellbound deployment operation is active.');
        }
        ftruncate($this->lockHandle, 0);
        fwrite($this->lockHandle, json_encode(['operation' => $this->operation, 'pid' => getmypid(), 'startedAt' => gmdate('c')]) . "\n");
        fflush($this->lockHandle);
    }

    private function ensureDeploymentRoot()
    {
        if (!is_dir($this->root)) {
            if (!mkdir($this->root, 0750, true) && !is_dir($this->root)) {
                throw new RuntimeException('Unable to create the deployment root.');
            }
        }
        if (is_link($this->root) || realpath($this->root) !== $this->root) {
            throw new RuntimeException('Deployment root must not be a symlink or alias.');
        }
        $marker = $this->root . '/.hellbound-deployment-root';
        if (!is_file($marker)) {
            $entries = array_values(array_diff(scandir($this->root) ?: [], ['.', '..']));
            if ($entries) {
                throw new RuntimeException('Refusing to adopt a non-empty deployment root without its marker.');
            }
            $this->writeExclusive($marker, json_encode(['schemaVersion' => 1, 'createdAt' => gmdate('c')]) . "\n", 0640);
        }
        foreach ([$this->releasesDir, $this->sharedDir, $this->sharedDir . '/backups', $this->sharedDir . '/storage'] as $directory) {
            if (!is_dir($directory) && !mkdir($directory, 0750, true) && !is_dir($directory)) {
                throw new RuntimeException('Unable to create deployment directory.');
            }
            $this->assertInsideRoot($directory, true);
        }
    }

    private function syncRepository()
    {
        if ($this->config['repositoryUrl'] === '') {
            throw new RuntimeException('Repository URL is not configured.');
        }
        return $this->withGitCredentials(function (array $gitEnvironment) {
            if (!is_dir($this->sourceDir . '/.git')) {
                throw new RuntimeException('Wspólne repozytorium nie jest jeszcze sklonowane. Najpierw uruchom synchronizację wspólnego runtime.');
            }
            $origin = trim($this->command(['git', '-C', $this->sourceDir, 'remote', 'get-url', 'origin'], $this->root, $gitEnvironment, 60)['stdout']);
            if (!hash_equals($this->config['repositoryUrl'], $origin)) {
                throw new RuntimeException('Skonfigurowane repozytorium nie pasuje do wspólnego checkoutu.');
            }
            $dirty = trim($this->command(['git', '-C', $this->sourceDir, 'status', '--porcelain', '--untracked-files=all'], $this->root, $gitEnvironment, 60)['stdout']);
            if ($dirty !== '') {
                throw new RuntimeException('Wspólne repozytorium zawiera lokalne zmiany; synchronizacja została zatrzymana.');
            }
            $this->command(['git', '-C', $this->sourceDir, 'fetch', '--prune', 'origin', $this->config['repositoryBranch']], $this->root, $gitEnvironment, 900);
            $remote = trim($this->command(['git', '-C', $this->sourceDir, 'rev-parse', '--verify', 'origin/' . $this->config['repositoryBranch']], $this->root, $gitEnvironment, 60)['stdout']);
            if (!preg_match('/^[a-f0-9]{40,64}$/', $remote)) {
                throw new RuntimeException('Remote branch did not resolve to a commit.');
            }
            $this->command(['git', '-c', 'advice.detachedHead=false', '-C', $this->sourceDir, 'checkout', '--detach', $remote], $this->root, $gitEnvironment, 300);
            $this->log('Repository synchronized to ' . substr($remote, 0, 12) . '.');
            return ['commit' => $remote, 'branch' => $this->config['repositoryBranch']];
        });
    }

    private function buildRelease()
    {
        if (!is_dir($this->sourceDir . '/.git')) {
            throw new RuntimeException('Najpierw zsynchronizuj wspólne repozytorium.');
        }
        $dirty = trim($this->command(['git', '-C', $this->sourceDir, 'status', '--porcelain', '--untracked-files=all'], $this->root, [], 60)['stdout']);
        if ($dirty !== '') {
            throw new RuntimeException('Wspólne repozytorium zawiera lokalne zmiany.');
        }
        $commit = trim($this->command(['git', '-C', $this->sourceDir, 'rev-parse', 'HEAD'], $this->root, [], 60)['stdout']);
        if (!preg_match('/^[a-f0-9]{40,64}$/', $commit)) {
            throw new RuntimeException('Local source commit is invalid.');
        }
        $releaseId = 'release-' . gmdate('Ymd\THis\Z') . '-' . substr($commit, 0, 12);
        HellboundContract::releaseId($releaseId);
        $destination = $this->releasesDir . '/' . $releaseId;
        if (is_dir($destination)) {
            return ['release' => $releaseId, 'commit' => $commit, 'reused' => true];
        }
        $staging = $this->releasesDir . '/.incomplete-' . bin2hex(random_bytes(12));
        try {
            $this->command(['git', 'clone', '--no-hardlinks', '--no-checkout', '--', $this->sourceDir, $staging], $this->root, [], 900);
            $this->command(['git', '-C', $staging, 'sparse-checkout', 'init', '--no-cone'], $this->root, [], 60);
            $this->command(['git', '-C', $staging, 'sparse-checkout', 'set', '--no-cone', '--', $this->productSubdirectory], $this->root, [], 60);
            $this->command(['git', '-c', 'advice.detachedHead=false', '-C', $staging, 'checkout', '--detach', $commit], $this->root, [], 300);
            $this->assertTreeRegular($staging, [$staging . '/.git']);
            $this->removeTree($staging . '/.git');
            $productRoot = $this->productPath($staging);
            foreach (['package.json', 'scripts/project-task.mjs', 'server/compose.yaml'] as $required) {
                if (!is_file($productRoot . '/' . $required)) {
                    throw new RuntimeException('Candidate release is missing ' . $required . '.');
                }
            }
            if (file_exists($productRoot . '/backups') || is_link($productRoot . '/backups')) {
                $this->removeTree($productRoot . '/backups');
            }
            if (!symlink($this->sharedDir . '/backups', $productRoot . '/backups')) {
                throw new RuntimeException('Unable to link shared backups into the release.');
            }
            $manifest = ['schemaVersion' => 1, 'releaseId' => $releaseId, 'commit' => $commit, 'builtAt' => gmdate('c')];
            $this->writeExclusive($staging . '/.hellbound-release.json', json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n", 0640);
            $this->runRunner($staging, ['server:build'], 3600, $commit, true);
            if (!rename($staging, $destination)) {
                throw new RuntimeException('Unable to activate the immutable release directory.');
            }
            $this->setCandidate($releaseId);
            $this->log('Built immutable release ' . $releaseId . '.');
            return ['release' => $releaseId, 'commit' => $commit, 'reused' => false];
        } catch (Throwable $exception) {
            if (is_dir($staging)) {
                $this->removeTree($staging);
            }
            throw $exception;
        }
    }

    private function deploy()
    {
        $candidate = $this->candidateRelease();
        if ($candidate === null) {
            $candidate = $this->buildRelease()['release'];
        }
        $candidatePath = $this->releasePath($candidate);
        $old = $this->linkedRelease('current');
        if ($old !== null && $old !== $candidate) {
            $this->runRunner($this->releasePath($old), ['backup:create', '--label', 'pre-deploy'], 1800);
        }
        $this->runRunner($candidatePath, ['server:migrate'], 900);
        if ($old !== null && $old !== $candidate) {
            $this->atomicReleaseLink('previous', $old);
        }
        $this->atomicReleaseLink('current', $candidate);
        try {
            $health = $this->runRunner($candidatePath, ['server:deploy', '--base-url', $this->config['publicUrl']], 1200);
        } catch (Throwable $exception) {
            $this->log('New release health gate failed; attempting last-known-good activation.');
            if ($old !== null && $old !== $candidate) {
                $this->atomicReleaseLink('current', $old);
                try {
                    $this->runRunner($this->releasePath($old), ['server:deploy', '--base-url', $this->config['publicUrl']], 1200);
                } catch (Throwable $recovery) {
                    throw new RuntimeException('Deployment and automatic last-known-good restart both failed: ' . $exception->getMessage());
                }
            } else {
                $this->removeLink('current');
            }
            throw $exception;
        }
        $this->setCandidate(null);
        $this->pruneReleases();
        return ['release' => $candidate, 'previous' => $old, 'health' => $health];
    }

    private function restore()
    {
        $backup = HellboundContract::backupId($this->arguments['backup'] ?? '');
        $confirm = (string) ($this->arguments['confirm'] ?? '');
        if (!hash_equals('RESTORE:' . $backup, $confirm)) {
            throw new RuntimeException('Restore confirmation does not match the selected backup.');
        }
        return $this->runCurrent(['backup:restore', '--backup', $backup, '--confirm', $confirm, '--base-url', $this->config['publicUrl']], 3600);
    }

    private function rollback()
    {
        $release = HellboundContract::releaseId($this->arguments['release'] ?? '');
        $confirm = (string) ($this->arguments['confirm'] ?? '');
        if (!hash_equals('ROLLBACK:' . $release, $confirm)) {
            throw new RuntimeException('Rollback confirmation does not match the selected release.');
        }
        $current = $this->linkedRelease('current');
        $previous = $this->linkedRelease('previous');
        if ($previous === null || !hash_equals($previous, $release) || $current === null) {
            throw new RuntimeException('Rollback is limited to the recorded last-known-good release.');
        }
        $this->runRunner($this->releasePath($current), ['backup:create', '--label', 'pre-rollback'], 1800);
        $this->atomicReleaseLink('current', $release);
        try {
            $health = $this->runRunner($this->releasePath($release), ['server:deploy', '--base-url', $this->config['publicUrl']], 1200);
        } catch (Throwable $exception) {
            $this->atomicReleaseLink('current', $current);
            $this->runRunner($this->releasePath($current), ['server:deploy', '--base-url', $this->config['publicUrl']], 1200);
            throw $exception;
        }
        $this->atomicReleaseLink('previous', $current);
        return ['release' => $release, 'previous' => $current, 'health' => $health];
    }

    private function pruneBackups()
    {
        $keep = (int) ($this->arguments['keep'] ?? 0);
        $confirm = (string) ($this->arguments['confirm'] ?? '');
        if ($keep < 1 || $keep > 100 || !hash_equals('PRUNE:' . $keep, $confirm)) {
            throw new RuntimeException('Backup retention confirmation is invalid.');
        }
        return $this->runCurrent(['backup:prune', '--keep', (string) $keep, '--confirm', $confirm], 1800);
    }

    private function logs()
    {
        $service = (string) ($this->arguments['service'] ?? 'gateway');
        $lines = (int) ($this->arguments['lines'] ?? 200);
        if (!in_array($service, ['gateway', 'nakama', 'postgres', 'app-migrate', 'nakama-migrate'], true) || $lines < 1 || $lines > 1000) {
            throw new RuntimeException('Log request is invalid.');
        }
        return $this->runCurrent(['server:logs', '--service', $service, '--lines', (string) $lines], 120);
    }

    private function runCurrent(array $arguments, $timeout)
    {
        $current = $this->linkedRelease('current');
        if ($current === null) {
            throw new RuntimeException('No active release is available.');
        }
        return $this->runRunner($this->releasePath($current), $arguments, $timeout);
    }

    private function runRunner($releasePath, array $arguments, $timeout, $revision = null, $staging = false)
    {
        if ($staging) {
            if (!preg_match('/^\.incomplete-[a-f0-9]{24}$/', basename($releasePath))) {
                throw new RuntimeException('Candidate staging path is invalid.');
            }
            $this->assertInsideRoot($releasePath, true);
        } else {
            $this->assertReleasePath($releasePath);
        }
        $environment = $this->runtimeEnvironment($revision ?: $this->releaseCommit($releasePath));
        $productPath = $this->productPath($releasePath);
        $command = array_merge(['node', $productPath . '/scripts/project-task.mjs'], $arguments);
        $result = $this->command($command, $productPath, $environment, $timeout);
        $decoded = json_decode(trim($result['stdout']), true);
        return is_array($decoded) ? $decoded : ['output' => mb_substr(trim($result['stdout']), -12000)];
    }

    private function productPath($releasePath)
    {
        $path = rtrim($releasePath, '/') . '/' . $this->productSubdirectory;
        if (!is_dir($path) || is_link($path)) {
            throw new RuntimeException('Hellbound source subdirectory is missing from the release.');
        }
        $releaseReal = realpath($releasePath);
        $productReal = realpath($path);
        if ($releaseReal === false || $productReal === false || strpos($productReal . '/', $releaseReal . '/') !== 0) {
            throw new RuntimeException('Hellbound source subdirectory escapes the immutable release.');
        }
        return $productReal;
    }

    private function runtimeEnvironment($revision)
    {
        if (!$this->environment) {
            throw new RuntimeException('Encrypted production environment is not configured.');
        }
        $environment = $this->environment;
        $environment['COMPOSE_PROJECT_NAME'] = $this->config['composeProject'];
        $environment['HELLBOUND_PORT_PREFIX'] = '127.0.0.1:';
        $environment['HELLBOUND_BACKUP_ROOT'] = $this->sharedDir . '/backups';
        $environment['HELLBOUND_STORAGE_ROOT'] = $this->sharedDir . '/storage';
        $environment['HELLBOUND_BUILD_REVISION'] = $revision;
        return $environment;
    }

    private function snapshot()
    {
        $state = $this->loadState();
        $state['schemaVersion'] = 1;
        $state['updatedAt'] = gmdate('c');
        $state['repository'] = [
            'branch' => $this->config['repositoryBranch'],
            'localCommit' => $this->gitCommit($this->sourceDir, 'HEAD'),
            'remoteCommit' => $this->gitCommit($this->sourceDir, 'origin/' . $this->config['repositoryBranch']),
        ];
        $state['release'] = [
            'current' => $this->linkedRelease('current'),
            'previous' => $this->linkedRelease('previous'),
            'candidate' => $this->candidateRelease(),
        ];
        $state['services'] = [];
        $state['backups'] = [];
        if ($this->serviceHostState !== null) $state['serviceHost'] = $this->serviceHostState;
        $current = $state['release']['current'];
        if ($current !== null && $this->environment) {
            try {
                $state['services'] = $this->runRunner($this->releasePath($current), ['server:status'], 120)['services'] ?? [];
            } catch (Throwable $exception) {
                $state['serviceError'] = mb_substr(HellboundContract::redact($exception->getMessage(), $this->redactionSecrets), 0, 1000);
            }
            try {
                $state['backups'] = $this->runRunner($this->releasePath($current), ['backup:list'], 300);
            } catch (Throwable $exception) {
                $state['backupError'] = mb_substr(HellboundContract::redact($exception->getMessage(), $this->redactionSecrets), 0, 1000);
            }
        }
        return $state;
    }

    private function gitCommit($directory, $revision)
    {
        if (!is_dir($directory . '/.git')) {
            return null;
        }
        try {
            $value = trim($this->command(['git', '-C', $directory, 'rev-parse', '--verify', $revision], $this->root, [], 30, false)['stdout']);
            return preg_match('/^[a-f0-9]{40,64}$/', $value) ? $value : null;
        } catch (Throwable $exception) {
            return null;
        }
    }

    private function releaseCommit($releasePath)
    {
        $manifest = $releasePath . '/.hellbound-release.json';
        if (!is_file($manifest) || filesize($manifest) > 8192) {
            throw new RuntimeException('Release manifest is missing.');
        }
        $decoded = json_decode((string) file_get_contents($manifest), true);
        $commit = (string) ($decoded['commit'] ?? '');
        if (!preg_match('/^[a-f0-9]{40,64}$/', $commit)) {
            throw new RuntimeException('Release manifest commit is invalid.');
        }
        return $commit;
    }

    private function candidateRelease()
    {
        $state = $this->loadState();
        $candidate = $state['release']['candidate'] ?? null;
        if (!is_string($candidate) || !preg_match(HellboundContract::RELEASE_PATTERN, $candidate)) {
            return null;
        }
        try {
            $this->releasePath($candidate);
            return $candidate;
        } catch (Throwable $exception) {
            return null;
        }
    }

    private function setCandidate($release)
    {
        $state = $this->loadState();
        if (!isset($state['release']) || !is_array($state['release'])) {
            $state['release'] = [];
        }
        $state['release']['candidate'] = $release;
        $state['updatedAt'] = gmdate('c');
        $this->writeState($state);
    }

    private function releasePath($release)
    {
        $release = HellboundContract::releaseId($release);
        $path = $this->releasesDir . '/' . $release;
        $this->assertReleasePath($path);
        return $path;
    }

    private function assertReleasePath($path)
    {
        if (!is_dir($path) || is_link($path)) {
            throw new RuntimeException('Release directory does not exist or is a symlink.');
        }
        $real = realpath($path);
        $prefix = realpath($this->releasesDir) . '/';
        if ($real === false || strpos($real . '/', $prefix) !== 0 || !preg_match(HellboundContract::RELEASE_PATTERN, basename($real))) {
            throw new RuntimeException('Release path escapes the dedicated releases root.');
        }
    }

    private function linkedRelease($name)
    {
        $path = $this->root . '/' . $name;
        if (!is_link($path)) {
            return null;
        }
        $target = readlink($path);
        if ($target === false) {
            return null;
        }
        $resolved = substr($target, 0, 1) === '/' ? $target : dirname($path) . '/' . $target;
        $real = realpath($resolved);
        $prefix = is_dir($this->releasesDir) ? realpath($this->releasesDir) . '/' : '';
        if ($real === false || $prefix === '' || strpos($real . '/', $prefix) !== 0 || !preg_match(HellboundContract::RELEASE_PATTERN, basename($real))) {
            throw new RuntimeException('Release link points outside the dedicated releases root.');
        }
        return basename($real);
    }

    private function atomicReleaseLink($name, $release)
    {
        $target = $this->releasePath($release);
        $link = $this->root . '/' . $name;
        if (file_exists($link) && !is_link($link)) {
            throw new RuntimeException('Release link path is occupied by a non-link file.');
        }
        $temporary = $this->root . '/.' . $name . '-' . bin2hex(random_bytes(8));
        if (!symlink($target, $temporary)) {
            throw new RuntimeException('Unable to create a release link.');
        }
        if (!rename($temporary, $link)) {
            @unlink($temporary);
            throw new RuntimeException('Unable to activate a release link.');
        }
    }

    private function removeLink($name)
    {
        $path = $this->root . '/' . $name;
        if (is_link($path)) {
            unlink($path);
        }
    }

    private function pruneReleases()
    {
        $protected = array_filter([$this->linkedRelease('current'), $this->linkedRelease('previous'), $this->candidateRelease()]);
        $entries = scandir($this->releasesDir) ?: [];
        $releases = [];
        foreach ($entries as $entry) {
            if (preg_match(HellboundContract::RELEASE_PATTERN, $entry) && is_dir($this->releasesDir . '/' . $entry) && !is_link($this->releasesDir . '/' . $entry)) {
                $releases[] = $entry;
            }
        }
        rsort($releases, SORT_STRING);
        $keep = array_slice($releases, 0, $this->config['releaseRetention']);
        $keep = array_unique(array_merge($keep, $protected));
        foreach ($releases as $release) {
            if (!in_array($release, $keep, true)) {
                $this->removeTree($this->releasePath($release));
                $this->log('Pruned inactive immutable release ' . $release . '.');
            }
        }
    }

    private function withGitCredentials(callable $action)
    {
        $prefix = $this->varDir . '/git-' . bin2hex(random_bytes(12));
        $created = [];
        $environment = ['GIT_TERMINAL_PROMPT' => '0'];
        try {
            $token = trim((string) ($this->secrets['gitToken'] ?? ''));
            $privateKey = trim((string) ($this->secrets['gitSshPrivateKey'] ?? ''));
            if ($token !== '') {
                $usernameFile = $prefix . '-username';
                $tokenFile = $prefix . '-token';
                $askpass = $prefix . '-askpass';
                $this->writeExclusive($usernameFile, (string) ($this->config['gitUsername'] ?? 'x-access-token'), 0600);
                $this->writeExclusive($tokenFile, $token, 0600);
                $script = "#!/bin/sh\ncase \"\$1\" in *sername*) cat \"\$HB_GIT_USERNAME_FILE\" ;; *) cat \"\$HB_GIT_TOKEN_FILE\" ;; esac\n";
                $this->writeExclusive($askpass, $script, 0700);
                $created = array_merge($created, [$usernameFile, $tokenFile, $askpass]);
                $environment['GIT_ASKPASS'] = $askpass;
                $environment['HB_GIT_USERNAME_FILE'] = $usernameFile;
                $environment['HB_GIT_TOKEN_FILE'] = $tokenFile;
            }
            if ($privateKey !== '') {
                $keyFile = $prefix . '-key';
                $knownHosts = $prefix . '-known-hosts';
                $wrapper = $prefix . '-ssh';
                $this->writeExclusive($keyFile, str_replace(["\r\n", "\r"], "\n", $privateKey) . "\n", 0600);
                $created[] = $keyFile;
                $this->command(['ssh-keygen', '-y', '-f', $keyFile], $this->varDir, [], 30);
                $knownHostsContent = trim((string) ($this->config['gitSshKnownHosts'] ?? ''));
                if ($knownHostsContent !== '') {
                    $this->writeExclusive($knownHosts, str_replace(["\r\n", "\r"], "\n", $knownHostsContent) . "\n", 0600);
                    $created[] = $knownHosts;
                }
                $script = "#!/bin/sh\nset -eu\nargs=\"-i \$HB_GIT_KEY_FILE -o IdentitiesOnly=yes -o StrictHostKeyChecking=yes\"\nif [ -n \"\${HB_GIT_KNOWN_HOSTS_FILE:-}\" ]; then args=\"\$args -o UserKnownHostsFile=\$HB_GIT_KNOWN_HOSTS_FILE\"; fi\nexec /usr/bin/ssh \$args \"\$@\"\n";
                $this->writeExclusive($wrapper, $script, 0700);
                $created[] = $wrapper;
                $environment['GIT_SSH'] = $wrapper;
                $environment['HB_GIT_KEY_FILE'] = $keyFile;
                if ($knownHostsContent !== '') {
                    $environment['HB_GIT_KNOWN_HOSTS_FILE'] = $knownHosts;
                }
            }
            return $action($environment);
        } finally {
            foreach ($created as $path) {
                if (is_file($path)) {
                    @unlink($path);
                }
            }
        }
    }

    private function command(array $command, $cwd, array $environment, $timeout, $logOutput = true)
    {
        if (!$command || !is_string($command[0]) || $command[0] === '') {
            throw new InvalidArgumentException('Command contract is invalid.');
        }
        foreach ($command as $argument) {
            if (!is_string($argument) || strpos($argument, "\0") !== false) {
                throw new InvalidArgumentException('Command argument is invalid.');
            }
        }
        $this->log('Running allowlisted tool: ' . basename($command[0]) . '.');
        $baseEnvironment = getenv();
        if (!is_array($baseEnvironment)) {
            $baseEnvironment = [];
        }
        $baseEnvironment['PATH'] = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin';
        $processEnvironment = array_merge($baseEnvironment, $environment);
        $descriptors = [
            0 => ['file', '/dev/null', 'r'],
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w'],
        ];
        $process = proc_open($command, $descriptors, $pipes, $cwd, $processEnvironment, ['bypass_shell' => true]);
        if (!is_resource($process)) {
            throw new RuntimeException('Unable to start an allowlisted process.');
        }
        stream_set_blocking($pipes[1], false);
        stream_set_blocking($pipes[2], false);
        $stdout = '';
        $stderr = '';
        $started = microtime(true);
        $exitCode = null;
        try {
            while (true) {
                $stdout .= (string) stream_get_contents($pipes[1]);
                $stderr .= (string) stream_get_contents($pipes[2]);
                if (strlen($stdout) + strlen($stderr) > 2097152) {
                    proc_terminate($process, 9);
                    throw new RuntimeException('Process output exceeded the 2 MiB safety limit.');
                }
                $status = proc_get_status($process);
                if (!$status['running']) {
                    $exitCode = (int) $status['exitcode'];
                    break;
                }
                if (microtime(true) - $started > $timeout) {
                    proc_terminate($process, 15);
                    usleep(500000);
                    $status = proc_get_status($process);
                    if ($status['running']) {
                        proc_terminate($process, 9);
                    }
                    throw new RuntimeException('Allowlisted process timed out.');
                }
                usleep(100000);
            }
            $stdout .= (string) stream_get_contents($pipes[1]);
            $stderr .= (string) stream_get_contents($pipes[2]);
        } finally {
            fclose($pipes[1]);
            fclose($pipes[2]);
            $closed = proc_close($process);
            if ($exitCode === null && $closed >= 0) {
                $exitCode = $closed;
            }
        }
        $stdout = HellboundContract::redact($stdout, $this->redactionSecrets);
        $stderr = HellboundContract::redact($stderr, $this->redactionSecrets);
        if ($exitCode !== 0) {
            throw new RuntimeException(basename($command[0]) . ' failed with exit code ' . $exitCode . ': ' . mb_substr(trim($stderr !== '' ? $stderr : $stdout), -4000));
        }
        if ($logOutput && trim($stdout) !== '') {
            $this->log(mb_substr(trim($stdout), -2000));
        }
        return ['code' => 0, 'stdout' => $stdout, 'stderr' => $stderr];
    }

    private function assertTreeRegular($root, array $skip = [])
    {
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
        foreach ($iterator as $item) {
            $path = $item->getPathname();
            $ignored = false;
            foreach ($skip as $prefix) {
                if ($path === $prefix || strpos($path, $prefix . '/') === 0) {
                    $ignored = true;
                    break;
                }
            }
            if ($ignored) {
                continue;
            }
            if ($item->isLink() || (!$item->isDir() && !$item->isFile())) {
                throw new RuntimeException('Candidate release contains a symlink or special file: ' . substr($path, strlen($root) + 1));
            }
        }
    }

    private function removeTree($path)
    {
        $this->assertInsideRoot($path, false);
        if (is_link($path) || is_file($path)) {
            if (!unlink($path)) {
                throw new RuntimeException('Unable to remove a confined file.');
            }
            return;
        }
        if (!is_dir($path)) {
            return;
        }
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($iterator as $item) {
            $itemPath = $item->getPathname();
            $this->assertInsideRoot($itemPath, false);
            if ($item->isLink() || $item->isFile()) {
                unlink($itemPath);
            } elseif ($item->isDir()) {
                rmdir($itemPath);
            } else {
                throw new RuntimeException('Refusing to remove a special file.');
            }
        }
        rmdir($path);
    }

    private function assertInsideRoot($path, $mustExist)
    {
        $root = realpath($this->root);
        if ($root === false) {
            throw new RuntimeException('Deployment root is unavailable.');
        }
        $candidate = $mustExist ? realpath($path) : realpath(dirname($path));
        if ($candidate === false || ($candidate !== $root && strpos($candidate . '/', $root . '/') !== 0)) {
            throw new RuntimeException('Path escapes the dedicated deployment root.');
        }
    }

    private function writeExclusive($path, $content, $mode)
    {
        $handle = fopen($path, 'x');
        if ($handle === false) {
            throw new RuntimeException('Unable to create a protected file.');
        }
        try {
            chmod($path, $mode);
            if (fwrite($handle, $content) === false) {
                throw new RuntimeException('Unable to write a protected file.');
            }
        } finally {
            fclose($handle);
        }
    }

    private function loadState()
    {
        if (!is_file($this->statePath) || filesize($this->statePath) > 262144) {
            return ['schemaVersion' => 1, 'release' => [], 'log' => []];
        }
        $decoded = json_decode((string) file_get_contents($this->statePath), true);
        return is_array($decoded) ? $decoded : ['schemaVersion' => 1, 'release' => [], 'log' => []];
    }

    private function writeState(array $state)
    {
        $state['log'] = array_slice(array_values(array_filter((array) ($state['log'] ?? []), 'is_string')), -120);
        $temporary = $this->varDir . '/state-' . bin2hex(random_bytes(8)) . '.tmp';
        $this->writeExclusive($temporary, json_encode($state, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n", 0600);
        if (!rename($temporary, $this->statePath)) {
            @unlink($temporary);
            throw new RuntimeException('Unable to atomically save operation state.');
        }
        chmod($this->statePath, 0600);
    }

    private function log($message)
    {
        $message = HellboundContract::redact((string) $message, $this->redactionSecrets);
        $message = str_replace(["\r", "\0"], ['', ''], $message);
        $this->log[] = gmdate('c') . ' ' . mb_substr($message, 0, 4000);
    }

    private function mergedLog(array $existing)
    {
        return array_slice(array_merge(array_values(array_filter($existing, 'is_string')), $this->log), -120);
    }
}

function loadOperationConfiguration($path)
{
    $path = (string) $path;
    if (!preg_match('/^operation-[a-f0-9]{32}\.json$/', basename($path)) || is_link($path) || !is_file($path)) {
        throw new InvalidArgumentException('Operation configuration path is invalid.');
    }
    $real = realpath($path);
    if ($real === false || filesize($real) > 131072 || (fileperms($real) & 0077) !== 0) {
        throw new InvalidArgumentException('Operation configuration permissions or size are invalid.');
    }
    $varDir = realpath(dirname($real));
    if ($varDir === false || !preg_match('#/var/modules/nerd-apps-runtime-manager/hellbound$#', str_replace('\\', '/', $varDir))) {
        throw new InvalidArgumentException('Operation configuration is outside the Plesk extension runtime directory.');
    }
    try {
        $payload = json_decode((string) file_get_contents($real), true, 64, JSON_THROW_ON_ERROR);
    } finally {
        @unlink($real);
    }
    if (!is_array($payload) || realpath((string) ($payload['varDir'] ?? '')) !== $varDir) {
        throw new InvalidArgumentException('Operation configuration runtime directory does not match.');
    }
    return [$payload, $varDir];
}

function nerdAppsHellboundSelfTest()
{
    $tests = 0;
    $assert = function ($condition, $message) use (&$tests) {
        $tests++;
        if (!$condition) {
            throw new RuntimeException('Self-test failed: ' . $message);
        }
    };
    $assert(HellboundContract::deploymentRoot('/opt/signum-hellbound') === '/opt/signum-hellbound', 'deployment root');
    try { HellboundContract::deploymentRoot('/opt'); $assert(false, 'broad root rejection'); } catch (InvalidArgumentException $exception) { $assert(true, 'broad root rejection'); }
    try { HellboundContract::repositoryUrl('https://token@example.test/repo.git'); $assert(false, 'embedded Git credential rejection'); } catch (InvalidArgumentException $exception) { $assert(true, 'embedded Git credential rejection'); }
    $assert(HellboundContract::branch('release/production') === 'release/production', 'branch');
    $assert(HellboundContract::sourceSubdirectory('apps/hellbound') === 'apps/hellbound', 'source subdirectory');
    try { HellboundContract::sourceSubdirectory('../outside'); $assert(false, 'source traversal rejection'); } catch (InvalidArgumentException $exception) { $assert(true, 'source traversal rejection'); }
    try { HellboundContract::releaseId('../../outside'); $assert(false, 'release traversal rejection'); } catch (InvalidArgumentException $exception) { $assert(true, 'release traversal rejection'); }
    $environment = HellboundContract::productionEnvironment(
        "POSTGRES_DB=nakama\nPOSTGRES_USER=hellbound\nPOSTGRES_PASSWORD=db0123456789abcdef0123456789abcdef\nHELLBOUND_ENV=production\nHELLBOUND_CONTENT_VERSION=2026.07.v7\nHELLBOUND_OPS_TOKEN=ops123456789abcdef0123456789abcdef\nHELLBOUND_NUA_REQUIRED=true\nHELLBOUND_NUA_TICKET_SECRETS=nua123456789abcdef0123456789abcdef\nHELLBOUND_NUA_TICKET_ISSUER=https://api.nerd.rip/\nHELLBOUND_NUA_TICKET_AUDIENCE=signum-hellbound\nNAKAMA_RUNTIME_HTTP_KEY=http123456789abcdef0123456789abcdef\nNAKAMA_SESSION_ENCRYPTION_KEY=session123456789abcdef0123456789abcdef\nNAKAMA_SESSION_REFRESH_ENCRYPTION_KEY=refresh123456789abcdef0123456789abcdef\nNAKAMA_SOCKET_SERVER_KEY=socket123456789abcdef0123456789abcdef\nNAKAMA_CONSOLE_USERNAME=hellbound-admin\nNAKAMA_CONSOLE_PASSWORD=console123456789abcdef0123456789abcdef\nNAKAMA_CONSOLE_SIGNING_KEY=signing123456789abcdef0123456789abcdef\n",
        'https://game.example.test'
    );
    $assert($environment['HELLBOUND_ENV'] === 'production', 'production environment');
    $assert($environment['HELLBOUND_PUBLIC_URL'] === 'https://game.example.test', 'derived public origin');
    $redacted = HellboundContract::redact('Bearer secret-token postgres://app:db-secret@db/app?token=query-secret', ['secret-token']);
    $assert(strpos($redacted, 'secret-token') === false && strpos($redacted, 'db-secret') === false && strpos($redacted, 'query-secret') === false, 'redaction');
    return ['ok' => true, 'tests' => $tests];
}

function runNerdAppsHellbound(array $arguments)
{
    if ($arguments === ['--self-test']) {
        return nerdAppsHellboundSelfTest();
    }
    if (count($arguments) !== 2 || $arguments[0] !== '--config') {
        throw new InvalidArgumentException('Usage: nerd-apps-runtime-manager --scope hellbound --config <operation-json>');
    }
    list($payload, $varDir) = loadOperationConfiguration($arguments[1]);
    $manager = new HellboundManager($payload, $varDir);
    return $manager->run();
}
