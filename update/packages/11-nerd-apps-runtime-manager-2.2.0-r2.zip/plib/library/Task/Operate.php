<?php

class Modules_NerdAppsRuntimeManager_Task_Operate extends pm_LongTask_Task
{
    public $trackProgress = true;

    public function run()
    {
        $runtimeConfig = (string) $this->getParam('runtimeConfig');
        if ($runtimeConfig === '') {
            throw new RuntimeException('Brak konfiguracji operacji Nerd Apps Runtime.');
        }
        $scope = (string) $this->getParam('scope');
        if (!in_array($scope, ['runtime', 'hellbound', 'extension'], true)) {
            throw new RuntimeException('Nieznany zakres operacji Nerd Apps.');
        }
        $arguments = $scope === 'hellbound'
            ? ['--scope', 'hellbound', '--config', $runtimeConfig]
            : ['--config', $runtimeConfig];
        $this->updateProgress(10);
        $result = pm_ApiCli::callSbin(
            'nerd-apps-runtime-manager',
            $arguments,
            pm_ApiCli::RESULT_FULL
        );
        $this->updateProgress(95);
        $output = trim((string) ($result['stdout'] ?? '') . "\n" . (string) ($result['stderr'] ?? ''));
        $this->setParam('output', mb_substr($output, -16000));
        if ((int) ($result['code'] ?? 1) !== 0) {
            throw new RuntimeException(trim((string) ($result['stderr'] ?? 'Operacja zakończyła się błędem.')));
        }
        $this->updateProgress(100);
    }

    public function onError(Exception $exception) { $this->removeRuntimeConfig(); }
    public function onDone() { $this->removeRuntimeConfig(); }

    public function statusMessage()
    {
        $operation = (string) $this->getParam('operation');
        $scope = (string) $this->getParam('scope');
        $label = $scope === 'hellbound' ? 'Hellbound' : ($scope === 'extension' ? 'Rozszerzenie Pleska' : 'Nerd Apps Runtime');
        if ($this->getStatus() === static::STATUS_RUNNING) return $label . ': trwa ' . $operation . '…';
        if ($this->getStatus() === static::STATUS_DONE) return $label . ': operacja zakończona.';
        if ($this->getStatus() === static::STATUS_ERROR) return $label . ': operacja zakończona błędem.';
        return $label . ': zadanie oczekuje.';
    }

    private function removeRuntimeConfig()
    {
        $path = (string) $this->getParam('runtimeConfig');
        if ($path !== '' && is_file($path)) @unlink($path);
    }
}
