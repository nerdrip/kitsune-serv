<?php

final class Modules_NerdAppsRuntimeManager_NginxConfig
{
    /**
     * Remove only legacy browser-CORS directives. FastAPI remains the sole CORS owner.
     */
    public static function stripLegacyCors($config, &$removedCount = 0)
    {
        $config = (string) $config;
        if (strpos($config, "\0") !== false) throw new RuntimeException('Konfiguracja nginx zawiera niedozwolony znak NUL.');
        $removedCount = 0;
        $config = str_replace(["\r\n", "\r"], "\n", $config);
        $config = self::stripLegacyOptionsBlocks($config, $removedCount);
        $directivePattern = '/^[\t ]*(?:add_header|more_set_headers|more_clear_headers|proxy_hide_header|proxy_pass_header)\b[^;]*Access-Control-[A-Za-z-]+[^;]*;[\t ]*(?:#[^\n]*)?(?:\n|$)/mi';
        $config = preg_replace_callback($directivePattern, function () use (&$removedCount) {
            $removedCount++;
            return '';
        }, $config);
        if ($config === null) throw new RuntimeException('Nie udało się przeanalizować konfiguracji CORS nginx.');
        $config = preg_replace("/\n{3,}/", "\n\n", $config);
        return rtrim((string) $config) . "\n";
    }

    private static function stripLegacyOptionsBlocks($config, &$removedCount)
    {
        $pattern = '/^[\t ]*if\s*\([^\)\n]*\$request_method[^\)\n]*OPTIONS[^\)\n]*\)\s*\{/mi';
        $cursor = 0;
        $ranges = [];
        while (preg_match($pattern, $config, $match, PREG_OFFSET_CAPTURE, $cursor)) {
            $start = (int) $match[0][1];
            $open = strpos($config, '{', $start);
            if ($open === false) break;
            $close = self::matchingBrace($config, $open);
            if ($close === null) throw new RuntimeException('Niekompletny blok OPTIONS w konfiguracji nginx.');
            $block = substr($config, $start, $close - $start + 1);
            if (stripos($block, 'Access-Control-') !== false || preg_match('/\breturn\s+204\s*;/i', $block)) {
                $end = $close + 1;
                while (isset($config[$end]) && ($config[$end] === ' ' || $config[$end] === "\t")) $end++;
                if (isset($config[$end]) && $config[$end] === '#') {
                    $newline = strpos($config, "\n", $end);
                    $end = $newline === false ? strlen($config) : $newline + 1;
                } elseif (isset($config[$end]) && $config[$end] === "\n") {
                    $end++;
                }
                $ranges[] = [$start, $end - $start];
                $removedCount++;
            }
            $cursor = $close + 1;
        }
        for ($index = count($ranges) - 1; $index >= 0; $index--) {
            $config = substr_replace($config, '', $ranges[$index][0], $ranges[$index][1]);
        }
        return $config;
    }

    private static function matchingBrace($config, $open)
    {
        $depth = 0;
        $quote = null;
        $escaped = false;
        $comment = false;
        $length = strlen($config);
        for ($index = $open; $index < $length; $index++) {
            $character = $config[$index];
            if ($comment) {
                if ($character === "\n") $comment = false;
                continue;
            }
            if ($quote !== null) {
                if ($escaped) { $escaped = false; continue; }
                if ($character === '\\') { $escaped = true; continue; }
                if ($character === $quote) $quote = null;
                continue;
            }
            if ($character === '#') { $comment = true; continue; }
            if ($character === '"' || $character === "'") { $quote = $character; continue; }
            if ($character === '{') $depth++;
            elseif ($character === '}') {
                $depth--;
                if ($depth === 0) return $index;
            }
        }
        return null;
    }
}
