<?php

class Modules_NerdAppsRuntimeManager_CustomButtons extends pm_Hook_CustomButtons
{
    public function getButtons()
    {
        if ($this->hubOwnsNavigation()) return [];
        return [[
            'place' => self::PLACE_ADMIN_NAVIGATION,
            'section' => self::SECTION_NAV_SERVER_MANAGEMENT,
            'order' => 57,
            'title' => 'Nerd Apps Runtime',
            'description' => 'Wdrażanie aplikacji, runtime, stron produktów i aktualizacji managera',
            'icon' => pm_Context::getBaseUrl() . 'images/nerd-runtime-menu.svg',
            'link' => pm_Context::getActionUrl('index', 'index'),
        ]];
    }

    private function hubOwnsNavigation()
    {
        try { return pm_Extension::getById('kitsuneserv-bridge')->isActive(); }
        catch (Throwable $exception) { return false; }
    }
}
