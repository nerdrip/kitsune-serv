<?php

class Modules_NerdAppsRuntimeManager_LongTasks extends pm_Hook_LongTasks
{
    public function getLongTasks()
    {
        return [
            new Modules_NerdAppsRuntimeManager_Task_Operate(),
        ];
    }
}
