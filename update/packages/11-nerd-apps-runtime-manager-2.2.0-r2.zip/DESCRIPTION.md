# Nerd Apps Runtime Manager

Single Plesk control plane for the shared Nerd Apps backend, Bound product sites and Hellbound.
It stores secrets using Plesk encryption, safely updates the dicex monorepository, manages Docker
Compose, product subdomains, health checks, immutable Hellbound releases, backups and rollback.
