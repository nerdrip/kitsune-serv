(function () {
  'use strict';

  var storageKey = 'nerd-apps-runtime-manager-tab';
  var operationLabels = {
    check: 'Sprawdź środowisko',
    sync: 'Pobierz aktualizację',
    deploy: 'Wdróż lokalny kod',
    'sync-deploy': 'Pobierz i wdróż',
    restart: 'Zastosuj konfigurację',
    start: 'Uruchom usługi',
    stop: 'Zatrzymaj usługi',
    ingest: 'Przebuduj indeks RAG',
    backup: 'Wykonaj snapshot Qdrant',
    logs: 'Odśwież logi',
    'sites-check': 'Audytuj domeny',
    'sites-sync': 'Synchronizuj domeny'
  };

  function randomToken() {
    var bytes = new Uint8Array(32);
    window.crypto.getRandomValues(bytes);
    return Array.prototype.map.call(bytes, function (value) { return ('0' + value.toString(16)).slice(-2); }).join('');
  }

  function initializeHellboundSetup(root) {
    var form = root.querySelector('#narm-hellbound-config-form');
    var generate = root.querySelector('[data-narm-generate-hellbound]');
    var environment = form && form.querySelector('[name="productionEnvironment"]');
    if (form && generate && environment) generate.addEventListener('click', function () {
      if (!window.crypto || typeof window.crypto.getRandomValues !== 'function') {
        window.alert('Ta przeglądarka nie udostępnia bezpiecznego generatora losowego. Zaktualizuj przeglądarkę i spróbuj ponownie.');
        return;
      }
      if (environment.value.trim() && !window.confirm('Zastąpić niezapisaną konfigurację nowymi sekretami?')) return;
      var nuaSecret = randomToken();
      var values = [
        'POSTGRES_DB=nakama',
        'POSTGRES_USER=hellbound',
        'POSTGRES_PASSWORD=' + randomToken(),
        'HELLBOUND_ENV=production',
        'HELLBOUND_CONTENT_VERSION=2026.08.v1',
        'HELLBOUND_HTTP_PORT=8080',
        'HELLBOUND_OPS_TOKEN=' + randomToken(),
        'HELLBOUND_NAKAMA_URL=http://nakama:7350',
        'HELLBOUND_NUA_REQUIRED=true',
        'HELLBOUND_NUA_TICKET_SECRETS=' + nuaSecret,
        'HELLBOUND_NUA_TICKET_ISSUER=https://api.nerd.rip/',
        'HELLBOUND_NUA_TICKET_AUDIENCE=signum-hellbound',
        'NAKAMA_RUNTIME_HTTP_KEY=' + randomToken(),
        'NAKAMA_SESSION_ENCRYPTION_KEY=' + randomToken(),
        'NAKAMA_SESSION_REFRESH_ENCRYPTION_KEY=' + randomToken(),
        'NAKAMA_SOCKET_SERVER_KEY=' + randomToken(),
        'NAKAMA_CONSOLE_USERNAME=hellbound-admin',
        'NAKAMA_CONSOLE_PASSWORD=' + randomToken(),
        'NAKAMA_CONSOLE_SIGNING_KEY=' + randomToken()
      ];
      environment.value = values.join('\n');
      var secretBox = root.querySelector('[data-narm-nua-secret]');
      var secretValue = root.querySelector('[data-narm-nua-secret-value]');
      var status = root.querySelector('[data-narm-env-status]');
      if (secretValue) secretValue.textContent = nuaSecret;
      if (secretBox) secretBox.hidden = false;
      if (status) status.textContent = 'Konfiguracja jest wygenerowana, ale jeszcze niezapisana. Sprawdź nazwę serwera Hellbound i kliknij „Zapisz konfigurację serwera”.';
      environment.focus();
    });
    var copy = root.querySelector('[data-narm-copy-hellbound-secret]');
    if (copy) copy.addEventListener('click', function () {
      var value = root.querySelector('[data-narm-nua-secret-value]');
      if (!value) return;
      var done = function () { copy.textContent = 'Skopiowano'; };
      if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') navigator.clipboard.writeText(value.textContent || '').then(done);
      else { var field = document.createElement('textarea'); field.value = value.textContent || ''; document.body.appendChild(field); field.select(); document.execCommand('copy'); document.body.removeChild(field); done(); }
    });

    var operationForm = root.querySelector('#narm-hellbound-operation-form');
    var operation = operationForm && operationForm.querySelector('[name="operation"]');
    if (!operationForm || !operation) return;
    var conditional = { backup: ['backup', 'confirm'], rollback: ['release', 'confirm'], prune: ['keep', 'confirm'], logs: ['service', 'lines'] };
    var update = function () {
      ['backup', 'release', 'keep', 'service', 'lines', 'confirm'].forEach(function (name) {
        var field = operationForm.querySelector('[name="' + name + '"]');
        var row = field && (field.closest ? field.closest('.form-row') : field.parentNode);
        var visible = (conditional[operation.value] || []).indexOf(name) !== -1;
        if (row) row.hidden = !visible;
        if (field) field.disabled = !visible;
      });
      var button = operationForm.querySelector('[data-narm-action="hellbound"]');
      if (button) button.textContent = operation.value === 'deploy' ? 'Wdróż Hellbound bezpiecznie' : 'Uruchom wybraną operację';
    };
    operation.addEventListener('change', update);
    update();
  }

  function rememberTab(name) {
    try { window.sessionStorage.setItem(storageKey, name); } catch (_error) { /* optional */ }
  }

  function initializeTabs(root) {
    var tabs = Array.prototype.slice.call(root.querySelectorAll('[data-narm-tab]'));
    var panels = Array.prototype.slice.call(root.querySelectorAll('[data-narm-panel]'));
    if (!tabs.length || !panels.length) return;

    var activate = function (name, remember, focus) {
      var selected = tabs.some(function (tab) {
        return tab.getAttribute('data-narm-tab') === name;
      }) ? name : 'status';

      tabs.forEach(function (tab) {
        var active = tab.getAttribute('data-narm-tab') === selected;
        tab.classList.toggle('is-active', active);
        tab.setAttribute('aria-selected', active ? 'true' : 'false');
        tab.setAttribute('tabindex', active ? '0' : '-1');
        if (active && focus) tab.focus();
      });
      panels.forEach(function (panel) {
        var active = panel.getAttribute('data-narm-panel') === selected;
        panel.classList.toggle('is-active', active);
        panel.hidden = !active;
        panel.setAttribute('aria-hidden', active ? 'false' : 'true');
      });
      root.setAttribute('data-narm-active-tab', selected);
      if (remember) rememberTab(selected);
    };

    tabs.forEach(function (tab, index) {
      tab.addEventListener('click', function (event) {
        event.preventDefault();
        activate(tab.getAttribute('data-narm-tab'), true, false);
      });
      tab.addEventListener('keydown', function (event) {
        if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].indexOf(event.key) === -1) return;
        event.preventDefault();
        var next = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1
          : (index + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
        activate(tabs[next].getAttribute('data-narm-tab'), true, true);
      });
    });

    Array.prototype.forEach.call(root.querySelectorAll('[data-narm-open-tab]'), function (button) {
      button.addEventListener('click', function () {
        activate(button.getAttribute('data-narm-open-tab'), true, false);
      });
    });

    var requested = root.getAttribute('data-narm-active-tab') || '';
    if (!requested) {
      try { requested = window.sessionStorage.getItem(storageKey) || ''; } catch (_error) { /* optional */ }
    }
    activate(requested || 'status', false, false);
    root.narmActivateTab = activate;
  }

  function initializeOperation(root) {
    var form = root.querySelector('#narm-operation-form');
    var operation = form && form.querySelector('[name="operation"]');
    var button = form && form.querySelector('[data-narm-action="operation"]');
    if (!form || !operation || !button) return;

    var update = function () {
      button.textContent = operationLabels[operation.value] || 'Uruchom operację';
    };
    operation.addEventListener('change', update);
    form.addEventListener('submit', function (event) {
      var risky = ['deploy', 'sync-deploy', 'restart', 'stop'].indexOf(operation.value) !== -1;
      var option = operation.options && operation.options[operation.selectedIndex];
      if (risky && !window.confirm('Uruchomić operację „' + (option ? option.text : operation.value) + '”?')) {
        event.preventDefault();
        return;
      }
      rememberTab('operations');
    });
    update();
  }

  function initializeForms(root) {
    Array.prototype.forEach.call(root.querySelectorAll('form'), function (form) {
      var submitting = false;
      form.addEventListener('submit', function (event) {
        if (submitting) {
          event.preventDefault();
          event.stopImmediatePropagation();
          return;
        }
        if (event.defaultPrevented) return;
        submitting = true;
        if (form.id === 'narm-deployment-form') rememberTab('deployment');
        if (form.id === 'narm-runtime-form') rememberTab('runtime');
        if (form.id === 'narm-sites-form' || form.id === 'narm-sites-operation-form') rememberTab('sites');
        if (form.id === 'narm-hellbound-config-form' || form.id === 'narm-hellbound-operation-form') rememberTab('apps');
        if (form.id === 'narm-extension-check-form' || form.id === 'narm-extension-deploy-form') rememberTab('status');
        var button = event.submitter || form.querySelector('[data-narm-action]');
        if (button) {
          button.disabled = true;
          button.textContent = 'Dodawanie zadania…';
        }
      });
    });
  }

  function initializeSiteConfig(root) {
    var card = root.querySelector('[data-narm-site-config]');
    var domain = card && card.querySelector('[name="contentDomain"]');
    if (!card || !domain) return;
    var manifest = card.querySelector('[data-narm-site-manifest]');
    var admin = card.querySelector('[data-narm-site-admin]');
    var update = function () {
      var host = String(domain.value || '').trim().toLowerCase();
      if (manifest) manifest.textContent = host ? 'https://' + host + '/wp-json/nerd-apps/v1/product-sites/manifest' : '—';
      if (admin) admin.textContent = host ? 'https://' + host + '/wp-admin/admin.php?page=nua-product-sites' : '—';
    };
    domain.addEventListener('change', update);
    update();
  }

  function initializeGuardedOperations(root) {
    var extensionDeploy = root.querySelector('#narm-extension-deploy-form');
    if (extensionDeploy) extensionDeploy.addEventListener('submit', function (event) {
      if (!window.confirm('Wdrożyć nową wersję rozszerzenia Pleska? Manager utworzy najpierw paczkę backupu i zweryfikuje dokładny commit z repozytorium.')) event.preventDefault();
    });
    var sites = root.querySelector('#narm-sites-operation-form');
    if (sites) sites.addEventListener('submit', function (event) {
      var operation = sites.querySelector('[name="operation"]');
      if (operation && operation.value === 'sites-sync' && !window.confirm('Utworzyć lub zaktualizować subdomeny produktów w Plesku? Żadna domena nie zostanie usunięta.')) event.preventDefault();
    });
    var hellbound = root.querySelector('#narm-hellbound-operation-form');
    if (hellbound) hellbound.addEventListener('submit', function (event) {
      var operation = hellbound.querySelector('[name="operation"]');
      if (operation && ['deploy', 'stop', 'restore', 'rollback', 'prune'].indexOf(operation.value) !== -1
          && !window.confirm('Uruchomić chronioną operację Hellbound „' + operation.value + '”?')) event.preventDefault();
    });
  }

  function initializeRefresh(root) {
    var refresh = root.querySelector('[data-narm-refresh]');
    if (!refresh) return;
    refresh.addEventListener('click', function () {
      refresh.disabled = true;
      refresh.textContent = 'Odświeżanie…';
      rememberTab('status');
      window.location.reload();
    });
  }

  function initializeCopy(root) {
    var bind = function (button, content) {
      if (!button || !content) return;
      button.addEventListener('click', function () {
        var value = content.textContent || '';
        var previous = button.textContent;
        var complete = function () {
          button.textContent = 'Skopiowano';
          window.setTimeout(function () { button.textContent = previous; }, 1400);
        };
        var fallback = function () {
          var textarea = document.createElement('textarea');
          textarea.value = value;
          textarea.setAttribute('readonly', 'readonly');
          textarea.style.position = 'fixed';
          textarea.style.opacity = '0';
          document.body.appendChild(textarea);
          textarea.select();
          try { document.execCommand('copy'); } catch (_error) { /* optional */ }
          document.body.removeChild(textarea);
          complete();
        };
        if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
          navigator.clipboard.writeText(value).then(complete).catch(fallback);
        } else {
          fallback();
        }
      });
    };

    bind(root.querySelector('[data-narm-copy-log]'), root.querySelector('[data-narm-log]'));
    Array.prototype.forEach.call(root.querySelectorAll('[data-narm-copy-target]'), function (button) {
      var target = button.getAttribute('data-narm-copy-target');
      bind(button, root.querySelector('[data-narm-copy-content="' + target + '"]'));
    });
  }

  function initialize() {
    var root = document.querySelector('[data-narm-root]');
    if (!root || root.getAttribute('data-narm-initialized') === 'true') return false;
    root.setAttribute('data-narm-initialized', 'true');
    initializeTabs(root);
    initializeOperation(root);
    initializeGuardedOperations(root);
    initializeForms(root);
      initializeSiteConfig(root);
      initializeHellboundSetup(root);
    initializeRefresh(root);
    initializeCopy(root);
    return true;
  }

  function boot() {
    if (initialize()) return;
    var attempts = 0;
    var retry = window.setInterval(function () {
      attempts += 1;
      if (initialize() || attempts >= 20) window.clearInterval(retry);
    }, 100);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
}());
