<?php

pm_Context::init('nerd-apps-runtime-manager');
$application = new pm_Application();
$application->run();
