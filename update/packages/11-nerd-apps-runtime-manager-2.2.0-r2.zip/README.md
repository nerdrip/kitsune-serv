# Nerd Apps Runtime Manager for Plesk

The extension is the single Plesk control plane for Nerd Apps: the shared AI/RAG runtime, Bound
product sites and the Hellbound server. It uses an admin-only MVC panel, encrypted `pm_Settings`
secrets, queued `pm_LongTask_Task` operations and one self-contained privileged helper with isolated scopes.

## Package

```bash
node tools/package_nerd_runtime_plesk.js
```

The ZIP and SHA-256 file are written to `release/plesk/`.

## Install or update

```bash
plesk bin extension -i Nerd-Apps-Runtime-Manager-2.2.0.zip
plesk bin extension -g Nerd-Apps-Runtime-Manager-2.2.0.zip
```

Configure the repository, runtime path, Plesk domain and runtime values in
`Server Management → Nerd Apps Runtime`. Production should enable authentication and use the same
NUA ticket secret/audience as the `nerd-runtime` service configured in Nerd Universal Apps.

The panel deliberately separates three hosts:

- `api.nerd.rip` is WordPress/CMS and keeps content, accounts and Nerd Universal Apps tickets;
- `ai.api.nerd.rip` is the AI server and proxies to the local Nerd Apps Runtime port (default `8000`);
- `hellbound.api.nerd.rip` is the Hellbound server and proxies to its local gateway (default `8080`).

In managed mode, saving the AI or Hellbound configuration finds the nearest active Plesk parent,
creates or updates the subdomain, enables SSL support and HTTPS redirect, and writes the isolated
nginx reverse-proxy block. It does not issue a new certificate; the selected Plesk certificate or a
wildcard certificate still has to cover the host. If authoritative DNS is external to Plesk, create
the corresponding DNS record there as well.

The status screen contains a self-update panel for the Plesk extension itself. `Sprawdź aktualizacje`
fetches the configured branch into a private bare mirror without changing the runtime checkout, reads
and validates the extension metadata and displays the installed and repository versions. `Wdróż nową
wersję` is enabled only for a higher SemVer and the exact commit that was checked. It builds a
self-contained ZIP, exports the installed extension with Plesk, then runs `plesk bin extension -g`.
The archive, backup and update state are kept under Plesk's persistent extension var directory.

When reverse proxy mode is set to `manual`, the deployment panel displays a ready-to-copy
`Additional nginx directives` block using the saved API port. It keeps `/.well-known` under Plesk
control and works with the domain's normal Plesk Proxy Mode enabled.

`Automatycznie napraw CORS domeny` backs up the selected domain's `vhost_nginx.conf`, removes
legacy wildcard CORS headers and manual `OPTIONS`/`204` handling, rebuilds the Plesk domain and
verifies that the runtime returns one configured origin. Managed proxy repair performs the same
cleanup automatically.

The OpenAI section independently configures chat and image generation, including model, output
size/quality/format, compression, timeout, inline-image limit and idempotent replay memory cap.

The manager never deletes Docker volumes. Uninstalling the extension leaves the repository,
runtime, persistent data and containers intact.

The `Strony produktów` tab lets an administrator assign three existing Plesk hosts: a private CMS/API
domain, a public studio domain and a public Bound hub. WordPress and all editing stay on the CMS host;
managed nginx proxy blocks render that content on the public hosts without another Node service or
WordPress installation. The tab reads the Nerd Universal Apps manifest, audits or creates
`<slug>.<hub-domain>` hosts and routes them to that renderer. It never deletes
unknown or retired domains. The `Hellbound` tab deploys `apps/hellbound/` from this monorepository as
immutable releases with an isolated state directory, encrypted production environment, backups,
health-gated activation and last-known-good rollback.

The Hellbound setup wizard generates its production dotenv in the administrator's browser using
`crypto.getRandomValues()`. Plesk stores the complete environment with encrypted settings; it is not
committed to Git or printed back into logs. The generated `HELLBOUND_NUA_TICKET_SECRETS` value must
also be configured as the `hellbound-game` service secret in Nerd Universal Apps on `api.nerd.rip`.

Deploy and configuration rollback now wait for `/ready` to report `healthy`, including Qdrant,
instead of accepting process liveness alone.
Deployments rebuild the RAG collection before this readiness check, so a fresh Qdrant volume
cannot produce a deceptively healthy assistant that fails on its first query.
Before ingest, the privileged helper safely assigns the document tree to the container UID/GID
`10001` using `0750` directories and `0640` files; symlinks and path escapes are rejected.
