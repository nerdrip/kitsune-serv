# Changelog

## 2.2.0-2 — 2026-08-20

- Dodano wspólny wygląd Kitsune Plesk Suite oraz powrót do centralnego Plesk Management w Kitsune Hub.
- Własny wpis menu pozostaje dostępny bez Huba i jest ukrywany po wykryciu aktywnego Kitsune Hub.

## 2.2.0

- Rozdzielono w panelu trzy role: WordPress/CMS, serwer AI i serwer Hellbound; host gry nie jest już prezentowany jako „strona API”.
- Pola publikacji przyjmują docelowy host, nawet jeżeli nie istnieje jeszcze w Plesku.
- Zapis konfiguracji serwera AI lub Hellbound automatycznie tworzy albo aktualizuje subdomenę, włącza obsługę SSL i przekierowanie HTTPS oraz zapisuje osobny reverse proxy nginx.
- Pierwsze przygotowanie hosta AI nie wymaga uruchomionego kontenera; publiczny healthcheck nadal działa przy wdrożeniu i jawnej naprawie proxy.
- Dodano operację ręcznego utworzenia lub naprawy hosta Hellbound oraz kontrolę, że CMS, AI i Hellbound nie współdzielą jednej domeny.
- Pole „Serwer Hellbound” jest jedynym źródłem publicznego adresu; helper wylicza `HELLBOUND_PUBLIC_URL`, więc generator i administrator nie muszą przechowywać go drugi raz.
- Zachowano zgodność z zapisanym wcześniej `hb_publicUrl`, migrując z niego sam host Hellbound.

## 2.1.0

- Dodano panel aktualizacji samego rozszerzenia z wersją lokalną, wersją repozytorium, commitem i czasem sprawdzenia.
- Sprawdzanie używa prywatnego bare mirrora oraz `git fetch`, nie modyfikuje checkoutu działającego runtime i nie uruchamia obcego kodu.
- Wdrożenie jest przypięte do wcześniej sprawdzonego commita, waliduje `meta.xml`, spójność wersji i wymagane pliki, a następnie buduje samodzielny ZIP.
- Przed upgrade'em Plesk eksportuje zainstalowaną paczkę; błąd uruchamia próbę rollbacku, a backup pozostaje dostępny do ręcznego odzyskania.
- Poprawiono instrukcję CLI: aktualizacja używa `extension -g`; wcześniejsze `-u` oznaczało odinstalowanie rozszerzenia.
- Poprawiono kategorię `meta.xml`, ukryto administracyjny skrót przed użytkownikami hostingu i usunięto zależność od PHP 8 `str_ends_with`.

## 2.0.1

- Naprawiono brakujące style kart aplikacji, przez który katalog renderował się jako długa surowa lista.
- Hellbound otwiera teraz zakładkę wyróżnionym panelem stanu i właściwym kreatorem wdrożenia.
- Pozostałe aplikacje przeniesiono do zwartego, zwijanego katalogu kafelków na końcu ekranu.
- Poprawiono responsywność kreatora, statusów i katalogu na węższych ekranach Pleska.

## 2.0.0

- Przebudowano ekran Hellbound jako czytelny kreator: konfiguracja, gotowość i bezpieczny deploy.
- Dodano lokalny generator kompletnego produkcyjnego dotenv z rozłącznymi sekretami kryptograficznymi.
- Wyjaśniono rolę zaszyfrowanego środowiska, wspólnego sekretu NUA i kolejność pierwszego wdrożenia.
- Pola restore, rollback, retencji i logów są widoczne wyłącznie dla odpowiadających im operacji.
- Zastąpiono angielski błąd braku środowiska konkretną polską instrukcją naprawy.

## 1.9.0

- Poprawiono tworzenie wielopoziomowych hostów produktów pod hubem będącym subdomeną Pleska.
- `roll.bound.9tails.dev` jest tworzony jako `roll.bound` pod rzeczywistą domeną nadrzędną `9tails.dev`.
- Hellbound korzysta ze wspólnej konfiguracji Git i istniejącego checkoutu całego projektu.
- Usunięto drugi URL, branch, token i klucz Git z formularza Hellbound; release nadal zawiera wyłącznie `apps/hellbound` dzięki sparse checkout.

## 1.8.0

- Rozdzielono domenę CMS/API od publicznej strony studia i publicznego hubu aplikacji.
- Synchronizacja konfiguruje lekki reverse proxy z publicznych hostów do renderera Nerd Universal Apps.
- Treść oraz baza pozostają wyłącznie na WordPressie; publiczne domeny nie wymagają drugiej instalacji ani serwera Node.
- Panel opisuje przepływ `CMS → studio + hub → strony produktów` i wylicza adresy administracyjne z domeny CMS.

## 1.7.0

- Zastąpiono ręczne pola domen dropdownami aktywnych domen głównych z hostingiem Pleska.
- Manifest, adres panelu WordPressa, lista awaryjna i document root są ustawiane automatycznie.
- Dodano instrukcję krok po kroku, podgląd wyliczonych wartości i jasny opis skutków zapisu, audytu oraz synchronizacji.
- Backend odrzuca domeny spoza listy Pleska również po spreparowaniu żądania HTTP.

## 1.6.0

- Dodano LifeBound do wspólnego katalogu aplikacji, autoryzacji runtime i stron produktów.
- Panel pokazuje moduł LifeBound oraz jego integrację NUA bez tworzenia osobnego pluginu.

## 1.5.0

- Dodano jeden katalog produktów dla Rollbound, Rollbound Light, Sheetbound i Hellbound.
- Zastąpiono osobną zakładkę Hellbound wspólną zakładką `Aplikacje` z wyborem właściwego wykonawcy.
- Wszystkie produkty wskazują jeden plugin, jeden ZIP i wspólny mechanizm długich zadań.

## 1.4.0

- Połączono wykonawców Nerd Apps Runtime i Hellbound w jeden helper `nerd-apps-runtime-manager`.
- Dodano jawne zakresy operacji (`runtime` i `hellbound`) przy zachowaniu osobnych sekcji panelu.
- Usunięto zbędną klasę zadania i drugi plik wykonywalny Hellbound.
- Zaktualizowano domyślne ścieżki monorepozytorium do katalogu `apps/`.

## 1.3.0

- Make this extension the single Plesk control plane for the shared runtime, Bound product sites and Hellbound.
- Add safe manifest-driven audit/synchronization for product subdomains without deleting existing hosts.
- Add an isolated Hellbound deployment helper with encrypted secrets, sparse monorepo checkout, immutable releases, backups and last-known-good rollback.
- Add dedicated, responsive `Strony produktów` and `Hellbound` dashboard tabs.
- Keep runtime and Hellbound settings, operation files, locks and state snapshots isolated from each other.

## 1.2.6

- Repair ownership and permissions of the active RAG document tree before every ingest.
- Assign only the non-root API UID/GID `10001`, with `0750` directories and `0640` files.
- Reject symlinks and paths escaping the deployed runtime before changing any permissions.
- Prepare the staged document tree during deployment so the read-only bind mount is usable immediately.

## 1.2.5

- Rebuild the RAG index automatically during every successful runtime deployment.
- Validate full readiness only after ingestion, preventing an empty Qdrant collection from reaching production unnoticed.
- Make the explicit RAG operation run readiness verification and include the ingest result in the manager log.

## 1.2.4

- Embed the nginx CORS sanitizer directly into the packaged privileged `sbin` helper.
- Remove the invalid runtime dependency on the separately installed Plesk `plib` tree.
- Verify during packaging that the executable is self-contained and contains no `require_once` path.

## 1.2.3

- Add an automatic domain CORS repair operation with an atomic vhost update and rollback.
- Remove only legacy `Access-Control-Allow-*` directives and manual `OPTIONS`/`204` blocks while preserving unrelated nginx security directives.
- Back up the original vhost, reconfigure the Plesk domain, run the nginx configuration test and verify the local HTTPS preflight response.
- Apply the same legacy CORS cleanup automatically whenever managed reverse proxy configuration is repaired.

## 1.2.2

- Fix managed reverse proxy generation when the Plesk domain has standard Proxy Mode enabled.
- Use the same ACME-safe regex location as manual mode instead of creating a duplicate `location /`.
- Disable proxy buffering and forward host/port consistently for streamed runtime responses.
- Add a dedicated proxy repair/apply operation that does not redeploy the runtime containers.

## 1.2.1

- Show an exact, copyable Plesk nginx vhost snippet whenever manual proxy mode is selected.
- Keep the Plesk ACME path outside the proxy and avoid a duplicate root location with Proxy Mode enabled.

## 1.2.0

- Fix tab initialization when Plesk mounts the extension view asynchronously.
- Add keyboard-accessible tabs, remembered selection and direct in-panel navigation.
- Redesign status, deployment, runtime and log panels to match the WPKit and KitsunePNC managers.
- Preserve the relevant panel after form validation, save and queued operations.
- Add status refresh, operation confirmations, duplicate-submit protection and log copying.

## 1.1.0

- Deployment and configuration rollback now use full `/ready` dependency readiness.
- Surface a degraded runtime explicitly in the Plesk dashboard.
- Align with capability-bound Nerd Universal Apps v2 tickets.

## 1.0.0

- Initial Nerd Apps Runtime deployment manager.
- Full runtime configuration, encrypted credentials and Git deploy keys.
- Safe check/sync/deploy workflow with Docker Compose health verification.
- Plesk domain reverse proxy, service controls, ingest, logs and Qdrant snapshot action.
- Central GPT Image model/output/timeout limits and bounded idempotent replay configuration.
- Nerd Universal Apps ticket settings for authenticated Rollbound and Sheetbound clients.
