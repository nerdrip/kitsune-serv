# KitsuneIRC Deployment Manager 1.2.7

Rozszerzenie jest przeznaczone dla Plesk Obsidian 18.0.41+ na Linuxie. Wymaga
Git, Docker Engine i Compose v2. Node.js nie jest wymagany na hoście.

Wersja rozszerzenia (`1.2.7`) jest niezależna od wersji wdrażanego produktu.
Serwer IRC, panel administracyjny i oba klienty mogą mieć np. wersję `1.0.0`,
podczas gdy manager Pleska rozwija się własnym cyklem wydań.

## Instalacja

Zbuduj paczkę poleceniem `npm run plesk:package`, a następnie zainstaluj ZIP:

```bash
plesk bin extension -i KitsuneIRC-Plesk-Manager-1.2.7-YYYYMMDD-HHMMSS.zip
```

Aktualizacja używa `plesk bin extension -g PACZKA.zip`. Odinstalowanie
rozszerzenia nie usuwa repozytorium, danych, backupów ani kontenerów.

## Pierwsze wdrożenie

1. Podaj repozytorium, branch i trzy rozłączne katalogi: kod, dane i backupy.
2. Ustaw tożsamość sieci IRC, MOTD, limity, porty IRC/TLS i opcjonalne hasło wejściowe.
3. Utwórz pierwszego operatora IRC oraz wybierz usługi NickServ, ChanServ,
   MemoServ, OperServ, BotServ i HostServ.
4. Skonfiguruj flood protection, throttle, SASL, cloaking, DNSBL i pełne limity bouncera.
5. Wybierz dwie aktywne domeny Pleska, konto administratora WWW i sposób reverse proxy.
6. Wybierz możliwości panelu: podgląd bazy i zapytania odczytowe są domyślnie
   włączone, zapis SQL domyślnie wyłączony, a edytor pluginów włączony.
7. W polu **Po zapisaniu** wybierz pełne pierwsze wdrożenie. Manager pobierze kod,
   zbuduje oba obrazy, zapisze prywatny `config.js`, utworzy operatora IRC i
   administratora WWW, uruchomi kontenery i skonfiguruje proxy.
8. Dla produkcyjnego IRC TLS zastąp wygenerowany certyfikat własnym certyfikatem
   w katalogu `certs`; manager nigdy go nie zapisuje w repozytorium.

Domyślne lokalne porty HTTP KitsuneIRC to `18181` dla panelu i `18180` dla
klienta WWW. Są celowo inne od portu `18080` używanego przez KitsunePNC.
Przed budową manager sprawdza wszystkie wymagane porty hosta i w razie kolizji
wskazuje dokładne pole w karcie **Konfiguracja**, które należy zmienić.

Domena klienta WWW może być taka sama jak nazwa serwera IRC: HTTPS/WSS działa
na porcie `443`, a natywny IRC na `6667` lub TLS `6697`. Kontener klienta łączy
się z serwerem przez wewnętrzny adres Compose `server:6667`. Handshake WSS jest
zgodny z RFC 6455 i nie wymaga wystawiania wewnętrznej nazwy `server` w DNS.

Kod aktualizuje się wyłącznie przez `git merge --ff-only`. Lokalne zmiany
blokują synchronizację i wdrożenie. Panel oraz klient webowy są publikowane
przez dwa oznaczone bloki nginx; publiczny TLS kończy się w Plesku. Porty HTTP
kontenerów pozostają na `127.0.0.1`.

Skrypt pełnej konfiguracji serwera jest częścią instalowanego `plib`. Dla
operacji wdrożenia trafia do prywatnego pliku zadania z uprawnieniami `0600`,
a program `sbin` przed użyciem weryfikuje jego SHA-256. Dzięki temu wdrożenie
nie zależy od tego, w jakich osobnych katalogach Plesk zainstalował `plib` i
uprzywilejowany program rozszerzenia.

Bouncer jest częścią modułu `server`; jego porty plain/TLS są publikowane
bezpośrednio tak jak IRC. Dla dostępu publicznego zalecany jest wyłącznie port
TLS z zaufanym certyfikatem, a reguły firewalla należy skonfigurować poza
rozszerzeniem.

Backup obejmuje bazę SQLite, konfigurację, pluginy i certyfikaty, zapisuje
rozmiary oraz SHA-256. Restore wymaga tekstu `RESTORE:nazwa`, zatrzymuje
serwer, weryfikuje kopię, odtwarza dane i ponownie sprawdza healthcheck.
Narzędzie danych zawsze otrzymuje jawne ścieżki kontenera, w tym zamontowany
katalog `/var/backups/kitsuneirc`; nie próbuje zapisywać w katalogu aplikacji
`/app`, który pozostaje tylko do odczytu.

## Ręczny reverse proxy

Po wybraniu trybu **Konfiguracja ręczna** karta formularza pokazuje dwa gotowe
bloki dla `vhost_nginx.conf`: osobny dla domeny panelu i klienta WWW. Kod jest
generowany z aktualnych domen i portów, działa z WebSocket i ma przycisk
kopiowania. Jest renderowany również bez JavaScriptu, więc pozostaje dostępny
przy problemie z assetami panelu Pleska.

Bloki używają `location ~ ^/.*`, ponieważ standardowy vhost Pleska posiada już
własne `location /`. Manager zastępuje starszy wadliwy blok automatycznie i
wycofuje zmianę pliku, jeżeli `httpdmng` lub test konfiguracji nginx zakończy
się błędem.

Karta podaje też dokładną ścieżkę każdego pliku oraz gotowe polecenie
`plesk sbin httpdmng --reconfigure-domain DOMENA`. Ręczne bloki mają znaczniki
`KITSUNEIRC MANUAL`; manager nie usuwa ich podczas kolejnego wdrożenia. Po
przełączeniu z trybu automatycznego usuwa jedynie własne stare bloki oznaczone
`KITSUNEIRC MANAGED`.

## Obsługa

Karta **Stan i usługi** zawiera Start/Restart/Stop dla obu kontenerów. Karta
**Dziennik** rozdziela log managera, serwera IRC i klienta WWW. Pozostałe karty
zapewniają bezpieczny fast-forward, selektywny deploy, wersje lokalne/zdalne,
backup z SHA-256 i kontrolowany restore.
