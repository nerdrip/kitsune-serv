# Changelog

## 1.3.4-4 — 2026-08-21

- Self-update synchronizuje repozytorium KitsuneIRC i buduje paczkę z przypiętego commitu zamiast korzystać z manifestu KitsuneServ.

## 1.3.4-2 — 2026-08-20

- Dodano wspólny pasek Kitsune Plesk Suite oraz powrót do centralnego ekranu zarządzania.
- Osobny wpis menu jest ukrywany tylko wtedy, gdy aktywny Kitsune Hub przejmuje nawigację.

## 1.3.4 — 2026-08-01

- Proces uprzywilejowany przekazuje teraz ograniczoną ramkę aktualnego stanu przez `stdout`; kontroler zapisuje ją atomowo we własnym katalogu Pleska, niezależnie od aliasów ścieżek lub przestrzeni montowania.
- Ten sam transport synchronizuje stan po zadaniach długotrwałych oraz po błędach, a ramka techniczna jest usuwana z komunikatów widocznych dla użytkownika.
- Brak ramki pokazuje klucze zwrócone przez `pm_ApiCli` i bezpiecznie skrócony `stdout`, co jednoznacznie wykrywa uruchomienie nieaktualnego albo niewłaściwego programu `sbin`.
- Diagnostyka pokazuje osobno ścieżkę stanu widzianą przez backend, ścieżkę kontrolera oraz użyty transport.

## 1.3.3 — 2026-08-01

- Ekran odczytuje stan niezależnie od kompletności pierwszej konfiguracji; brak domyślnego e-maila, domeny lub sekretu nie blokuje już uruchomienia diagnostyki.
- Status ma osobną minimalną walidację bez wymagań właściwych dla wdrożenia i może wykryć istniejące repozytorium oraz kontenery jeszcze przed ukończeniem konfiguracji.
- Kontroler zgłasza teraz jawny błąd, gdy backend zwróci sukces bez utworzenia `state.json`, a komunikat jest wyświetlany bezpośrednio w sekcji stanu.
- Diagnostyka pokazuje wersję faktycznie uruchomionego programu backendowego, co pozwala wykryć niepełną aktualizację pliku `sbin`.

## 1.3.2 — 2026-08-01

- Stan kontenerów jest wykrywany także bez lokalnego `runtime.env` lub pliku Compose: manager korzysta awaryjnie z globalnej listy Dockera i etykiet projektu KitsuneIRC.
- Wersja wdrożona pochodzi teraz z obrazu faktycznie przypisanego do kontenera, a stan obejmuje również zatrzymane kontenery.
- Lokalna wersja produktu jest odczytywana niezależnie od metadanych Git, natomiast jawne odświeżenie aktualizuje `origin` bez zmiany działających usług.
- Ekran pokazuje dokładną diagnostykę użytych ścieżek, źródła danych i przyczyny braku repozytorium lub kontenerów zamiast samych pustych pól.
- Odczyt stanu czeka krótko na kończącą się operację, a po przekroczeniu czasu wyświetla informację o stanie z pamięci podręcznej zamiast milczącego sukcesu.

## 1.3.1 — 2026-08-01

- Przycisk „Odśwież stan” zawsze otwiera teraz kartę „Stan i usługi”, niezależnie od poprzedniego parametru `tab` w adresie.
- Kliknięcie karty aktualizuje adres strony, dzięki czemu ręczne odświeżenie i nawigacja Pleska zachowują właściwą sekcję.

## 1.3.0 — 2026-08-01

- Operacje Pleska są teraz serializowane: kolejne zadanie czeka na poprzednie, a odświeżenie stanu nie powoduje już błędu „Another KitsuneIRC operation is already running”.
- Manager pokazuje aktywną operację i zachowuje ostatni poprawny stan podczas wdrożenia.
- Pierwszy operator oraz operatorzy dodawani w panelu otrzymują powiązane, niegasnące konto NickServ używające tego samego hasha bcrypt; kolizja z cudzym kontem jest bezpiecznie odrzucana.
- Klient WWW i desktopowy mają zwijaną, nieutrwalaną sekcję logowania operatora oraz skróty do pełnej pomocy i `/HELP OPER`.
- `/HELP` obejmuje wszystkie polecenia IRC, z osobną składnią i wymaganiami uprawnień dla każdego tematu.

## 1.2.7 — 2026-08-01

- Dodano do pierwszej konfiguracji przełączniki podglądu bazy/konsoli SQL, modyfikacji SQL i edytora pluginów.
- Domyślnie działają tabele, przegląd bazy, zapytania tylko do odczytu oraz edytor pluginów; modyfikacje SQL pozostają bezpiecznie wyłączone.
- Panel otrzymuje capabilities po zalogowaniu, ukrywa niedostępne strony i destrukcyjne kontrolki oraz scala powtarzające się komunikaty błędów.
- Naprawiono handshake klienta WWW zgodnie z RFC 6455: `Sec-WebSocket-Accept` używa teraz prawidłowego GUID protokołu.

## 1.2.6 — 2026-08-01

- Usunięto konflikt ze standardowym `location /` generowanym przez Pleska; zarządzane i ręczne bloki proxy używają teraz bezpiecznego catch-all regex `location ~ ^/.*`.
- Ponowne wdrożenie automatycznie zastępuje wadliwe bloki zapisane przez wersje do `1.2.5`.
- Dodano rollback pliku `vhost_nginx.conf` i ponowną rekonfigurację domeny po błędzie `httpdmng` lub testu nginx.

## 1.2.5 — 2026-08-01

- Naprawiono automatyczny backup przed aktualizacją: narzędzie danych używa teraz zamontowanego katalogu `/var/backups/kitsuneirc`, a nie niedostępnego `/app/backups`.
- Backup i restore otrzymują jawnie wszystkie ścieżki danych wewnątrz kontenera, dzięki czemu działają również ze starszym plikiem Compose pobranym z repozytorium.

## 1.2.4 — 2026-08-01

- Usunięto kolizję domyślnego portu klienta WWW z KitsunePNC: KitsuneIRC używa teraz własnych portów `18180/18181`.
- Dodano preflight portów IRC, bouncera, panelu oraz klienta WWW przed budową i startem kontenerów.
- Aktualizacja automatycznie przenosi port `18080` na pierwszy wolny port `18180–18199`, ale wyłącznie po dokładnie rozpoznanym nieudanym pierwszym wdrożeniu.

## 1.2.3 — 2026-08-01

- Naprawiono uruchamianie pełnej konfiguracji serwera po instalacji rozszerzenia: Plesk przechowuje program `sbin` oddzielnie od zasobów modułu.
- Skrypt provisioningu jest teraz ładowany z instalowanej części `plib`, dołączany do prywatnej konfiguracji zadania i weryfikowany sumą SHA-256 przed wykonaniem.

## 1.2.2 — 2026-08-01

- Poprawiono bazowy katalog `docker compose`: plik z `deploy/` rozwiązuje teraz
  `build.context: ..` względem katalogu `source/deploy`, dzięki czemu Docker
  używa repozytorium `source` i istniejącego `source/deploy/Dockerfile` zamiast
  błędnej ścieżki `/home/kitsuneirc/deploy`.
- Dodano test regresyjny blokujący ponowne ustawienie katalogu projektu Compose
  na katalog główny repozytorium.

## 1.2.1 — 2026-08-01

- Poprawiono odpowiedzi wszystkich formularzy pod `Jsw.FormAjax` w Plesk
  Obsidian 18.0.79. Zapis, błędy walidacji i kolejka operacji zwracają teraz
  oczekiwany JSON z przekierowaniem zamiast pełnej strony HTML pokazywanej jako
  „Internal error”.
- Dodano walidację dwóch różnych domen jeszcze przed wysłaniem konfiguracji,
  natywne atrybuty `required` i powrót do właściwej karty po operacji.

## 1.2.0 — 2026-07-31

- Przebudowano interfejs na ten sam odporny model kart i kontrolek co managery
  NailIT, KitsunePNC i WPKit; aktywna karta jest renderowana przez PHP i działa
  również wtedy, gdy JavaScript Pleska załaduje się z opóźnieniem.
- Dodano pełną konfigurację pierwszego uruchomienia: tożsamość IRC, MOTD,
  operator bcrypt, usługi sieciowe, limity, zabezpieczenia, bouncer, panel WWW,
  domeny, Git i automatyczne wdrożenie obu modułów.
- Dodano Start/Restart/Stop dla serwera i klienta WWW oraz osobne logi obu
  kontenerów.
- Tryb ręcznego proxy pokazuje dwa kompletne bloki `vhost_nginx.conf`, aktualizuje
  je wraz z formularzem i pozwala kopiować kod.
- Pakowacz blokuje rozbieżność wersji `meta.xml` i backendu rozszerzenia.

## 1.1.1 — 2026-07-31

- Usunięto konflikt prywatnego helpera `redirect()` z publiczną metodą
  `Zend_Controller_Action::redirect()`, który powodował błąd krytyczny po
  otwarciu rozszerzenia w Plesk Obsidian 18.0.79.

## 1.1.0 — 2026-07-29

- Konfiguracja i publikacja portów trwałego bouncera IRC (plain/TLS).
- Walidacja unikalności sześciu portów oraz adresu nasłuchu bouncera.
- Widoczny stan portów bouncera na ekranie podsumowania.

## 1.0.0 — 2026-07-29

- Pierwsze kompletne wydanie wzorowane na managerach KitsunePNC, NailIT i WPKit.
- Bezpieczny Git fast-forward przez token HTTPS albo przypięty klucz SSH.
- Osobne wersje i selektywne wdrażanie serwera oraz klienta webowego.
- Docker Compose z portami WWW dostępnymi tylko na loopbackie.
- Zarządzany reverse proxy Pleska dla panelu admina i klienta webowego.
- Szyfrowane sekrety, blokada operacji, redakcja logów i pliki z trybem 0600.
- Backup, weryfikacja integralności i restore z jawnym potwierdzeniem.
