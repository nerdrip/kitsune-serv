<?php

pm_Context::init('kitsuneirc-manager');
$application = new pm_Application();
$application->run();
