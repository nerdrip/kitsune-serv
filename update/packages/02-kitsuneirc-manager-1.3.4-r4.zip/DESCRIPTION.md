# KitsuneIRC Deployment Manager

Panel Pleska do pełnej pierwszej konfiguracji, bezpiecznej synchronizacji Git,
selektywnego wdrażania i sterowania serwerem IRC, usługami, bouncerem, panelem
administracyjnym oraz klientem WWW. Zawiera automatyczny lub udokumentowany
ręczny reverse proxy, logi usług, kontrolę zdrowia i wersji oraz backup/restore.
