<?php

class Modules_KitsuneircManager_Config
{
    public const EXTENSION_VERSION = '1.3.4';

    private const SECRET_FIELDS = [
        'gitToken' => 'secret_git_token',
        'gitSshPrivateKey' => 'secret_git_ssh_private_key',
        'adminPassword' => 'secret_admin_password',
        'operPassword' => 'secret_oper_password',
        'serverPassword' => 'secret_server_password',
    ];

    public static function defaults()
    {
        return [
            'repositoryUrl' => 'https://github.com/nerdrip/kitsune-irc.git',
            'repositoryBranch' => 'main',
            'repositoryPath' => '/opt/kitsuneirc/source',
            'gitUsername' => 'x-access-token',
            'gitSshKnownHosts' => '',
            'dataPath' => '/var/lib/kitsuneirc',
            'backupPath' => '/var/backups/kitsuneirc',
            'backupRetention' => '10',
            'serverName' => 'irc.example.com',
            'networkName' => 'KitsuneNet',
            'serverDescription' => 'KitsuneNet IRC Server',
            'serverAdminEmail' => 'admin@example.com',
            'motd' => "Witaj w KitsuneNet!\n\n/msg NickServ HELP — rejestracja nicka\n/msg ChanServ HELP — rejestracja kanału",
            'maxClients' => '1024',
            'maxChannelsPerUser' => '50',
            'defaultModes' => '+iwx',
            'serverPasswordEnabled' => 'false',
            'ircBindAddress' => '0.0.0.0',
            'ircPort' => '6667',
            'ircTlsPort' => '6697',
            'bouncerEnabled' => 'true',
            'bouncerBindAddress' => '0.0.0.0',
            'bouncerPort' => '7667',
            'bouncerTlsPort' => '7669',
            'bouncerMaxUsers' => '100',
            'bouncerMaxNetworks' => '10',
            'bouncerMaxClients' => '250',
            'bouncerMaxConnectionsPerIP' => '5',
            'bouncerMaxAuthAttempts' => '10',
            'bouncerAuthWindowMs' => '300000',
            'bouncerBufferSize' => '2000',
            'bouncerBufferLines' => '10000',
            'tlsEnabled' => 'true',
            'operName' => 'admin',
            'operHost' => '*@*',
            'operFlags' => 'oOaANrRDKGZCcdkbBnmMSqtUTHW',
            'nickservEnabled' => 'true',
            'chanservEnabled' => 'true',
            'memoservEnabled' => 'true',
            'operservEnabled' => 'true',
            'botservEnabled' => 'true',
            'hostservEnabled' => 'true',
            'requireSasl' => 'false',
            'cloakEnabled' => 'true',
            'cloakPrefix' => 'kitsune',
            'dnsblEnabled' => 'false',
            'dnsblServers' => "dnsbl.dronebl.org\nrbl.efnetrbl.org",
            'floodEnabled' => 'true',
            'floodMaxPerInterval' => '20',
            'floodIntervalMs' => '10000',
            'maxConnectionsPerIp' => '5',
            'throttleEnabled' => 'true',
            'throttleConnections' => '3',
            'throttlePeriodMs' => '60000',
            'adminPort' => '18181',
            'webPort' => '18180',
            'webMaxConnections' => '250',
            'sessionTimeoutMs' => '86400000',
            'sqlConsoleEnabled' => 'true',
            'sqlWriteEnabled' => 'false',
            'pluginEditorEnabled' => 'true',
            'adminDomain' => 'admin.example.com',
            'webDomain' => 'chat.example.com',
            'proxyMode' => 'managed',
            'adminUsername' => 'admin',
            'loggingLevel' => 'info',
        ];
    }

    public static function values()
    {
        $values = [];
        foreach (self::defaults() as $key => $default) {
            $values[$key] = (string) pm_Settings::get($key, $default);
        }
        return $values;
    }

    public static function save(array $values)
    {
        foreach (self::defaults() as $key => $default) {
            if (array_key_exists($key, $values)) {
                pm_Settings::set($key, trim((string) $values[$key]));
            }
        }
        foreach (self::SECRET_FIELDS as $field => $setting) {
            $value = trim((string) ($values[$field] ?? ''));
            if ($field === 'gitSshPrivateKey') $value = self::normalizePrivateKey($value);
            if ($value !== '') pm_Settings::setEncrypted($setting, $value);
        }
    }

    public static function hasSecret($field)
    {
        return self::secret($field) !== '';
    }

    public static function isFirstRunReady()
    {
        $values = self::values();
        return trim($values['repositoryUrl']) !== ''
            && strtolower(trim($values['serverName'])) !== 'irc.example.com'
            && strtolower(trim($values['adminDomain'])) !== 'admin.example.com'
            && strtolower(trim($values['webDomain'])) !== 'chat.example.com'
            && strtolower(trim($values['serverAdminEmail'])) !== 'admin@example.com'
            && self::hasSecret('adminPassword')
            && self::hasSecret('operPassword')
            && ($values['serverPasswordEnabled'] !== 'true' || self::hasSecret('serverPassword'));
    }

    public static function readState()
    {
        $path = pm_Context::getVarDir() . '/state.json';
        if (!is_file($path)) return self::emptyState();
        $decoded = json_decode((string) file_get_contents($path), true);
        return is_array($decoded)
            ? array_replace_recursive(self::emptyState(), $decoded)
            : self::emptyState();
    }

    public static function importStateFromOutput($output)
    {
        $output = (string) $output;
        if (!preg_match_all('/^::kitsuneirc-state-v1::([A-Za-z0-9+\/=]+)\r?$/m', $output, $matches) || empty($matches[1])) {
            return false;
        }
        $encoded = (string) end($matches[1]);
        if (strlen($encoded) > 12582912) return false;
        $json = base64_decode($encoded, true);
        if ($json === false || strlen($json) > 8388608) return false;
        $state = json_decode($json, true);
        if (!is_array($state)) return false;

        $varDir = rtrim((string) pm_Context::getVarDir(), "/\\");
        if (!is_dir($varDir) && !mkdir($varDir, 0700, true) && !is_dir($varDir)) return false;
        @chmod($varDir, 0700);
        $state['diagnostics'] = is_array($state['diagnostics'] ?? null) ? $state['diagnostics'] : [];
        $state['diagnostics']['controllerStatePath'] = $varDir . '/state.json';
        $state['diagnostics']['stateTransport'] = 'stdout-v1';
        $serialized = json_encode($state, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($serialized === false) return false;

        $temporary = $varDir . '/.state-import-' . bin2hex(random_bytes(8)) . '.tmp';
        $previousUmask = umask(0077);
        try {
            if (file_put_contents($temporary, $serialized . "\n", LOCK_EX) === false) return false;
            @chmod($temporary, 0600);
            if (!rename($temporary, $varDir . '/state.json')) return false;
        } finally {
            umask($previousUmask);
            if (is_file($temporary)) @unlink($temporary);
        }
        return true;
    }

    public static function stripStateFromOutput($output)
    {
        return trim((string) preg_replace('/^::kitsuneirc-state-v1::[A-Za-z0-9+\/=]+\r?\n?/m', '', (string) $output));
    }

    public static function createRuntimeConfig($action, array $parameters = [])
    {
        $allowed = ['status', 'check', 'sync', 'deploy', 'sync-deploy', 'backup', 'restore', 'start', 'stop', 'restart'];
        if (!in_array($action, $allowed, true)) throw new InvalidArgumentException('Unsupported operation.');
        $varDir = rtrim((string) pm_Context::getVarDir(), "/\\");
        if (!is_dir($varDir) && !mkdir($varDir, 0700, true) && !is_dir($varDir)) {
            throw new RuntimeException('Nie udało się utworzyć katalogu roboczego rozszerzenia.');
        }
        @chmod($varDir, 0700);
        $realVarDir = realpath($varDir);
        if ($realVarDir === false) throw new RuntimeException('Nie udało się ustalić katalogu roboczego.');

        $config = self::values();
        $config['gitToken'] = self::secret('gitToken');
        $config['gitSshPrivateKey'] = self::normalizePrivateKey(self::secret('gitSshPrivateKey'));
        $config['adminPassword'] = self::secret('adminPassword');
        $config['operPassword'] = self::secret('operPassword');
        $config['serverPassword'] = self::secret('serverPassword');
        $config['action'] = $action;
        $config['modules'] = array_values(array_intersect(
            (array) ($parameters['modules'] ?? []),
            ['server', 'web-client']
        ));
        $config['backupName'] = trim((string) ($parameters['backupName'] ?? ''));
        $config['confirmation'] = trim((string) ($parameters['confirmation'] ?? ''));
        $config['refreshRemote'] = !empty($parameters['refreshRemote']);
        $config['requestedAt'] = gmdate('c');

        if (
            in_array($action, ['deploy', 'sync-deploy'], true)
            && in_array('server', $config['modules'], true)
        ) {
            $provisionPath = dirname(__DIR__) . '/resources/provision.js';
            $provisionScript = is_file($provisionPath) ? file_get_contents($provisionPath) : false;
            if (
                $provisionScript === false
                || $provisionScript === ''
                || strlen($provisionScript) > 262144
            ) {
                throw new RuntimeException('Brak prawidłowego skryptu konfiguracji serwera w pakiecie rozszerzenia.');
            }
            $config['provisionScriptBase64'] = base64_encode($provisionScript);
            $config['provisionScriptSha256'] = hash('sha256', $provisionScript);
        }

        if ($config['proxyMode'] === 'managed' && in_array($action, ['deploy', 'sync-deploy', 'restore'], true)) {
            foreach (['adminDomain', 'webDomain'] as $field) {
                $domain = self::hostedDomain($config[$field]);
                $prefix = $field === 'adminDomain' ? 'admin' : 'web';
                $config[$prefix . 'VhostSystemPath'] = (string) $domain->getVhostSystemPath();
            }
        }

        $path = $realVarDir . '/operation-' . bin2hex(random_bytes(12)) . '.json';
        $json = json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $previousUmask = umask(0077);
        try {
            if ($json === false || file_put_contents($path, $json, LOCK_EX) === false) {
                throw new RuntimeException('Nie udało się zapisać konfiguracji operacji.');
            }
            @chmod($path, 0600);
        } finally {
            umask($previousUmask);
        }
        return $path;
    }

    private static function hostedDomain($name)
    {
        $name = strtolower(trim((string) $name));
        try {
            $domain = pm_Domain::getByName($name);
        } catch (Throwable $exception) {
            throw new RuntimeException('Domena Pleska nie istnieje lub jest niedostępna: ' . $name, 0, $exception);
        }
        if (
            !$domain instanceof pm_Domain ||
            !$domain->hasHosting() ||
            !$domain->isActive() ||
            $domain->isSuspended() ||
            $domain->isDisabled()
        ) {
            throw new RuntimeException('Domena musi mieć aktywny hosting: ' . $name);
        }
        return $domain;
    }

    private static function secret($field)
    {
        $setting = self::SECRET_FIELDS[$field] ?? null;
        if ($setting === null) return '';
        try {
            return (string) pm_Settings::getDecrypted($setting);
        } catch (Exception $exception) {
            return '';
        }
    }

    private static function normalizePrivateKey($value)
    {
        $value = str_replace(["\r\n", "\r"], "\n", (string) $value);
        if (strncmp($value, "\xEF\xBB\xBF", 3) === 0) $value = substr($value, 3);
        return trim($value);
    }

    private static function emptyState()
    {
        return [
            'updatedAt' => null,
            'lastOperation' => null,
            'lastSuccess' => null,
            'lastError' => null,
            'activeOperation' => null,
            'repository' => [
                'branch' => null,
                'localCommit' => null,
                'remoteCommit' => null,
                'dirty' => null,
                'updateAvailable' => null,
                'error' => null,
            ],
            'versions' => [
                'server' => ['deployed' => null, 'local' => null, 'remote' => null],
                'web-client' => ['deployed' => null, 'local' => null, 'remote' => null],
            ],
            'services' => [],
            'serviceLogs' => ['server' => [], 'web-client' => []],
            'proxy' => ['mode' => null, 'adminDomain' => null, 'webDomain' => null, 'configuredAt' => null],
            'backups' => [],
            'diagnostics' => [],
            'log' => [],
        ];
    }
}
