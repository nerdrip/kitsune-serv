<?php

pm_Context::init('kitsuneirc-manager');
require_once dirname(__DIR__) . '/library/Config.php';
$varDir = pm_Context::getVarDir();
if (!is_dir($varDir)) mkdir($varDir, 0700, true);
@chmod($varDir, 0700);
foreach (Modules_KitsuneircManager_Config::defaults() as $key => $value) {
    if (pm_Settings::get($key) === null) pm_Settings::set($key, (string) $value);
}

// KitsunePNC historically uses 127.0.0.1:18080. Migrate only the failed
// KitsuneIRC first-deploy case, never a working or deliberately configured site.
$state = Modules_KitsuneircManager_Config::readState();
$lastError = strtolower((string) ($state['lastError'] ?? ''));
$legacyWebPortConflict = (string) pm_Settings::get('webPort', '') === '18080'
    && strpos($lastError, '127.0.0.1:18080') !== false
    && (strpos($lastError, 'port is already allocated') !== false || strpos($lastError, 'address already in use') !== false);
if ($legacyWebPortConflict) {
    $reserved = [];
    foreach (['ircPort', 'ircTlsPort', 'bouncerPort', 'bouncerTlsPort', 'adminPort'] as $field) {
        $reserved[] = (int) pm_Settings::get($field, '0');
    }
    foreach (range(18180, 18199) as $candidate) {
        if (in_array($candidate, $reserved, true)) continue;
        $errorCode = 0;
        $errorMessage = '';
        $socket = @stream_socket_server(
            'tcp://127.0.0.1:' . $candidate,
            $errorCode,
            $errorMessage,
            STREAM_SERVER_BIND | STREAM_SERVER_LISTEN
        );
        if (!is_resource($socket)) continue;
        fclose($socket);
        pm_Settings::set('webPort', (string) $candidate);
        break;
    }
}
$productRoot = defined('PRODUCT_ROOT_D') ? PRODUCT_ROOT_D : '/usr/local/psa';
$utility = $productRoot . '/admin/bin/modules/kitsuneirc-manager/kitsuneirc-manager';
if (is_file($utility)) @chmod($utility, 0750);
