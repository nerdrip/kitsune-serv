<?php

class Modules_KitsuneircManager_LongTasks extends pm_Hook_LongTasks
{
    public function getLongTasks()
    {
        return [new Modules_KitsuneircManager_Task_Operate()];
    }
}
