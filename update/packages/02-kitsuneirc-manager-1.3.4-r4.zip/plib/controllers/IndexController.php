<?php

class IndexController extends pm_Controller_Action
{
    protected $_accessLevel = 'admin';

    public function init()
    {
        parent::init();
        $this->view->pageTitle = 'KitsuneIRC Deployment Manager';
        $this->view->headLink()->appendStylesheet(
            pm_Context::getBaseUrl() . 'css/kitsuneirc.css?v=' . Modules_KitsuneircManager_Config::EXTENSION_VERSION
        );
        $this->view->headLink()->appendStylesheet(pm_Context::getBaseUrl() . 'css/kitsune-platform.css?v=2');
        $this->view->headScript()->appendFile(pm_Context::getBaseUrl() . 'js/kitsune-platform.js?v=2');
        $this->view->suiteProduct = 'KitsuneIRC Manager';
        $this->view->suiteVersion = Modules_KitsuneircManager_Config::EXTENSION_VERSION;
        try { $this->view->suiteHubActive = pm_Extension::getById('kitsuneserv-bridge')->isActive(); }
        catch (Throwable $exception) { $this->view->suiteHubActive = false; }
    }

    public function indexAction()
    {
        $configForm = $this->configForm();
        $operationForm = $this->operationForm();
        $maintenanceForm = $this->maintenanceForm();
        $serviceForms = [
            'server' => $this->serviceForm('server'),
            'web-client' => $this->serviceForm('web-client'),
        ];
        $tabs = ['status', 'deploy', 'config', 'data', 'log'];
        $requestedTab = (string) $this->getRequest()->getParam('tab', '');
        $activeTab = in_array($requestedTab, $tabs, true)
            ? $requestedTab
            : (Modules_KitsuneircManager_Config::isFirstRunReady() ? 'status' : 'config');

        if ($this->getRequest()->isPost()) {
            $post = $this->getRequest()->getPost();
            $formType = (string) ($post['formType'] ?? '');
            if ($formType === 'config') {
                $this->saveConfig($configForm, $post);
                return $this->respondWithRedirect('config');
            } elseif ($formType === 'operation') {
                $this->startOperation($operationForm, $post);
                return $this->respondWithRedirect('deploy');
            } elseif ($formType === 'maintenance') {
                $this->startMaintenance($maintenanceForm, $post);
                return $this->respondWithRedirect('data');
            } elseif ($formType === 'service') {
                $this->startServiceOperation($serviceForms, $post);
                return $this->respondWithRedirect('status');
            } else {
                $this->_status->addMessage('error', 'Nie rozpoznano formularza.');
                return $this->respondWithRedirect($activeTab);
            }
        }

        $firstRunReady = Modules_KitsuneircManager_Config::isFirstRunReady();
        $refreshRequested = (string) $this->getRequest()->getParam('refresh', '') === '1';
        $refreshResult = $this->refreshStatus($refreshRequested);
        $refreshUrl = pm_Context::getActionUrl('index', 'index');
        $refreshUrl .= (strpos($refreshUrl, '?') === false ? '?' : '&') . 'tab=status&refresh=1';
        $this->view->configForm = $configForm;
        $this->view->operationForm = $operationForm;
        $this->view->maintenanceForm = $maintenanceForm;
        $this->view->serviceForms = $serviceForms;
        $this->view->state = Modules_KitsuneircManager_Config::readState();
        $this->view->config = Modules_KitsuneircManager_Config::values();
        $this->view->activeTab = $activeTab;
        $this->view->statusRefreshError = $refreshResult['error'];
        $this->view->statusRefreshNotice = $refreshResult['notice'];
        $this->view->statusRefreshUrl = $refreshUrl;
        $this->view->hasGitToken = Modules_KitsuneircManager_Config::hasSecret('gitToken');
        $this->view->hasSshKey = Modules_KitsuneircManager_Config::hasSecret('gitSshPrivateKey');
        $this->view->hasAdminPassword = Modules_KitsuneircManager_Config::hasSecret('adminPassword');
        $this->view->hasOperPassword = Modules_KitsuneircManager_Config::hasSecret('operPassword');
        $this->view->hasServerPassword = Modules_KitsuneircManager_Config::hasSecret('serverPassword');
        $this->view->firstRunReady = $firstRunReady;
        $this->view->extensionVersion = Modules_KitsuneircManager_Config::EXTENSION_VERSION;
    }

    private function configForm()
    {
        $v = Modules_KitsuneircManager_Config::values();
        $domains = $this->domainOptions();
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kitsuneirc-config-form');
        $form->addElement('hidden', 'formType', ['value' => 'config']);

        $this->section($form, 'repoSection', 'Repozytorium i trwałe dane', 'Kopia wdrożeniowa jest oddzielona od danych, certyfikatów, pluginów i backupów.');
        $this->text($form, 'repositoryUrl', 'Repozytorium Git', $v['repositoryUrl'], 'HTTPS lub SSH, np. git@github.com:firma/kitsune-irc.git.', true);
        $this->text($form, 'repositoryBranch', 'Gałąź', $v['repositoryBranch'], 'Synchronizacja używa wyłącznie fast-forward.', true);
        $this->path($form, 'repositoryPath', 'Katalog kodu', $v['repositoryPath'], 'Np. /opt/kitsuneirc/source.');
        $this->path($form, 'dataPath', 'Katalog danych', $v['dataPath'], 'Zawiera bazę, konfigurację, certyfikaty i pluginy; musi być poza repozytorium.');
        $this->path($form, 'backupPath', 'Katalog backupów', $v['backupPath'], 'Musi być poza repozytorium i katalogiem danych.');
        $this->number($form, 'backupRetention', 'Liczba backupów', $v['backupRetention'], 1, 365, 'Starsze kopie są rotowane po udanym backupie.');

        $this->section($form, 'ircSection', 'Serwer IRC', 'Porty IRC są publikowane bezpośrednio; panel i klient WWW pozostają na loopbackie.');
        $this->text($form, 'serverName', 'Publiczna nazwa serwera', $v['serverName'], 'FQDN używany przez protokół IRC i certyfikat.', true);
        $this->text($form, 'networkName', 'Nazwa sieci', $v['networkName'], 'Widoczna w powitaniu i ISUPPORT.', true);
        $this->text($form, 'serverDescription', 'Opis serwera', $v['serverDescription'], 'Widoczny w odpowiedziach INFO i powitaniu.', true);
        $this->text($form, 'serverAdminEmail', 'E-mail administratora sieci', $v['serverAdminEmail'], 'Adres techniczny pokazywany użytkownikom.', true);
        $form->addElement('textarea', 'motd', [
            'label' => 'MOTD', 'value' => $v['motd'], 'rows' => 8,
            'description' => 'Jedna linia MOTD na wiersz; maksymalnie 100 linii.',
        ]);
        $this->number($form, 'maxClients', 'Maksymalna liczba klientów', $v['maxClients'], 1, 100000, 'Globalny limit jednoczesnych klientów IRC.');
        $this->number($form, 'maxChannelsPerUser', 'Kanały na użytkownika', $v['maxChannelsPerUser'], 1, 1000, 'Maksymalna liczba kanałów jednego klienta.');
        $this->text($form, 'defaultModes', 'Domyślne tryby użytkownika', $v['defaultModes'], 'Np. +iwx.', true);
        $form->addElement('select', 'serverPasswordEnabled', [
            'label' => 'Hasło wejściowe serwera',
            'multiOptions' => ['false' => 'Wyłączone', 'true' => 'Włączone'],
            'value' => $v['serverPasswordEnabled'],
        ]);
        $form->addElement('password', 'serverPassword', [
            'label' => 'Hasło wejściowe', 'value' => '',
            'description' => Modules_KitsuneircManager_Config::hasSecret('serverPassword')
                ? 'Zapisane i zaszyfrowane. Puste pole zachowa wartość.'
                : 'Wymagane tylko po włączeniu hasła serwera.',
        ]);
        $form->addElement('select', 'ircBindAddress', [
            'label' => 'Adres nasłuchu IRC',
            'multiOptions' => ['0.0.0.0' => 'Wszystkie interfejsy', '127.0.0.1' => 'Tylko lokalnie'],
            'value' => $v['ircBindAddress'],
        ]);
        $this->number($form, 'ircPort', 'Port IRC', $v['ircPort'], 1, 65535, 'Zwykle 6667.');
        $this->number($form, 'ircTlsPort', 'Port IRC TLS', $v['ircTlsPort'], 1, 65535, 'Zwykle 6697.');
        $form->addElement('select', 'bouncerEnabled', [
            'label' => 'IRC bouncer (ZNC-style)',
            'multiOptions' => ['true' => 'Włączony', 'false' => 'Wyłączony'],
            'value' => $v['bouncerEnabled'],
            'description' => 'Trwałe połączenia upstream, autojoin i bufor wiadomości zarządzane z panelu admina.',
        ]);
        $form->addElement('select', 'bouncerBindAddress', [
            'label' => 'Adres nasłuchu bouncera',
            'multiOptions' => ['0.0.0.0' => 'Wszystkie interfejsy', '127.0.0.1' => 'Tylko lokalnie'],
            'value' => $v['bouncerBindAddress'],
        ]);
        $this->number($form, 'bouncerPort', 'Port bouncera', $v['bouncerPort'], 1, 65535, 'Połączenie bez TLS; domyślnie 7667.');
        $this->number($form, 'bouncerTlsPort', 'Port bouncera TLS', $v['bouncerTlsPort'], 1, 65535, 'Zalecany publicznie; domyślnie 7669.');
        $this->number($form, 'bouncerMaxUsers', 'Konta bouncera', $v['bouncerMaxUsers'], 1, 10000, 'Maksymalna liczba kont bouncera.');
        $this->number($form, 'bouncerMaxNetworks', 'Sieci na konto', $v['bouncerMaxNetworks'], 1, 100, 'Maksymalna liczba upstreamów jednego konta.');
        $this->number($form, 'bouncerMaxClients', 'Klienci bouncera', $v['bouncerMaxClients'], 1, 100000, 'Globalny limit klientów downstream.');
        $this->number($form, 'bouncerMaxConnectionsPerIP', 'Połączenia bouncera na IP', $v['bouncerMaxConnectionsPerIP'], 1, 1000, 'Limit jednoczesnych połączeń z adresu.');
        $this->number($form, 'bouncerMaxAuthAttempts', 'Próby logowania bouncera', $v['bouncerMaxAuthAttempts'], 1, 1000, 'Limit w oknie uwierzytelniania.');
        $this->number($form, 'bouncerAuthWindowMs', 'Okno logowania bouncera (ms)', $v['bouncerAuthWindowMs'], 10000, 3600000, 'Domyślnie 300000 ms.');
        $this->number($form, 'bouncerBufferSize', 'Playback na połączenie', $v['bouncerBufferSize'], 0, 100000, 'Maksymalna liczba odtwarzanych wpisów.');
        $this->number($form, 'bouncerBufferLines', 'Bufor na sieć', $v['bouncerBufferLines'], 1, 500000, 'Maksymalna liczba zapisanych linii na sieć.');
        $form->addElement('select', 'tlsEnabled', [
            'label' => 'IRC TLS',
            'multiOptions' => ['true' => 'Włączony', 'false' => 'Wyłączony'],
            'value' => $v['tlsEnabled'],
            'description' => 'Przy braku certyfikatu pierwszy start generuje certyfikat self-signed.',
        ]);

        $this->section($form, 'operSection', 'Pierwszy operator IRC i usługi', 'Manager zapisze operatora z hasłem bcrypt, utworzy powiązane konto NickServ i skonfiguruje komplet usług sieciowych.');
        $this->text($form, 'operName', 'Nazwa operatora IRC', $v['operName'], 'Używana przez /OPER nazwa hasło oraz jako nazwa konta NickServ.', true);
        $form->addElement('password', 'operPassword', [
            'label' => 'Hasło operatora IRC', 'value' => '',
            'description' => Modules_KitsuneircManager_Config::hasSecret('operPassword')
                ? 'Zapisane i zaszyfrowane. Puste pole zachowa wartość.'
                : 'Wymagane przed pierwszym wdrożeniem; 12-72 bajty.',
        ]);
        $this->text($form, 'operHost', 'Maska hosta operatora', $v['operHost'], 'Domyślnie *@*; w produkcji warto ją zawęzić.', true);
        $this->text($form, 'operFlags', 'Flagi operatora', $v['operFlags'], 'Litery uprawnień bez separatorów.', true);
        foreach ([
            'nickservEnabled' => 'NickServ', 'chanservEnabled' => 'ChanServ',
            'memoservEnabled' => 'MemoServ', 'operservEnabled' => 'OperServ',
            'botservEnabled' => 'BotServ', 'hostservEnabled' => 'HostServ',
        ] as $name => $label) {
            $form->addElement('select', $name, [
                'label' => $label,
                'multiOptions' => ['true' => 'Włączony', 'false' => 'Wyłączony'],
                'value' => $v[$name],
            ]);
        }

        $this->section($form, 'securitySection', 'Bezpieczeństwo IRC', 'Bezpieczne wartości startowe można później dopracować w panelu administracyjnym.');
        foreach ([
            'requireSasl' => 'Wymagaj SASL', 'cloakEnabled' => 'Maskowanie hostów',
            'dnsblEnabled' => 'DNSBL', 'floodEnabled' => 'Ochrona flood',
            'throttleEnabled' => 'Ograniczanie nowych połączeń',
        ] as $name => $label) {
            $form->addElement('select', $name, [
                'label' => $label,
                'multiOptions' => ['true' => 'Włączone', 'false' => 'Wyłączone'],
                'value' => $v[$name],
            ]);
        }
        $this->text($form, 'cloakPrefix', 'Prefiks cloaka', $v['cloakPrefix'], 'Bezpieczna etykieta, np. kitsune.', true);
        $form->addElement('textarea', 'dnsblServers', [
            'label' => 'Serwery DNSBL', 'value' => $v['dnsblServers'], 'rows' => 3,
            'description' => 'Jedna prawidłowa domena DNSBL na wiersz.',
        ]);
        $this->number($form, 'floodMaxPerInterval', 'Linie w oknie flood', $v['floodMaxPerInterval'], 1, 100000, 'Limit poleceń klienta.');
        $this->number($form, 'floodIntervalMs', 'Okno flood (ms)', $v['floodIntervalMs'], 100, 86400000, 'Czas okna limitu.');
        $this->number($form, 'maxConnectionsPerIp', 'Klienci IRC na IP', $v['maxConnectionsPerIp'], 1, 100000, 'Limit równoczesny.');
        $this->number($form, 'throttleConnections', 'Nowe połączenia w okresie', $v['throttleConnections'], 1, 100000, 'Limit przyjęć z jednego IP.');
        $this->number($form, 'throttlePeriodMs', 'Okres throttle (ms)', $v['throttlePeriodMs'], 100, 86400000, 'Okno ograniczenia nowych połączeń.');

        $this->section($form, 'webSection', 'Panel i klient webowy', 'Plesk kończy publiczny TLS i przekazuje ruch do lokalnych portów kontenerów.');
        $form->addElement('select', 'proxyMode', [
            'label' => 'Reverse proxy',
            'multiOptions' => ['managed' => 'Zarządzany automatycznie przez rozszerzenie', 'manual' => 'Konfiguracja ręczna'],
            'value' => $v['proxyMode'],
        ]);
        $this->domainField($form, 'adminDomain', 'Domena panelu administracyjnego', $v['adminDomain'], $domains);
        $this->domainField($form, 'webDomain', 'Domena klienta webowego', $v['webDomain'], $domains);
        $this->number($form, 'adminPort', 'Lokalny port panelu', $v['adminPort'], 1024, 65535, 'Przypięty wyłącznie do 127.0.0.1.');
        $this->number($form, 'webPort', 'Lokalny port klienta', $v['webPort'], 1024, 65535, 'Przypięty wyłącznie do 127.0.0.1.');
        $this->number($form, 'webMaxConnections', 'Limit sesji webowych', $v['webMaxConnections'], 1, 10000, 'Maksymalna liczba równoległych mostów WebSocket–IRC.');
        $this->number($form, 'sessionTimeoutMs', 'Czas sesji panelu (ms)', $v['sessionTimeoutMs'], 60000, 2592000000, 'Domyślnie 86400000 ms, czyli 24 godziny.');
        $form->addElement('select', 'sqlConsoleEnabled', [
            'label' => 'Podgląd bazy i konsola SQL',
            'multiOptions' => ['true' => 'Włączone', 'false' => 'Wyłączone'],
            'value' => $v['sqlConsoleEnabled'],
            'description' => 'Zapewnia tabele, przegląd danych i zapytania tylko do odczytu dla administratora.',
        ]);
        $form->addElement('select', 'sqlWriteEnabled', [
            'label' => 'Modyfikacje SQL',
            'multiOptions' => ['false' => 'Wyłączone — zalecane', 'true' => 'Włączone'],
            'value' => $v['sqlWriteEnabled'],
            'description' => 'Pozwala wykonywać INSERT/UPDATE/DELETE/DDL oraz usuwać wiersze. Wymaga włączonej konsoli.',
        ]);
        $form->addElement('select', 'pluginEditorEnabled', [
            'label' => 'Edytor pluginów serwera',
            'multiOptions' => ['true' => 'Włączony', 'false' => 'Wyłączony'],
            'value' => $v['pluginEditorEnabled'],
            'description' => 'Pozwala administratorowi tworzyć, edytować, ładować i przeładowywać pluginy JavaScript.',
        ]);
        $this->text($form, 'adminUsername', 'Pierwszy administrator', $v['adminUsername'], 'Tworzony tylko wtedy, gdy baza nie ma jeszcze administratora.', true);
        $form->addElement('password', 'adminPassword', [
            'label' => 'Hasło administratora',
            'value' => '',
            'description' => Modules_KitsuneircManager_Config::hasSecret('adminPassword')
                ? 'Zaszyfrowane. Puste pole zachowa obecną wartość.'
                : 'Wymagane przed pierwszym wdrożeniem; 12-72 bajty.',
        ]);

        $this->section($form, 'gitSection', 'Dostęp do Git', 'Token i klucz prywatny są szyfrowane przez Pleska i istnieją jako pliki tylko podczas operacji.');
        $this->text($form, 'gitUsername', 'Użytkownik Git HTTPS', $v['gitUsername'], 'Dla GitHub zwykle x-access-token.');
        $form->addElement('password', 'gitToken', [
            'label' => 'Token / hasło Git',
            'value' => '',
            'description' => Modules_KitsuneircManager_Config::hasSecret('gitToken')
                ? 'Zaszyfrowany. Puste pole zachowa wartość.'
                : 'Opcjonalny dla publicznego repozytorium lub SSH.',
        ]);
        $form->addElement('textarea', 'gitSshPrivateKey', [
            'label' => 'Prywatny klucz SSH',
            'value' => '',
            'rows' => 6,
            'description' => Modules_KitsuneircManager_Config::hasSecret('gitSshPrivateKey')
                ? 'Zaszyfrowany. Puste pole zachowa wartość.'
                : 'Opcjonalny read-only deploy key bez hasła.',
        ]);
        $form->addElement('textarea', 'gitSshKnownHosts', [
            'label' => 'SSH known_hosts',
            'value' => $v['gitSshKnownHosts'],
            'rows' => 4,
            'description' => 'Wymagane dla SSH. Wklej przypięty klucz hosta; weryfikacja nigdy nie jest wyłączana.',
        ]);
        $form->addElement('select', 'loggingLevel', [
            'label' => 'Poziom logowania serwera',
            'multiOptions' => ['error' => 'error', 'warn' => 'warn', 'info' => 'info', 'debug' => 'debug'],
            'value' => $v['loggingLevel'],
            'description' => 'Na produkcji zalecane jest info; debug służy do diagnostyki.',
        ]);
        $form->addElement('select', 'afterSave', [
            'label' => 'Po zapisaniu',
            'multiOptions' => [
                'save' => 'Tylko zapisz konfigurację',
                'first-deploy' => 'Pobierz kod i wykonaj pełne pierwsze wdrożenie',
            ],
            'value' => 'save',
            'description' => 'Pełne wdrożenie skonfiguruje serwer, operatora IRC, administratora WWW, oba moduły i reverse proxy.',
        ]);
        $form->addElement('submit', 'saveAction', ['label' => 'Zapisz konfigurację', 'value' => 'save']);
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function operationForm()
    {
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kitsuneirc-operation-form');
        $form->addElement('hidden', 'formType', ['value' => 'operation']);
        $form->addElement('select', 'operation', [
            'label' => 'Operacja',
            'multiOptions' => [
                'check' => 'Sprawdź repozytorium i wersje',
                'sync' => 'Pobierz kod (fast-forward)',
                'deploy' => 'Wdróż z lokalnej kopii',
                'sync-deploy' => 'Pobierz i wdróż',
            ],
            'description' => 'Sprawdzenie i pobranie nie restartują kontenerów.',
        ]);
        $form->addElement('checkbox', 'moduleServer', [
            'label' => 'Serwer IRC + usługi + panel admina',
            'value' => '1',
        ]);
        $form->addElement('checkbox', 'moduleWeb', [
            'label' => 'Klient webowy + most WebSocket',
            'value' => '1',
        ]);
        $form->addElement('submit', 'operationAction', ['label' => 'Uruchom operację', 'value' => 'run']);
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function maintenanceForm()
    {
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kitsuneirc-maintenance-form');
        $form->addElement('hidden', 'formType', ['value' => 'maintenance']);
        $form->addElement('select', 'maintenanceOperation', [
            'label' => 'Operacja danych',
            'multiOptions' => ['backup' => 'Utwórz backup', 'restore' => 'Przywróć backup'],
        ]);
        $this->text($form, 'backupName', 'Nazwa backupu', '', 'Opcjonalna dla backupu; dla restore wybierz nazwę z listy.');
        $this->text($form, 'confirmation', 'Potwierdzenie restore', '', 'Wpisz RESTORE:nazwa-backupu.');
        $form->addElement('submit', 'maintenanceAction', ['label' => 'Wykonaj', 'value' => 'run']);
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function saveConfig(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) {
            $this->_status->addMessage('error', $this->validationSummary($form));
            return false;
        }
        $values = $form->getValues();
        $pathFields = ['repositoryPath', 'dataPath', 'backupPath'];
        foreach ($pathFields as $field) {
            if (!preg_match('#^/(?:home|opt|srv|var/lib|var/backups)(?:/[A-Za-z0-9._-]+)+$#', (string) $values[$field])) {
                return $this->fieldError($form, $field, 'Dozwolona jest bezwzględna ścieżka pod /home, /opt, /srv, /var/lib lub /var/backups.');
            }
        }
        $repo = rtrim((string) $values['repositoryPath'], '/');
        $data = rtrim((string) $values['dataPath'], '/');
        $backup = rtrim((string) $values['backupPath'], '/');
        if ($this->pathsOverlap($repo, $data)) {
            return $this->fieldError($form, 'dataPath', 'Dane muszą znajdować się poza katalogiem repozytorium.');
        }
        if ($this->pathsOverlap($repo, $backup) || $this->pathsOverlap($data, $backup)) {
            return $this->fieldError($form, 'backupPath', 'Backupy muszą znajdować się poza repozytorium i katalogiem danych.');
        }
        if (strlen((string) $values['repositoryUrl']) > 2000 || preg_match('/[\r\n\0]/', (string) $values['repositoryUrl']) ||
            !preg_match('#^(?:https://|ssh://|git@)#', (string) $values['repositoryUrl'])) {
            return $this->fieldError($form, 'repositoryUrl', 'Użyj adresu HTTPS albo SSH.');
        }
        if (!preg_match('/^(?![-.])(?!.*\.\.)(?!.*@\{)[A-Za-z0-9._\/-]+$/', (string) $values['repositoryBranch'])) {
            return $this->fieldError($form, 'repositoryBranch', 'Nieprawidłowa nazwa gałęzi.');
        }
        if (!$this->validHostname((string) $values['serverName'])) {
            return $this->fieldError($form, 'serverName', 'Podaj prawidłową nazwę hosta IRC.');
        }
        if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/', (string) $values['networkName'])) {
            return $this->fieldError($form, 'networkName', 'Nazwa sieci musi być tokenem 1-64 znaków bez spacji.');
        }
        if (trim((string) $values['serverDescription']) === '' || strlen((string) $values['serverDescription']) > 200 || preg_match('/[\x00-\x1f\x7f]/', (string) $values['serverDescription'])) {
            return $this->fieldError($form, 'serverDescription', 'Opis musi mieć 1-200 znaków bez znaków sterujących.');
        }
        if (!filter_var((string) $values['serverAdminEmail'], FILTER_VALIDATE_EMAIL)) {
            return $this->fieldError($form, 'serverAdminEmail', 'Podaj prawidłowy adres e-mail administratora sieci.');
        }
        $motdLines = preg_split('/\r?\n/', (string) $values['motd']);
        if (count($motdLines) > 100 || array_filter($motdLines, function ($line) { return strlen($line) > 510 || preg_match('/[\r\n\0]/', $line); })) {
            return $this->fieldError($form, 'motd', 'MOTD może mieć maksymalnie 100 linii po 510 bajtów.');
        }
        if (!preg_match('/^\+?[iowxrsDGBRTWZSHIpq]{0,32}$/', (string) $values['defaultModes'])) {
            return $this->fieldError($form, 'defaultModes', 'Domyślne tryby użytkownika zawierają niedozwolone flagi.');
        }
        if (!preg_match('/^[A-Za-z0-9._-]{3,64}$/', (string) $values['operName'])) {
            return $this->fieldError($form, 'operName', 'Nazwa operatora musi mieć 3-64 dozwolone znaki.');
        }
        if ($values['nickservEnabled'] === 'true' && !preg_match('/^[A-Za-z_`\[\]\\^{}|][A-Za-z0-9_`\[\]\\^{}|\-]{2,29}$/', (string) $values['operName'])) {
            return $this->fieldError($form, 'operName', 'Przy włączonym NickServ nazwa operatora musi być prawidłowym nickiem IRC (3-30 znaków).');
        }
        if (strlen((string) $values['operHost']) < 1 || strlen((string) $values['operHost']) > 255 || preg_match('/[\r\n\0]/', (string) $values['operHost'])) {
            return $this->fieldError($form, 'operHost', 'Maska operatora jest nieprawidłowa.');
        }
        if (!preg_match('/^[A-Za-z]{1,128}$/', (string) $values['operFlags'])) {
            return $this->fieldError($form, 'operFlags', 'Flagi operatora mogą zawierać wyłącznie litery.');
        }
        $operPassword = (string) ($values['operPassword'] ?? '');
        if ($operPassword !== '' && (strlen($operPassword) < 12 || strlen($operPassword) > 72)) {
            return $this->fieldError($form, 'operPassword', 'Hasło operatora musi mieć 12-72 bajty.');
        }
        if ($operPassword === '' && !Modules_KitsuneircManager_Config::hasSecret('operPassword')) {
            return $this->fieldError($form, 'operPassword', 'Hasło operatora jest wymagane przed pierwszym wdrożeniem.');
        }
        $serverPassword = (string) ($values['serverPassword'] ?? '');
        if ($values['serverPasswordEnabled'] === 'true' && $serverPassword === '' && !Modules_KitsuneircManager_Config::hasSecret('serverPassword')) {
            return $this->fieldError($form, 'serverPassword', 'Włączone hasło serwera wymaga podania wartości.');
        }
        if ($serverPassword !== '' && (strlen($serverPassword) < 12 || strlen($serverPassword) > 200)) {
            return $this->fieldError($form, 'serverPassword', 'Hasło serwera musi mieć 12-200 bajtów.');
        }
        foreach (preg_split('/\r?\n/', trim((string) $values['dnsblServers'])) as $dnsbl) {
            if ($dnsbl !== '' && !$this->validHostname($dnsbl)) return $this->fieldError($form, 'dnsblServers', 'Każdy wpis DNSBL musi być prawidłową domeną.');
        }
        if (!preg_match('/^[A-Za-z0-9._-]{3,64}$/', (string) $values['adminUsername'])) {
            return $this->fieldError($form, 'adminUsername', 'Nazwa musi mieć 3-64 dozwolone znaki.');
        }
        foreach (['sqlConsoleEnabled', 'sqlWriteEnabled', 'pluginEditorEnabled'] as $field) {
            if (!in_array((string) $values[$field], ['true', 'false'], true)) {
                return $this->fieldError($form, $field, 'Wybierz prawidłową wartość.');
            }
        }
        if ($values['sqlWriteEnabled'] === 'true' && $values['sqlConsoleEnabled'] !== 'true') {
            return $this->fieldError($form, 'sqlWriteEnabled', 'Modyfikacje SQL wymagają włączonej konsoli SQL.');
        }
        if (!$this->validHostname((string) $values['adminDomain']) || !$this->validHostname((string) $values['webDomain'])) {
            return $this->fieldError($form, 'adminDomain', 'Wybierz prawidłowe domeny Pleska.');
        }
        if (strcasecmp((string) $values['adminDomain'], (string) $values['webDomain']) === 0) {
            return $this->fieldError($form, 'webDomain', 'Panel admina i klient webowy wymagają różnych domen.');
        }
        if (!preg_match('/^[A-Za-z0-9._@+-]{1,128}$/', (string) $values['gitUsername'])) {
            return $this->fieldError($form, 'gitUsername', 'Nieprawidłowa nazwa użytkownika Git.');
        }
        $ports = [
            (string) $values['ircPort'], (string) $values['ircTlsPort'],
            (string) $values['bouncerPort'], (string) $values['bouncerTlsPort'],
            (string) $values['adminPort'], (string) $values['webPort'],
        ];
        if (count(array_unique($ports)) !== count($ports)) {
            return $this->fieldError($form, 'webPort', 'Każda usługa musi używać innego portu hosta.');
        }
        $password = (string) ($values['adminPassword'] ?? '');
        if ($password !== '' && (strlen($password) < 12 || strlen($password) > 72)) {
            return $this->fieldError($form, 'adminPassword', 'Hasło musi mieć 12-72 bajty.');
        }
        if ($password === '' && !Modules_KitsuneircManager_Config::hasSecret('adminPassword')) {
            return $this->fieldError($form, 'adminPassword', 'Hasło jest wymagane przed pierwszym wdrożeniem.');
        }
        if (strpos((string) $values['repositoryUrl'], 'git@') === 0 && trim((string) $values['gitSshKnownHosts']) === '') {
            return $this->fieldError($form, 'gitSshKnownHosts', 'Dla SSH wklej zweryfikowany wpis known_hosts.');
        }
        Modules_KitsuneircManager_Config::save($values);
        $this->_status->addMessage('info', 'Konfiguracja została zapisana.');
        if (($values['afterSave'] ?? 'save') === 'first-deploy') {
            return $this->enqueue('sync-deploy', ['modules' => ['server', 'web-client']]);
        }
        return true;
    }

    private function startOperation(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) {
            $this->_status->addMessage('error', $this->validationSummary($form));
            return false;
        }
        $operation = (string) ($post['operation'] ?? '');
        if (!in_array($operation, ['check', 'sync', 'deploy', 'sync-deploy'], true)) {
            $this->_status->addMessage('error', 'Nieprawidłowa operacja.');
            return false;
        }
        $modules = [];
        if (!empty($post['moduleServer'])) $modules[] = 'server';
        if (!empty($post['moduleWeb'])) $modules[] = 'web-client';
        if (in_array($operation, ['deploy', 'sync-deploy'], true) && !$modules) {
            $this->_status->addMessage('error', 'Wybierz co najmniej jeden moduł do wdrożenia.');
            return false;
        }
        return $this->enqueue($operation, ['modules' => $modules]);
    }

    private function startMaintenance(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) {
            $this->_status->addMessage('error', $this->validationSummary($form));
            return false;
        }
        $operation = (string) ($post['maintenanceOperation'] ?? '');
        $backupName = trim((string) ($post['backupName'] ?? ''));
        $confirmation = trim((string) ($post['confirmation'] ?? ''));
        if (!in_array($operation, ['backup', 'restore'], true)) {
            $this->_status->addMessage('error', 'Nieprawidłowa operacja danych.');
            return false;
        }
        if ($backupName !== '' && !preg_match('/^[A-Za-z0-9._-]{1,100}$/', $backupName)) {
            return $this->fieldError($form, 'backupName', 'Nazwa może zawierać tylko litery, cyfry, kropki, myślniki i podkreślenia.');
        }
        if ($operation === 'restore' && ($backupName === '' || $confirmation !== 'RESTORE:' . $backupName)) {
            return $this->fieldError($form, 'confirmation', 'Wpisz dokładnie RESTORE:' . $backupName);
        }
        return $this->enqueue($operation, ['backupName' => $backupName, 'confirmation' => $confirmation]);
    }

    private function serviceForm($module)
    {
        $labels = ['server' => 'serwerem IRC', 'web-client' => 'klientem WWW'];
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kitsuneirc-service-form-' . str_replace('-', '_', $module));
        $form->addElement('hidden', 'formType', ['value' => 'service']);
        $form->addElement('hidden', 'module', ['value' => $module]);
        $form->addElement('simpleText', 'serviceControls', [
            'label' => '', 'escape' => false,
            'value' => '<div class="kitsuneirc-service-actions" role="group" aria-label="Sterowanie ' . htmlspecialchars($labels[$module] ?? $module, ENT_QUOTES, 'UTF-8') . '">'
                . '<button type="submit" name="serviceAction" value="start" class="kitsuneirc-service-button is-start">Uruchom</button>'
                . '<button type="submit" name="serviceAction" value="restart" class="kitsuneirc-service-button is-restart">Restart</button>'
                . '<button type="submit" name="serviceAction" value="stop" class="kitsuneirc-service-button is-stop">Zatrzymaj</button>'
                . '</div>',
        ]);
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function startServiceOperation(array $forms, array $post)
    {
        $module = (string) ($post['module'] ?? '');
        if (!isset($forms[$module]) || !$forms[$module]->isValid($post)) {
            $this->_status->addMessage('error', 'Nieprawidłowy moduł usługi.');
            return false;
        }
        $action = (string) ($post['serviceAction'] ?? '');
        if (!in_array($action, ['start', 'restart', 'stop'], true)) {
            $this->_status->addMessage('error', 'Nieprawidłowa akcja usługi.');
            return false;
        }
        return $this->enqueue($action, ['modules' => [$module]]);
    }

    private function enqueue($operation, array $parameters)
    {
        try {
            $runtime = Modules_KitsuneircManager_Config::createRuntimeConfig($operation, $parameters);
            $task = new Modules_KitsuneircManager_Task_Operate();
            $task->setParam('runtimeConfig', $runtime);
            (new pm_LongTask_Manager())->start($task);
            $this->_status->addMessage('info', 'Operacja została dodana do kolejki: ' . $operation . '.');
            return true;
        } catch (Throwable $exception) {
            $this->_status->addMessage('error', $exception->getMessage());
            return false;
        }
    }

    private function refreshStatus($refreshRemote = false)
    {
        $runtime = null;
        try {
            $runtime = Modules_KitsuneircManager_Config::createRuntimeConfig('status', [
                'refreshRemote' => (bool) $refreshRemote,
            ]);
            $result = pm_ApiCli::callSbin('kitsuneirc-manager', ['--config', $runtime], pm_ApiCli::RESULT_FULL);
            $stdout = (string) ($result['stdout'] ?? '');
            $stateImported = Modules_KitsuneircManager_Config::importStateFromOutput($stdout);
            $cleanStdout = Modules_KitsuneircManager_Config::stripStateFromOutput($stdout);
            if ((int) ($result['code'] ?? 1) !== 0) {
                $errorOutput = trim((string) ($result['stderr'] ?? ''));
                if ($errorOutput === '') $errorOutput = $cleanStdout !== '' ? $cleanStdout : 'Nie udało się odświeżyć stanu.';
                return [
                    'error' => $errorOutput,
                    'notice' => null,
                ];
            }
            if (preg_match('/^BUSY\r?$/m', $cleanStdout)) {
                return [
                    'error' => null,
                    'notice' => 'Trwa inna operacja. Pokazano ostatni zapisany stan; odśwież ponownie po jej zakończeniu.',
                ];
            }
            if (!$stateImported) {
                $keys = is_array($result) ? implode(', ', array_keys($result)) : gettype($result);
                $diagnostic = $cleanStdout !== '' ? substr($cleanStdout, 0, 2000) : '(pusty stdout)';
                return [
                    'error' => 'Backend nie przekazał ramki stanu. Klucze wyniku: ' . $keys . '. stdout: ' . $diagnostic,
                    'notice' => null,
                ];
            }
            $state = Modules_KitsuneircManager_Config::readState();
            if (empty($state['updatedAt'])) {
                return [
                    'error' => 'Backend zakończył odczyt bez zapisania state.json. Sprawdzony katalog: ' . pm_Context::getVarDir(),
                    'notice' => null,
                ];
            }
            return ['error' => null, 'notice' => null];
        } catch (Throwable $exception) {
            return ['error' => $exception->getMessage(), 'notice' => null];
        } finally {
            if ($runtime && is_file($runtime)) @unlink($runtime);
        }
    }

    private function section(pm_Form_Simple $form, $name, $title, $description)
    {
        $form->addElement('simpleText', $name, [
            'value' => '<div class="kitsuneirc-form-section"><h3>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</h3><p>' . htmlspecialchars($description, ENT_QUOTES, 'UTF-8') . '</p></div>',
            'escape' => false,
        ]);
    }

    private function text(pm_Form_Simple $form, $name, $label, $value, $description, $required = false)
    {
        $form->addElement('text', $name, [
            'label' => $label,
            'value' => $value,
            'description' => $description,
            'required' => $required,
            'validators' => [['StringLength', true, ['min' => $required ? 1 : 0, 'max' => 2000]]],
        ]);
    }

    private function path(pm_Form_Simple $form, $name, $label, $value, $description)
    {
        $this->text($form, $name, $label, $value, $description, true);
    }

    private function number(pm_Form_Simple $form, $name, $label, $value, $min, $max, $description)
    {
        $form->addElement('text', $name, [
            'label' => $label,
            'value' => $value,
            'description' => $description,
            'required' => true,
            'validators' => [['Digits', true], ['Between', true, ['min' => $min, 'max' => $max]]],
        ]);
    }

    private function domainField(pm_Form_Simple $form, $name, $label, $value, array $domains)
    {
        if ($domains) {
            $options = ['' => '— wybierz aktywną domenę Pleska —'] + $domains;
            $form->addElement('select', $name, [
                'label' => $label,
                'multiOptions' => $options,
                'value' => isset($domains[$value]) ? $value : '',
                'required' => true,
            ]);
            $form->getElement($name)->setAttrib('required', 'required');
        } else {
            $this->text($form, $name, $label, $value, 'Aktywna domena lub subdomena z hostingiem WWW.', true);
        }
    }

    private function domainOptions()
    {
        $result = [];
        try {
            foreach (pm_Domain::getAllDomains() as $domain) {
                if ($domain->hasHosting() && $domain->isActive() && !$domain->isSuspended() && !$domain->isDisabled()) {
                    $name = strtolower((string) $domain->getName());
                    $result[$name] = $name;
                }
            }
        } catch (Throwable $exception) {}
        ksort($result);
        return $result;
    }

    private function validationSummary(pm_Form_Simple $form)
    {
        $labels = [];
        foreach ($form->getMessages() as $name => $messages) {
            $element = $form->getElement($name);
            $labels[] = $element ? (string) $element->getLabel() : (string) $name;
        }
        return $labels ? 'Sprawdź pola: ' . implode(', ', array_unique($labels)) . '.' : 'Sprawdź formularz.';
    }

    private function fieldError(pm_Form_Simple $form, $name, $message)
    {
        $element = $form->getElement($name);
        if ($element) $element->addError($message);
        $this->_status->addMessage('error', $message);
        return false;
    }

    private function pathsOverlap($left, $right)
    {
        $left = rtrim((string) $left, '/');
        $right = rtrim((string) $right, '/');
        return $left === $right || strpos($left . '/', $right . '/') === 0 || strpos($right . '/', $left . '/') === 0;
    }

    private function validHostname($value)
    {
        $value = (string) $value;
        if ($value === '' || strlen($value) > 253) return false;
        foreach (explode('.', $value) as $label) {
            if (!preg_match('/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?$/', $label)) return false;
        }
        return true;
    }

    private function respondWithRedirect($tab)
    {
        $allowed = ['status', 'deploy', 'config', 'data', 'log'];
        if (!in_array((string) $tab, $allowed, true)) $tab = 'status';
        $url = pm_Context::getActionUrl('index', 'index');
        $url .= (strpos($url, '?') === false ? '?' : '&') . 'tab=' . rawurlencode((string) $tab);
        $this->_helper->json(['redirect' => $url]);
    }
}
