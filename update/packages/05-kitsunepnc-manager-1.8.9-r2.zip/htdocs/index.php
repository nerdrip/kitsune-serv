<?php

pm_Context::init('kitsunepnc-manager');

$application = new pm_Application();
$application->run();
