<?php

class IndexController extends pm_Controller_Action
{
    protected $_accessLevel = 'admin';

    public function init()
    {
        parent::init();
        $this->view->pageTitle = 'KitsunePNC Deployment Manager';
        $this->view->headLink()->appendStylesheet(
            pm_Context::getBaseUrl() . 'css/kitsunepnc.css?v=' . Modules_KitsunepncManager_Config::EXTENSION_VERSION
        );
        $this->view->headLink()->appendStylesheet(pm_Context::getBaseUrl() . 'css/kitsune-platform.css?v=1');
        $this->view->headScript()->appendFile(pm_Context::getBaseUrl() . 'js/kitsune-platform.js?v=1');
        $this->view->suiteProduct = 'KitsunePNC Manager';
        $this->view->suiteVersion = Modules_KitsunepncManager_Config::EXTENSION_VERSION;
        try { $this->view->suiteHubActive = pm_Extension::getById('kitsuneserv-bridge')->isActive(); }
        catch (Throwable $exception) { $this->view->suiteHubActive = false; }
    }

    public function indexAction()
    {
        $configForm = $this->configForm();
        $operationForm = $this->operationForm();
        $suiteForm = $this->suiteForm();
        $suiteBootstrapForms = [
            'colab' => $this->suiteBootstrapForm('colab'),
            'test' => $this->suiteBootstrapForm('test'),
        ];
        $maintenanceForm = $this->maintenanceForm();
        if ($this->getRequest()->isPost()) {
            $post = $this->getRequest()->getPost();
            if (($post['formType'] ?? '') === 'config') {
                $this->view->activeTab = 'config';
                if ($this->saveConfig($configForm, $post)) return;
            }
            if (($post['formType'] ?? '') === 'operation') {
                $this->view->activeTab = 'deploy';
                if ($this->startOperation($operationForm, $post)) return;
            }
            if (($post['formType'] ?? '') === 'maintenance') {
                $this->view->activeTab = 'data';
                if ($this->startMaintenance($maintenanceForm, $post)) return;
            }
            if (($post['formType'] ?? '') === 'suite') {
                $this->view->activeTab = 'suite';
                if ($this->startSuiteOperation($suiteForm, $post)) return;
            }
            if (($post['formType'] ?? '') === 'suite-bootstrap') {
                $this->view->activeTab = 'suite';
                $product = (string) ($post['suiteProduct'] ?? '');
                if (isset($suiteBootstrapForms[$product]) && $this->startSuiteBootstrap($suiteBootstrapForms[$product], $post, $product)) return;
            }
        }

        $this->view->statusRefreshError = $this->refreshStatus();
        $this->view->configForm = $configForm;
        $this->view->operationForm = $operationForm;
        $this->view->suiteForm = $suiteForm;
        $this->view->suiteBootstrapForms = $suiteBootstrapForms;
        $this->view->maintenanceForm = $maintenanceForm;
        $this->view->state = Modules_KitsunepncManager_Config::readState();
        $this->view->config = Modules_KitsunepncManager_Config::values();
        $this->view->hasGitToken = Modules_KitsunepncManager_Config::hasSecret('gitToken');
        $this->view->hasSshKey = Modules_KitsunepncManager_Config::hasSecret('gitSshPrivateKey');
        $this->view->hasJwt = Modules_KitsunepncManager_Config::hasSecret('jwtSecret')
            && Modules_KitsunepncManager_Config::hasSecret('jwtRefreshSecret');
        $this->view->hasSuiteSecret = Modules_KitsunepncManager_Config::hasSecret('suiteSharedSecret');
        $this->view->suiteManagerUrls = $this->suiteManagerUrls();
        $this->view->extensionVersion = Modules_KitsunepncManager_Config::EXTENSION_VERSION;
    }

    private function suiteManagerUrls()
    {
        $targets = [
            'colab' => 'kitsune-manager',
            'test' => 'kitsunetest-manager',
        ];
        $urls = [];
        foreach ($targets as $product => $extensionId) {
            // An absolute route is deliberately independent from the Hub's
            // current MVC context. Context switching here made Plesk append a
            // second `/modules/.../index.php` segment on some Obsidian builds.
            $urls[$product] = '/modules/' . rawurlencode($extensionId) . '/index.php/index/index';
        }
        return $urls;
    }

    private function configForm()
    {
        $v = Modules_KitsunepncManager_Config::values();
        $domains = $this->domainOptions($v['domain']);
        $selectedDomain = $v['domain'];
        if ($domains && !isset($domains[$selectedDomain])) $selectedDomain = (string) array_key_first($domains);
        $savedPublicHost = strtolower((string) (parse_url((string) $v['publicUrl'], PHP_URL_HOST) ?: ''));
        $publicUrl = $savedPublicHost === strtolower($selectedDomain)
            ? $v['publicUrl']
            : 'https://' . $selectedDomain;
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kpc-config-form');
        $form->addElement('hidden', 'formType', ['value' => 'config']);

        $form->addElement('simpleText', 'quickStart', [
            'label' => '', 'escape' => false,
            'value' => '<div class="kpc-quick-start"><strong>Najkrótsza droga</strong><span>Wybierz domenę, wklej adres repozytorium i kliknij „Zapisz konfigurację”. Katalogi, adres publiczny i cztery sekrety aplikacji mogą zostać uzupełnione automatycznie.</span><button type="button" class="kpc-secondary-action" data-kpc-fill-defaults>Uzupełnij bezpieczne domyślne wartości</button></div>',
        ]);
        $this->section($form, 'repositorySection', 'Repozytorium i trwałe dane', 'Najprościej użyć jednego katalogu bazowego, np. /home/pnc. Kod trafia do source, a dane i backupy są obok niego, dzięki czemu aktualizacja ich nie nadpisze.');
        $this->text($form, 'repositoryUrl', 'Repozytorium Git', $v['repositoryUrl'], 0, 1000, '#^$|^(https://|ssh://|git@)#', 'Adres HTTPS albo SSH repozytorium zawierającego KitsunePNC, np. https://github.com/firma/KitsunePNC.git. Możesz zapisać resztę ustawień bez repozytorium; będzie wymagane dopiero przy sprawdzaniu lub wdrożeniu.');
        $this->text($form, 'repositoryBranch', 'Gałąź wdrożeniowa', $v['repositoryBranch'], 1, 200, '/^(?![-.])(?!.*\.\.)(?!.*@\{)[A-Za-z0-9._\/-]+$/', 'Zwykle main. Synchronizacja dopuszcza wyłącznie bezpieczny fast-forward.', true);
        $this->path($form, 'repositoryPath', 'Katalog kodu (Git)', $v['repositoryPath'], 'Tutaj zostanie sklonowane repozytorium. Przykład: /home/pnc/source.');
        $this->path($form, 'deployPath', 'Katalog Docker Compose', $v['deployPath'], 'Zawsze katalog kodu z dopiskiem /deploy, np. /home/pnc/source/deploy. Pole uzupełnia się automatycznie po zmianie katalogu kodu.');
        $this->path($form, 'dataPath', 'Katalog danych trwałych', $v['dataPath'], 'Baza SQLite i pliki użytkowników. Przykład: /home/pnc/data/kitsunepnc. Nie może znajdować się wewnątrz katalogu kodu.');
        $this->path($form, 'backupPath', 'Katalog backupów', $v['backupPath'], 'Pełne kopie danych. Przykład: /home/pnc/backups/kitsunepnc. Nie może znajdować się wewnątrz katalogu kodu.');
        $form->addElement('text', 'backupKeep', [
            'label' => 'Liczba zachowywanych backupów',
            'value' => $v['backupKeep'],
            'description' => 'Od 1 do 365 ostatnich pełnych kopii. Starsze kopie są usuwane rotacyjnie.',
            'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 365]]],
        ]);

        $this->section($form, 'domainSection', 'Publikacja i reverse proxy', 'Kontener web/Caddy nasłuchuje wyłącznie na 127.0.0.1. Publiczny ruch HTTPS kończy się w Plesku i jest przekazywany do stałego portu HTTP kontenera.');
        $form->addElement('select', 'proxyMode', [
            'label' => 'Konfiguracja vhosta / reverse proxy',
            'multiOptions' => [
                'managed' => 'Automatycznie przez plugin — ustaw bezpieczny vhost nginx',
                'docker' => 'Ręcznie w panelu Pleska — pokaż kod vhosta',
            ],
                'value' => $v['proxyMode'],
            'description' => 'Automatycznie: plugin zapisuje wyłącznie własny, oznaczony blok nginx. Ręcznie: nic nie zmienia na serwerze, tylko pokazuje kod do „Dodatkowe dyrektywy nginx”. W obu trybach nie powstaje konfliktowy blok location /.',
        ]);
        if ($domains) {
            $form->addElement('select', 'domain', [
                'label' => 'Domena dla KitsuneHub',
                'multiOptions' => $domains,
                'value' => $selectedDomain,
                'description' => 'Lista aktywnych domen i subdomen z hostingiem w tym Plesku. Po wyborze adres publiczny uzupełni się automatycznie.',
                'required' => true,
            ]);
        } else {
            $this->text($form, 'domain', 'Domena dla KitsuneHub', $v['domain'], 3, 253, '/^(?=.{1,253}$)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}$/', 'Domena musi istnieć w Plesku, mieć aktywny hosting i certyfikat TLS.', true);
        }
        $this->text($form, 'publicUrl', 'Publiczny adres aplikacji', $publicUrl, 8, 1000, null, 'Uzupełniany z wybranej domeny. Dokładnie https://wybrana-domena, bez końcowego ukośnika ani dodatkowej ścieżki.', true);
        $form->addElement('simpleText', 'suiteDomainPlan', [
            'label' => 'Adresy Kitsune Suite', 'escape' => false,
            'value' => '<div class="kpc-domain-plan" data-kpc-suite-domain-plan></div>',
        ]);
        $form->addElement('simpleText', 'manualVhost', [
            'label' => 'Kod ręcznej konfiguracji vhosta', 'escape' => false,
            'value' => '<div class="kpc-vhost-snippet" data-kpc-manual-vhost hidden><strong>Ręczna konfiguracja: wklej kod do „Dodatkowe dyrektywy nginx” wybranej domeny — bez bloku <code>server {}</code>.</strong><pre><code data-kpc-vhost-code></code></pre><span>Nie używaj Docker Proxy Rules równocześnie z tym kodem. Fragment świadomie nie używa <code>location /</code>.</span></div>',
        ]);
        $form->addElement('text', 'httpPort', [
            'label' => 'Stały port hosta dla Docker Proxy Rules',
            'value' => $v['httpPort'],
            'description' => 'Domyślnie 18080. W regule Docker wybierz mapowanie kontenera web: 80 → ten port. Port jest dostępny tylko na 127.0.0.1.',
            'validators' => [['Digits', true], ['Between', true, ['min' => 1024, 'max' => 65535]]],
        ]);
        $form->addElement('text', 'httpsPort', [
            'label' => 'Rezerwowy port kontenera HTTPS',
            'value' => $v['httpsPort'],
            'description' => 'Techniczne mapowanie zapasowe. Docker Proxy Rules powinny używać portu HTTP powyżej, ponieważ TLS obsługuje Plesk.',
            'validators' => [['Digits', true], ['Between', true, ['min' => 1024, 'max' => 65535]]],
        ]);
        $this->text($form, 'adminEmails', 'Administratorzy KitsuneHub', $v['adminEmails'], 0, 2000, null, 'Adresy e-mail rozdzielone przecinkami. Konta o tych adresach otrzymują uprawnienia administratora aplikacji.');

        $this->section($form, 'suiteConfigSection', 'Kitsune Suite — Colab i Test', 'Połączenie jest opcjonalne. Puste adresy pozostawiają każdy produkt w pełni samodzielny; po ustawieniu Hub automatycznie synchronizuje projekty i odbiera issue oraz wyniki testów.');
        $this->text($form, 'colabApiUrl', 'URL API KitsuneColab', $v['colabApiUrl'], 0, 1000, '#^$|^https://[^\s/]+(?::\d+)?/?$#i', 'Bazowy adres HTTPS API bez ścieżki, np. https://api.colab.example.com.');
        $this->text($form, 'testApiUrl', 'URL API KitsuneTest', $v['testApiUrl'], 0, 1000, '#^$|^https://[^\s/]+(?::\d+)?/?$#i', 'Bazowy adres HTTPS API bez ścieżki, np. https://api.tests.example.com.');
        $this->text($form, 'suiteOrganizationName', 'Nazwa nadrzędnej organizacji Suite', $v['suiteOrganizationName'], 1, 120, null, 'Nazwa wspólnej ekipy widocznej nad organizacjami tworzonymi z workspace’ów, np. Chaos Group Games. Zmiana trafi do Colaba i Testa przy następnym SSO lub synchronizacji.');
        $this->text($form, 'suiteWorkspaceId', 'Workspace dla importów z Suite', $v['suiteWorkspaceId'], 0, 200, '/^[A-Za-z0-9_-]*$/', 'Opcjonalne ID workspace Huba dla projektów tworzonych z Colaba/Test.');
        $this->text($form, 'suiteActorId', 'Użytkownik techniczny Suite', $v['suiteActorId'], 0, 200, '/^[A-Za-z0-9_-]*$/', 'Opcjonalne ID użytkownika Huba przypisywanego importowanym projektom.');
        $form->addElement('password', 'suiteSharedSecret', [
            'label' => 'Wspólny sekret Suite (min. 32)',
            'value' => '',
            'description' => Modules_KitsunepncManager_Config::hasSecret('suiteSharedSecret') ? 'Zaszyfrowany. Puste pole zachowa wartość.' : 'Ustaw identyczną losową wartość w Hubie, Colabie i Teście.',
            'validators' => [['Regex', true, ['pattern' => '/^$|^.{32,512}$/s']]],
        ]);

        $this->section($form, 'mailSection', 'Konta i poczta', 'Bez weryfikacji konto działa od razu. Po jej włączeniu skonfiguruj SMTP, aby wysyłać linki aktywacyjne i reset hasła.');
        $form->addElement('select', 'requireEmailVerification', [
            'label' => 'Wymagaj weryfikacji e-mail',
            'multiOptions' => ['false' => 'Nie', 'true' => 'Tak'],
            'value' => $v['requireEmailVerification'],
        ]);
        $this->text($form, 'smtpHost', 'Serwer SMTP', $v['smtpHost'], 0, 255, null, 'Nazwa hosta serwera wysyłającego wiadomości, np. smtp.example.com.');
        $form->addElement('text', 'smtpPort', [
            'label' => 'SMTP port',
            'value' => $v['smtpPort'],
            'description' => 'Najczęściej 587 dla STARTTLS albo 465 dla SMTPS.',
            'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 65535]]],
        ]);
        $this->text($form, 'smtpUser', 'Użytkownik SMTP', $v['smtpUser'], 0, 255, null, 'Login skrzynki lub konta technicznego używanego do wysyłki.');
        $this->text($form, 'smtpFrom', 'Nadawca wiadomości', $v['smtpFrom'], 0, 500, null, 'Nazwa i adres widoczne dla odbiorcy, np. KitsuneHub <noreply@example.com>.');
        $form->addElement('select', 'smtpSecure', [
            'label' => 'SMTP TLS od połączenia',
            'multiOptions' => ['false' => 'Nie (STARTTLS/port 587)', 'true' => 'Tak (SMTPS/port 465)'],
            'value' => $v['smtpSecure'],
        ]);
        $form->addElement('password', 'smtpPass', [
            'label' => 'Hasło SMTP',
            'value' => '',
            'description' => Modules_KitsunepncManager_Config::hasSecret('smtpPass') ? 'Zaszyfrowane. Puste pole zachowa wartość.' : 'Opcjonalne, jeśli serwer SMTP nie wymaga uwierzytelnienia.',
        ]);

        $this->section($form, 'secretSection', 'Git i sekrety', 'Puste pole sekretu zachowuje poprzednią zaszyfrowaną wartość.');
        $this->text($form, 'gitUsername', 'Użytkownik Git HTTPS', $v['gitUsername'], 0, 255, null, 'Używany tylko razem z tokenem Git dla prywatnego repozytorium HTTPS.');
        $form->addElement('textarea', 'gitSshKnownHosts', [
            'label' => 'SSH known_hosts',
            'value' => $v['gitSshKnownHosts'],
            'rows' => 4,
            'description' => 'Opcjonalna przypięta lista hostów, przygotowana i zweryfikowana poza panelem.',
        ]);
        foreach ([
            'gitToken' => ['Token Git', Modules_KitsunepncManager_Config::hasSecret('gitToken')],
            'jwtSecret' => ['JWT secret (min. 32)', Modules_KitsunepncManager_Config::hasSecret('jwtSecret')],
            'jwtRefreshSecret' => ['JWT refresh secret (min. 32)', Modules_KitsunepncManager_Config::hasSecret('jwtRefreshSecret')],
            'dataEncryptionKey' => ['Klucz szyfrowania danych (min. 32)', Modules_KitsunepncManager_Config::hasSecret('dataEncryptionKey')],
            'metricsToken' => ['Token Prometheus /metrics (min. 32)', Modules_KitsunepncManager_Config::hasSecret('metricsToken')],
        ] as $name => $meta) {
            $form->addElement('password', $name, [
                'label' => $meta[0],
                'value' => '',
                'description' => $meta[1] ? 'Zaszyfrowane. Puste pole zachowa wartość.' : 'Zostanie bezpiecznie wygenerowane przy pierwszym zapisie; możesz też wkleić własną wartość (minimum 32 znaki).',
            ]);
        }
        $form->addElement('textarea', 'gitSshPrivateKey', [
            'label' => 'Klucz SSH deploy',
            'value' => '',
            'rows' => 6,
            'description' => Modules_KitsunepncManager_Config::hasSecret('gitSshPrivateKey') ? 'Zaszyfrowany. Puste pole zachowa wartość.' : 'Opcjonalny klucz tylko do odczytu, bez hasła.',
        ]);
        $this->submitButton($form, 'Zapisz konfigurację');
        return $form;
    }

    private function operationForm()
    {
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kpc-operation-form');
        $form->addElement('hidden', 'formType', ['value' => 'operation']);
        $form->addElement('select', 'operation', [
            'label' => 'Co chcesz zrobić?',
            'description' => 'Sprawdzenie i pobranie kodu nie zmieniają działających kontenerów. Wdrożenie dotyczy tylko zaznaczonych modułów.',
            'multiOptions' => [
                'check' => 'Sprawdź repozytorium i dostępne wersje',
                'sync' => 'Zaktualizuj tylko lokalną kopię kodu',
                'deploy' => 'Wdróż wybrane moduły z lokalnej kopii',
                'sync-deploy' => 'Pobierz najnowszy kod i wdróż wybrane moduły',
            ],
        ]);
        $this->section($form, 'moduleSection', 'Moduły do wdrożenia', 'Serwer współpracy obejmuje API i worker, ponieważ korzystają z jednego obrazu. Edytor webowy ma osobny obraz i może być aktualizowany niezależnie.');
        $form->addElement('checkbox', 'moduleServer', [
            'label' => 'Serwer współpracy + worker',
            'value' => '1',
            'description' => 'API, WebSocket, konta, baza, poczta oraz zadania w tle. Przed aktualizacją istniejącej bazy manager tworzy pełny backup.',
        ]);
        $form->addElement('checkbox', 'moduleWeb', [
            'label' => 'Edytor webowy + Caddy',
            'value' => '1',
            'description' => 'Interfejs przeglądarkowy i lokalny reverse proxy Caddy. Nie dotyka bazy ani plików użytkowników.',
        ]);
        $this->submitButton($form, 'Uruchom operację');
        return $form;
    }

    private function maintenanceForm()
    {
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kpc-maintenance-form');
        $form->addElement('hidden', 'formType', ['value' => 'maintenance']);
        $form->addElement('select', 'maintenanceOperation', [
            'label' => 'Operacja na danych',
            'multiOptions' => [
                'backup' => 'Utwórz pełny backup danych',
                'restore' => 'Przywróć wskazany backup',
            ],
            'description' => 'Backup obejmuje bazę SQLite i blob storage. Restore nie usuwa katalogu kopii i wymaga jawnego potwierdzenia.',
        ]);
        $form->addElement('text', 'restorePath', [
            'label' => 'Pełna ścieżka backupu',
            'description' => 'Tylko dla restore. Musi wskazywać istniejący katalog wewnątrz skonfigurowanego katalogu backupów.',
        ]);
        $form->addElement('text', 'confirmation', [
            'label' => 'Potwierdzenie restore',
            'description' => 'Wpisz RESTORE:nazwa-katalogu, np. RESTORE:2026-07-27T120000Z.',
        ]);
        $this->submitButton($form, 'Utwórz pełny backup');
        return $form;
    }

    private function suiteForm()
    {
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kpc-suite-form');
        $form->setAttrib('enctype', 'multipart/form-data');
        $form->addElement('hidden', 'formType', ['value' => 'suite']);
        $form->addElement('select', 'suiteProduct', [
            'label' => 'Produkt',
            'multiOptions' => ['all' => 'KitsuneColab i KitsuneTest', 'colab' => 'Tylko KitsuneColab', 'test' => 'Tylko KitsuneTest'],
        ]);
        $form->addElement('select', 'suiteOperation', [
            'label' => 'Operacja',
            'multiOptions' => [
                'suite-install-deploy' => 'Zainstaluj/aktualizuj pluginy z repo i od razu wdróż',
                'suite-install-repo' => 'Tylko zainstaluj/aktualizuj pluginy z repozytorium',
                'suite-deploy' => 'Wdróż aplikacje przez zainstalowane pluginy',
                'suite-check' => 'Tylko odśwież stan pluginów i połączeń',
                'suite-backup' => 'Utwórz backup aplikacji',
                'suite-install' => 'Awaryjnie: zainstaluj jeden plugin z ZIP',
            ],
            'description' => 'Najprościej wybierz oba produkty i pierwszą operację. Hub pobierze repozytoria, zainstaluje pluginy, przekaże konfigurację, włączy delegowanie i uruchomi wdrożenia.',
        ]);
        $form->addElement('file', 'suitePackage', [
            'label' => 'Paczka pluginu Plesk (.zip)',
            'description' => 'Widoczne wyłącznie dla awaryjnej instalacji pojedynczego pluginu z ZIP.',
        ]);
        $this->submitButton($form, 'Uruchom operację Suite');
        return $form;
    }

    private function suiteBootstrapForm($product)
    {
        $v = Modules_KitsunepncManager_Config::values();
        $isColab = $product === 'colab';
        $prefix = $isColab ? 'colab' : 'test';
        $name = $isColab ? 'KitsuneColab' : 'KitsuneTest';
        $domains = $this->domainOptions();
        $technicalId = static function ($value) {
            $value = trim((string) $value);
            return preg_match('/^[A-Za-z0-9_-]+$/', $value) ? $value : '';
        };
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kpc-suite-bootstrap-' . $product);
        $form->addElement('hidden', 'formType', ['value' => 'suite-bootstrap']);
        $form->addElement('hidden', 'suiteProduct', ['value' => $product]);
        $this->section($form, $prefix . 'BootstrapRepository', 'Repozytorium ' . $name, 'Hub używa tych ustawień przy każdej jawnej instalacji lub aktualizacji z repozytorium: przekazuje domenę, dostęp Git i integrację, włącza sterowanie oraz naprawia niepełną wcześniejszą instalację. Produkt nadal możesz później obsługiwać niezależnie w jego własnym managerze.');
        $this->text($form, $prefix . 'RepositoryUrl', 'Repozytorium Git', $v[$prefix . 'RepositoryUrl'], 5, 1000, '/^(https:\/\/|ssh:\/\/|git@)/', 'Repozytorium musi zawierać katalog tools/plesk-extension właściwego produktu.', true);
        $this->text($form, $prefix . 'RepositoryBranch', 'Gałąź', $v[$prefix . 'RepositoryBranch'], 1, 200, '/^(?![-.])(?!.*\.\.)(?!.*@\{)[A-Za-z0-9._\/-]+$/', 'Hub pobierze tę gałąź i spakuje wyłącznie śledzone pliki pluginu.', true);
        $this->path($form, $prefix . 'RepositoryPath', 'Docelowy katalog kodu aplikacji', $v[$prefix . 'RepositoryPath'], 'Ustawienie zostanie bezpiecznie przekazane do samodzielnego pluginu.');
        if ($isColab) {
            $this->path($form, 'colabDeployPath', 'Katalog wdrożenia Colaba', $v['colabDeployPath'], 'Oddzielny od repozytorium katalog aktywnego wdrożenia.');
            $this->path($form, 'colabBackupPath', 'Katalog backupów Colaba', $v['colabBackupPath'], 'Oddzielny katalog pełnych kopii PostgreSQL i MinIO.');
            $this->suiteDomainSelect($form, 'colabPublicDomain', 'Domena KitsuneColab', $domains, $v['colabPublicDomain'], 'Jedna domena dla panelu i API. Plugin ustawi panel pod /, a API pod /api.');
            $this->text($form, 'colabOrganizationId', 'ID organizacji Colab (opcjonalne)', $technicalId($v['colabOrganizationId']), 0, 200, '/^[A-Za-z0-9_-]*$/', 'Pozostaw puste: pierwsze logowanie z Huba utworzy organizację kitsune-suite. Wpisz techniczne ID tylko dla istniejącej organizacji (nie jej nazwę).', false);
            $this->text($form, 'colabOwnerId', 'ID właściciela Colab (opcjonalne)', $technicalId($v['colabOwnerId']), 0, 200, '/^[A-Za-z0-9_-]*$/', 'Techniczne ID użytkownika dla automatycznych projektów i issue. Nie jest wymagane do samodzielnej instalacji Colaba.', false);
        } else {
            $this->suiteDomainSelect($form, 'testPublicDomain', 'Domena KitsuneTest', $domains, $v['testPublicDomain'], 'Jedna domena dla panelu, API (/api) i readiness (/readyz).');
            $this->text($form, 'testOrganizationId', 'ID organizacji Test (opcjonalne)', $technicalId($v['testOrganizationId']), 0, 200, '/^[A-Za-z0-9_-]*$/', 'Pozostaw puste: pierwsze logowanie z Huba utworzy organizację kitsune-suite. Podaj ID tylko dla istniejącej organizacji docelowej.', false);
            $form->addElement('textarea', 'testGitSshKnownHosts', ['label' => 'SSH known_hosts KitsuneTest', 'value' => $v['testGitSshKnownHosts'], 'rows' => 3, 'description' => 'Opcjonalne; przy SSH Hub przypnie klucz hosta automatycznie.']);
            $form->addElement('textarea', 'testGitSshPrivateKey', ['label' => 'Klucz SSH KitsuneTest', 'value' => '', 'rows' => 5, 'description' => Modules_KitsunepncManager_Config::hasSecret('testGitSshPrivateKey') ? 'Zaszyfrowany. Puste pole zachowa wartość.' : 'Wymagany tylko dla prywatnego repozytorium SSH.']);
        }
        $this->text($form, $prefix . 'GitUsername', 'Użytkownik Git HTTPS', $v[$prefix . 'GitUsername'], 0, 255, null, 'Zwykle x-access-token. Token jest zaszyfrowany i nigdy nie trafia do URL-a.');
        $form->addElement('password', $prefix . 'GitToken', [
            'label' => 'Token Git ' . $name,
            'value' => '',
            'description' => Modules_KitsunepncManager_Config::hasSecret($prefix . 'GitToken') ? 'Zaszyfrowany. Puste pole zachowa wartość.' : 'Opcjonalny dla repozytorium publicznego.',
        ]);
        if ($isColab) {
            $form->addElement('textarea', 'colabGitSshKnownHosts', ['label' => 'SSH known_hosts Colaba', 'value' => $v['colabGitSshKnownHosts'], 'rows' => 3, 'description' => 'Zweryfikowane klucze hosta dla repozytorium SSH.']);
            $form->addElement('textarea', 'colabGitSshPrivateKey', ['label' => 'Klucz SSH Colaba', 'value' => '', 'rows' => 5, 'description' => Modules_KitsunepncManager_Config::hasSecret('colabGitSshPrivateKey') ? 'Zaszyfrowany. Puste pole zachowa wartość.' : 'Opcjonalny read-only deploy key bez hasła.']);
        }
        $form->addElement('password', 'suiteSharedSecret', [
            'label' => 'Wspólny sekret Kitsune Suite',
            'value' => '',
            'description' => Modules_KitsunepncManager_Config::hasSecret('suiteSharedSecret') ? 'Zaszyfrowany. Zostanie przekazany do instalowanego pluginu.' : 'Zostanie automatycznie wygenerowany przy pierwszej instalacji. Możesz też wkleić własny (minimum 32 znaki).',
            'validators' => [['Regex', true, ['pattern' => '/^$|^.{32,512}$/s']]],
        ]);
        $this->submitButton($form, 'Zapisz i zainstaluj z repozytorium');
        return $form;
    }

    private function saveConfig(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) {
            $this->_status->addMessage('error', $this->validationSummary($form, 'konfiguracji'));
            return false;
        }
        $values = $form->getValues();
        $publicUrl = rtrim((string) $values['publicUrl'], '/');
        $parts = parse_url($publicUrl);
        $domain = strtolower(trim((string) $values['domain']));
        if (!is_array($parts) || ($parts['scheme'] ?? '') !== 'https' || strtolower((string) ($parts['host'] ?? '')) !== $domain || isset($parts['query']) || isset($parts['fragment']) || !empty($parts['path'])) {
            return $this->rejectField($form, 'publicUrl', 'Wpisz dokładnie https://' . $domain . ' bez końcowego ukośnika, ścieżki, parametrów ani fragmentu.');
        }
        if ((string) $values['httpPort'] === (string) $values['httpsPort']) {
            return $this->rejectField($form, 'httpsPort', 'Port rezerwowy HTTPS musi różnić się od portu HTTP ' . (string) $values['httpPort'] . '.');
        }
        if (($values['requireEmailVerification'] ?? 'false') === 'true' && trim((string) $values['smtpHost']) === '') {
            return $this->rejectField($form, 'smtpHost', 'To pole jest wymagane, gdy weryfikacja e-mail jest włączona.');
        }
        if (!in_array((string) ($values['proxyMode'] ?? ''), ['docker', 'managed'], true)) {
            return $this->rejectField($form, 'proxyMode', 'Wybierz Docker Proxy Rules albo automatyczny wpis nginx.');
        }
        $repositoryPath = rtrim((string) $values['repositoryPath'], '/');
        foreach (['repositoryPath', 'deployPath', 'dataPath', 'backupPath'] as $pathField) {
            if (in_array('..', explode('/', (string) $values[$pathField]), true)) {
                return $this->rejectField($form, $pathField, 'Ścieżka nie może zawierać segmentu "..".');
            }
        }
        if (rtrim((string) $values['deployPath'], '/') !== $repositoryPath . '/deploy') {
            return $this->rejectField($form, 'deployPath', 'Katalog Docker Compose musi mieć wartość ' . $repositoryPath . '/deploy.');
        }
        foreach (['dataPath' => 'Katalog danych trwałych', 'backupPath' => 'Katalog backupów'] as $field => $label) {
            $candidate = rtrim((string) $values[$field], '/');
            if ($candidate === $repositoryPath || strpos($candidate . '/', $repositoryPath . '/') === 0) {
                return $this->rejectField($form, $field, $label . ' musi znajdować się poza katalogiem kodu, aby aktualizacja nie mogła go nadpisać.');
            }
        }
        foreach (preg_split('/\s*,\s*/', trim((string) ($values['adminEmails'] ?? '')), -1, PREG_SPLIT_NO_EMPTY) as $email) {
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                return $this->rejectField($form, 'adminEmails', 'Nieprawidłowy adres e-mail: ' . $email . '. Adresy rozdziel przecinkami.');
            }
        }
        foreach (['colabApiUrl', 'testApiUrl'] as $field) {
            $value = rtrim(trim((string) ($values[$field] ?? '')), '/');
            if ($value !== '') {
                $parts = parse_url($value);
                $path = (string) ($parts['path'] ?? '');
                if (!is_array($parts) || ($parts['scheme'] ?? '') !== 'https' || empty($parts['host']) || ($path !== '' && $path !== '/') || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])) {
                    return $this->rejectField($form, $field, 'Użyj prostego bazowego adresu HTTPS bez ścieżki, loginu, parametrów ani fragmentu.');
                }
            }
            $values[$field] = $value;
        }
        if (($values['colabApiUrl'] !== '' || $values['testApiUrl'] !== '') && !Modules_KitsunepncManager_Config::hasSecret('suiteSharedSecret') && trim((string) ($values['suiteSharedSecret'] ?? $post['suiteSharedSecret'] ?? '')) === '') {
            return $this->rejectField($form, 'suiteSharedSecret', 'Połączenie z Colabem lub Testem wymaga wspólnego sekretu o długości minimum 32 znaków.');
        }
        $providedSecrets = [];
        foreach (['jwtSecret', 'jwtRefreshSecret', 'dataEncryptionKey', 'metricsToken'] as $secretField) {
            $secret = trim((string) ($values[$secretField] ?? $post[$secretField] ?? ''));
            if ($secret !== '' && strlen($secret) < 32) {
                return $this->rejectField($form, $secretField, 'Nowy sekret musi mieć co najmniej 32 znaki; otrzymano ' . strlen($secret) . '.');
            }
            if ($secret !== '') $providedSecrets[$secretField] = $secret;
        }
        if (count(array_unique(array_values($providedSecrets))) !== count($providedSecrets)) {
            return $this->rejectField($form, 'jwtSecret', 'Każdy z czterech sekretów musi mieć inną wartość.');
        }
        $values['publicUrl'] = $publicUrl;
        try {
            Modules_KitsunepncManager_Config::save($values);
        } catch (Throwable $exception) {
            $this->_status->addMessage('error', 'Nie zapisano konfiguracji: ' . $exception->getMessage());
            return false;
        }
        $this->_status->addMessage('info', 'Konfiguracja została zapisana.');
        $this->respondWithRedirect();
        return true;
    }

    private function startOperation(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) {
            $this->_status->addMessage('error', $this->validationSummary($form, 'operacji'));
            return false;
        }
        $operation = (string) $form->getValue('operation');
        $allowed = ['check', 'sync', 'deploy', 'sync-deploy'];
        if (!in_array($operation, $allowed, true)) {
            return $this->rejectField($form, 'operation', 'Wybierz jedną z dostępnych operacji aktualizacji.');
        }
        $modules = [];
        if ($form->getValue('moduleServer')) $modules[] = 'collaboration-server';
        if ($form->getValue('moduleWeb')) $modules[] = 'web-editor';
        if (in_array($operation, ['deploy', 'sync-deploy'], true) && !$modules) {
            return $this->rejectField($form, 'moduleServer', 'Zaznacz co najmniej jeden moduł do wdrożenia.');
        }
        try {
            $runtime = Modules_KitsunepncManager_Config::createRuntimeConfig($operation, ['modules' => $modules]);
            $task = new Modules_KitsunepncManager_Task_Operate();
            $task->setParam('runtimeConfig', $runtime);
            (new pm_LongTask_Manager())->start($task);
            $this->_status->addMessage('info', 'Operacja została dodana do kolejki Pleska.');
        } catch (Throwable $exception) {
            $this->_status->addMessage('error', $exception->getMessage());
            return false;
        }
        $this->respondWithRedirect();
        return true;
    }

    private function startMaintenance(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) {
            $this->_status->addMessage('error', $this->validationSummary($form, 'operacji na danych'));
            return false;
        }
        $operation = (string) $form->getValue('maintenanceOperation');
        if (!in_array($operation, ['backup', 'restore'], true)) {
            return $this->rejectField($form, 'maintenanceOperation', 'Wybierz backup albo restore.');
        }
        $extra = [
            'restorePath' => trim((string) $form->getValue('restorePath')),
            'confirmation' => trim((string) $form->getValue('confirmation')),
        ];
        if ($operation === 'restore') {
            $expected = 'RESTORE:' . basename($extra['restorePath']);
            if ($extra['restorePath'] === '' || $extra['confirmation'] !== $expected) {
                return $this->rejectField($form, 'confirmation', 'Wpisz dokładnie ' . $expected . '.');
            }
        }
        try {
            $runtime = Modules_KitsunepncManager_Config::createRuntimeConfig($operation, $extra);
            $task = new Modules_KitsunepncManager_Task_Operate();
            $task->setParam('runtimeConfig', $runtime);
            (new pm_LongTask_Manager())->start($task);
            $this->_status->addMessage('info', $operation === 'backup' ? 'Backup został dodany do kolejki Pleska.' : 'Restore został dodany do kolejki Pleska.');
        } catch (Throwable $exception) {
            $this->_status->addMessage('error', $exception->getMessage());
            return false;
        }
        $this->respondWithRedirect();
        return true;
    }

    private function startSuiteOperation(pm_Form_Simple $form, array $post)
    {
        // The ZIP field is intentionally disabled for repository actions.
        // pm_Form_Simple may nevertheless validate that hidden upload field,
        // so validate the only two relevant scalar choices explicitly here.
        $operation = trim((string) ($post['suiteOperation'] ?? ''));
        $product = trim((string) ($post['suiteProduct'] ?? ''));
        if (!in_array($operation, ['suite-check', 'suite-install', 'suite-install-repo', 'suite-install-deploy', 'suite-deploy', 'suite-backup'], true) || !in_array($product, ['all', 'colab', 'test'], true)) {
            return $this->rejectField($form, 'suiteOperation', 'Wybierz obsługiwaną operację i produkt.');
        }
        $extra = ['suiteProduct' => $product];
        if (in_array($operation, ['suite-install-repo', 'suite-install-deploy'], true)) {
            $selectedProducts = $product === 'all' ? ['colab', 'test'] : [$product];
            $bootstraps = [];
            $activeDomains = $this->domainOptions();
            foreach ($selectedProducts as $selectedProduct) {
                $bootstrap = Modules_KitsunepncManager_Config::suiteBootstrapConfig($selectedProduct);
                $productName = $selectedProduct === 'colab' ? 'KitsuneColab' : 'KitsuneTest';
                if (trim((string) ($bootstrap['repositoryUrl'] ?? '')) === '') {
                    return $this->rejectField($form, 'suiteOperation', 'Najpierw zapisz repozytorium produktu ' . $productName . ' w jego sekcji poniżej.');
                }
                $domain = strtolower(trim((string) ($bootstrap['publicDomain'] ?? '')));
                if ($domain === '' || !isset($activeDomains[$domain])) {
                    return $this->rejectField($form, 'suiteOperation', 'Najpierw wybierz aktywną domenę Pleska dla ' . $productName . '.');
                }
                $repositoryUrl = (string) $bootstrap['repositoryUrl'];
                $usesSsh = strpos($repositoryUrl, 'git@') === 0 || strpos($repositoryUrl, 'ssh://') === 0;
                if ($usesSsh && (trim((string) ($bootstrap['gitSshPrivateKey'] ?? '')) === '' || trim((string) ($bootstrap['gitSshKnownHosts'] ?? '')) === '')) {
                    return $this->rejectField($form, 'suiteOperation', 'Repozytorium SSH ' . $productName . ' wymaga zapisanego klucza prywatnego i known_hosts.');
                }
                $bootstraps[$selectedProduct] = $bootstrap;
            }
            if ($product === 'all') $extra['suiteBootstraps'] = $bootstraps;
            else $extra['suiteBootstrap'] = $bootstraps[$product];
        }
        if ($operation === 'suite-install') {
            if ($product === 'all') {
                return $this->rejectField($form, 'suiteProduct', 'Instalacja ZIP obsługuje jeden produkt. Dla obu wybierz instalację z repozytoriów.');
            }
            $file = $_FILES['suitePackage'] ?? null;
            if (!is_array($file) || (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file((string) ($file['tmp_name'] ?? ''))) {
                return $this->rejectField($form, 'suitePackage', 'Wybierz poprawnie przesłaną paczkę ZIP pluginu Plesk.');
            }
            $size = (int) ($file['size'] ?? 0);
            if ($size < 256 || $size > 512 * 1024 * 1024 || strtolower(pathinfo((string) ($file['name'] ?? ''), PATHINFO_EXTENSION)) !== 'zip') {
                return $this->rejectField($form, 'suitePackage', 'Paczka musi być plikiem ZIP o rozmiarze od 256 B do 512 MB.');
            }
            $uploads = rtrim((string) pm_Context::getVarDir(), '/\\') . '/uploads';
            if (!is_dir($uploads) && !mkdir($uploads, 0700, true) && !is_dir($uploads)) {
                throw new RuntimeException('Nie udało się utworzyć bezpiecznego katalogu uploadów.');
            }
            @chmod($uploads, 0700);
            $artifact = $uploads . '/' . $product . '-' . bin2hex(random_bytes(12)) . '.zip';
            if (!move_uploaded_file((string) $file['tmp_name'], $artifact)) {
                return $this->rejectField($form, 'suitePackage', 'Nie udało się zabezpieczyć przesłanej paczki.');
            }
            @chmod($artifact, 0600);
            $extra['artifactPath'] = $artifact;
            $extra['artifactSha256'] = hash_file('sha256', $artifact);
        }
        try {
            $runtime = Modules_KitsunepncManager_Config::createRuntimeConfig($operation, $extra);
            $task = new Modules_KitsunepncManager_Task_Operate();
            $task->setParam('runtimeConfig', $runtime);
            (new pm_LongTask_Manager())->start($task);
            $this->_status->addMessage('info', 'Operacja Kitsune Suite została dodana do kolejki Pleska.');
        } catch (Throwable $exception) {
            if (!empty($extra['artifactPath']) && is_file($extra['artifactPath'])) @unlink($extra['artifactPath']);
            $this->_status->addMessage('error', 'Nie uruchomiono operacji Suite: ' . $exception->getMessage());
            return false;
        }
        $this->respondWithRedirect();
        return true;
    }

    private function startSuiteBootstrap(pm_Form_Simple $form, array $post, $product)
    {
        if (!$form->isValid($post)) {
            $this->_status->addMessage('error', $this->validationSummary($form, 'repozytoryjnej konfiguracji Suite'));
            return false;
        }
        if (!in_array($product, ['colab', 'test'], true)) {
            return $this->rejectField($form, 'suiteProduct', 'Nieznany produkt Kitsune Suite.');
        }
        $values = $form->getValues();
        $prefix = $product === 'colab' ? 'colab' : 'test';
        $availableDomains = $this->domainOptions();
        $applyDomain = function ($field, $urlField) use (&$values, $availableDomains, $form) {
            $domain = strtolower(trim((string) ($values[$field] ?? '')));
            if ($domain === '') return true;
            if (!isset($availableDomains[$domain])) {
                return $this->rejectField($form, $field, 'Wybierz aktywną domenę lub subdomenę z hostingiem w tym Plesku.');
            }
            $values[$field] = $domain;
            $values[$urlField] = 'https://' . $domain;
            return true;
        };
        if ($product === 'colab') {
            if (!$applyDomain('colabPublicDomain', 'colabPublicWebUrl')) return false;
            if (trim((string) ($values['colabPublicDomain'] ?? '')) !== '') $values['colabApiUrl'] = $values['colabPublicWebUrl'];
        } else {
            if (!$applyDomain('testPublicDomain', 'testPublicWebUrl')) return false;
            if (trim((string) ($values['testPublicDomain'] ?? '')) !== '') {
                $values['testApiUrl'] = $values['testPublicWebUrl'];
                $values['testHealthUrl'] = $values['testPublicWebUrl'] . '/readyz';
            }
        }
        $repositoryUrl = trim((string) ($values[$prefix . 'RepositoryUrl'] ?? ''));
        $repositoryParts = parse_url($repositoryUrl);
        $repositoryScheme = is_array($repositoryParts) ? (string) ($repositoryParts['scheme'] ?? '') : '';
        $repositoryUser = is_array($repositoryParts) ? (string) ($repositoryParts['user'] ?? '') : '';
        $safeSshUser = $repositoryScheme === 'ssh' && $repositoryUser === 'git' && !isset($repositoryParts['pass']);
        if (!is_array($repositoryParts) || (isset($repositoryParts['user']) && !$safeSshUser) || isset($repositoryParts['pass']) || isset($repositoryParts['query']) || isset($repositoryParts['fragment'])) {
            return $this->rejectField($form, $prefix . 'RepositoryUrl', 'Adres repozytorium nie może zawierać danych logowania, parametrów ani fragmentu (dla ssh:// dozwolony jest wyłącznie użytkownik git).');
        }
        $repositoryPath = rtrim((string) ($values[$prefix . 'RepositoryPath'] ?? ''), '/');
        if (!preg_match('#^/(?:home|opt|srv|var/lib|var/backups)/[A-Za-z0-9._/-]+$#', $repositoryPath) || in_array('..', explode('/', $repositoryPath), true)) {
            return $this->rejectField($form, $prefix . 'RepositoryPath', 'Użyj pełnej, dedykowanej ścieżki zaczynającej się od /home, /opt, /srv, /var/lib albo /var/backups, bez segmentu "..".');
        }
        if ($product === 'colab') {
            $paths = [
                rtrim((string) ($values['colabRepositoryPath'] ?? ''), '/'),
                rtrim((string) ($values['colabDeployPath'] ?? ''), '/'),
                rtrim((string) ($values['colabBackupPath'] ?? ''), '/'),
            ];
            for ($first = 0; $first < count($paths); $first++) {
                for ($second = $first + 1; $second < count($paths); $second++) {
                    if ($paths[$first] === $paths[$second] || strpos($paths[$first] . '/', $paths[$second] . '/') === 0 || strpos($paths[$second] . '/', $paths[$first] . '/') === 0) {
                        return $this->rejectField($form, 'colabDeployPath', 'Katalog repozytorium, wdrożenia i backupów Colaba nie mogą się pokrywać.');
                    }
                }
            }
        }
        $apiField = $product === 'colab' ? 'colabApiUrl' : 'testApiUrl';
        $apiUrl = rtrim(trim((string) ($values[$apiField] ?? '')), '/');
        $apiParts = parse_url($apiUrl);
        $apiPath = is_array($apiParts) ? (string) ($apiParts['path'] ?? '') : '';
        if (!is_array($apiParts) || ($apiParts['scheme'] ?? '') !== 'https' || empty($apiParts['host']) || ($apiPath !== '' && $apiPath !== '/') || isset($apiParts['query']) || isset($apiParts['fragment']) || isset($apiParts['user']) || isset($apiParts['pass'])) {
            return $this->rejectField($form, $apiField, 'Ustaw prosty bazowy URL HTTPS API bez ścieżki, loginu, parametrów ani fragmentu.');
        }
        $values[$apiField] = $apiUrl;
        $suiteSecret = trim((string) ($values['suiteSharedSecret'] ?? $post['suiteSharedSecret'] ?? ''));
        if (!Modules_KitsunepncManager_Config::hasSecret('suiteSharedSecret') && $suiteSecret === '') {
            Modules_KitsunepncManager_Config::ensureSuiteSharedSecret();
        }
        if (strpos($repositoryUrl, 'git@') === 0 || ($repositoryParts['scheme'] ?? '') === 'ssh') {
            $keyField = $prefix . 'GitSshPrivateKey';
            $knownHostsField = $prefix . 'GitSshKnownHosts';
            $newKey = trim((string) ($values[$keyField] ?? $post[$keyField] ?? ''));
            if (!Modules_KitsunepncManager_Config::hasSecret($keyField) && $newKey === '') {
                return $this->rejectField($form, $prefix . 'RepositoryUrl', 'Repozytorium SSH wymaga read-only deploy key.');
            }
            if (trim((string) ($values[$knownHostsField] ?? '')) === '') {
                try {
                    $values[$knownHostsField] = Modules_KitsunepncManager_Config::discoverSshKnownHosts($repositoryUrl);
                    $this->_status->addMessage('info', 'Automatycznie pobrano i przypięto klucz SSH hosta repozytorium.');
                } catch (Throwable $exception) {
                    return $this->rejectField($form, $knownHostsField, 'Nie udało się automatycznie pobrać klucza SSH hosta: ' . $exception->getMessage());
                }
            }
        }
        try {
            Modules_KitsunepncManager_Config::save($values);
            $runtime = Modules_KitsunepncManager_Config::createRuntimeConfig('suite-install-repo', [
                'suiteProduct' => $product,
                'suiteBootstrap' => Modules_KitsunepncManager_Config::suiteBootstrapConfig($product),
            ]);
            $task = new Modules_KitsunepncManager_Task_Operate();
            $task->setParam('runtimeConfig', $runtime);
            (new pm_LongTask_Manager())->start($task);
            $this->_status->addMessage('info', 'Hub zapisał konfigurację i dodał instalację pluginu ' . ($product === 'colab' ? 'KitsuneColab' : 'KitsuneTest') . ' z repozytorium do kolejki.');
        } catch (Throwable $exception) {
            $this->_status->addMessage('error', 'Nie uruchomiono repozytoryjnego bootstrapu: ' . $exception->getMessage());
            return false;
        }
        $this->respondWithRedirect();
        return true;
    }

    private function rejectField(pm_Form_Simple $form, $field, $message)
    {
        $element = $form->getElement($field);
        if ($element) $element->addError($message);
        $label = $element ? trim(strip_tags((string) $element->getLabel())) : (string) $field;
        $this->_status->addMessage('error', 'Nie zapisano formularza. ' . $label . ': ' . $message);
        return false;
    }

    private function validationSummary(pm_Form_Simple $form, $context)
    {
        $hints = [
            'repositoryUrl' => 'podaj adres zaczynający się od https://, ssh:// albo git@',
            'repositoryBranch' => 'użyj nazwy gałęzi, np. main, bez spacji i sekwencji ..',
            'repositoryPath' => 'podaj pełną ścieżkę, np. /home/pnc/source',
            'deployPath' => 'podaj katalog deploy wewnątrz repozytorium',
            'dataPath' => 'podaj pełną ścieżkę poza repozytorium, np. /home/pnc/data/kitsunepnc',
            'backupPath' => 'podaj pełną ścieżkę poza repozytorium, np. /home/pnc/backups/kitsunepnc',
            'backupKeep' => 'wpisz liczbę od 1 do 365',
            'domain' => 'wybierz aktywną domenę Pleska z hostingiem',
            'publicUrl' => 'wpisz https://domena bez dodatkowej ścieżki',
            'httpPort' => 'wpisz wolny port od 1024 do 65535',
            'httpsPort' => 'wpisz inny wolny port od 1024 do 65535',
            'smtpPort' => 'wpisz port od 1 do 65535',
        ];
        $details = [];
        foreach ((array) $form->getMessages() as $field => $messages) {
            if (!$messages) continue;
            $element = $form->getElement($field);
            $label = $element ? trim(strip_tags((string) $element->getLabel())) : (string) $field;
            $reason = $hints[$field] ?? implode(', ', array_values((array) $messages));
            $details[] = $label . ' — ' . $reason;
        }
        if (!$details) $details[] = 'sprawdź wartości oznaczone bezpośrednio przy polach';
        return 'Nie zapisano ' . $context . '. Popraw: ' . implode('; ', $details) . '.';
    }

    private function refreshStatus()
    {
        $runtime = null;
        try {
            $runtime = Modules_KitsunepncManager_Config::createRuntimeConfig('status');
            $result = pm_ApiCli::callSbin('kitsunepnc-manager', ['--config', $runtime], pm_ApiCli::RESULT_FULL);
            if ((int) ($result['code'] ?? 1) !== 0) {
                $detail = trim((string) ($result['stderr'] ?? $result['stdout'] ?? ''));
                return $detail !== '' ? mb_substr($detail, -2000) : 'Narzędzie statusu zakończyło się błędem.';
            }
            return null;
        } catch (Throwable $exception) {
            return mb_substr($exception->getMessage(), -2000);
        } finally {
            if ($runtime && is_file($runtime)) @unlink($runtime);
        }
    }

    private function respondWithRedirect()
    {
        $path = '/modules/kitsunepnc-manager/index.php/index/index';
        if ($this->getRequest()->isXmlHttpRequest()) {
            $this->_helper->json(['redirect' => $path]);
            return;
        }
        // Zend's redirect helper prepends the current module base URL on some
        // Plesk Obsidian builds. Set an absolute Location header directly so
        // /modules/kitsunepnc-manager is never duplicated.
        $host = preg_replace('/[^A-Za-z0-9.:-]/', '', (string) ($_SERVER['HTTP_HOST'] ?? ''));
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $location = $host !== '' ? $scheme . '://' . $host . $path : $path;
        $this->getResponse()->setRedirect($location, 303);
        $this->_helper->viewRenderer->setNoRender(true);
    }

    private function domainOptions($savedDomain = '')
    {
        $options = [];
        try {
            foreach ((array) pm_Domain::getAllDomains() as $domain) {
                if (!$domain instanceof pm_Domain || !$domain->hasHosting() || !$domain->isActive() || $domain->isSuspended() || $domain->isDisabled()) continue;
                $name = strtolower(trim((string) $domain->getName()));
                if (preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/', $name)) $options[$name] = $name;
            }
        } catch (Throwable $exception) {
            // Formularz pozostaje dostępny; deploy ponownie zweryfikuje domenę.
        }
        natcasesort($options);
        $savedDomain = strtolower(trim((string) $savedDomain));
        if (!$options && preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/', $savedDomain)) {
            $options[$savedDomain] = $savedDomain . ' (zapisana konfiguracja)';
        }
        return $options;
    }

    private function suiteDomainSelect(pm_Form_Simple $form, $field, $label, array $domains, $selected, $description)
    {
        if ($domains) {
            $options = ['' => '— wybierz domenę Pleska —'] + $domains;
            $form->addElement('select', $field, [
                'label' => $label,
                'multiOptions' => $options,
                'value' => isset($domains[$selected]) ? $selected : '',
                'description' => $description . ' Widoczne są wyłącznie aktywne domeny i subdomeny z hostingiem.',
            ]);
            return;
        }
        $this->text($form, $field, $label, $selected, 0, 253, '/^$|^(?=.{1,253}$)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}$/', $description . ' Brak domen z hostingiem do wyboru — wpisz adres ręcznie.', false);
    }

    private function submitButton(pm_Form_Simple $form, $label)
    {
        // pm_Form_Simple renders every control as #btn-send. This page has
        // several independent forms, so those duplicate ids break Plesk's
        // CommandButton initialization. A normal submit is safely handled by
        // Jsw.FormAjax and remains unique for each form.
        $id = preg_replace('/[^A-Za-z0-9_-]/', '-', (string) $form->getAttrib('id')) . '-submit';
        $form->addElement('simpleText', $id, [
            'label' => '', 'escape' => false,
            'value' => '<div class="kpc-action-row"><button type="submit" name="send" value="1" id="' . htmlspecialchars($id, ENT_QUOTES, 'UTF-8') . '" class="kpc-primary-action">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</button></div>',
        ]);
    }

    private function section(pm_Form_Simple $form, $name, $title, $description)
    {
        $form->addElement('simpleText', $name, [
            'label' => '',
            'escape' => false,
            'value' => '<div class="kpc-form-section"><strong>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</strong><span>' . htmlspecialchars($description, ENT_QUOTES, 'UTF-8') . '</span></div>',
        ]);
    }

    private function path(pm_Form_Simple $form, $name, $label, $value, $description = '')
    {
        $this->text($form, $name, $label, $value, 2, 1000, '#^/(?:home|opt|srv|var/lib|var/backups)/[A-Za-z0-9._/-]+$#', $description, true);
    }

    private function text(pm_Form_Simple $form, $name, $label, $value, $min, $max, $regex = null, $description = '', $required = false)
    {
        $validators = [['StringLength', true, ['min' => $min, 'max' => $max]]];
        if ($regex) $validators[] = ['Regex', true, ['pattern' => $regex]];
        $form->addElement('text', $name, ['label' => $label, 'value' => $value, 'description' => $description, 'required' => $required, 'validators' => $validators]);
    }
}
