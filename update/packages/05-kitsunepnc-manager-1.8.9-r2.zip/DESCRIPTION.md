# KitsunePNC Deployment Manager

Panel administracyjny Pleska dla wdrożeń KitsuneHub przez Docker Compose, wraz z
porównaniem wersji modułów, selektywnym wdrażaniem, bezpieczną synchronizacją
Git oraz oddzielnymi operacjami backup i restore.
