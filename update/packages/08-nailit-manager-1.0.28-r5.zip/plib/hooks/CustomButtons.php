<?php

class Modules_NailitManager_CustomButtons extends pm_Hook_CustomButtons
{
    public function getButtons()
    {
        if ($this->hubOwnsNavigation()) return [];
        return [[
            'place' => [
                self::PLACE_ADMIN_NAVIGATION,
                self::PLACE_HOSTING_PANEL_NAVIGATION,
            ],
            'section' => self::SECTION_NAV_SERVER_MANAGEMENT,
            'order' => 50,
            'title' => 'NailIT Manager',
            'description' => 'Wdrażanie i aktualizowanie modułów NailIT',
            'icon' => pm_Context::getBaseUrl() . 'images/nailit-menu.svg',
            'link' => pm_Context::getActionUrl('index', 'index'),
            'newWindow' => false,
        ]];
    }

    private function hubOwnsNavigation()
    {
        try { return pm_Extension::getById('kitsuneserv-bridge')->isActive(); }
        catch (Throwable $exception) { return false; }
    }
}
