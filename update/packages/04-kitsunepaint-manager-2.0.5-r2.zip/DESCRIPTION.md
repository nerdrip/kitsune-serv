# Kitsune Creative Suite Deployment Manager

Klasyczne rozszerzenie Plesk Obsidian do bezpiecznego pobierania, wdrażania, aktualizowania i diagnozowania Kitsune Creative Suite oraz prywatnej chmury projektów.
