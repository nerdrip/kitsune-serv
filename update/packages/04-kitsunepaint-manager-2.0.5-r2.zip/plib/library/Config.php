<?php

class Modules_KitsunepaintManager_Config
{
    public const EXTENSION_VERSION = '2.0.5';

    private const SECRET_FIELDS = [
        'gitToken' => 'secret_git_token',
        'gitSshPrivateKey' => 'secret_git_ssh_private_key',
        'aiApiKey' => 'secret_ai_api_key',
        'smtpPassword' => 'secret_smtp_password',
        'c2paCertificate' => 'secret_c2pa_certificate',
        'c2paPrivateKey' => 'secret_c2pa_private_key',
        'connectorsJson' => 'secret_connectors_json',
        'adminKey' => 'secret_admin_key',
        'auditKey' => 'secret_audit_key',
        'stripeSecretKey' => 'secret_stripe_key',
        'stripeWebhookSecret' => 'secret_stripe_webhook',
        'offlineLicenseKey' => 'secret_offline_license_key',
        'costAlertWebhookSecret' => 'secret_cost_alert_webhook',
        'enterpriseIdentityJson' => 'secret_enterprise_identity_json',
    ];

    public static function defaults()
    {
        return [
            'repositoryUrl' => '',
            'repositoryBranch' => 'main',
            'repositoryPath' => '/opt/kitsunepaint/source',
            'gitUsername' => 'x-access-token',
            'gitSshKnownHosts' => '',
            'dataPath' => '/opt/kitsunepaint/data',
            'backupPath' => '/opt/kitsunepaint/backups',
            'backupRetention' => '14',
            'backupIntervalMinutes' => '60',
            'rpoTargetMinutes' => '60',
            'rtoTargetMinutes' => '15',
            'bindAddress' => '127.0.0.1',
            'httpPort' => '47841',
            'domain' => '',
            'registrationEnabled' => 'false',
            'requireEmailVerification' => 'false',
            'mailMode' => 'development',
            'mailFrom' => 'Kitsune Creative Suite <no-reply@localhost>',
            'smtpHost' => '',
            'smtpPort' => '587',
            'smtpSecure' => 'false',
            'smtpUser' => '',
            'adminEmails' => '',
            'sessionTtlDays' => '30',
            'maxProjectMb' => '50',
            'maxProjects' => '100',
            'userQuotaMb' => '1024',
            'proMaxProjectMb' => '200',
            'proMaxProjects' => '500',
            'proUserQuotaMb' => '10240',
            'aiBaseUrl' => '',
            'aiApiMode' => 'responses',
            'aiTextModel' => '',
            'aiImageModel' => '',
            'aiTimeoutMs' => '120000',
            'aiMaxImageMb' => '20',
            'aiConcurrencyPerUser' => '1',
            'aiTextDailyRequests' => '200',
            'aiImageDailyRequests' => '25',
            'proAiTextDailyRequests' => '800',
            'proAiImageDailyRequests' => '100',
            'renderDailyJobs' => '100',
            'renderDailyMinutes' => '240',
            'renderDailyOutputMb' => '1024',
            'proRenderDailyJobs' => '400',
            'proRenderDailyMinutes' => '960',
            'proRenderDailyOutputMb' => '4096',
            'stripePriceId' => '',
            'whiteLabelJson' => '',
            'costStorageGbMonth' => '0.03',
            'costRenderMinute' => '0.01',
            'costCurrency' => 'EUR',
            'costAlertWebhookUrl' => '',
            'costAlertAmount' => '0',
            'costAlertCooldownHours' => '24',
            'restoreDrillIntervalHours' => '168',
        ];
    }

    public static function values()
    {
        $values = [];
        foreach (self::defaults() as $key => $default) {
            $values[$key] = (string) pm_Settings::get($key, $default);
        }
        return $values;
    }

    public static function save(array $values)
    {
        foreach (self::defaults() as $key => $default) {
            if (array_key_exists($key, $values)) {
                pm_Settings::set($key, trim((string) $values[$key]));
            }
        }
        foreach (self::SECRET_FIELDS as $field => $setting) {
            $value = trim((string) ($values[$field] ?? ''));
            if (in_array($field, ['gitSshPrivateKey', 'c2paCertificate', 'c2paPrivateKey'], true)) {
                $value = str_replace(["\r\n", "\r"], "\n", $value);
            }
            if ($value !== '') pm_Settings::setEncrypted($setting, $value);
        }
    }

    public static function hasSecret($field)
    {
        return self::secret($field) !== '';
    }

    public static function readState()
    {
        $path = pm_Context::getVarDir() . '/state.json';
        if (!is_file($path)) return self::emptyState();
        $decoded = json_decode((string) file_get_contents($path), true);
        return is_array($decoded) ? array_replace_recursive(self::emptyState(), $decoded) : self::emptyState();
    }

    public static function createRuntimeConfig($action, array $parameters = [])
    {
        $varDir = rtrim((string) pm_Context::getVarDir(), '/\\');
        if (!is_dir($varDir) && !mkdir($varDir, 0700, true) && !is_dir($varDir)) {
            throw new RuntimeException('Nie udało się utworzyć katalogu roboczego rozszerzenia.');
        }
        @chmod($varDir, 0700);
        $realVarDir = realpath($varDir);
        if ($realVarDir === false) throw new RuntimeException('Nie udało się ustalić katalogu roboczego.');
        $config = self::values();
        $config['action'] = (string) $action;
        $config['extensionVersion'] = self::EXTENSION_VERSION;
        $config['gitToken'] = self::secret('gitToken');
        $config['gitSshPrivateKey'] = self::secret('gitSshPrivateKey');
        $config['aiApiKey'] = self::secret('aiApiKey');
        $config['smtpPassword'] = self::secret('smtpPassword');
        $config['c2paCertificate'] = self::secret('c2paCertificate');
        $config['c2paPrivateKey'] = self::secret('c2paPrivateKey');
        $config['connectorsJson'] = self::secret('connectorsJson');
        $config['adminKey'] = self::secret('adminKey');
        $config['auditKey'] = self::secret('auditKey');
        $config['stripeSecretKey'] = self::secret('stripeSecretKey');
        $config['stripeWebhookSecret'] = self::secret('stripeWebhookSecret');
        $config['offlineLicenseKey'] = self::secret('offlineLicenseKey');
        $config['costAlertWebhookSecret'] = self::secret('costAlertWebhookSecret');
        $config['enterpriseIdentityJson'] = self::secret('enterpriseIdentityJson');
        $config['statePath'] = $realVarDir . '/state.json';
        $config['lockPath'] = $realVarDir . '/operation.lock';
        $config['backupName'] = trim((string) ($parameters['backupName'] ?? ''));
        $config['confirmation'] = trim((string) ($parameters['confirmation'] ?? ''));
        $path = $realVarDir . '/operation-' . bin2hex(random_bytes(12)) . '.json';
        $json = json_encode($config, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($json === false || file_put_contents($path, $json, LOCK_EX) === false) {
            throw new RuntimeException('Nie udało się zapisać konfiguracji zadania.');
        }
        chmod($path, 0600);
        return $path;
    }

    private static function secret($field)
    {
        if (!isset(self::SECRET_FIELDS[$field])) return '';
        try {
            return (string) pm_Settings::getDecrypted(self::SECRET_FIELDS[$field], '');
        } catch (Throwable $exception) {
            return '';
        }
    }

    private static function emptyState()
    {
        return [
            'updatedAt' => null,
            'lastOperation' => null,
            'lastSuccess' => null,
            'lastError' => null,
            'repository' => ['commit' => null, 'remoteCommit' => null, 'branch' => null, 'dirty' => null, 'updateAvailable' => null, 'checkedAt' => null],
            'service' => ['state' => 'unknown', 'health' => 'unknown', 'url' => null],
            'versions' => ['runningApp' => null, 'localApp' => null, 'remoteApp' => null, 'installedPlugin' => self::EXTENSION_VERSION, 'localPlugin' => null, 'remotePlugin' => null],
            'services' => [],
            'docker' => ['available' => false, 'engineVersion' => null, 'composeVersion' => null],
            'proxy' => ['domain' => null, 'hostPort' => null, 'configured' => false, 'path' => null],
            'backups' => [],
            'restoreDrill' => ['state' => 'not-run', 'backup' => null, 'completedAt' => null, 'isolated' => null],
            'log' => [],
        ];
    }
}
