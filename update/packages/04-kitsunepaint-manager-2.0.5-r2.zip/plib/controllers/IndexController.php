<?php

class IndexController extends pm_Controller_Action
{
    protected $_accessLevel = 'admin';

    public function init()
    {
        parent::init();
        $this->view->pageTitle = 'Kitsune Creative Suite Deployment Manager';
        $this->view->headLink()->appendStylesheet(
            pm_Context::getBaseUrl() . 'css/kitsunepaint.css?v=' . Modules_KitsunepaintManager_Config::EXTENSION_VERSION
        );
        $this->view->headScript()->appendFile(
            pm_Context::getBaseUrl() . 'js/kitsunepaint.js?v=' . Modules_KitsunepaintManager_Config::EXTENSION_VERSION
        );
        $this->view->headLink()->appendStylesheet(pm_Context::getBaseUrl() . 'css/kitsune-platform.css?v=1');
        $this->view->headScript()->appendFile(pm_Context::getBaseUrl() . 'js/kitsune-platform.js?v=1');
        $this->view->suiteProduct = 'Kitsune Creative Suite';
        $this->view->suiteVersion = Modules_KitsunepaintManager_Config::EXTENSION_VERSION;
        try { $this->view->suiteHubActive = pm_Extension::getById('kitsuneserv-bridge')->isActive(); }
        catch (Throwable $exception) { $this->view->suiteHubActive = false; }
    }

    public function indexAction()
    {
        $configForm = $this->configForm();
        $operationForm = $this->operationForm();
        $pluginUpdateForm = $this->pluginUpdateForm();
        $maintenanceForm = $this->maintenanceForm();
        $serviceForm = $this->serviceForm();
        $allowedTabs = ['status', 'deploy', 'config', 'data', 'log'];
        $requestedTab = (string) $this->getRequest()->getParam('tab', '');
        $activeTab = in_array($requestedTab, $allowedTabs, true) ? $requestedTab : 'status';
        if ($this->getRequest()->isPost()) {
            $post = $this->getRequest()->getPost();
            if (($post['formType'] ?? '') === 'config') {
                $this->saveConfig($configForm, $post);
                $this->clearSensitiveFormValues($configForm);
                return $this->respondWithRedirect('config');
            } elseif (($post['formType'] ?? '') === 'operation') {
                $this->startOperation($operationForm, $post, ['check', 'sync', 'deploy', 'sync-deploy']);
                return $this->respondWithRedirect('deploy');
            } elseif (($post['formType'] ?? '') === 'plugin-update') {
                $this->startOperation($pluginUpdateForm, $post, ['plugin-update'], 'pluginOperation');
                return $this->respondWithRedirect('deploy');
            } elseif (($post['formType'] ?? '') === 'maintenance') {
                $this->startMaintenance($maintenanceForm, $post);
                return $this->respondWithRedirect('data');
            } elseif (($post['formType'] ?? '') === 'service') {
                $this->startOperation($serviceForm, $post, ['start', 'restart', 'stop'], 'serviceOperation');
                return $this->respondWithRedirect('status');
            } else {
                $this->_status->addMessage('error', 'Nie rozpoznano wysłanego formularza.');
                return $this->respondWithRedirect($activeTab);
            }
        }
        $this->view->statusRefreshError = $this->refreshStatus();
        $this->view->configForm = $configForm;
        $this->view->operationForm = $operationForm;
        $this->view->pluginUpdateForm = $pluginUpdateForm;
        $this->view->maintenanceForm = $maintenanceForm;
        $this->view->serviceForm = $serviceForm;
        $this->view->config = Modules_KitsunepaintManager_Config::values();
        $this->view->state = Modules_KitsunepaintManager_Config::readState();
        $this->view->hasGitToken = Modules_KitsunepaintManager_Config::hasSecret('gitToken');
        $this->view->hasSshKey = Modules_KitsunepaintManager_Config::hasSecret('gitSshPrivateKey');
        $this->view->hasAiKey = Modules_KitsunepaintManager_Config::hasSecret('aiApiKey');
        $this->view->hasAdminKey = Modules_KitsunepaintManager_Config::hasSecret('adminKey');
        $this->view->hasAuditKey = Modules_KitsunepaintManager_Config::hasSecret('auditKey');
        $this->view->hasStripe = Modules_KitsunepaintManager_Config::hasSecret('stripeSecretKey');
        $this->view->hasEnterpriseIdentity = Modules_KitsunepaintManager_Config::hasSecret('enterpriseIdentityJson');
        $this->view->activeTab = $activeTab;
        $this->view->extensionVersion = Modules_KitsunepaintManager_Config::EXTENSION_VERSION;
    }

    private function configForm()
    {
        $values = Modules_KitsunepaintManager_Config::values();
        $domains = $this->domainOptions($values['domain']);
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kpp-config-form');
        $form->addElement('hidden', 'formType', ['value' => 'config']);

        $this->section($form, 'repositorySection', 'Repozytorium i trwałe dane', 'Kod, dane aplikacji oraz backupy muszą znajdować się w rozłącznych katalogach. Aktualizacja kodu nie dotyka danych użytkowników.');
        $this->text($form, 'repositoryUrl', 'Repozytorium Git', $values['repositoryUrl'], true, 'HTTPS albo SSH do repozytorium Kitsune Creative Suite.');
        $this->text($form, 'repositoryBranch', 'Gałąź', $values['repositoryBranch'], true, 'Zwykle main. Aktualizacja używa wyłącznie fast-forward.');
        $this->text($form, 'repositoryPath', 'Katalog kodu', $values['repositoryPath'], true, 'Dedykowana kopia wdrożeniowa, np. /opt/kitsunepaint/source.');
        $this->text($form, 'dataPath', 'Dane trwałe', $values['dataPath'], true, 'Konta i projekty poza repozytorium.');
        $this->text($form, 'backupPath', 'Backupy', $values['backupPath'], true, 'Kopie danych poza repozytorium.');
        $form->addElement('text', 'backupRetention', ['label' => 'Retencja backupów', 'value' => $values['backupRetention'], 'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 100]]]]);

        $this->section($form, 'publicationSection', 'Publikacja i dostęp', 'Kontener nasłuchuje lokalnie, a publiczny HTTPS kończy się w Plesku. Manager utrzymuje oznaczony blok reverse proxy wybranej domeny.');
        $form->addElement('select', 'bindAddress', ['label' => 'Adres nasłuchu', 'multiOptions' => ['127.0.0.1' => '127.0.0.1 — zalecane', '0.0.0.0' => '0.0.0.0 — tylko z firewallem'], 'value' => $values['bindAddress']]);
        $form->addElement('text', 'httpPort', ['label' => 'Port HTTP', 'value' => $values['httpPort'], 'validators' => [['Digits', true], ['Between', true, ['min' => 1024, 'max' => 65535]]]]);
        if ($domains) {
            $form->addElement('select', 'domain', ['label' => 'Domena Pleska', 'multiOptions' => $domains, 'value' => isset($domains[$values['domain']]) ? $values['domain'] : array_key_first($domains), 'description' => 'Aktywna domena lub subdomena z hostingiem WWW i certyfikatem TLS.', 'required' => true]);
        } else {
            $this->text($form, 'domain', 'Domena Pleska', $values['domain'], true, 'Nie znaleziono aktywnej domeny z hostingiem. Utwórz ją w Plesku albo wpisz nazwę ręcznie.');
        }
        $form->addElement('select', 'registrationEnabled', ['label' => 'Rejestracja kont', 'multiOptions' => ['true' => 'Włączona', 'false' => 'Wyłączona'], 'value' => $values['registrationEnabled']]);
        $form->addElement('select', 'requireEmailVerification', ['label' => 'Weryfikacja e-mail', 'multiOptions' => ['true' => 'Wymagana przed dostępem do projektów', 'false' => 'Wyłączona'], 'value' => $values['requireEmailVerification'], 'description' => 'W produkcji włącz dopiero po poprawnym skonfigurowaniu SMTP.']);
        $form->addElement('select', 'mailMode', ['label' => 'Tryb poczty', 'multiOptions' => ['smtp' => 'SMTP — produkcja', 'development' => 'Prywatny outbox — testy', 'disabled' => 'Wyłączona'], 'value' => $values['mailMode']]);
        $this->text($form, 'mailFrom', 'Nadawca e-mail', $values['mailFrom'], true, 'Np. Kitsune Creative Suite <no-reply@twoja-domena.pl>.');
        $this->text($form, 'smtpHost', 'SMTP host', $values['smtpHost'], false, 'Wymagany dla trybu SMTP.');
        $form->addElement('text', 'smtpPort', ['label' => 'SMTP port', 'value' => $values['smtpPort'], 'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 65535]]]]);
        $form->addElement('select', 'smtpSecure', ['label' => 'SMTP TLS od połączenia', 'multiOptions' => ['false' => 'Nie — STARTTLS / port 587', 'true' => 'Tak — implicit TLS / port 465'], 'value' => $values['smtpSecure']]);
        $this->text($form, 'smtpUser', 'SMTP użytkownik', $values['smtpUser'], false, 'Login skrzynki lub identyfikator usługi SMTP.');
        $form->addElement('password', 'smtpPassword', ['label' => 'SMTP hasło', 'value' => '', 'description' => Modules_KitsunepaintManager_Config::hasSecret('smtpPassword') ? 'Zaszyfrowane. Puste pole zachowa wartość.' : 'Wymagane, jeśli dostawca SMTP używa uwierzytelniania.']);
        foreach ([
            'sessionTtlDays' => ['Ważność sesji (dni)', 1, 365],
            'maxProjectMb' => ['Maks. projekt (MB)', 1, 500],
            'maxProjects' => ['Maks. projektów / konto', 1, 1000],
            'userQuotaMb' => ['Limit konta (MB)', 10, 100000],
            'proMaxProjectMb' => ['Pro · maks. projekt (MB)', 1, 2048],
            'proMaxProjects' => ['Pro · maks. projektów', 1, 100000],
            'proUserQuotaMb' => ['Pro · limit konta (MB)', 10, 10485760],
        ] as $name => $meta) {
            $form->addElement('text', $name, ['label' => $meta[0], 'value' => $values[$name], 'validators' => [['Digits', true], ['Between', true, ['min' => $meta[1], 'max' => $meta[2]]]]]);
        }

        $this->section($form, 'aiSection', 'AI Studio i Content Credentials', 'Integracje AI pozostają opcjonalne. Klucze, certyfikat C2PA oraz klucz podpisujący są szyfrowane przez Pleska i przekazywane wyłącznie do backendu.');
        $this->text($form, 'aiBaseUrl', 'Brama AI · Base URL', $values['aiBaseUrl'], false, 'Opcjonalny endpoint zgodny z OpenAI, wyłącznie HTTPS.');
        $form->addElement('select', 'aiApiMode', ['label' => 'API tekstowe AI', 'multiOptions' => ['responses' => 'Responses API — OpenAI', 'chat-completions' => 'Chat Completions — zgodność'], 'value' => $values['aiApiMode'], 'description' => 'Responses wyłącza przechowywanie odpowiedzi przez store=false; tryb zgodności obsługuje starszych providerów.']);
        $this->text($form, 'aiTextModel', 'Model tekstowy AI', $values['aiTextModel'], false, 'Nazwa modelu dostępnego u skonfigurowanego dostawcy.');
        $this->text($form, 'aiImageModel', 'Model obrazu AI', $values['aiImageModel'], false, 'Model obsługujący image edits / maskę.');
        foreach ([
            'aiTimeoutMs' => ['Timeout AI (ms)', 1000, 300000],
            'aiMaxImageMb' => ['Maks. obraz/maska AI (MB)', 1, 64],
            'aiConcurrencyPerUser' => ['Równoległe zadania AI / konto', 1, 4],
            'aiTextDailyRequests' => ['Free · tekst AI / 24 h', 1, 10000],
            'aiImageDailyRequests' => ['Free · obrazy AI / 24 h', 1, 1000],
            'proAiTextDailyRequests' => ['Pro · tekst AI / 24 h', 1, 100000],
            'proAiImageDailyRequests' => ['Pro · obrazy AI / 24 h', 1, 10000],
        ] as $name => $meta) {
            $form->addElement('text', $name, ['label' => $meta[0], 'value' => $values[$name], 'validators' => [['Digits', true], ['Between', true, ['min' => $meta[1], 'max' => $meta[2]]]]]);
        }
        $form->addElement('password', 'aiApiKey', ['label' => 'Klucz bramy AI', 'value' => '', 'description' => Modules_KitsunepaintManager_Config::hasSecret('aiApiKey') ? 'Zaszyfrowany. Puste pole zachowa wartość.' : 'Opcjonalny; nigdy nie trafia do przeglądarki.']);
        $form->addElement('textarea', 'c2paCertificate', ['label' => 'Certyfikat C2PA PEM', 'value' => '', 'rows' => 5, 'description' => Modules_KitsunepaintManager_Config::hasSecret('c2paCertificate') ? 'Zaszyfrowany. Puste pole zachowa wartość.' : 'Opcjonalny certyfikat podpisujący Content Credentials.']);
        $form->addElement('textarea', 'c2paPrivateKey', ['label' => 'Klucz prywatny C2PA PEM', 'value' => '', 'rows' => 5, 'description' => Modules_KitsunepaintManager_Config::hasSecret('c2paPrivateKey') ? 'Zaszyfrowany. Puste pole zachowa wartość.' : 'Klucz pozostaje po stronie serwera.']);

        $this->section($form, 'integrationSection', 'Integracje i operacje SaaS', 'Konektory, dashboard administracyjny, audit i billing są konfigurowane centralnie. Puste pole sekretu zachowuje zapisaną wartość.');
        $form->addElement('textarea', 'connectorsJson', ['label' => 'Konektory zewnętrzne · JSON', 'value' => '', 'rows' => 8, 'description' => Modules_KitsunepaintManager_Config::hasSecret('connectorsJson') ? 'Cała konfiguracja i tokeny są zaszyfrowane. Puste pole zachowa wartość.' : 'Opcjonalna mapa do 50 konektorów; tokeny pozostają wyłącznie na serwerze.']);
        $form->addElement('textarea', 'adminEmails', ['label' => 'Administratorzy aplikacji · e-maile', 'value' => $values['adminEmails'], 'rows' => 4, 'description' => 'Jeden adres w wierszu albo lista rozdzielona przecinkami. Zweryfikowane konto z tej listy zobaczy Panel administratora. Wymaga włączonej weryfikacji e-mail; maksymalnie 100 adresów.']);
        $form->addElement('password', 'adminKey', ['label' => 'Klucz dashboardu operacyjnego', 'value' => '', 'description' => Modules_KitsunepaintManager_Config::hasSecret('adminKey') ? 'Zaszyfrowany. Puste pole zachowa wartość.' : 'Opcjonalny; przy pierwszym deployu powstanie losowy klucz.']);
        $form->addElement('password', 'auditKey', ['label' => 'Niezależny klucz audit logu', 'value' => '', 'description' => Modules_KitsunepaintManager_Config::hasSecret('auditKey') ? 'Zaszyfrowany. Puste pole zachowa wartość.' : 'Oddzielny sekret HMAC; przy pierwszym deployu powstanie losowy klucz.']);
        $form->addElement('password', 'stripeSecretKey', ['label' => 'Stripe secret key', 'value' => '', 'description' => Modules_KitsunepaintManager_Config::hasSecret('stripeSecretKey') ? 'Zaszyfrowany. Puste pole zachowa wartość.' : 'Opcjonalny klucz serwerowy Stripe.']);
        $form->addElement('password', 'stripeWebhookSecret', ['label' => 'Stripe webhook secret', 'value' => '', 'description' => Modules_KitsunepaintManager_Config::hasSecret('stripeWebhookSecret') ? 'Zaszyfrowany. Puste pole zachowa wartość.' : 'Sekret podpisu endpointu webhook.']);
        $this->text($form, 'stripePriceId', 'Stripe Price ID', $values['stripePriceId'], false, 'Cena subskrypcji, np. price_...');
        foreach ([
            'renderDailyJobs' => ['Free · rendery / 24 h', 1, 10000],
            'renderDailyMinutes' => ['Free · minuty renderu / 24 h', 1, 100000],
            'renderDailyOutputMb' => ['Free · wynik renderu (MB) / 24 h', 1, 102400],
            'proRenderDailyJobs' => ['Pro · rendery / 24 h', 1, 100000],
            'proRenderDailyMinutes' => ['Pro · minuty renderu / 24 h', 1, 1000000],
            'proRenderDailyOutputMb' => ['Pro · wynik renderu (MB) / 24 h', 1, 1048576],
        ] as $name => $meta) {
            $form->addElement('text', $name, ['label' => $meta[0], 'value' => $values[$name], 'validators' => [['Digits', true], ['Between', true, ['min' => $meta[1], 'max' => $meta[2]]]]]);
        }
        $form->addElement('password', 'offlineLicenseKey', ['label' => 'Klucz licencji offline', 'value' => '', 'description' => Modules_KitsunepaintManager_Config::hasSecret('offlineLicenseKey') ? 'Zaszyfrowany. Puste pole zachowa wartość.' : 'Niezależny klucz podpisu licencji self-hosted.']);
        $form->addElement('textarea', 'enterpriseIdentityJson', ['label' => 'OIDC / SAML / SCIM · JSON', 'value' => '', 'rows' => 8, 'description' => Modules_KitsunepaintManager_Config::hasSecret('enterpriseIdentityJson') ? 'Konfiguracja providerów jest zaszyfrowana. Puste pole zachowa wartość.' : 'Sekrety klientów i tokeny SCIM pozostają po stronie serwera.']);
        $form->addElement('textarea', 'whiteLabelJson', ['label' => 'White-label · JSON', 'value' => $values['whiteLabelJson'], 'rows' => 4, 'description' => 'Nazwa, logoUrl, accent i supportUrl agencji.']);
        $this->text($form, 'costStorageGbMonth', 'Koszt storage / GB-miesiąc', $values['costStorageGbMonth'], true, 'Jawna stawka informacyjna cost explorera.');
        $this->text($form, 'costRenderMinute', 'Koszt renderu / minuta', $values['costRenderMinute'], true, 'Jawna stawka informacyjna cost explorera.');
        $this->text($form, 'costCurrency', 'Waluta kosztów', $values['costCurrency'], true, 'Kod ISO 4217, np. EUR.');
        $this->text($form, 'costAlertWebhookUrl', 'Webhook alertu kosztowego', $values['costAlertWebhookUrl'], false, 'Opcjonalny publiczny URL HTTPS. Alert nie zawiera e-maila ani surowego ID konta.');
        $form->addElement('password', 'costAlertWebhookSecret', ['label' => 'Sekret podpisu alertu', 'value' => '', 'description' => Modules_KitsunepaintManager_Config::hasSecret('costAlertWebhookSecret') ? 'Zaszyfrowany. Puste pole zachowa wartość.' : 'Co najmniej 16 znaków; wymagany po podaniu URL.']);
        $this->text($form, 'costAlertAmount', 'Próg alertu kosztowego', $values['costAlertAmount'], true, '0 wyłącza alert. Kwota używa waluty estymacji.');
        $form->addElement('text', 'costAlertCooldownHours', ['label' => 'Cooldown alertu (godz.)', 'value' => $values['costAlertCooldownHours'], 'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 720]]]]);
        $form->addElement('text', 'backupIntervalMinutes', ['label' => 'Backup co (min.)', 'value' => $values['backupIntervalMinutes'], 'validators' => [['Digits', true], ['Between', true, ['min' => 0, 'max' => 10080]]], 'description' => 'Scheduler store plikowego; dla PostgreSQL/S3 ustawia ten sam cel dla harmonogramu infrastruktury.']);
        $form->addElement('text', 'rpoTargetMinutes', ['label' => 'Cel RPO (min.)', 'value' => $values['rpoTargetMinutes'], 'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 10080]]]]);
        $form->addElement('text', 'rtoTargetMinutes', ['label' => 'Cel RTO (min.)', 'value' => $values['rtoTargetMinutes'], 'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 10080]]]]);
        $form->addElement('text', 'restoreDrillIntervalHours', ['label' => 'Restore drill co (godz.)', 'value' => $values['restoreDrillIntervalHours'], 'validators' => [['Digits', true], ['Between', true, ['min' => 0, 'max' => 8760]]], 'description' => '0 wyłącza scheduler store plikowego; PostgreSQL wymaga drill infrastruktury.']);

        $this->section($form, 'gitAuthenticationSection', 'Uwierzytelnianie Git', 'Dla repozytorium publicznego pozostaw pola sekretów puste. Dla prywatnego użyj tokenu HTTPS albo klucza SSH read-only.');
        $this->text($form, 'gitUsername', 'Użytkownik Git HTTPS', $values['gitUsername'], false, 'Dla tokenu GitHub zwykle x-access-token.');
        $form->addElement('password', 'gitToken', ['label' => 'Token Git', 'value' => '', 'description' => Modules_KitsunepaintManager_Config::hasSecret('gitToken') ? 'Zaszyfrowany. Puste pole zachowa wartość.' : 'Opcjonalny dla prywatnego HTTPS.']);
        $form->addElement('textarea', 'gitSshPrivateKey', ['label' => 'Klucz SSH deploy', 'value' => '', 'rows' => 6, 'description' => Modules_KitsunepaintManager_Config::hasSecret('gitSshPrivateKey') ? 'Zaszyfrowany. Puste pole zachowa wartość.' : 'Opcjonalny klucz tylko do odczytu, bez hasła.']);
        $form->addElement('textarea', 'gitSshKnownHosts', ['label' => 'SSH known_hosts', 'value' => $values['gitSshKnownHosts'], 'rows' => 4, 'description' => 'Zweryfikowane klucze hostów dla połączeń SSH.']);
        $this->actionButton($form, 'configAction', 'Zapisz konfigurację', 'save', 'kpp-config-submit');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function operationForm()
    {
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kpp-operation-form');
        $form->addElement('hidden', 'formType', ['value' => 'operation']);
        $form->addElement('select', 'operation', [
            'label' => 'Co chcesz zrobić?',
            'multiOptions' => [
                'check' => 'Sprawdź repozytorium i dostępne zmiany',
                'sync' => 'Zaktualizuj tylko lokalną kopię kodu',
                'deploy' => 'Wdróż obecną lokalną wersję produktu',
                'sync-deploy' => 'Pobierz najnowszy kod i wdróż produkt',
            ],
            'description' => 'Sprawdzenie i synchronizacja nie zmieniają kontenerów. Wdrożenie uruchamia build, readiness i konfigurację proxy.',
        ]);
        $this->actionButton($form, 'operationAction', 'Uruchom operację', 'run', 'kpp-operation-submit');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function pluginUpdateForm()
    {
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kpp-plugin-update-form');
        $form->addElement('hidden', 'formType', ['value' => 'plugin-update']);
        $form->addElement('hidden', 'pluginOperation', ['value' => 'plugin-update']);
        $this->actionButton($form, 'pluginUpdateAction', 'Zaktualizuj rozszerzenie z repozytorium', 'update', 'kpp-plugin-update-submit');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function maintenanceForm()
    {
        $state = Modules_KitsunepaintManager_Config::readState();
        $backupOptions = ['' => '— wybierz backup —'];
        foreach ((array) ($state['backups'] ?? []) as $backup) {
            $name = is_array($backup) ? (string) ($backup['name'] ?? '') : (string) $backup;
            if (preg_match('/^KitsunePaint-data-\d{8}-\d{6}\.tar\.gz$/', $name)) $backupOptions[$name] = $name;
        }
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kpp-maintenance-form');
        $form->addElement('hidden', 'formType', ['value' => 'maintenance']);
        $form->addElement('select', 'maintenanceOperation', [
            'label' => 'Operacja na danych',
            'multiOptions' => [
                'backup' => 'Utwórz spójny backup danych',
                'restore-drill' => 'Zweryfikuj i testowo odtwórz najnowszy backup',
                'restore' => 'Przywróć wskazany backup na produkcji',
            ],
            'description' => 'Backup zatrzymuje zapis na czas archiwizacji. Restore drill nie zmienia produkcji. Właściwy restore zachowuje poprzedni katalog danych do ręcznego usunięcia po weryfikacji.',
        ]);
        $form->addElement('select', 'backupName', [
            'label' => 'Backup do przywrócenia',
            'multiOptions' => $backupOptions,
            'description' => 'Używane tylko przez właściwy restore. Lista zawiera wyłącznie archiwa utworzone przez Kitsune Creative Suite Manager.',
        ]);
        $form->addElement('text', 'confirmation', [
            'label' => 'Potwierdzenie restore',
            'description' => 'Dla właściwego restore wpisz dokładnie RESTORE:nazwa-archiwum.tar.gz. Backup i restore drill nie wymagają potwierdzenia.',
        ]);
        $this->actionButton($form, 'maintenanceAction', 'Uruchom operację danych', 'backup', 'kpp-maintenance-submit');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function serviceForm()
    {
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kpp-service-form');
        $form->addElement('hidden', 'formType', ['value' => 'service']);
        $form->addElement('select', 'serviceOperation', [
            'label' => 'Sterowanie stackiem',
            'multiOptions' => [
                'start' => 'Uruchom istniejące kontenery',
                'restart' => 'Zrestartuj stack i sprawdź readiness',
                'stop' => 'Zatrzymaj stack bez usuwania danych',
            ],
            'description' => 'Operacje nie wykonują docker compose down ani nie usuwają wolumenów lub katalogów danych.',
        ]);
        $this->actionButton($form, 'serviceAction', 'Wykonaj na stacku', 'service', 'kpp-service-submit');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function saveConfig(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) {
            $this->_status->addMessage('error', $this->validationSummary($form, 'konfiguracji'));
            return false;
        }
        $values = $form->getValues();
        try {
            $this->validateConfig($values);
            Modules_KitsunepaintManager_Config::save($values);
            $this->_status->addMessage('info', 'Konfiguracja została zapisana.');
            return true;
        } catch (Throwable $exception) {
            $this->_status->addMessage('error', 'Nie zapisano konfiguracji: ' . $exception->getMessage());
            return false;
        }
    }

    private function startOperation(pm_Form_Simple $form, array $post, array $allowed, $field = 'operation')
    {
        if (!$form->isValid($post)) {
            $this->_status->addMessage('error', $this->validationSummary($form, 'operacji'));
            return false;
        }
        $operation = (string) $form->getValue($field);
        if (!in_array($operation, $allowed, true)) {
            $this->_status->addMessage('error', 'Wybierz prawidłową operację.');
            return false;
        }
        try {
            $values = Modules_KitsunepaintManager_Config::values();
            $this->validateConfig($values);
            $runtime = Modules_KitsunepaintManager_Config::createRuntimeConfig($operation);
            $task = new Modules_KitsunepaintManager_Task_Operate();
            $task->setParam('runtimeConfig', $runtime);
            (new pm_LongTask_Manager())->start($task);
            $this->_status->addMessage('info', 'Operacja została dodana do kolejki zadań Pleska.');
            return true;
        } catch (Throwable $exception) {
            $this->_status->addMessage('error', 'Nie uruchomiono operacji: ' . $exception->getMessage());
            return false;
        }
    }

    private function startMaintenance(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) {
            $this->_status->addMessage('error', $this->validationSummary($form, 'operacji na danych'));
            return false;
        }
        $operation = (string) $form->getValue('maintenanceOperation');
        if (!in_array($operation, ['backup', 'restore-drill', 'restore'], true)) {
            $this->_status->addMessage('error', 'Wybierz prawidłową operację na danych.');
            return false;
        }
        $backupName = trim((string) $form->getValue('backupName'));
        $confirmation = trim((string) $form->getValue('confirmation'));
        if ($operation === 'restore') {
            if (!preg_match('/^KitsunePaint-data-\d{8}-\d{6}\.tar\.gz$/', $backupName)) {
                $this->_status->addMessage('error', 'Wybierz backup utworzony przez Kitsune Creative Suite Manager.');
                return false;
            }
            $expected = 'RESTORE:' . $backupName;
            if (!hash_equals($expected, $confirmation)) {
                $this->_status->addMessage('error', 'Potwierdzenie restore musi mieć dokładną wartość ' . $expected . '.');
                return false;
            }
        }
        try {
            $values = Modules_KitsunepaintManager_Config::values();
            $this->validateConfig($values);
            $runtime = Modules_KitsunepaintManager_Config::createRuntimeConfig($operation, [
                'backupName' => $backupName,
                'confirmation' => $confirmation,
            ]);
            $task = new Modules_KitsunepaintManager_Task_Operate();
            $task->setParam('runtimeConfig', $runtime);
            (new pm_LongTask_Manager())->start($task);
            $this->_status->addMessage('info', 'Operacja danych została dodana do kolejki zadań Pleska.');
            return true;
        } catch (Throwable $exception) {
            $this->_status->addMessage('error', 'Nie uruchomiono operacji danych: ' . $exception->getMessage());
            return false;
        }
    }

    private function validateConfig(array $values)
    {
        if (!preg_match('#^(https://|ssh://|git@)#', (string) ($values['repositoryUrl'] ?? ''))) throw new RuntimeException('Podaj adres repozytorium HTTPS lub SSH.');
        if (!preg_match('/^(?![-.])(?!.*\.\.)(?!.*@\{)[A-Za-z0-9._\/-]+$/', (string) ($values['repositoryBranch'] ?? ''))) throw new RuntimeException('Nieprawidłowa nazwa gałęzi.');
        foreach (['repositoryPath', 'dataPath', 'backupPath'] as $field) {
            $path = rtrim((string) ($values[$field] ?? ''), '/');
            if (!preg_match('#^/(opt|srv|home|var/lib|var/backups)/[A-Za-z0-9._/-]+$#', $path) || in_array('..', explode('/', $path), true)) throw new RuntimeException('Nieprawidłowa bezwzględna ścieżka: ' . $field . '.');
        }
        $repository = rtrim((string) $values['repositoryPath'], '/');
        foreach (['dataPath', 'backupPath'] as $field) {
            $candidate = rtrim((string) $values[$field], '/');
            if ($candidate === $repository || strpos($candidate . '/', $repository . '/') === 0 || strpos($repository . '/', $candidate . '/') === 0) throw new RuntimeException('Kod, dane i backupy muszą mieć rozłączne ścieżki.');
        }
        $data = rtrim((string) $values['dataPath'], '/');
        $backups = rtrim((string) $values['backupPath'], '/');
        if ($data === $backups || strpos($data . '/', $backups . '/') === 0 || strpos($backups . '/', $data . '/') === 0) throw new RuntimeException('Katalog danych i backupów muszą być rozłączne.');
        $domain = strtolower((string) ($values['domain'] ?? ''));
        if (!preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/', $domain)) throw new RuntimeException('Nieprawidłowa domena Pleska.');
        $aiBaseUrl = trim((string) ($values['aiBaseUrl'] ?? ''));
        if ($aiBaseUrl !== '' && !preg_match('#^https://[^\s]+$#', $aiBaseUrl)) throw new RuntimeException('Brama AI musi używać HTTPS.');
        if (!in_array((string) ($values['aiApiMode'] ?? ''), ['responses', 'chat-completions'], true)) throw new RuntimeException('Nieprawidłowy tryb API AI.');
        if (!in_array((string) ($values['mailMode'] ?? ''), ['smtp', 'development', 'disabled'], true)) throw new RuntimeException('Nieprawidłowy tryb poczty.');
        foreach (['registrationEnabled', 'requireEmailVerification', 'smtpSecure'] as $booleanField) if (!in_array((string) ($values[$booleanField] ?? ''), ['true', 'false'], true)) throw new RuntimeException('Nieprawidłowa wartość logiczna: ' . $booleanField . '.');
        if ((string) $values['requireEmailVerification'] === 'true' && (string) $values['mailMode'] === 'disabled') throw new RuntimeException('Weryfikacja e-mail wymaga trybu SMTP albo development.');
        if ((string) $values['mailMode'] === 'smtp' && trim((string) ($values['smtpHost'] ?? '')) === '') throw new RuntimeException('Tryb SMTP wymaga hosta.');
        foreach (['mailFrom', 'smtpHost', 'smtpUser'] as $mailField) if (preg_match('/[\r\n\0]/', (string) ($values[$mailField] ?? ''))) throw new RuntimeException('Pole poczty zawiera niedozwolony znak nowej linii.');
        $connectorsJson = trim((string) ($values['connectorsJson'] ?? ''));
        if ($connectorsJson !== '') {
            $connectors = json_decode($connectorsJson, true);
            if (!is_array($connectors) || $this->isListArray($connectors) || count($connectors) > 50 || json_last_error() !== JSON_ERROR_NONE) throw new RuntimeException('Konektory muszą być mapą JSON zawierającą maksymalnie 50 wpisów.');
        }
        $adminEmails = preg_split('/[\s,;]+/', strtolower(trim((string) ($values['adminEmails'] ?? ''))), -1, PREG_SPLIT_NO_EMPTY);
        if (count($adminEmails) > 100) throw new RuntimeException('Można wskazać maksymalnie 100 administratorów aplikacji.');
        foreach ($adminEmails as $email) if (strlen($email) > 254 || !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Nieprawidłowy adres administratora: ' . $email . '.');
        if ($adminEmails && (string) $values['requireEmailVerification'] !== 'true') throw new RuntimeException('Konta administratorów wymagają włączonej weryfikacji e-mail.');
        foreach (['enterpriseIdentityJson', 'whiteLabelJson'] as $jsonField) {
            $jsonValue = trim((string) ($values[$jsonField] ?? ''));
            if ($jsonValue !== '' && (!is_array(json_decode($jsonValue, true)) || json_last_error() !== JSON_ERROR_NONE)) throw new RuntimeException($jsonField . ' musi być prawidłowym obiektem JSON.');
        }
        if (!preg_match('/^[A-Z]{3}$/', (string) ($values['costCurrency'] ?? ''))) throw new RuntimeException('Waluta kosztów musi być kodem ISO 4217.');
        foreach (['costStorageGbMonth', 'costRenderMinute', 'costAlertAmount'] as $numberField) if (!is_numeric($values[$numberField] ?? null) || (float) $values[$numberField] < 0) throw new RuntimeException('Nieprawidłowa stawka kosztowa.');
        $alertUrl = trim((string) ($values['costAlertWebhookUrl'] ?? ''));
        if ($alertUrl !== '' && !preg_match('#^https://[^\s/@]+(?:/[^\s]*)?$#', $alertUrl)) throw new RuntimeException('Webhook alertu kosztowego musi używać publicznego URL HTTPS bez danych logowania.');
        if ($alertUrl !== '' && trim((string) ($values['costAlertWebhookSecret'] ?? '')) === '' && !Modules_KitsunepaintManager_Config::hasSecret('costAlertWebhookSecret')) throw new RuntimeException('Webhook alertu kosztowego wymaga sekretu podpisu.');
    }

    private function refreshStatus()
    {
        $runtime = null;
        try {
            $runtime = Modules_KitsunepaintManager_Config::createRuntimeConfig('status');
            $result = pm_ApiCli::callSbin('kitsunepaint-manager', ['--config', $runtime], pm_ApiCli::RESULT_FULL);
            if ((int) ($result['code'] ?? 1) !== 0) {
                $detail = trim((string) ($result['stderr'] ?? $result['stdout'] ?? ''));
                return $detail !== '' ? mb_substr($detail, -2000) : 'Narzędzie statusu zakończyło się błędem.';
            }
            return null;
        } catch (Throwable $exception) {
            return mb_substr($exception->getMessage(), -2000);
        } finally {
            if ($runtime && is_file($runtime)) @unlink($runtime);
        }
    }

    private function respondWithRedirect($tab = 'status')
    {
        $allowed = ['status', 'deploy', 'config', 'data', 'log'];
        if (!in_array($tab, $allowed, true)) $tab = 'status';
        $url = pm_Context::getActionUrl('index', 'index');
        $url .= (strpos($url, '?') === false ? '?' : '&') . 'tab=' . rawurlencode($tab);
        $this->_helper->json(['redirect' => $url]);
    }

    private function clearSensitiveFormValues(pm_Form_Simple $form)
    {
        foreach ([
            'gitToken',
            'gitSshPrivateKey',
            'aiApiKey',
            'smtpPassword',
            'c2paCertificate',
            'c2paPrivateKey',
            'connectorsJson',
            'adminKey',
            'auditKey',
            'stripeSecretKey',
            'stripeWebhookSecret',
            'offlineLicenseKey',
            'costAlertWebhookSecret',
            'enterpriseIdentityJson',
        ] as $field) {
            $element = $form->getElement($field);
            if ($element) $element->setValue('');
        }
    }

    private function isListArray(array $value)
    {
        return array_values($value) === $value;
    }

    private function domainOptions($savedDomain = '')
    {
        $options = [];
        try {
            foreach ((array) pm_Domain::getAllDomains() as $domain) {
                if (!$domain instanceof pm_Domain || !$domain->hasHosting() || !$domain->isActive() || $domain->isSuspended() || $domain->isDisabled()) continue;
                $name = strtolower(trim((string) $domain->getName()));
                if (preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/', $name)) $options[$name] = $name;
            }
        } catch (Throwable $exception) {
            // Formularz pozostaje dostępny; wdrożenie ponownie zweryfikuje domenę.
        }
        natcasesort($options);
        $savedDomain = strtolower(trim((string) $savedDomain));
        if ($savedDomain !== '' && !isset($options[$savedDomain])) $options[$savedDomain] = $savedDomain . ' (zapisana konfiguracja)';
        return $options;
    }

    private function validationSummary(pm_Form_Simple $form, $context)
    {
        $details = [];
        foreach ((array) $form->getMessages() as $field => $messages) {
            if (!$messages) continue;
            $element = $form->getElement($field);
            $label = $element ? trim(strip_tags((string) $element->getLabel())) : (string) $field;
            $details[] = $label;
        }
        if (!$details) $details[] = 'wartości oznaczone bezpośrednio przy polach';
        return 'Nie zapisano ' . $context . '. Popraw: ' . implode(', ', array_unique($details)) . '.';
    }

    private function actionButton(pm_Form_Simple $form, $name, $label, $kind, $id = '')
    {
        $safeLabel = htmlspecialchars($label, ENT_QUOTES, 'UTF-8');
        $safeKind = htmlspecialchars($kind, ENT_QUOTES, 'UTF-8');
        $safeId = $id !== '' ? ' id="' . htmlspecialchars($id, ENT_QUOTES, 'UTF-8') . '"' : '';
        $form->addElement('simpleText', $name, [
            'label' => '',
            'escape' => false,
            'value' => '<div class="kpp-action-row"><button type="submit" class="kpp-primary-action" data-kpp-action="' . $safeKind . '"' . $safeId . '>' . $safeLabel . '</button></div>',
        ]);
    }

    private function section(pm_Form_Simple $form, $name, $title, $description)
    {
        $form->addElement('simpleText', $name, [
            'label' => '',
            'escape' => false,
            'value' => '<div class="kpp-form-section"><strong>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</strong><span>' . htmlspecialchars($description, ENT_QUOTES, 'UTF-8') . '</span></div>',
        ]);
    }

    private function text(pm_Form_Simple $form, $name, $label, $value, $required, $description)
    {
        $form->addElement('text', $name, [
            'label' => $label,
            'value' => $value,
            'required' => $required,
            'description' => $description,
            'validators' => [['StringLength', true, ['min' => $required ? 1 : 0, 'max' => 4800]]],
        ]);
    }
}
