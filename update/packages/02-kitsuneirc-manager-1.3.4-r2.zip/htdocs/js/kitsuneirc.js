(function () {
  'use strict';

  function copyText(value, button) {
    var completed = function () {
      var previous = button.textContent;
      button.textContent = 'Skopiowano';
      window.setTimeout(function () { button.textContent = previous; }, 1500);
    };
    var fallback = function () {
      var area = document.createElement('textarea');
      area.value = value;
      area.setAttribute('readonly', 'readonly');
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();
      var copied = document.execCommand('copy');
      document.body.removeChild(area);
      if (copied) completed();
    };
    if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
      navigator.clipboard.writeText(value).then(completed).catch(fallback);
    } else fallback();
  }

  function initializeTabs(shell) {
    var tabs = Array.prototype.slice.call(shell.querySelectorAll('[data-kitsuneirc-tab]'));
    var panels = Array.prototype.slice.call(shell.querySelectorAll('[data-kitsuneirc-panel]'));
    if (!tabs.length || !panels.length) return;
    var tabUrl = function (name) {
      var url = new URL(window.location.href);
      url.searchParams.set('tab', name);
      url.searchParams.delete('refresh');
      return url.toString();
    };
    var activate = function (name, remember, focus) {
      var selected = tabs.some(function (tab) { return tab.getAttribute('data-kitsuneirc-tab') === name; }) ? name : 'status';
      tabs.forEach(function (tab) {
        var active = tab.getAttribute('data-kitsuneirc-tab') === selected;
        tab.classList.toggle('is-active', active);
        tab.setAttribute('aria-selected', active ? 'true' : 'false');
        tab.setAttribute('tabindex', active ? '0' : '-1');
        if (active && focus) tab.focus();
      });
      panels.forEach(function (panel) {
        var active = panel.getAttribute('data-kitsuneirc-panel') === selected;
        panel.classList.toggle('is-active', active);
        panel.hidden = !active;
        panel.setAttribute('aria-hidden', active ? 'false' : 'true');
      });
      if (remember) {
        try { window.sessionStorage.setItem('kitsuneirc-manager-tab', selected); } catch (_) {}
        try { window.history.replaceState(null, '', tabUrl(selected)); } catch (_) {}
      }
    };
    tabs.forEach(function (tab, index) {
      tab.addEventListener('click', function (event) {
        event.preventDefault();
        activate(tab.getAttribute('data-kitsuneirc-tab'), true, false);
      });
      tab.addEventListener('keydown', function (event) {
        if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].indexOf(event.key) === -1) return;
        event.preventDefault();
        var next = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1
          : (index + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
        activate(tabs[next].getAttribute('data-kitsuneirc-tab'), true, true);
      });
    });
    var initial = shell.getAttribute('data-kitsuneirc-active-tab') || '';
    if (!initial) {
      try { initial = window.sessionStorage.getItem('kitsuneirc-manager-tab') || ''; } catch (_) {}
    }
    activate(initial || 'status', false, false);
    return { activate: activate, url: tabUrl };
  }

  function initializeForms(shell) {
    Array.prototype.forEach.call(shell.querySelectorAll('form'), function (form) {
      form.addEventListener('submit', function (event) {
        if (form.id === 'kitsuneirc-config-form') {
          var adminDomain = form.querySelector('[name="adminDomain"]');
          var webDomain = form.querySelector('[name="webDomain"]');
          var errorBox = shell.querySelector('[data-kitsuneirc-config-error]');
          var message = '';
          if (!adminDomain || !adminDomain.value || !webDomain || !webDomain.value) {
            message = 'Wybierz domenę panelu administracyjnego i osobną domenę klienta WWW.';
          } else if (adminDomain.value.toLowerCase() === webDomain.value.toLowerCase()) {
            message = 'Panel administracyjny i klient WWW muszą używać dwóch różnych domen.';
          }
          if (message) {
            event.preventDefault();
            if (errorBox) {
              errorBox.textContent = message;
              errorBox.hidden = false;
            }
            if (adminDomain && !adminDomain.value) adminDomain.focus();
            else if (webDomain) webDomain.focus();
            return;
          }
          if (errorBox) errorBox.hidden = true;
        }
        var button = event.submitter || form.querySelector('input[type="submit"], button[type="submit"]');
        if (!button || form.getAttribute('data-kitsuneirc-submitting') === 'true') {
          if (form.getAttribute('data-kitsuneirc-submitting') === 'true') event.preventDefault();
          return;
        }
        form.setAttribute('data-kitsuneirc-submitting', 'true');
        window.setTimeout(function () {
          button.disabled = true;
          if (button.tagName.toLowerCase() === 'button') button.textContent = 'Uruchamianie…';
        }, 0);
      });
    });
  }

  function initializeOperation(shell) {
    var operation = shell.querySelector('#kitsuneirc-operation-form [name="operation"]');
    if (!operation) return;
    var sync = function () {
      var deploy = operation.value === 'deploy' || operation.value === 'sync-deploy';
      ['moduleServer', 'moduleWeb'].forEach(function (name) {
        var field = shell.querySelector('#kitsuneirc-operation-form [name="' + name + '"]');
        if (field) field.disabled = !deploy;
      });
    };
    operation.addEventListener('change', sync);
    sync();
  }

  function initializeMaintenance(shell) {
    var operation = shell.querySelector('#kitsuneirc-maintenance-form [name="maintenanceOperation"]');
    var nameField = shell.querySelector('#kitsuneirc-maintenance-form [name="backupName"]');
    var confirmation = shell.querySelector('#kitsuneirc-maintenance-form [name="confirmation"]');
    var sync = function () {
      if (!operation) return;
      var restore = operation.value === 'restore';
      if (confirmation) confirmation.disabled = !restore;
    };
    if (operation) operation.addEventListener('change', sync);
    Array.prototype.forEach.call(shell.querySelectorAll('[data-kitsuneirc-backup]'), function (button) {
      button.addEventListener('click', function () {
        var name = button.getAttribute('data-kitsuneirc-backup') || '';
        if (operation) operation.value = 'restore';
        if (nameField) nameField.value = name;
        if (confirmation) confirmation.value = 'RESTORE:' + name;
        sync();
      });
    });
    sync();
  }

  function proxyText(domain, port, name) {
    return '# Plik: /var/www/vhosts/system/' + domain + '/conf/vhost_nginx.conf\n'
      + '# BEGIN KITSUNEIRC MANUAL ' + name + ' REVERSE PROXY\n'
      + 'location ~ ^/.* {\n'
      + '    proxy_pass http://127.0.0.1:' + port + ';\n'
      + '    proxy_http_version 1.1;\n'
      + '    proxy_set_header Host $host;\n'
      + '    proxy_set_header X-Real-IP $remote_addr;\n'
      + '    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;\n'
      + '    proxy_set_header X-Forwarded-Proto $scheme;\n'
      + '    proxy_set_header Upgrade $http_upgrade;\n'
      + '    proxy_set_header Connection "upgrade";\n'
      + '    proxy_read_timeout 3600s;\n'
      + '    proxy_send_timeout 3600s;\n'
      + '    proxy_buffering off;\n'
      + '}\n'
      + '# END KITSUNEIRC MANUAL ' + name + ' REVERSE PROXY';
  }

  function initializeProxyPreview(shell) {
    var fields = {
      proxyMode: shell.querySelector('[name="proxyMode"]'),
      adminDomain: shell.querySelector('[name="adminDomain"]'),
      adminPort: shell.querySelector('[name="adminPort"]'),
      webDomain: shell.querySelector('[name="webDomain"]'),
      webPort: shell.querySelector('[name="webPort"]')
    };
    var update = function () {
      var card = shell.querySelector('[data-kitsuneirc-manual-proxy]');
      var admin = shell.querySelector('[data-kitsuneirc-code="admin-proxy"]');
      var web = shell.querySelector('[data-kitsuneirc-code="web-proxy"]');
      var adminPath = shell.querySelector('[data-kitsuneirc-vhost-path="admin"]');
      var webPath = shell.querySelector('[data-kitsuneirc-vhost-path="web"]');
      var adminCommand = shell.querySelector('[data-kitsuneirc-vhost-command="admin"]');
      var webCommand = shell.querySelector('[data-kitsuneirc-vhost-command="web"]');
      if (card && fields.proxyMode) card.hidden = fields.proxyMode.value !== 'manual';
      if (admin && fields.adminDomain && fields.adminPort) admin.textContent = proxyText(fields.adminDomain.value, fields.adminPort.value, 'ADMIN');
      if (web && fields.webDomain && fields.webPort) web.textContent = proxyText(fields.webDomain.value, fields.webPort.value, 'WEB');
      if (adminPath && fields.adminDomain) adminPath.textContent = '/var/www/vhosts/system/' + fields.adminDomain.value + '/conf/vhost_nginx.conf';
      if (webPath && fields.webDomain) webPath.textContent = '/var/www/vhosts/system/' + fields.webDomain.value + '/conf/vhost_nginx.conf';
      if (adminCommand && fields.adminDomain) adminCommand.textContent = 'plesk sbin httpdmng --reconfigure-domain ' + fields.adminDomain.value;
      if (webCommand && fields.webDomain) webCommand.textContent = 'plesk sbin httpdmng --reconfigure-domain ' + fields.webDomain.value;
    };
    Object.keys(fields).forEach(function (name) {
      if (fields[name]) {
        fields[name].addEventListener('input', update);
        fields[name].addEventListener('change', update);
      }
    });
    update();
  }

  function initializeConditionalFields(shell) {
    var enabled = shell.querySelector('[name="serverPasswordEnabled"]');
    var password = shell.querySelector('[name="serverPassword"]');
    if (!enabled || !password) return;
    var sync = function () {
      var row = typeof password.closest === 'function' ? password.closest('.form-row') : password.parentNode;
      var visible = enabled.value === 'true';
      password.disabled = !visible;
      if (row) {
        row.hidden = !visible;
        row.style.display = visible ? '' : 'none';
      }
    };
    enabled.addEventListener('change', sync);
    sync();
  }

  function initialize() {
    var shell = document.querySelector('.kitsuneirc-shell');
    if (!shell || shell.getAttribute('data-kitsuneirc-initialized') === 'true') return;
    shell.setAttribute('data-kitsuneirc-initialized', 'true');
    var tabController = initializeTabs(shell);
    initializeForms(shell);
    initializeOperation(shell);
    initializeMaintenance(shell);
    initializeProxyPreview(shell);
    initializeConditionalFields(shell);
    var refresh = shell.querySelector('[data-kitsuneirc-refresh]');
    if (refresh) refresh.addEventListener('click', function () {
      refresh.textContent = 'Odświeżanie…';
      refresh.setAttribute('aria-disabled', 'true');
      if (tabController) tabController.activate('status', true, false);
    });
    Array.prototype.forEach.call(shell.querySelectorAll('[data-kitsuneirc-copy]'), function (button) {
      button.addEventListener('click', function () {
        var target = shell.querySelector('[data-kitsuneirc-code="' + button.getAttribute('data-kitsuneirc-copy') + '"]');
        if (target) copyText(target.textContent || '', button);
      });
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize);
  else initialize();
}());
