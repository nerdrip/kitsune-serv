<?php

class Modules_KitsuneircManager_Task_Operate extends pm_LongTask_Task
{
    public $trackProgress = true;

    public function run()
    {
        $runtimeConfig = (string) $this->getParam('runtimeConfig');
        try {
            $this->updateProgress(5);
            $result = pm_ApiCli::callSbin(
                'kitsuneirc-manager',
                ['--config', $runtimeConfig],
                pm_ApiCli::RESULT_FULL
            );
            $stdout = (string) ($result['stdout'] ?? '');
            Modules_KitsuneircManager_Config::importStateFromOutput($stdout);
            $cleanStdout = Modules_KitsuneircManager_Config::stripStateFromOutput($stdout);
            if ((int) ($result['code'] ?? 1) !== 0) {
                $errorOutput = trim((string) ($result['stderr'] ?? ''));
                if ($errorOutput === '') $errorOutput = $cleanStdout !== '' ? $cleanStdout : 'Operation failed.';
                throw new RuntimeException($errorOutput);
            }
            $this->updateProgress(100);
            return $cleanStdout !== '' ? $cleanStdout : 'OK';
        } finally {
            if ($runtimeConfig !== '' && is_file($runtimeConfig)) @unlink($runtimeConfig);
        }
    }
}
