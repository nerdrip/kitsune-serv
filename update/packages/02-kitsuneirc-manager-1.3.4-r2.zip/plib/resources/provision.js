'use strict';

const bcrypt = require('/app/node_modules/bcrypt');
const { ConfigManager } = require('/app/src/config/ConfigManager');
const { Database } = require('/app/src/database/Database');

function value(name) {
  const result = String(process.env[name] || '');
  if (!result) throw new Error(`Missing ${name}`);
  return result;
}
function boolean(name) {
  const result = value(name).toLowerCase();
  if (!['true', 'false'].includes(result)) throw new Error(`${name} must be boolean`);
  return result === 'true';
}
function integer(name, min, max) {
  const result = Number(value(name));
  if (!Number.isInteger(result) || result < min || result > max) throw new Error(`Invalid ${name}`);
  return result;
}
function password(name, min = 12, max = 72) {
  const result = value(name);
  const bytes = Buffer.byteLength(result, 'utf8');
  if (bytes < min || bytes > max) throw new Error(`Invalid ${name} length`);
  return result;
}
function json(name) {
  try { return JSON.parse(Buffer.from(value(name), 'base64').toString('utf8')); }
  catch (_) { throw new Error(`Invalid ${name}`); }
}

function syncOperatorAccount(database, oper) {
  const existing = database.get('SELECT account FROM nicknames WHERE nick = ? COLLATE NOCASE', oper.name);
  if (existing && String(existing.account).toLowerCase() !== oper.name.toLowerCase()) {
    throw new Error(`Nickname ${oper.name} already belongs to a different NickServ account`);
  }
  database.transaction(() => {
    database.run('INSERT OR IGNORE INTO accounts (account, flags) VALUES (?, ?)', oper.name, 'oper');
    database.run(
      `INSERT INTO nicknames (nick, account, password, no_expire)
       VALUES (?, ?, ?, 1)
       ON CONFLICT(nick) DO UPDATE SET
         password = excluded.password,
         no_expire = 1,
         last_seen = datetime('now')`,
      oper.name, oper.name, oper.password
    );
  });
}

async function main() {
  const config = new ConfigManager('/var/lib/kitsuneirc/config/config.js');
  await config.load();
  const assignments = [
    ['server.name', 'KITSUNE_PROVISION_SERVER_NAME', value],
    ['server.network', 'KITSUNE_PROVISION_NETWORK_NAME', value],
    ['server.description', 'KITSUNE_PROVISION_SERVER_DESCRIPTION', value],
    ['server.adminEmail', 'KITSUNE_PROVISION_ADMIN_EMAIL', value],
    ['server.maxClients', 'KITSUNE_PROVISION_MAX_CLIENTS', name => integer(name, 1, 100000)],
    ['server.maxChannelsPerUser', 'KITSUNE_PROVISION_MAX_CHANNELS', name => integer(name, 1, 1000)],
    ['server.defaultModes', 'KITSUNE_PROVISION_DEFAULT_MODES', value],
    ['motd', 'KITSUNE_PROVISION_MOTD', json],
    ['security.requireSASL', 'KITSUNE_PROVISION_REQUIRE_SASL', boolean],
    ['security.enableCloaking', 'KITSUNE_PROVISION_CLOAK_ENABLED', boolean],
    ['security.cloak.enabled', 'KITSUNE_PROVISION_CLOAK_ENABLED', boolean],
    ['security.cloak.prefix', 'KITSUNE_PROVISION_CLOAK_PREFIX', value],
    ['security.dnsbl.enabled', 'KITSUNE_PROVISION_DNSBL_ENABLED', boolean],
    ['security.dnsbl.servers', 'KITSUNE_PROVISION_DNSBL_SERVERS', json],
    ['security.floodProtection.enabled', 'KITSUNE_PROVISION_FLOOD_ENABLED', boolean],
    ['security.floodProtection.maxPerInterval', 'KITSUNE_PROVISION_FLOOD_MAX', name => integer(name, 1, 100000)],
    ['security.floodProtection.intervalMs', 'KITSUNE_PROVISION_FLOOD_INTERVAL_MS', name => integer(name, 100, 86400000)],
    ['security.floodProtection.maxConnPerIP', 'KITSUNE_PROVISION_MAX_CONN_PER_IP', name => integer(name, 1, 100000)],
    ['security.throttle.enabled', 'KITSUNE_PROVISION_THROTTLE_ENABLED', boolean],
    ['security.throttle.connectionsPerPeriod', 'KITSUNE_PROVISION_THROTTLE_CONNECTIONS', name => integer(name, 1, 100000)],
    ['security.throttle.periodMs', 'KITSUNE_PROVISION_THROTTLE_PERIOD_MS', name => integer(name, 100, 86400000)],
    ['webPanel.sessionTimeout', 'KITSUNE_PROVISION_SESSION_TIMEOUT_MS', name => integer(name, 60000, 2592000000)],
    ['bouncer.maxUsers', 'KITSUNE_PROVISION_BOUNCER_MAX_USERS', name => integer(name, 1, 10000)],
    ['bouncer.maxNetworksPerUser', 'KITSUNE_PROVISION_BOUNCER_MAX_NETWORKS', name => integer(name, 1, 100)],
    ['bouncer.maxClients', 'KITSUNE_PROVISION_BOUNCER_MAX_CLIENTS', name => integer(name, 1, 100000)],
    ['bouncer.maxConnectionsPerIP', 'KITSUNE_PROVISION_BOUNCER_MAX_CONN_PER_IP', name => integer(name, 1, 1000)],
    ['bouncer.maxAuthAttemptsPerWindow', 'KITSUNE_PROVISION_BOUNCER_MAX_AUTH', name => integer(name, 1, 1000)],
    ['bouncer.authWindowMs', 'KITSUNE_PROVISION_BOUNCER_AUTH_WINDOW_MS', name => integer(name, 10000, 3600000)],
    ['bouncer.maxBufferSize', 'KITSUNE_PROVISION_BOUNCER_BUFFER_SIZE', name => integer(name, 0, 100000)],
    ['bouncer.maxBufferLinesPerNetwork', 'KITSUNE_PROVISION_BOUNCER_BUFFER_LINES', name => integer(name, 1, 500000)],
  ];
  for (const [key, name, transform] of assignments) config.set(key, transform(name));
  for (const service of ['nickserv', 'chanserv', 'memoserv', 'operserv', 'botserv', 'hostserv']) {
    config.set(`services.${service}.enabled`, boolean(`KITSUNE_PROVISION_${service.toUpperCase()}_ENABLED`));
  }
  config.set('server.password', boolean('KITSUNE_PROVISION_SERVER_PASSWORD_ENABLED')
    ? password('KITSUNE_PROVISION_SERVER_PASSWORD', 1, 200) : null);
  config.set('webPanel.allowRemoteSetup', false);
  config.set('webPanel.allowSqlConsole', boolean('KITSUNE_PROVISION_SQL_CONSOLE_ENABLED'));
  config.set('webPanel.allowSqlWrite', boolean('KITSUNE_PROVISION_SQL_WRITE_ENABLED'));
  config.set('webPanel.allowPluginEditor', boolean('KITSUNE_PROVISION_PLUGIN_EDITOR_ENABLED'));
  config.set('webPanel.trustProxy', true);
  config.set('webPanel.corsOrigin', `https://${value('KITSUNE_PROVISION_ADMIN_DOMAIN')}`);
  const loggingLevel = String(process.env.KITSUNE_PROVISION_LOGGING_LEVEL || 'info').toLowerCase();
  if (!['error', 'warn', 'info', 'debug'].includes(loggingLevel)) {
    throw new Error('Invalid KITSUNE_PROVISION_LOGGING_LEVEL');
  }
  config.set('logging.level', loggingLevel);

  const operName = value('KITSUNE_PROVISION_OPER_NAME');
  const oper = {
    name: operName,
    password: await bcrypt.hash(password('KITSUNE_PROVISION_OPER_PASSWORD'), 12),
    host: value('KITSUNE_PROVISION_OPER_HOST'),
    flags: value('KITSUNE_PROVISION_OPER_FLAGS'),
    nickserv: boolean('KITSUNE_PROVISION_NICKSERV_ENABLED')
  };
  const opers = config.get('opers', []).filter(item => String(item.name || '').toLowerCase() !== operName.toLowerCase());
  config.set('opers', [oper].concat(opers));
  config.validate(config.getAll());
  config.save();
  if (oper.nickserv) {
    const database = new Database(config);
    await database.initialize();
    try {
      syncOperatorAccount(database, oper);
    } finally {
      await database.close();
    }
  }
  console.log('KitsuneIRC persistent configuration provisioned.');
}

main().catch(error => { console.error(`[provision] ${error.message}`); process.exit(1); });
