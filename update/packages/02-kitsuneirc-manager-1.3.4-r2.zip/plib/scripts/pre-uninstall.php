<?php

pm_Context::init('kitsuneirc-manager');
try { (new pm_LongTask_Manager())->cancelAllTasks(); } catch (Exception $exception) {}
foreach (glob(pm_Context::getVarDir() . '/operation-*.json') ?: [] as $path) @unlink($path);
