<?php

pm_Context::init('kitsunecolab-manager');

$application = new pm_Application();
$application->run();
