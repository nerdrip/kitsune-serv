# KitsuneColab w Kitsune Suite

Puste URL-e Suite oznaczają pełny tryb samodzielny. Aby włączyć integrację,
ustaw bazowe URL-e HTTPS Huba/Testu, ID istniejącej organizacji i właściciela
oraz wspólny, losowy sekret (minimum 32 znaki), a następnie wykonaj deploy.

Colab tworzy projekty powiązane z Hubem i idempotentne bugi dla nieudanych
przebiegów Test. Issue trafia trwałym outboxem do Huba i Testu.

Opcja sterowania z Huba jest niezależna od integracji API, domyślnie wyłączona i
tworzy profil `suite-control-profile.json` z prawami `0600`.

Jeśli plugin nie jest jeszcze zainstalowany, KitsuneHub może zbudować go z
repozytorium Colaba i przekazać konfigurację startową przez jednorazowy
`suite-bootstrap.json` z prawami `0600`. Po imporcie plik jest usuwany. Jeśli
Plesk odtworzy wpis ZIP z trybem wynikającym z własnego `umask`, plugin przed
odczytem weryfikuje prywatny katalog, ścieżkę i właściciela, a następnie
natychmiast przywraca `0700`/`0600`. Jeśli
Plesk pominie lifecycle hook podczas aktualizacji, Hub może uruchomić wyłącznie
ograniczony tryb `--import-suite-bootstrap` managera przez środowisko PHP SDK
Pleska. Osobny
manager Colaba nadal pozwala zarządzać produktem niezależnie. Jawna operacja
„instaluj/aktualizuj z repo” uzgadnia domenę, repozytorium, dostęp Git, wspólny
sekret i zgodę na delegowanie; istniejące sekrety aplikacji pozostają bez zmian.
Bezsekretowy `suite-discovery.json` pozwala Hubowi wykryć plugin, branch,
publiczne API i stan zgody na delegowanie.
