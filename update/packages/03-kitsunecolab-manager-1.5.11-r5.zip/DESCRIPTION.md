# KitsuneColab Deployment Manager

Rozszerzenie administratora Plesk do bezpiecznego zarządzania wdrożeniem KitsuneColab: kontroli wersji, synchronizacji Git, wdrażania z rollbackiem, migracji, stanu kontenerów oraz kompletnych kopii i odtwarzania PostgreSQL + MinIO.
