<?php

pm_Context::init('kitsunecolab-manager');

$configLibrary = dirname(__DIR__) . '/library/Config.php';
if (!class_exists('Modules_KitsunecolabManager_Config', false)) {
    require_once $configLibrary;
}

if (!Modules_KitsunecolabManager_Config::importSuiteBootstrap()) {
    throw new RuntimeException('Nie znaleziono oczekującego bootstrapu KitsuneColab.');
}
Modules_KitsunecolabManager_Config::refreshSuiteDiscovery();
fwrite(STDOUT, "KitsuneColab Suite bootstrap imported.\n");
