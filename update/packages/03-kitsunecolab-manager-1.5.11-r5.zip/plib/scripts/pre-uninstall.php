<?php

pm_Context::init('kitsunecolab-manager');

try {
    $manager = new pm_LongTask_Manager();
    $manager->cancelAllTasks();
} catch (Exception $exception) {
    // Odinstalowanie nie usuwa wdrożenia, wolumenów ani kopii zapasowych.
}

foreach (glob(pm_Context::getVarDir() . '/operation-*.json') ?: [] as $path) {
    @unlink($path);
}

