<?php

pm_Context::init('kitsunecolab-manager');

// Plesk can invoke an extension install from a long task that uses a private
// umask. Keep runtime secrets private, but make the extension's code readable
// and its directories traversable by the panel worker. This also repairs an
// older installation whose plib/htdocs roots were accidentally created 0700.
$productRoot = defined('PRODUCT_ROOT_D') ? PRODUCT_ROOT_D : '/usr/local/psa';
$repairCodeTree = static function ($root, $fileMode) {
    if (!file_exists($root)) return;
    if (is_link($root) || !is_dir($root)) {
        throw new RuntimeException('Unsafe KitsuneColab extension code tree: ' . $root);
    }
    @chmod($root, 0755);
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($iterator as $item) {
        if ($item->isLink()) {
            throw new RuntimeException('KitsuneColab extension code tree contains a symbolic link.');
        }
        @chmod($item->getPathname(), $item->isDir() ? 0755 : $fileMode);
    }
};
$repairCodeTree($productRoot . '/admin/plib/modules/kitsunecolab-manager', 0644);
$repairCodeTree($productRoot . '/admin/htdocs/modules/kitsunecolab-manager', 0644);
$repairCodeTree($productRoot . '/admin/sbin/modules/kitsunecolab-manager', 0750);

$configLibrary = dirname(__DIR__) . '/library/Config.php';
if (!class_exists('Modules_KitsunecolabManager_Config', false)) {
    require_once $configLibrary;
}

$varDir = pm_Context::getVarDir();
if (!is_dir($varDir)) {
    mkdir($varDir, 0700, true);
}
@chmod($varDir, 0700);

$utility = $productRoot . '/admin/sbin/modules/kitsunecolab-manager/kitsunecolab-manager';
if (is_file($utility)) {
    @chmod($utility, 0750);
}

foreach (Modules_KitsunecolabManager_Config::defaults() as $key => $value) {
    if (pm_Settings::get($key) === null) {
        pm_Settings::set($key, (string) $value);
    }
}

Modules_KitsunecolabManager_Config::importSuiteBootstrap();
Modules_KitsunecolabManager_Config::refreshSuiteDiscovery();
