<?php

class Modules_KitsunecolabManager_LongTasks extends pm_Hook_LongTasks
{
    public function getLongTasks()
    {
        return [new Modules_KitsunecolabManager_Task_Deploy()];
    }
}
