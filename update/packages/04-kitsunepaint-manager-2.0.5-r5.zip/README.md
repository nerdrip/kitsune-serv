# Kitsune Creative Suite Deployment Manager dla Pleska

Rozszerzenie wdraża jeden spójny produkt: moduły webowe Kitsune Creative Suite i prywatny serwer kont/projektów. Publiczny HTTPS kończy się w Plesku, a kontener nasłuchuje domyślnie wyłącznie na `127.0.0.1:47841`.

## Wymagania

- Plesk Obsidian 18.0.41+ na Linuxie,
- administrator Pleska i root do instalacji paczki,
- Git, `curl`, `tar`, Docker Engine i Docker Compose v2,
- domena/subdomena z aktywnym hostingiem oraz certyfikatem TLS,
- Node.js nie jest wymagany na serwerze wdrożeniowym — build wykonuje się w Dockerze.
- FFmpeg dla kolejki MP4/WebM jest instalowany wewnątrz obrazu Kitsune Creative Suite; limity kolejki można ustawić zmiennymi `KITSUNE_MOTION_*` w konfiguracji stacku.

## Instalacja

Paczka powstaje w głównym repozytorium:

```bash
npm run plesk:package
```

Instalacja przez SSH:

```bash
plesk bin extension -i /root/Kitsune-Creative-Suite-Plesk-Manager-2.0.5-YYYYMMDD-HHMMSS.zip
```

Aktualizacja rozszerzenia:

```bash
plesk bin extension -g /root/Kitsune-Creative-Suite-Plesk-Manager-2.0.5-YYYYMMDD-HHMMSS.zip
```

Usunięcie panelu (bez kasowania danych, repozytorium i kontenerów):

```bash
plesk bin extension -u kitsunepaint-manager
```

## Pierwsza konfiguracja

1. Wskaż repozytorium i gałąź wdrożeniową.
2. Zachowaj oddzielne ścieżki, np. kod `/opt/kitsunepaint/source`, dane `/opt/kitsunepaint/data`, backupy `/opt/kitsunepaint/backups`.
3. Dla prywatnego HTTPS wklej token. Nie trafia do URL ani argumentów procesu; tymczasowy `GIT_ASKPASS` pobiera go ze środowiska.
4. Dla SSH wklej read-only deploy key bez hasła oraz zweryfikowane `known_hosts`. Klucz istnieje na dysku tylko podczas Git i ma tryb `0600`.
5. W polu „Administratorzy aplikacji · e-maile” wpisz konta, które po zalogowaniu mają widzieć Panel administratora i moderować deklaratywne paczki Marketplace. Lista jest jawna w konfiguracji Pleska; klucz operatorski pozostaje osobnym sekretem awaryjnym.
5. Wskaż istniejącą domenę Pleska z TLS. Manager doda oznaczony blok reverse proxy i wykona `httpdmng --reconfigure-domain`; błąd powoduje rollback konfiguracji.
6. Ustaw limity projektu, liczby projektów i przestrzeni konta. Dla prywatnej instancji pozostaw rejestrację wyłączoną.
7. Skonfiguruj SMTP, weryfikację e-mail i — opcjonalnie — prywatną bramę AI. Puste pole istniejącego hasła/klucza zachowuje zaszyfrowaną wartość.
8. Zapisz konfigurację, wykonaj **Sprawdź repozytorium**, a potem **Pobierz i wdróż**.

Przed startem manager tworzy rozłączne katalogi aplikacji, PostgreSQL i MinIO. Katalog aplikacji dostaje `0750` i właściciela `1000:1000`, zgodnego z użytkownikiem `node`. Hasła PostgreSQL/MinIO oraz 32-bajtowy klucz szyfrowania MFA są generowane kryptograficznie przy pierwszym wdrożeniu, zachowywane pomiędzy aktualizacjami w pliku `0600` i redagowane z logów. Origin oraz RP ID WebAuthn są wyliczane z domeny Pleska.

Nowe wdrożenie ma domyślnie wyłączoną rejestrację. Aby utworzyć pierwsze konto, tymczasowo ją włącz, wdróż, zarejestruj konto, a następnie wyłącz rejestrację i wdróż ponownie. Produkcja powinna używać SMTP oraz wymaganej weryfikacji e-mail; tryb `development` zapisuje wiadomości wyłącznie w prywatnym outboxie katalogu danych.

Pełna instrukcja bootstrapu konta, aktualne ustawienia AI, mapa katalogów i wszystkie parametry Compose znajdują się w repozytorium w `docs/CONFIGURATION.md`.

## Model aktualizacji

- **Odśwież stan** nie pobiera ani nie wdraża kodu.
- **Sprawdź origin** klonuje brakującą kopię i wykonuje `git fetch`; kontener nie jest zmieniany.
- **Zaktualizuj kod** wymaga czystego repozytorium i wykonuje wyłącznie `merge --ff-only`.
- **Wdróż** blokuje lokalne zmiany, buduje obraz, uruchamia Compose, czeka na `/api/health`, a następnie konfiguruje proxy.
- **Pobierz i wdróż** łączy dwa poprzednie kroki.

Rozszerzenie nie wykonuje `git clean`, `docker compose down -v` ani kasowania danych. `.env.kitsunepaint-plesk` ma prawa `0600`, zawiera sekrety usług i nie może być kopiowany do repozytorium ani logów.

## Backup

Backup zatrzymuje cały stos na czas utworzenia spójnej kopii PostgreSQL, MinIO i danych aplikacji, archiwizuje katalog danych, uruchamia usługi i czeka na healthcheck. Obok archiwum zapisywana jest suma SHA-256. Retencja usuwa tylko najstarsze pliki o nazwie `KitsunePaint-data-*.tar.gz` w skonfigurowanym katalogu.

To jest kopia lokalna, dlatego katalog backupów warto replikować off-site. Zakładka **Dane i backup** udostępnia dwa tryby odtwarzania:

- **restore drill** weryfikuje SHA-256, ścieżki i dowiązania, po czym rozpakowuje archiwum do izolowanego katalogu bez zmiany produkcji;
- **restore produkcyjny** wymaga wybrania archiwum oraz wpisania dokładnego potwierdzenia `RESTORE:nazwa-archiwum.tar.gz`. Manager zatrzymuje stack, atomowo podmienia katalog danych, uruchamia usługi i sprawdza readiness. Błąd powoduje rollback.

Po poprawnym restore poprzednie dane pozostają obok właściwego katalogu jako `data.before-restore-YYYYMMDD-HHMMSS`. Nie usuwaj ich, dopóki healthcheck, logowanie i otwarcie projektów nie zostaną sprawdzone.

## Diagnostyka

```bash
cd /opt/kitsunepaint/source/deploy
docker compose --env-file .env.kitsunepaint-plesk ps
docker compose --env-file .env.kitsunepaint-plesk logs --tail=200
curl -fsS http://127.0.0.1:47841/api/health
curl -I https://twoja-domena.example/
```

Panel przechowuje maksymalnie 300 ostatnich wpisów. Token i klucz SSH są maskowane przed zapisaniem stanu.

Jeżeli klucz prywatny, token lub inny sekret kiedykolwiek pojawi się w komunikacie błędu, eksporcie HTML, zgłoszeniu albo załączniku, uznaj go za ujawniony: usuń go u dostawcy, wygeneruj nowy klucz o minimalnych uprawnieniach i dopiero nową wartość zapisz w managerze. Samo usunięcie komunikatu lub aktualizacja rozszerzenia nie unieważnia starego sekretu.

Jeżeli po aktualizacji nadal pojawia się 403, sprawdź, czy serwer rzeczywiście ma entrypoint z wersji 2.0.2:

```bash
grep -n "pm_Context::init('kitsunepaint-manager')" /usr/local/psa/admin/htdocs/modules/kitsunepaint-manager/index.php
tail -n 200 /var/log/plesk/panel.log
```

Brak pierwszego wyniku oznacza, że Plesk nadal używa starszej paczki, a nie kodu 2.0.2.

Jeżeli wdrożenie zgłasza `TS2307` dla `tools/electron/creative-formats.json`, gałąź aplikacji nadal zawiera Dockerfile sprzed hotfixa 2.0.1. Opublikuj aktualny kod na skonfigurowanej gałęzi, użyj „Sprawdź/aktualizuj”, a następnie ponów wdrożenie. Manager 2.0.1 wykrywa brak pliku lub instrukcji `COPY` przed kosztownym buildem i zwraca bezpośredni komunikat.

Jeżeli desktop pokazuje „Serwer chmury nie odpowiada”, a `GET /api/health` zwraca 200, sprawdź preflight CORS dla bieżącego portu desktopu. Manager 2.0.2 zapisuje ograniczony zakres `http://localhost:47841–47870` oraz `http://127.0.0.1:47841–47870`; po aktualizacji paczki wybierz ponowne wdrożenie, aby wygenerować środowisko i zrestartować usługę.
