<?php

pm_Context::init('kitsunepaint-manager');
try { (new pm_LongTask_Manager())->cancelAllTasks(); } catch (Throwable $exception) {}
foreach (glob(pm_Context::getVarDir() . '/operation-*.json') ?: [] as $path) @unlink($path);
