<?php

class Modules_KitsunepaintManager_LongTasks extends pm_Hook_LongTasks
{
    public function getLongTasks()
    {
        return [new Modules_KitsunepaintManager_Task_Operate()];
    }
}
