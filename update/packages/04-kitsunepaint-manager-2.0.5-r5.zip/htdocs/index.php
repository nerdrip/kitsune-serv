<?php

pm_Context::init('kitsunepaint-manager');

$application = new pm_Application();
$application->run();
