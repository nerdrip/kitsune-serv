(function () {
  'use strict';

  var storageKey = 'kitsunepaint-plesk-active-tab';

  function list(nodes) {
    return Array.prototype.slice.call(nodes || []);
  }

  function remember(name) {
    try { window.sessionStorage.setItem(storageKey, name); } catch (error) {}
  }

  function closestRow(field) {
    if (!field) return null;
    if (typeof field.closest === 'function') return field.closest('.form-row');
    var node = field.parentNode;
    while (node && node !== document.body) {
      if (String(node.className || '').split(/\s+/).indexOf('form-row') !== -1) return node;
      node = node.parentNode;
    }
    return null;
  }

  function findSubmit(form) {
    return form ? form.querySelector('button[type="submit"], input[type="submit"], [data-kpp-action]') : null;
  }

  function setButtonLabel(button, label) {
    if (!button) return;
    if (String(button.tagName).toUpperCase() === 'INPUT') button.value = label;
    else button.textContent = label;
    button.setAttribute('aria-label', label);
  }

  function initializeTabs(shell) {
    var tabs = list(shell.querySelectorAll('[data-kpp-tab]'));
    var panels = list(shell.querySelectorAll('[data-kpp-panel]'));
    if (!tabs.length || !panels.length) return;

    var hasTab = function (name) {
      return tabs.some(function (tab) { return tab.getAttribute('data-kpp-tab') === name; });
    };
    var activate = function (name, shouldRemember, shouldFocus, updateUrl) {
      var selected = hasTab(name) ? name : 'status';
      tabs.forEach(function (tab) {
        var active = tab.getAttribute('data-kpp-tab') === selected;
        tab.classList.toggle('is-active', active);
        tab.setAttribute('aria-selected', active ? 'true' : 'false');
        tab.setAttribute('tabindex', active ? '0' : '-1');
        if (active && shouldFocus) tab.focus();
        if (active && updateUrl && window.history && window.history.replaceState && tab.href) {
          try { window.history.replaceState(null, '', tab.href); } catch (error) {}
        }
      });
      panels.forEach(function (panel) {
        var active = panel.getAttribute('data-kpp-panel') === selected;
        panel.hidden = !active;
        panel.classList.toggle('is-active', active);
        panel.setAttribute('aria-hidden', active ? 'false' : 'true');
      });
      if (shouldRemember) remember(selected);
    };

    tabs.forEach(function (tab, index) {
      tab.addEventListener('click', function (event) {
        event.preventDefault();
        activate(tab.getAttribute('data-kpp-tab'), true, false, true);
      });
      tab.addEventListener('keydown', function (event) {
        if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].indexOf(event.key) === -1) return;
        event.preventDefault();
        var next = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1
          : (index + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
        activate(tabs[next].getAttribute('data-kpp-tab'), true, true, true);
      });
    });

    var initial = shell.getAttribute('data-kpp-active-tab') || '';
    if (!initial) {
      try { initial = window.sessionStorage.getItem(storageKey) || ''; } catch (error) {}
    }
    activate(initial || 'status', false, false, false);
  }

  function initializeRefresh(shell) {
    var refresh = shell.querySelector('[data-kpp-refresh]');
    if (!refresh) return;
    refresh.addEventListener('click', function () {
      refresh.disabled = true;
      refresh.textContent = 'Odświeżanie…';
      remember('status');
      window.location.reload();
    });
  }

  function initializeForms(shell) {
    var definitions = [
      ['#kpp-config-form', 'config', 'Zapisywanie…'],
      ['#kpp-operation-form', 'deploy', 'Dodawanie do kolejki…'],
      ['#kpp-maintenance-form', 'data', 'Dodawanie do kolejki…'],
      ['#kpp-service-form', 'status', 'Dodawanie do kolejki…']
    ];
    definitions.forEach(function (definition) {
      var form = shell.querySelector(definition[0]);
      if (!form) return;
      var submitting = false;
      form.addEventListener('submit', function (event) {
        if (submitting) {
          event.preventDefault();
          event.stopImmediatePropagation();
          return;
        }
        submitting = true;
        remember(definition[1]);
        var submit = event.submitter || findSubmit(form);
        window.setTimeout(function () {
          if (!submit) return;
          submit.disabled = true;
          setButtonLabel(submit, definition[2]);
        }, 0);
      });
    });
  }

  function initializeMaintenance(shell) {
    var form = shell.querySelector('#kpp-maintenance-form');
    if (!form) return;
    var operation = form.querySelector('[name="maintenanceOperation"]');
    var backup = form.querySelector('[name="backupName"]');
    var confirmation = form.querySelector('[name="confirmation"]');
    var submit = findSubmit(form);
    if (!operation) return;

    var synchronize = function () {
      var restoring = operation.value === 'restore';
      [backup, confirmation].forEach(function (field) {
        var row = closestRow(field);
        if (row) row.hidden = !restoring;
        if (field) {
          field.disabled = !restoring;
          field.required = restoring;
        }
      });
      if (confirmation) confirmation.placeholder = restoring && backup && backup.value ? 'RESTORE:' + backup.value : '';
      setButtonLabel(submit, restoring ? 'Przywróć wskazany backup'
        : operation.value === 'restore-drill' ? 'Uruchom bezpieczny restore drill'
          : 'Utwórz spójny backup');
    };
    operation.addEventListener('change', synchronize);
    if (backup) backup.addEventListener('change', synchronize);
    form.addEventListener('submit', function (event) {
      if (operation.value === 'restore' && !window.confirm('Przywrócić wskazany backup? Manager zachowa bieżące dane i wykona rollback, jeżeli readiness nie przejdzie.')) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    }, true);
    synchronize();
  }

  function initializeValidation(shell) {
    var form = shell.querySelector('#kpp-config-form');
    var summary = shell.querySelector('[data-kpp-config-errors]');
    if (!form || !summary) return;
    var collect = function () {
      var invalid = list(form.querySelectorAll(':invalid'));
      if (!invalid.length) {
        summary.hidden = true;
        summary.textContent = '';
        return;
      }
      var labels = [];
      invalid.forEach(function (field) {
        var row = closestRow(field);
        var label = row ? row.querySelector('label') : null;
        var value = String(label ? label.textContent : field.getAttribute('name') || 'pole').replace(/\s*\*\s*$/, '').trim();
        if (labels.indexOf(value) === -1) labels.push(value);
      });
      summary.textContent = 'Popraw pola: ' + labels.join(', ') + '.';
      summary.hidden = false;
    };
    form.addEventListener('invalid', collect, true);
    form.addEventListener('input', collect);
  }

  function initializeCopy(shell) {
    var button = shell.querySelector('[data-kpp-copy-log]');
    var log = shell.querySelector('[data-kpp-log]');
    if (!button || !log) return;
    var completed = function () {
      button.textContent = 'Skopiowano';
      window.setTimeout(function () { button.textContent = 'Kopiuj dziennik'; }, 1800);
    };
    var fallback = function () {
      var textarea = document.createElement('textarea');
      textarea.value = log.textContent || '';
      textarea.setAttribute('readonly', 'readonly');
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      var copied = document.execCommand('copy');
      document.body.removeChild(textarea);
      if (copied) completed();
      else button.textContent = 'Nie udało się skopiować';
    };
    button.addEventListener('click', function () {
      if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
        navigator.clipboard.writeText(log.textContent || '').then(completed).catch(fallback);
      } else fallback();
    });
  }

  function initialize(shell) {
    if (!shell || shell.getAttribute('data-kpp-initialized') === 'true') return;
    shell.setAttribute('data-kpp-initialized', 'true');
    initializeTabs(shell);
    initializeRefresh(shell);
    initializeForms(shell);
    initializeMaintenance(shell);
    initializeValidation(shell);
    initializeCopy(shell);
  }

  function initializeAll() {
    list(document.querySelectorAll('.kpp-shell')).forEach(initialize);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initializeAll);
  else initializeAll();
  window.addEventListener('pageshow', initializeAll);
  window.setTimeout(initializeAll, 0);
  window.setTimeout(initializeAll, 250);

  if (typeof MutationObserver === 'function') {
    var observer = new MutationObserver(initializeAll);
    var observe = function () {
      if (document.body) observer.observe(document.body, { childList: true, subtree: true });
    };
    if (document.body) observe();
    else document.addEventListener('DOMContentLoaded', observe);
  }
})();
