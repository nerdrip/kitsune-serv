# Historia zmian

## 2.0.5-5 — 2026-08-21

- Self-update korzysta bezpośrednio ze skonfigurowanego repozytorium produktu, wykonuje bezpieczny fast-forward i pakuje przypięty commit.

## 2.0.5-4 — 2026-08-20

- Usunięto zdublowaną kartę aktualizacji rozszerzenia z zakładki wdrożenia.
- Aktualizacja managera pozostaje dostępna wyłącznie we wspólnym kanale „Aktualizacja wtyczki” w nagłówku Kitsune Plesk Suite.

## 2.0.5-2 — 2026-08-20

- Dodano wspólny pasek Kitsune Plesk Suite i przejście do centralnego zarządzania rozszerzeniami.
- Własny wpis menu pozostaje dostępny w trybie samodzielnym, a znika po aktywacji Kitsune Hub.

## 2.0.5

- panel pokazuje zainstalowane, lokalne, zdalne i uruchomione wersje produktu oraz rozszerzenia;
- rozszerzenie może bezpiecznie zaktualizować samo siebie z repozytorium przez fast-forward, walidację manifestów i CLI Pleska;
- wersja aplikacji przekazywana do obrazu nie jest już mylona ze skrótem commita.

## 2.0.4

- panel, manifest i paczka instalacyjna używają marki Kitsune Creative Suite;
- zachowano identyfikator `kitsunepaint-manager`, ścieżki wdrożenia oraz nazwy backupów, aby aktualizacja była zgodna z istniejącymi instalacjami.

## 2.0.3

- konfiguracja przyjmuje walidowaną listę adresów administratorów aplikacji i przekazuje ją do kontenera jako `KITSUNE_ADMIN_EMAILS`;
- aktywowanie listy administratorów wymaga włączenia weryfikacji adresów e-mail.

## 2.0.2

- produkcyjny CORS dopuszcza wyłącznie loopback desktopu na ograniczonych portach 47841–47870;
- generator środowiska zapisuje również konkretne originy localhost/127.0.0.1, dzięki czemu aktualizacja managera naprawia serwery 2.0.1 bez otwierania API dla dowolnego localhostu.

## 2.0.1

- kontekst builda Docker zawiera współdzielony kontrakt `creative-formats.json`, dzięki czemu kompilacja webowa nie kończy się błędem TS2307 podczas wdrożenia z Pleska;
- preflight oraz test rozszerzenia blokują ponowne pominięcie tego pliku.

## 2.0.0

- panel, manifest i dokumentacja wskazują stabilny zakres KitsunePaint 2.0.0;
- konfiguracja przekazuje osobny harmonogram backupu oraz jawne cele RPO/RTO;
- runbook rozdziela lokalny backup filesystem od operatorskiego drillu PostgreSQL/S3 i nie deklaruje zewnętrznego SLA bez raportu.

## 1.2.10

- panel, manifest i dokumentacja wskazują aplikację KitsunePaint 1.3.0;
- zachowano zgodność procedur wdrożenia i backupu z nowym runbookiem migracji filesystem → PostgreSQL/object storage.

## 1.2.9

- osobne limity rozmiaru/liczby/storage projektów dla planu pro oraz dobowe budżety AI i renderu są walidowane i przekazywane do Compose;
- dodano walidowany, podpisany sekretem webhook alertów kosztowych z progiem i ograniczonym cooldownem;
- tryb API AI jest jawny (`responses` lub `chat-completions`), a hasło SMTP trafia do środowiska przez Base64URL bez pustego podstawowego sekretu;
- panel i dokumentacja wskazują aplikację KitsunePaint 1.2.0.

## 1.2.8

- webowy edytor jest zamknięty za logowaniem, a publiczna rejestracja jest domyślnie wyłączona dla nowych wdrożeń produkcyjnych,
- konfiguracja Pleska obejmuje weryfikację e-mail, SMTP oraz bezpiecznie szyfrowane hasło poczty,
- dodane limity timeoutu, rozmiaru obrazu i współbieżności prywatnej bramy AI,
- poprawione przekazywanie konfiguracji enterprise identity i white-label w Base64URL do kontenera.

## 1.2.7

- katalog danych PostgreSQL jest przygotowywany z UID/GID `70:70`, zgodnym z przypiętym obrazem `postgres:18.4-alpine`, przed uruchomieniem kontenera,
- bind-mounty danych mają jawne ustawienia `create_host_path: false` i prywatne etykietowanie SELinux,
- błąd startu lub restartu automatycznie zawiera `docker compose ps --all` oraz końcówkę logu PostgreSQL,
- dodane testy blokujące regresję uprawnień i ponowny powrót nieczytelnego błędu `container is unhealthy`.

## 1.2.6

- pełny log BuildKit w trybie `plain`, ze zredagowanym wyjściem npm i Dockera dostępnym w błędzie zadania oraz dzienniku managera,
- jednoczesne, odporne na zapełnienie potoków przechwytywanie `stdout` i `stderr` przez ograniczone pliki tymczasowe,
- informacja o commicie i wolnym miejscu przed buildem,
- test zgodności mechanizmu uruchamiania i przechwytywania wyjścia na PHP 7.3.

## 1.2.5

- poprawiona zgodność launchera z interpreterem PHP panelu Plesk: `proc_open()` otrzymuje bezpiecznie escapowany tekst polecenia,
- zastąpione niedostępne `array_is_list()` lokalnym, kompatybilnym sprawdzeniem tablic,
- dodane testy i kontrola paczkowania chroniące zgodność ze starszym runtime’em Pleska.

## 1.2.4

- poprawiony kontrakt formularzy AJAX Pleska: sukces i każdy błąd kończą się odpowiedzią JSON z przekierowaniem do właściwej zakładki,
- wyeliminowany komunikat „Internal error” z pełnym dokumentem HTML po nieudanej walidacji,
- przesłane sekrety są czyszczone w formularzu przed odpowiedzią i nie są ponownie renderowane po błędzie,
- testy oraz packager odrzucają wydanie bez bezpiecznego przepływu POST/Redirect/GET.

## 1.2.3

- naprawione niedziałające zakładki w panelu Pleska przez ładowanie skryptu z nagłówka strony i inicjalizację odporną na dynamiczne renderowanie,
- dodana nawigacja zapasowa po stronie serwera: każda zakładka jest prawdziwym linkiem i działa również bez JavaScriptu,
- skrypt panelu jest zgodny ze starszym środowiskiem przeglądarkowym Pleska, a URL zasobu zawiera wersję rozszerzenia dla poprawnego odświeżania cache.

## 1.2.2

- pełny bootstrap rozszerzenia przez `pm_Context::init('kitsunepaint-manager')` i `pm_Application`, zgodny z działającymi managerami NailIT, KitsunePNC i KitsuneIRC,
- klasyczny pięciozakładkowy interfejs Pleska ze stanem repozytorium, kontenerów, proxy, konfiguracji, danych i dziennika,
- automatyczny odczyt statusu, wybór aktywnej domeny Pleska i czytelne sekcje konfiguracji,
- sterowanie stackiem start/restart/stop, szczegółowy inventory Docker Compose i lista backupów,
- produkcyjny restore z jawnym potwierdzeniem, kontrolą SHA-256 i ścieżek, zachowaniem poprzednich danych oraz rollbackiem po nieudanym healthchecku,
- testy blokujące regresję bootstrapu, uproszczony placeholder UI i brak kluczowych operacji.

## 1.2.1

- poprawione wejście panelu: rozszerzenie uruchamia teraz kontrolery przez `pm_Application` zamiast przekierowywać do chronionego katalogu `/modules/`,
- dodana kontrola regresji routingu do testów i packagera.

## 1.2.0

- dashboard operations, independent HMAC audit key, offline licenses and automated backup restore-drill controls,
- Stripe, OIDC/SAML/SCIM, white-label and transparent cost-explorer configuration,
- encrypted Base64URL transport for enterprise identity and stable high-entropy generated secrets.

## 1.1.0

- encrypted external connector configuration for publishing, DAM, review, automation and print-proof workflows,
- Base64URL transport of connector JSON into Docker Compose without exposing it to the browser.

## 1.0.0

- Pierwsze wydanie: Git HTTPS/SSH, Docker Compose, healthcheck, zarządzany reverse proxy domeny, trwałe dane, backupy i dziennik bez sekretów.
