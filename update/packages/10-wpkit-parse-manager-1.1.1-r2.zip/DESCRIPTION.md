# WPKit Parse Manager

Installs and manages the WPKit Parse Server and Parse Dashboard from a Git repository. The extension provides encrypted secret storage, systemd services, optional Plesk nginx reverse proxies, health status, safe fast-forward updates and a complete runtime configuration form.

Application defaults remain in the repository. The **Restore source defaults** action reloads those files and removes all Plesk runtime overrides.
