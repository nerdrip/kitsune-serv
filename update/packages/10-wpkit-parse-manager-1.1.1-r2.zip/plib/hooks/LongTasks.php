<?php

class Modules_WpkitParseManager_LongTasks extends pm_Hook_LongTasks
{
    public function getLongTasks()
    {
        return [new Modules_WpkitParseManager_Task_Operate()];
    }
}
