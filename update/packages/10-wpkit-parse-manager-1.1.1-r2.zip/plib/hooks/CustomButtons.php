<?php

class Modules_WpkitParseManager_CustomButtons extends pm_Hook_CustomButtons
{
    public function getButtons()
    {
        if ($this->hubOwnsNavigation()) return [];
        return [[
            'place' => [self::PLACE_ADMIN_NAVIGATION, self::PLACE_HOSTING_PANEL_NAVIGATION],
            'section' => self::SECTION_NAV_SERVER_MANAGEMENT,
            'order' => 56,
            'title' => 'WPKit Parse Manager',
            'description' => 'Deploy and operate Parse Server and Parse Dashboard',
            'icon' => pm_Context::getBaseUrl() . 'images/wpkit-parse-menu.svg',
            'link' => pm_Context::getActionUrl('index', 'index'),
        ]];
    }

    private function hubOwnsNavigation()
    {
        try { return pm_Extension::getById('kitsuneserv-bridge')->isActive(); }
        catch (Throwable $exception) { return false; }
    }
}
