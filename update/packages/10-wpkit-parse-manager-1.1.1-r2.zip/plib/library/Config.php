<?php

class Modules_WpkitParseManager_Config
{
    public const EXTENSION_VERSION = '1.1.1';

    private const DEPLOYMENT_SECRETS = [
        'gitToken' => 'secret_git_token',
        'gitSshPrivateKey' => 'secret_git_ssh_private_key',
    ];

    private const RUNTIME_SECRET_FIELDS = [
        'databaseURI', 'masterKey', 'javascriptKey', 'restAPIKey', 'dotNetKey', 'clientKey',
        'smtpPassword', 'cloudPasswordKeyHex', 'cloudPasswordIvHex', 'opsToken', 'pushAppsJson',
        'dashboardMasterKey', 'dashboardAccessKey', 'dashboardCookieSecret', 'dashboardPassword',
    ];

    private const RUNTIME_PUBLIC_FIELDS = [
        'nodeEnvironment', 'parseHost', 'parsePort', 'parseMountPath', 'parseTrustProxy', 'appId', 'serverURL',
        'publicServerURL', 'appName', 'verifyUserEmails', 'emailVerifyTokenValidityDuration',
        'masterKeyIps', 'liveQueryClassNames', 'smtpSecure',
        'smtpPort', 'smtpHost', 'smtpUser', 'smtpFromAddress', 'rateLimitEnabled', 'rateLimitWindowMs',
        'rateLimitMax', 'rateLimitPaths', 'readinessTimeoutMs', 'pushDefaultApp',
        'dashboardEnvironment', 'dashboardHost', 'dashboardPort', 'dashboardMountPath',
        'dashboardTrustProxy', 'dashboardServerURL', 'dashboardAppId', 'dashboardAppName',
        'dashboardCookieName', 'dashboardCookieMaxAgeMs', 'dashboardCookieSecure', 'dashboardUser',
        'dashboardAllowInsecureHTTP',
    ];

    public static function deploymentDefaults()
    {
        return [
            'repositoryUrl' => '',
            'repositoryBranch' => 'develop',
            'repositoryPath' => '/opt/wpkit/source',
            'parsePath' => '/opt/wpkit/source/parse-server',
            'runtimePath' => '/var/lib/wpkit-parse',
            'nodeBinary' => '/usr/bin/node',
            'npmBinary' => '/usr/bin/npm',
            'serviceUser' => 'wpkit-parse',
            'parseService' => 'wpkit-parse-server',
            'dashboardService' => 'wpkit-parse-dashboard',
            'gitUsername' => 'x-access-token',
            'gitSshKnownHosts' => '',
            'proxyMode' => 'manual',
            'parseDomain' => 'api.example.com',
            'dashboardDomain' => 'dashboard.example.com',
        ];
    }

    public static function deploymentValues()
    {
        $result = [];
        foreach (self::deploymentDefaults() as $key => $default) {
            $result[$key] = (string) pm_Settings::get('deploy_' . $key, $default);
        }
        return $result;
    }

    public static function runtimePublicFields()
    {
        return self::RUNTIME_PUBLIC_FIELDS;
    }

    public static function runtimeSecretFields()
    {
        return self::RUNTIME_SECRET_FIELDS;
    }

    public static function runtimeValues()
    {
        $state = self::readState();
        $defaults = (array) ($state['sourceDefaults']['values'] ?? []);
        $result = [];
        foreach (self::RUNTIME_PUBLIC_FIELDS as $field) {
            $result[$field] = self::hasRuntimeOverride($field)
                ? (string) pm_Settings::get('runtime_' . $field, '')
                : self::displayValue($defaults[$field] ?? '');
        }
        return $result;
    }

    public static function saveDeployment(array $values)
    {
        foreach (self::deploymentDefaults() as $key => $default) {
            if (!array_key_exists($key, $values)) continue;
            $value = trim((string) $values[$key]);
            if ($key === 'gitSshKnownHosts') $value = self::normalizeMultiline($value);
            pm_Settings::set('deploy_' . $key, $value);
        }
        foreach (self::DEPLOYMENT_SECRETS as $field => $setting) {
            if (!isset($values[$field]) || trim((string) $values[$field]) === '') continue;
            $value = self::normalizeMultiline($values[$field]);
            if ($field === 'gitSshPrivateKey' && strpos($value, 'PRIVATE KEY') === false) {
                throw new RuntimeException('Klucz SSH nie zawiera poprawnego nagłówka PRIVATE KEY.');
            }
            pm_Settings::setEncrypted($setting, $value);
        }
    }

    public static function saveRuntime(array $values)
    {
        foreach (self::RUNTIME_PUBLIC_FIELDS as $field) {
            if (!array_key_exists($field, $values)) continue;
            $value = trim((string) $values[$field]);
            pm_Settings::set('runtime_' . $field, $value);
            pm_Settings::set('runtime_override_' . $field, '1');
        }
        foreach (self::RUNTIME_SECRET_FIELDS as $field) {
            if (!isset($values[$field]) || trim((string) $values[$field]) === '') continue;
            $value = self::normalizeMultiline($values[$field]);
            pm_Settings::setEncrypted('runtime_secret_' . $field, $value);
            pm_Settings::set('runtime_override_' . $field, '1');
        }
    }

    public static function resetRuntimeOverrides()
    {
        foreach (array_merge(self::RUNTIME_PUBLIC_FIELDS, self::RUNTIME_SECRET_FIELDS) as $field) {
            pm_Settings::set('runtime_override_' . $field, '0');
        }
    }

    public static function hasRuntimeOverride($field)
    {
        return (string) pm_Settings::get('runtime_override_' . $field, '0') === '1';
    }

    public static function hasRuntimeSecret($field)
    {
        if (!in_array($field, self::RUNTIME_SECRET_FIELDS, true)) return false;
        if (self::hasRuntimeOverride($field)) return self::runtimeSecret($field) !== '';
        $state = self::readState();
        return !empty($state['sourceDefaults']['secretDefaults'][$field]);
    }

    public static function hasDeploymentSecret($field)
    {
        return self::deploymentSecret($field) !== '';
    }

    public static function createRuntimeConfig($operation, array $extra = [])
    {
        $allowed = ['status', 'defaults', 'check', 'sync', 'deploy', 'sync-deploy', 'migrate', 'start', 'stop', 'restart', 'uninstall'];
        if (!in_array($operation, $allowed, true)) throw new RuntimeException('Nieznana operacja WPKit Parse.');

        $varDir = rtrim((string) pm_Context::getVarDir(), '/\\');
        if (!is_dir($varDir) && !mkdir($varDir, 0700, true) && !is_dir($varDir)) {
            throw new RuntimeException('Nie można utworzyć katalogu stanu rozszerzenia.');
        }
        @chmod($varDir, 0700);
        $realVarDir = realpath($varDir);
        if ($realVarDir === false) throw new RuntimeException('Nie można rozpoznać katalogu stanu rozszerzenia.');

        $deployment = self::deploymentValues();
        $payload = array_merge($deployment, [
            'extensionVersion' => self::EXTENSION_VERSION,
            'operation' => $operation,
            'varDir' => $realVarDir,
            'runtimeOverrides' => self::runtimeOverrides(),
            'gitToken' => self::deploymentSecret('gitToken'),
            'gitSshPrivateKey' => self::deploymentSecret('gitSshPrivateKey'),
            'requestedAt' => gmdate('c'),
        ], $extra);

        if (($deployment['proxyMode'] ?? 'manual') === 'managed' && in_array($operation, ['deploy', 'sync-deploy'], true)) {
            foreach (['parse' => 'parseDomain', 'dashboard' => 'dashboardDomain'] as $module => $field) {
                if (!in_array($module, (array) ($extra['modules'] ?? []), true)) continue;
                $domain = self::hostedDomain($deployment[$field]);
                $payload[$module . 'VhostSystemPath'] = (string) $domain->getVhostSystemPath();
            }
        }

        $path = $realVarDir . '/operation-' . bin2hex(random_bytes(12)) . '.json';
        $previous = umask(0077);
        try {
            $json = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            if ($json === false || file_put_contents($path, $json, LOCK_EX) === false) {
                throw new RuntimeException('Nie można zapisać konfiguracji operacji.');
            }
            @chmod($path, 0600);
        } finally {
            umask($previous);
        }
        return $path;
    }

    public static function managerBackendInfo()
    {
        $expected = self::EXTENSION_VERSION;
        $actual = null;
        $detail = '';
        try {
            $result = pm_ApiCli::callSbin('wpkit-parse-manager', ['--version-json'], pm_ApiCli::RESULT_FULL);
            if ((int) ($result['code'] ?? 1) === 0) {
                $decoded = json_decode((string) ($result['stdout'] ?? ''), true);
                if (is_array($decoded) && ($decoded['component'] ?? '') === 'wpkit-parse-manager'
                    && preg_match('/^[0-9]+\.[0-9]+\.[0-9]+$/', (string) ($decoded['version'] ?? ''))) {
                    $actual = (string) $decoded['version'];
                } else {
                    $detail = 'Helper zwrócił nieprawidłowy identyfikator wersji.';
                }
            } else {
                $detail = trim((string) ($result['stderr'] ?? '') . "\n" . (string) ($result['stdout'] ?? ''));
            }
        } catch (Throwable $exception) {
            $detail = $exception->getMessage();
        }

        $compatible = $actual === $expected;
        $productRoot = defined('PRODUCT_ROOT_D') ? PRODUCT_ROOT_D : '/usr/local/psa';
        $utility = rtrim((string) $productRoot, '/') . '/admin/bin/modules/wpkit-parse-manager/wpkit-parse-manager';
        $actualLabel = $actual !== null ? $actual : 'starszy lub nierozpoznany';
        $error = null;
        if (!$compatible) {
            $error = 'Niezgodna wersja komponentów WPKit Parse: panel ' . $expected . ', helper sbin ' . $actualLabel . '. '
                . 'Plesk nadal uruchamia ' . $utility . '. Zainstaluj ponownie paczkę wpkit-parse-manager-' . $expected . '.zip; '
                . 'operacje zostały zablokowane, aby nie uruchamiać starego kodu.';
            if ($detail !== '') $error .= ' Szczegóły: ' . mb_substr(preg_replace('/\s+/', ' ', $detail), 0, 500);
        }
        return ['expected' => $expected, 'version' => $actual, 'compatible' => $compatible, 'error' => $error];
    }

    public static function assertManagerBackendCompatible()
    {
        $info = self::managerBackendInfo();
        if (!$info['compatible']) throw new RuntimeException((string) $info['error']);
        return $info;
    }

    public static function readState()
    {
        $empty = [
            'updatedAt' => null,
            'lastOperation' => null,
            'lastSuccess' => null,
            'lastError' => null,
            'repository' => [],
            'sourceDefaults' => ['loadedAt' => null, 'values' => [], 'secretDefaults' => []],
            'deployments' => [],
            'services' => [],
            'serviceLogs' => ['parse' => [], 'dashboard' => []],
            'proxy' => [],
            'log' => [],
        ];
        $path = pm_Context::getVarDir() . '/state.json';
        if (!is_file($path)) return $empty;
        $decoded = json_decode((string) file_get_contents($path), true);
        return is_array($decoded) ? array_replace_recursive($empty, $decoded) : $empty;
    }

    private static function runtimeOverrides()
    {
        $result = [];
        foreach (self::RUNTIME_PUBLIC_FIELDS as $field) {
            if (self::hasRuntimeOverride($field)) $result[$field] = (string) pm_Settings::get('runtime_' . $field, '');
        }
        foreach (self::RUNTIME_SECRET_FIELDS as $field) {
            if (self::hasRuntimeOverride($field)) $result[$field] = self::runtimeSecret($field);
        }
        return $result;
    }

    private static function runtimeSecret($field)
    {
        try { return (string) pm_Settings::getDecrypted('runtime_secret_' . $field); }
        catch (Exception $exception) { return ''; }
    }

    private static function deploymentSecret($field)
    {
        $setting = self::DEPLOYMENT_SECRETS[$field] ?? null;
        if ($setting === null) return '';
        try { return (string) pm_Settings::getDecrypted($setting); }
        catch (Exception $exception) { return ''; }
    }

    private static function hostedDomain($name)
    {
        $name = strtolower(trim((string) $name));
        try { $domain = pm_Domain::getByName($name); }
        catch (Throwable $exception) { throw new RuntimeException('Domena Pleska jest niedostępna: ' . $name, 0, $exception); }
        if (!$domain instanceof pm_Domain || !$domain->hasHosting() || !$domain->isActive() || $domain->isSuspended() || $domain->isDisabled()) {
            throw new RuntimeException('Domena musi być aktywna i mieć hosting WWW: ' . $name);
        }
        return $domain;
    }

    private static function displayValue($value)
    {
        if (is_bool($value)) return $value ? 'true' : 'false';
        if (is_array($value)) return implode(',', $value);
        return (string) $value;
    }

    private static function normalizeMultiline($value)
    {
        $value = str_replace(["\r\n", "\r"], "\n", (string) $value);
        if (strncmp($value, "\xEF\xBB\xBF", 3) === 0) $value = substr($value, 3);
        return trim($value);
    }
}
