<?php

pm_Context::init('wpkit-parse-manager');
require_once dirname(__DIR__) . '/library/Config.php';
$varDir = pm_Context::getVarDir();
if (!is_dir($varDir)) mkdir($varDir, 0700, true);
@chmod($varDir, 0700);
foreach (Modules_WpkitParseManager_Config::deploymentDefaults() as $key => $value) {
    if (pm_Settings::get('deploy_' . $key) === null) pm_Settings::set('deploy_' . $key, (string) $value);
}
if ((string) pm_Settings::get('runtime_override_publicServerURL', '0') === '1'
    && rtrim((string) pm_Settings::get('runtime_publicServerURL', ''), '/') === 'https://bzt.nerd.rip/p') {
    pm_Settings::set('runtime_publicServerURL', 'https://api.nerd.rip/gildia/');
}
$productRoot = defined('PRODUCT_ROOT_D') ? PRODUCT_ROOT_D : '/usr/local/psa';
$utility = $productRoot . '/admin/bin/modules/wpkit-parse-manager/wpkit-parse-manager';
if (!is_file($utility)) throw new RuntimeException('Plesk nie zainstalował uprzywilejowanego helpera: ' . $utility . '.');
@chmod($utility, 0750);
$backendInfo = Modules_WpkitParseManager_Config::managerBackendInfo();
pm_Settings::set('backend_install_warning', $backendInfo['compatible'] ? '' : (string) $backendInfo['error']);
