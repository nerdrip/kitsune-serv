<?php

pm_Context::init('wpkit-parse-manager');
require_once dirname(__DIR__) . '/library/Config.php';
try { (new pm_LongTask_Manager())->cancelAllTasks(); } catch (Exception $exception) {}
$runtimeConfig = null;
try {
    $runtimeConfig = Modules_WpkitParseManager_Config::createRuntimeConfig('uninstall');
    pm_ApiCli::callSbin('wpkit-parse-manager', ['--config', $runtimeConfig], pm_ApiCli::RESULT_FULL);
} catch (Throwable $exception) {
    // Nie blokuj odinstalowania panelu. Repozytorium i runtime pozostają na dysku,
    // a administrator może ręcznie usunąć jednostki, jeśli systemd jest niedostępny.
} finally {
    if ($runtimeConfig && is_file($runtimeConfig)) @unlink($runtimeConfig);
}
foreach (glob(pm_Context::getVarDir() . '/operation-*.json') ?: [] as $path) @unlink($path);
