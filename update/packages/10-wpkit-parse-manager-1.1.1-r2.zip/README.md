# WPKit Parse Manager for Plesk

Rozszerzenie wdraża dwa moduły z tego repozytorium:

- `parse-server` jako usługę systemd,
- `parse-server/dashboard` jako osobną usługę systemd.

## Najważniejsze właściwości

- struktura rozszerzenia zgodna z managerami KitsunePNC i NailIT (`meta.xml`, MVC Pleska, long task, `sbin`, hook menu),
- klonowanie prywatnego repozytorium przez token HTTPS albo przypięty klucz SSH,
- automatyczne, trwałe przypięcie klucza hosta SSH przy pierwszym połączeniu; ręczne `known_hosts` pozostaje opcjonalne,
- aktualizacje tylko przez fast-forward; lokalne zmiany blokują synchronizację i wdrożenie,
- instalacja deterministyczna przez `npm ci --omit=dev`,
- zabezpieczone obejście błędnej walidacji lockfile w npm 11: tylko istniejące wpisy są naprawiane tymczasowo, a źródłowy plik jest przywracany,
- automatyczne wykrywanie środowisk Node.js z systemu, Pleska, NVM i FNM oraz opcja własnych ścieżek,
- chroniona kopia wybranej binarki Node.js w katalogu runtime, dzięki czemu usługa nie wymaga dostępu do katalogu `/root`,
- osobna, jawna operacja uruchamiania idempotentnych migracji schematu Parse,
- osobny użytkownik systemowy bez powłoki logowania,
- prywatne pliki środowiska `0640` w katalogu runtime,
- zahartowane jednostki systemd z `NoNewPrivileges`, `ProtectSystem` i `PrivateTmp`,
- warstwowy healthcheck z diagnostyką systemd i oddzielnymi logami journal dla Parse Servera oraz Dashboardu,
- opcjonalne, oznaczone bloki reverse proxy nginx dla domen Pleska,
- 53 pola konfiguracji Parse Servera, SMTP, Cloud Code, push i Parse Dashboardu,
- sekrety przechowywane przez `pm_Settings::setEncrypted()`,
- przywracanie wartości domyślnych przez ponowne wykonanie `parse-server/scripts/plesk-config.mjs defaults`.

## Instalacja

1. Zbuduj archiwum w katalogu głównym repozytorium:

   ```bash
   cd parse-server
   npm run plesk:package
   ```

2. Skopiuj `parse-server/dist/wpkit-parse-manager-1.1.1.zip` na serwer.
3. Przy pierwszej instalacji użyj:

   ```bash
   plesk bin extension -i wpkit-parse-manager-1.1.1.zip
   ```

   Przy aktualizacji już zainstalowanej wersji użyj:

   ```bash
   plesk bin extension -g wpkit-parse-manager-1.1.1.zip
   ```

4. W panelu **WPKit Parse Manager → Wdrożenie** podaj repozytorium, gałąź i katalogi oraz wybierz wykryte środowisko Node.js. Opcja **Własne ścieżki…** pozwala podać binarki ręcznie.
5. Wykonaj **Zaktualizuj lokalny kod**, sprawdź formularz konfiguracji, następnie wybierz **Wdróż**.

## Wartości domyślne i nadpisania

Pliki `parse-server/config/defaults.js`, `parse-server/push/apps.config.js` oraz `parse-server/dashboard/config/defaults.js` pozostają źródłem prawdy. Rozszerzenie nie modyfikuje ich.

Zapis formularza tworzy nadpisania środowiskowe. Przycisk **Przywróć wartości z plików**:

1. wymaga potwierdzenia,
2. odczytuje aktualne pliki z lokalnego repozytorium,
3. dopiero po poprawnym odczycie wyłącza wszystkie nadpisania,
4. nie ujawnia sekretów w stanie ani interfejsie.

Po resecie wykonaj **Uruchom ponownie** lub **Wdróż**, aby odtworzyć pliki `.env` i zastosować wartości.

## Reverse proxy

Tryb `manual` pozostawia konfigurację publikacji administratorowi. Tryb `managed` wymaga dwóch aktywnych domen z hostingiem WWW: osobnej dla API i osobnej dla dashboardu. Rozszerzenie zapisuje tylko oznaczone bloki w `vhost_nginx.conf`, a TLS pozostaje zarządzany przez Pleska.

## Odinstalowanie

Odinstalowanie wyłącza i usuwa jednostki systemd oraz zarządzane bloki proxy. Repozytorium i katalog runtime pozostają na dysku celowo, aby odinstalowanie panelu nie usuwało danych lub konfiguracji aplikacji.
