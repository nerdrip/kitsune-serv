(function () {
  'use strict';

  function initializeTabs(shell) {
    var tabs = Array.prototype.slice.call(shell.querySelectorAll('[data-wppm-tab]'));
    var panels = Array.prototype.slice.call(shell.querySelectorAll('[data-wppm-panel]'));
    if (!tabs.length || !panels.length) return;

    var activate = function (name, remember, focus) {
      var selected = tabs.some(function (tab) {
        return tab.getAttribute('data-wppm-tab') === name;
      }) ? name : 'status';

      tabs.forEach(function (tab) {
        var active = tab.getAttribute('data-wppm-tab') === selected;
        tab.classList.toggle('is-active', active);
        tab.setAttribute('aria-selected', active ? 'true' : 'false');
        tab.setAttribute('tabindex', active ? '0' : '-1');
        if (active && focus) tab.focus();
      });

      panels.forEach(function (panel) {
        var active = panel.getAttribute('data-wppm-panel') === selected;
        panel.classList.toggle('is-active', active);
        panel.hidden = !active;
        panel.setAttribute('aria-hidden', active ? 'false' : 'true');
      });

      if (remember) {
        try {
          window.sessionStorage.setItem('wpkit-parse-manager-tab', selected);
        } catch (_error) {
          /* Pamięć zakładki jest opcjonalna. */
        }
      }
    };

    tabs.forEach(function (tab, index) {
      tab.addEventListener('click', function (event) {
        event.preventDefault();
        activate(tab.getAttribute('data-wppm-tab'), true, false);
      });

      tab.addEventListener('keydown', function (event) {
        if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].indexOf(event.key) === -1) return;
        event.preventDefault();
        var targetIndex = event.key === 'Home'
          ? 0
          : event.key === 'End'
            ? tabs.length - 1
            : (index + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
        activate(tabs[targetIndex].getAttribute('data-wppm-tab'), true, true);
      });
    });

    var requested = shell.getAttribute('data-wppm-active-tab') || '';
    if (!requested) {
      try {
        requested = window.sessionStorage.getItem('wpkit-parse-manager-tab') || '';
      } catch (_error) {
        /* Pamięć zakładki jest opcjonalna. */
      }
    }
    activate(requested || 'status', false, false);

    shell.wpkitParseActivateTab = activate;
  }

  function initializeForms(shell) {
    Array.prototype.forEach.call(shell.querySelectorAll('form'), function (form) {
      Array.prototype.forEach.call(form.querySelectorAll('[data-wppm-action]'), function (candidate) {
        candidate.addEventListener('click', function () { form.wpkitParseSubmitter = candidate; });
      });
      form.addEventListener('submit', function (event) {
        var button = event.submitter || form.wpkitParseSubmitter || form.querySelector('[data-wppm-action]');
        if (!button) return;
        if (button.getAttribute('data-wppm-action') === 'reset'
          && !window.confirm('Usunąć wszystkie nadpisania i odczytać wartości ponownie z plików źródłowych?')) {
          event.preventDefault();
          return;
        }
        button.disabled = true;
        button.textContent = 'Uruchamianie…';
      });
    });
  }

  function initializeOperation(shell) {
    var operation = shell.querySelector('#wppm-operation-form [name="operation"]');
    var button = shell.querySelector('#wppm-operation-form [data-wppm-action="operation"]');
    if (!operation || !button) return;
    var labels = {
      check: 'Sprawdź',
      sync: 'Zaktualizuj kod',
      deploy: 'Wdróż',
      'sync-deploy': 'Pobierz i wdróż',
      migrate: 'Uruchom migracje'
    };
    var update = function () {
      button.textContent = labels[operation.value] || 'Uruchom operację';
    };
    operation.addEventListener('change', update);
    update();
  }

  function initializeNodeRuntime(shell) {
    var preset = shell.querySelector('[name="nodeRuntimePreset"]');
    var customFields = Array.prototype.slice.call(shell.querySelectorAll('[name="nodeBinaryCustom"], [name="npmBinaryCustom"]'));
    if (!preset || !customFields.length) return;

    var update = function () {
      var custom = preset.value === 'custom';
      customFields.forEach(function (field) {
        field.disabled = !custom;
        var row = typeof field.closest === 'function' ? field.closest('.form-row') : field.parentNode;
        if (row) {
          row.hidden = !custom;
          row.style.display = custom ? '' : 'none';
          row.setAttribute('aria-hidden', custom ? 'false' : 'true');
        }
      });
    };
    preset.addEventListener('change', update);
    update();
  }

  function initializeRefresh(shell) {
    var refresh = shell.querySelector('[data-wppm-refresh]');
    if (!refresh) return;
    refresh.addEventListener('click', function () {
      refresh.disabled = true;
      refresh.textContent = 'Odświeżanie…';
      if (typeof shell.wpkitParseActivateTab === 'function') {
        shell.wpkitParseActivateTab('status', true, false);
      }
      window.location.reload();
    });
  }

  function legacyCopy(value) {
    var textarea = document.createElement('textarea');
    textarea.value = value;
    textarea.setAttribute('readonly', 'readonly');
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    var copied = document.execCommand('copy');
    document.body.removeChild(textarea);
    return copied;
  }

  function initializeLogTabs(shell) {
    var tabs = Array.prototype.slice.call(shell.querySelectorAll('[data-wppm-log-tab]'));
    var panels = Array.prototype.slice.call(shell.querySelectorAll('[data-wppm-log-panel]'));
    if (!tabs.length || !panels.length) return;

    var activate = function (name, focus) {
      var selected = tabs.some(function (tab) { return tab.getAttribute('data-wppm-log-tab') === name; }) ? name : 'manager';
      tabs.forEach(function (tab) {
        var active = tab.getAttribute('data-wppm-log-tab') === selected;
        tab.classList.toggle('is-active', active);
        tab.setAttribute('aria-selected', active ? 'true' : 'false');
        tab.setAttribute('tabindex', active ? '0' : '-1');
        if (active && focus) tab.focus();
      });
      panels.forEach(function (panel) {
        panel.hidden = panel.getAttribute('data-wppm-log-panel') !== selected;
      });
    };

    tabs.forEach(function (tab, index) {
      tab.addEventListener('click', function () { activate(tab.getAttribute('data-wppm-log-tab'), false); });
      tab.addEventListener('keydown', function (event) {
        if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
        event.preventDefault();
        var target = tabs[(index + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length];
        activate(target.getAttribute('data-wppm-log-tab'), true);
      });
    });
    activate('manager', false);
  }

  function initializeLogCopy(shell) {
    Array.prototype.forEach.call(shell.querySelectorAll('[data-wppm-copy]'), function (copy) {
      var target = copy.getAttribute('data-wppm-copy');
      var log = shell.querySelector('[data-wppm-log-content="' + target + '"]');
      if (!log) return;
      var completed = function () {
        copy.textContent = 'Skopiowano';
        window.setTimeout(function () { copy.textContent = 'Kopiuj'; }, 1500);
      };
      var fallback = function () {
        if (legacyCopy(log.textContent || '')) completed();
      };

      copy.addEventListener('click', function () {
        var value = log.textContent || '';
        if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
          navigator.clipboard.writeText(value).then(completed).catch(fallback);
        } else {
          fallback();
        }
      });
    });
  }

  function initialize() {
    var shell = document.querySelector('.wppm-shell');
    if (!shell || shell.getAttribute('data-wppm-initialized') === 'true') return;
    shell.setAttribute('data-wppm-initialized', 'true');
    initializeTabs(shell);
    initializeForms(shell);
    initializeOperation(shell);
    initializeNodeRuntime(shell);
    initializeRefresh(shell);
    initializeLogTabs(shell);
    initializeLogCopy(shell);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize);
  else initialize();
})();
