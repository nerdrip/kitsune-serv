<?php

pm_Context::init('wpkit-parse-manager');
$application = new pm_Application();
$application->run();
