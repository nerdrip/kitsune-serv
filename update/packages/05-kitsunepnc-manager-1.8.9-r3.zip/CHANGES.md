# Changelog

## 1.8.9-3 — 2026-08-20

- Instalator Kitsune Suite używa aktualnej ścieżki repozytoryjnej `plesk-extension/kitsunecolab-manager`.
- Audyt, instalacja i odnośnik panelu rozpoznają unikalny identyfikator oraz runner `kitsunecolab-manager` zamiast historycznego `kitsune-manager`.

## 1.8.9-2 — 2026-08-20

- Dodano wspólną powłokę Kitsune Plesk Suite i centralny powrót do konfiguracji w Hubie.
- Nawigacja produktu jest ukrywana tylko po wykryciu aktywnego Kitsune Hub.

## 1.8.9 — 2026-08-12

- Hub naprawia właściciela i prawa redagowanego `state.json` satelitów, aby ich UI mogło odczytać status zapisany przez runnera root.

## 1.8.8 — 2026-08-12

- Przed instalacją lub aktualizacją satelity Hub normalizuje właściciela i tryb
  trzech prywatnych plików integracji: bootstrapu, profilu sterowania oraz
  profilu wykrywania. Naprawia to stan pozostawiony przez wcześniejszy `filemng`,
  w którym plik `0600` należał do `root` i proces panelu nie mógł go zastąpić.
- Normalizacja obejmuje wyłącznie znane pliki regularne w zweryfikowanym katalogu
  danego pluginu; symlinki i inne typy wpisów nadal zatrzymują instalację.

## 1.8.7 — 2026-08-12

- Repozytoryjna paczka pluginu satelity zapisuje teraz także jawny tryb `0700`
  dla katalogu `var/`, obok trybu `0600` jednorazowego bootstrapu. Chroni to
  sekret również przy instalacji przez `filemng` Pleska.
- Colab 1.5.8 i Test 1.4.8 potrafią bezpiecznie utwardzić tryb własnego pliku
  bootstrap po rozpakowaniu przez Pleska, ale wyłącznie po sprawdzeniu ścieżki,
  braku symlinków i zgodności właściciela z prywatnym katalogiem stanu.

## 1.8.6 — 2026-08-12

- Instalator satelitów nie przekazuje już prywatnego `umask 0077` do CLI
  rozszerzeń Pleska. Kod `plib`, `htdocs` i `sbin` otrzymuje prawa dostępne dla
  procesu panelu, podczas gdy katalogi oraz pliki z sekretami nadal pozostają
  prywatne.
- Po instalacji Hub normalizuje i weryfikuje prawa obu managerów. Nie uzna za
  udaną instalacji, której kontroler, `meta.xml`, entrypoint lub hook menu jest
  niedostępny dla Pleska.
- Pierwsze SSO ponawia pełny snapshot istniejących projektów dla wybranego
  satelity, dzięki czemu doinstalowany KitsuneTest odtwarza wcześniejsze
  projekty Huba.

## 1.8.5 — 2026-08-11

- Po instalacji lub aktualizacji Hub jawnie aktywuje rozszerzenia Colaba i
  Testa przez mechanizm `extension --enable` Pleska. Usuwa to stan, w którym
  satelita był zarejestrowany i miał komplet plików, ale nie miał akcji Open,
  wpisu w menu ani działającej trasy panelu.
- Aktywacja jest częścią tej samej weryfikowanej operacji co instalacja; jej
  błąd nie jest już raportowany jako pozornie poprawne wdrożenie pluginu.
- Paczka zawiera komplet ikon katalogowych Pleska 32/64/128 px zamiast
  zastępczej ikony klocków.
- Metadane używają obsługiwanej kategorii `developer` i rzeczywistych adresów
  projektu oraz zgłoszeń zamiast wartości zastępczych.

## 1.8.4 — 2026-08-11

- Instalacja satelitów naprawia również częściowo skopiowane lub
  niezarejestrowane rozszerzenia i nie uznaje już samego pliku managera za
  kompletną instalację.
- Po instalacji Hub sprawdza rejestr Pleska, dokładną wersję i wydanie,
  kontroler WWW, entrypoint oraz hook obu trybów menu; niepełna aktualizacja
  kończy się czytelnym błędem zamiast fałszywego sukcesu.
- Karta Suite pokazuje wersję z faktycznie zainstalowanego `meta.xml`, a link
  managera pojawia się dopiero po zweryfikowaniu kompletnej instalacji.

## 1.8.3 — 2026-08-11

- Pierwsze logowanie SSO aktywuje synchronizację wybranego workspace'a tylko
  dla otwieranego satelity; konta i zasoby nie są tworzone dla nieaktywnych
  użytkowników.
- Workspace'y stają się organizacjami podrzędnymi, projekty są synchronizowane
  wraz ze zmianą nazwy i usunięciem, a role istniejących kont SSO podążają za
  uprawnieniami Huba.
- Linki managerów oraz wpis menu używają kanonicznego adresu modułu Pleska.
- Bootstrap przekazuje konfigurowalną nazwę nadrzędnej organizacji Suite.

## 1.8.2 — 2026-08-11

- Linki do niezależnych managerów są generowane przez router akcji SDK Pleska,
  dzięki czemu nie trafiają na nieistniejącą lub podwójną ścieżkę modułu.
- Wpis nawigacji używa układu zgodnego z działającymi managerami Pleska i nie
  łączy sekcji menu serwera z miejscem Narzędzia i ustawienia.

## 1.8.1 — 2026-08-11

- Linki do osobnych managerów korzystają z oficjalnego bazowego URL-a modułu
  Pleska i nie tworzą błędnych ani zduplikowanych ścieżek.
- Karty Suite pokazują oddzielnie wersję rozszerzenia Pleska oraz wersję i
  skrócony commit faktycznie działającej aplikacji Colab/Test.
- Adresy Suite są kanonizowane do pojedynczego `/api`, także gdy zapisany URL
  API już zawiera tę ścieżkę.
- Integracje Colab i Test są stale widoczne w nagłówku Huba i otwierają się w
  nowej karcie; pozostają też dostępne w menu konta.
- Przycisk managera rejestruje się również w Narzędziach i ustawieniach oraz w
  nawigacji trybu Power User.

## 1.8.0 — 2026-08-11

- Dodano centralne logowanie Kitsune Suite z Huba do Colaba i Testu: jednorazowy
  kod, PKCE S256, dokładne callbacki oraz powiązanie tożsamości po `(issuer, sub)`.
- Menu konta Huba pokazuje dostępne integracje i uruchamia logowanie bez
  przekazywania tokenów w adresie URL.
- Role workspace są mapowane na role satelitów przy każdym logowaniu; lokalne
  konta Colaba i Testu pozostają niezależne i nie przyznają dostępu do Huba.
- Bootstrap Pleska przekazuje URL-e i wspólny sekret potrzebny do SSO.

## 1.7.9 — 2026-08-11

- Linki do osobnych managerów Colaba i Testa są generowane przez kontekst
  docelowego rozszerzenia Pleska i otwierają się bezpiecznie w nowej karcie.
- Zakładka Suite wyjaśnia rozdział kont, organizacji, ról i technicznych
  tożsamości provisioningu oraz odróżnia wspólny sekret od logowania/SSO.

## 1.7.8 — 2026-08-11

- Orkiestracja pobiera KitsuneTest 1.3.4, który poprawnie uruchamia MinIO, API
  i Redis z sekretami zapisanymi na hoście z uprawnieniami `0600`.
- Kontenery odczytują sekrety w krótkiej fazie startowej jako root, a procesy
  aplikacyjne działają dalej jako nieuprzywilejowani użytkownicy.
- W razie kolejnego błędu Hub otrzyma stan i końcówkę logów usług Compose,
  zamiast nieczytelnego komunikatu `container is unhealthy`.

## 1.7.7 — 2026-08-11

- Orkiestracja repozytoryjna pobiera poprawione managery KitsuneColab 1.4.3 i
  KitsuneTest 1.3.3 przed delegowanym wdrożeniem.
- Colab automatycznie omija zajęte porty hosta, a produkcyjny deploy Testa
  uruchamia Docker Compose bez zależności od hostowego Node.js i `pnpm`.
- Opcjonalne narzędzia Testa wykrywają Node.js 22+ z Plesk Node.js Toolkit i
  korzystają z Corepack, gdy `pnpm` nie ma w PATH.
- Oba produkty zapamiętują przydzielone porty i pozostają rozłączne również po
  restarcie, backupie oraz kolejnym wdrożeniu.

## 1.7.6 — 2026-08-11

- Delegowane wdrożenie i backup nie wymagają już ustawionego bitu wykonywania
  na pliku managera satelity. Hub uruchamia manager Colaba lub Testa przez
  zweryfikowany interpreter i konfigurację PHP Pleska, tak samo jak importer
  bootstrapu.
- Naprawia to fałszywy komunikat „manager is not installed” po udanej
  automatycznej instalacji na serwerach, które pominęły lifecycle hook
  ustawiający `chmod`. Plik managera nadal jest weryfikowany względem dokładnej
  ścieżki zainstalowanego rozszerzenia.

## 1.7.5 — 2026-08-11

- Hub nie zakłada już, że udana komenda aktualizacji Pleska oznacza wykonanie
  hooka `post-install`. Jeśli bootstrap pozostał, uruchamia nowy, ściśle
  ograniczony tryb importu managera Colaba lub Testa przez interpreter PHP,
  konfigurację i SDK należące do Pleska.
- Import odbywa się we właściwym `pm_Context` satelity, dzięki czemu ustawienia
  i sekrety trafiają do jego własnego magazynu Pleska. Hub następnie sprawdza
  usunięcie bootstrapu oraz poprawność profilu delegowanego sterowania.
- Repozytoria satelitów mają wersje Colab 1.4.2 i Test 1.3.2, więc istniejące
  instalacje otrzymają manager z deterministycznym importerem przed użyciem.

## 1.7.4 — 2026-08-11

- Repozytoryjna instalacja osadza jednorazowy, chroniony
  `var/suite-bootstrap.json` bezpośrednio w paczce pluginu Colaba lub Testa.
  Ich zwykły hook `post-install` importuje ustawienia i usuwa sekret, więc Hub
  nie zależy już od niewystawianego przez Pleska skryptu
  `import-suite-bootstrap.php` uruchamianego przez `extension -e`.
- Jeżeli satelita ma już tę samą wersję, Hub zwiększa numer `release` wyłącznie
  dla generowanej paczki. Plesk wykonuje dzięki temu prawdziwą, naprawczą
  aktualizację i ponownie uruchamia `post-install`, bez sztucznego zmieniania
  wersji aplikacji i bez ręcznego odinstalowywania pluginu.
- Zawartość osadzonego bootstrapu, numer wydania, lifecycle hook oraz SHA-256
  gotowej paczki są sprawdzane przed przekazaniem jej instalatorowi Pleska.

## 1.7.3 — 2026-08-11

- Hub naprawia częściowo zainstalowane pluginy satelitarne: przed jawnym
  importem weryfikuje SHA-256 `import-suite-bootstrap.php` w katalogu runtime
  Pleska i, jeżeli pliku brakuje albo jest nieaktualny, odtwarza go atomowo ze
  zweryfikowanego checkoutu repozytorium Colaba lub Testa.
- Paczka pluginu satelitarnego bez importera jest odrzucana jeszcze przed
  wywołaniem instalatora Pleska. Ponowienie działa również wtedy, gdy wersja
  pluginu jest już zgodna z repozytorium i nie wymaga ręcznej reinstalacji.

## 1.7.2 — 2026-08-11

- Jawny import nie odwołuje się już do lifecycle hooka `post-install.php`,
  którego część instalacji Pleska nie zachowuje po aktualizacji. Hub uruchamia
  nowy, trwały `import-suite-bootstrap.php` dostarczany przez oba pluginy.
- Repozytoria satelitów mają odpowiednio wersje Colab 1.4.1 i Test 1.3.1, więc
  istniejące wadliwe instalacje zostaną naprawdę zaktualizowane przed importem.

## 1.7.1 — 2026-08-11

- Jeśli automatyczny hook Pleska pozostawi bootstrap po instalacji lub
  aktualizacji, Hub jawnie uruchamia `post-install.php` właściwego pluginu przez
  oficjalne `extension -e` i dopiero potem deleguje wdrożenie.
- Ponowienie operacji z pluginem w tej samej wersji nie wykonuje niedozwolonego
  upgrade'u: Hub uzgadnia konfigurację istniejącej instalacji i kontynuuje
  deploy. Downgrade do starszej wersji z repozytorium jest blokowany.

## 1.7.0 — 2026-08-11

- Dodano jedną operację instalującą lub aktualizującą pluginy KitsuneColab i
  KitsuneTest bezpośrednio z ich repozytoriów, przekazującą pełny bootstrap i
  od razu wdrażającą oba produkty.
- Aktualizacja repozytoryjna zawsze uzgadnia konfigurację satelity i sprawdza,
  czy powstał bezpieczny profil delegowania; naprawia to wcześniejsze,
  częściowo skonfigurowane instalacje.
- Produkt można wybrać pojedynczo albo uruchomić operację dla całego Suite;
  awaria jednego produktu nie blokuje próby wdrożenia drugiego i jest czytelnie
  raportowana.
- Bootstrap wymusza automatyczny vhost jednej domeny dla panelu i API oraz
  przekazuje obsługę Git HTTPS/SSH również do KitsuneTest.

## 1.6.12 — 2026-08-10

- Naprawiono przekierowania po formularzach na Plesk Obsidian: odpowiedź HTTP
  używa teraz bezpośredniego, absolutnego nagłówka `Location`, więc ścieżka
  modułu nie jest ponownie doklejana do bieżącego adresu.
- Tę samą ochronę zastosowano w kontrolerach samodzielnych pluginów Colaba i
  Testa.

## 1.6.1 — 2026-08-10

- Bootstrap Colaba i Testa wymaga już tylko jednej domeny produktu wybranej z
  listy Pleska. Adresy panelu, API i readiness są wyprowadzane automatycznie;
  nie ma pól do ręcznego wpisywania URL-i.

## 1.6.0 — 2026-08-10

- Konfiguracja Huba i bootstrapy Colaba/Testa mają listy aktywnych domen oraz
  subdomen Pleska. Wybór domeny wypełnia właściwe URL-e paneli, API i endpoint
  readiness; brakujące subdomeny są jasno proponowane do utworzenia.
- Dodano wybór automatycznej albo ręcznej konfiguracji vhosta. Tryb ręczny
  pokazuje gotowy fragment nginx do wklejenia dla wybranej domeny, bez
  konfliktowego `location /` i bez opakowania `server {}`.
- Naprawiono uprawnienia katalogu bootstrapu repozytoryjnego: przed instalacją
  pluginu Suite jest on dostępny dla użytkownika Pleska `psaadm`.

## 1.5.7 — 2026-08-10

- Bootstrap SSH KitsuneColab automatycznie pobiera i przypina klucz hosta przez
  `ssh-keyscan`, jeśli `known_hosts` jest puste; późniejszy Git nadal wymaga
  ścisłego sprawdzania przypiętego klucza.

## 1.5.6 — 2026-08-10

- Naprawiono wieloformularzowy widok Suite: Plesk generował powielone
  identyfikatory `btn-send`, więc przyciski były szarymi prostokątami. Każdy
  formularz ma teraz własny, widoczny przycisk submit.
- Wspólny sekret Kitsune Suite generuje się automatycznie przy pierwszym
  zapisie lub bootstrapie Colaba/Testa.

## 1.5.5 — 2026-08-10

- Naprawiono etykiety i działanie przycisków formularzy Pleska: właściwy
  parametr API to `sendTitle`, nie `sendLabel`.

## 1.5.4 — 2026-08-10

- Bootstrap nie blokuje się na zapisanej nazwie organizacji zamiast jej
  technicznego ID; taka wartość jest pokazywana jako puste pole opcjonalne.

## 1.5.3 — 2026-08-10

- Wszystkie formularze operacyjne, w tym „Zapisz i zainstaluj z repozytorium”,
  używają natywnego przycisku `pm_Form_Simple` Pleska. Zapewnia to poprawne
  wysłanie AJAX i CSRF, zamiast niepewnego własnego przycisku HTML.
- Identyfikatory organizacji i właściciela Suite są opcjonalne podczas
  samodzielnego bootstrapu; nazwa organizacji nie jest technicznym ID.

## 1.5.2 — 2026-08-10

- Naprawiono pozornie nieaktywne przyciski konfiguracji: przeglądarka już nie
  blokuje wysłania formularza przez wstępną walidację wszystkich pól. Plesk
  zapisuje formularz lub pokazuje błąd przy konkretnym polu.
- Domena jest wybierana z aktywnych domen Pleska, a `https://domena` uzupełnia
  się automatycznie po jej zmianie.
- Dodano czytelny szybki start, przykładowe wartości, przełącznik automatycznej
  konfiguracji nginx / ręcznych Docker Proxy Rules i automatyczne generowanie
  brakujących sekretów aplikacji przy pierwszym zapisie.

## 1.5.1 — 2026-08-10

- Tryb automatycznego vhosta ma teraz jawną gwarancję, że nie zapisze gołego
  `location /`, które koliduje z lokalizacją generowaną przez Pleska.
- Manager odrzuca istniejący konflikt w `vhost_nginx.conf` przed zmianą pliku,
  a zarządzana reguła regexowa omija `/.well-known` używane przy certyfikatach.
- Nieudana walidacja nadal przywraca poprzednią konfigurację i ponownie
  konfiguruje domenę Pleska.

## 1.5.0 — 2026-08-09

- Dodano instalowanie i aktualizowanie pluginów KitsuneColab oraz KitsuneTest
  bezpośrednio z ich repozytoriów, z wyborem brancha i ścieżki rozszerzenia.
- Gdy osobny plugin nie jest zainstalowany, Hub pokazuje jego pełną konfigurację
  startową i przekazuje ją jednorazowym, chronionym profilem podczas instalacji.
- Zainstalowany plugin jest automatycznie wykrywany i pozostaje właścicielem
  swojej konfiguracji; aktualizacja z Huba nie nadpisuje jego sekretów ani ścieżek.
- Repozytoria prywatne obsługują token HTTPS, a Colab także klucz SSH z
  obowiązkowym, przypiętym `known_hosts`; dane uwierzytelniające nie trafiają do URL.
- Paczka instalacyjna powstaje wyłącznie ze śledzonego drzewa Git, a checkout
  zarządzany przez Hub wymaga czystego stanu i aktualizacji fast-forward.

## 1.4.0 — 2026-08-09

- Dodano zakładkę Kitsune Suite z automatycznym wykrywaniem samodzielnych
  pluginów KitsuneColab i KitsuneTest oraz kontrolą zgodności manifestu API.
- Hub może bezpiecznie instalować lub aktualizować paczki ZIP obu pluginów,
  delegować wdrożenie i backup oraz pokazywać stan połączenia każdego produktu.
- Paczki są sprawdzane pod kątem ścieżek, rozmiaru, SHA-256, identyfikatora
  rozszerzenia i produktu; profile delegowania są opt-in i wymagają praw `0600`.
- Dodano opcjonalny protokół Suite v1: automatyczne tworzenie projektów w
  Colabie i Teście, trwałą kolejkę retry oraz odbiór issue i wyników testów.
- Wszystkie trzy produkty nadal działają niezależnie, gdy URL-e Suite pozostają
  puste; awaria satelity nie blokuje pracy Huba.

## 1.2.0 — 2026-07-27

- Przebudowano manager zgodnie z układem rozszerzenia NailIT: `Stan i wersje`,
  `Aktualizacja i wdrożenie`, `Konfiguracja`, `Dane i backup` oraz `Dziennik`.
- Ekran główny porównuje dla każdego modułu wersję wdrożoną, wersję lokalnej
  kopii i wersję dostępną w `origin`, wraz z commitem repozytorium i stanem usług.
- Zastąpiono niejednoznaczne Deploy/Redeploy czterema operacjami: sprawdzenie,
  aktualizacja lokalnej kopii, wdrożenie z lokalnej kopii oraz pobranie i
  wdrożenie.
- Dodano wybór modułów. `collab-server` i `worker` są bezpiecznie aktualizowane
  razem jako serwer współpracy, a `web` jako niezależny edytor webowy.
- Obrazy używają osobnych tagów `KPC_SERVER_VERSION` i `KPC_WEB_VERSION`, więc
  późniejsze odtworzenie kontenera nie aktualizuje niewybranego modułu.
- Usunięto z panelu zduplikowane Start/Stop/Restart i pobieranie surowych logów;
  te zadania pozostają w rozszerzeniu Docker Pleska.
- Backup i restore przeniesiono do osobnej zakładki. Aktualizacja serwera nadal
  automatycznie zabezpiecza istniejącą bazę, a dane i konfiguracja pozostają poza
  repozytorium.

## 1.1.7 — 2026-07-26

- Naprawiono restart kontenera `web` z błędem `open /etc/caddy/Caddyfile:
  permission denied`. Bezpieczny `umask 0077` zadania Pleska nadawał plikowi
  źródłowemu tryb `0600`, który Docker zachowywał w obrazie.
- Manager przed każdym buildem i rollbackiem ustawia jawny tryb `0644` wyłącznie
  dla niesekretnego `deploy/Caddyfile`. Dzięki temu poprawka działa również ze
  starszym Dockerfile obecnym już na serwerze.
- Dockerfile edytora dodatkowo używa `COPY --chmod=0644`, więc wynik obrazu nie
  zależy od uprawnień checkoutu ani ustawień hosta.
- Diagnostyka rozpoznaje ten konkretny błąd i wskazuje konieczność przebudowania
  obrazu przez Redeploy.

## 1.1.6 — 2026-07-26

- Healthcheck kontenera `web` sprawdza teraz lokalny endpoint Caddy `/healthz`,
  a nie API przez DNS sieci Compose. Każda usługa odpowiada więc wyłącznie za
  własny stan.
- Końcowa kontrola managera używa tego samego endpointu co Docker Compose.
- Nieudany Start, Deploy, Restore lub Rollback pokazuje stan wszystkich
  kontenerów i ostatnie logi, a komunikat potwierdza, że dane nie zostały
  usunięte.

## 1.1.5 — 2026-07-26

- Deploy nie instaluje już zależności Node.js na hoście. Obrazy budują je
  wewnątrz kontrolowanego środowiska Node 20 z Dockerfile.
- Dockerfile serwera i edytora instalują przypięty pnpm 9.12.0 bezpośrednio przez
  npm, bez zależności od wersji i podpisów Corepack.
- Backup i restore uruchamiają sprawdzone narzędzia w jednorazowym, odizolowanym
  kontenerze `collab-server`, więc nie zależą od hostowego Node, pnpm, Pythona ani
  `node-gyp`.
- Narzędzie danych ma wyłączoną sieć, system plików tylko do odczytu, ograniczenia
  CPU/RAM/PID i dostęp wyłącznie do repozytorium, danych oraz backupów.
- Restore zatrzymuje zarówno API, jak i worker; po odtworzeniu serwer wykonuje
  migracje przy starcie, a manager czeka na healthcheck.

## 1.1.4 — 2026-07-26

- Na Node.js 24 przypięty pnpm 9.12 jest uruchamiany przez npm przed próbą użycia
  starego Corepack, co omija awarię zakończoną ostrzeżeniem `DEP0169`.
- Przed wykrywaniem narzędzi usuwany jest lokalny wrapper z poprzedniej operacji,
  więc nie może ponownie wskazać niedziałającego Corepack.
- Błąd procesu zawiera teraz jednocześnie `stderr` i `stdout`, dzięki czemu
  ostrzeżenie nie ukrywa właściwej przyczyny niepowodzenia.

## 1.1.3 — 2026-07-26

- Zadania Pleska rozszerzają ograniczony `PATH` o standardowe katalogi, Plesk
  Node.js Toolkit, root NVM i lokalizacje pnpm użytkownika root.
- Manager wykrywa kolejno pnpm, Corepack albo npm i może uruchomić przypięty
  pnpm 9.12 bez ręcznej instalacji globalnej.
- Root-only wrapper w katalogu stanu przekazuje wywołania `pnpm` ze starszej
  kopii kodu do wykrytego narzędzia bez modyfikowania globalnego środowiska.
- Deploy wykonuje kontrolę Node.js/pnpm z czytelnym komunikatem i instaluje tylko
  zależności serwera potrzebne do backupu oraz migracji.

## 1.1.2 — 2026-07-26

- Ścieżki wdrożenia mogą teraz znajdować się w katalogu `/home`, więc poprawny
  układ taki jak `/home/pnc/source` nie jest już błędnie odrzucany.
- Formularz pokazuje gotowy przykład czterech katalogów, automatycznie dopisuje
  `/deploy` i wyświetla przyczynę bezpośrednio pod każdym błędnym polem.
- Poszerzono pola formularza, aby pełne ścieżki były czytelne bez przewijania.

## 1.1.1 — 2026-07-26

- Błędny formularz nie wykonuje już redirectu i zachowuje wszystkie bezpieczne
  wartości wpisane przez administratora.
- Komunikat walidacji wymienia konkretne pola oraz podaje oczekiwany format,
  zakres albo zależność między wartościami.
- Dodano walidację w przeglądarce dla ścieżek, domeny, URL, portów, SMTP,
  administratorów i sekretów, aby wykryć problem przed wysłaniem formularza.
- Sekrety nie są ponownie umieszczane w HTML odpowiedzi; po błędzie serwera mogą
  wymagać ponownego wpisania, natomiast błędy klienckie nie czyszczą pól.

## 1.1.0 — 2026-07-26

- Nowy dashboard operacyjny z czytelnym stanem platformy, repozytorium, Dockera,
  reverse proxy i ostatnich zadań.
- Osobne karty serwera współpracy, workera i edytora webowego pokazują nazwę
  kontenera, stan, healthcheck, obraz, wersję oraz mapowania portów.
- Dodano zalecany tryb Plesk Docker Proxy Rules oraz zachowano opcjonalny,
  automatycznie zarządzany blok nginx.
- Wszystkie nieoczywiste pola konfiguracji i operacje mają opisy skutków oraz
  bezpiecznych wartości.
- Status obsługuje zarówno tablicę JSON, jak i JSON Lines zwracane przez różne
  wersje Docker Compose.

## 1.0.1 — 2026-07-26

- Poprawiono punkt wejścia panelu: kontekst modułu jest inicjalizowany przed
  uruchomieniem aplikacji MVC Pleska.

## 1.0.0 — 2026-07-26

- Pierwsze wydanie: status, Git sync, deploy/redeploy, start/stop/restart, logi.
- Pełne wdrożenie serwera współpracy, workera i edytora webowego na lokalnych portach.
- Automatyczny, odwracalny reverse proxy wybranej domeny Pleska z obsługą WebSocket.
- Konfiguracja SMTP i opcjonalnej weryfikacji kont; dane SMTP trafiają także do workera.
- Obsługa przypiętego `known_hosts`, osobna blokada statusu i widoczna wersja rozszerzenia.
- Zgodność uprzywilejowanego launchera z PHP 7.3+ oraz ścisła walidacja katalogu pliku operacji.
- Aktualizacja blokuje się przy lokalnych zmianach Git, zachowuje trwałe dane i wykonuje backup przed redeployem.
- Pełny backup SQLite i storage z manifestem oraz SHA-256.
- Restore z weryfikacją integralności i jawnym potwierdzeniem.
- Rollback do ostatniego wdrożonego commita.
- Szyfrowane sekrety Pleska, blokada równoległych operacji i redakcja logów.
