# Changelog

## 1.4.13-2 — 2026-08-20

- Dodano wspólną powłokę Kitsune Plesk Suite i odnośnik do centralnego zarządzania.
- Własny wpis menu jest ukrywany wyłącznie przy aktywnym Kitsune Hub.

## 1.4.13 — 2026-08-17

- Dodano brakującą zmienną `NEXT_PUBLIC_WEBRTC_ICE_SERVERS` do produkcyjnego `.env.production` generowanego przez
  manager Plesk, dzięki czemu `docker compose` z profilem produkcyjnym nie kończy się błędem wymaganej zmiennej.

## 1.4.12 — 2026-08-17

- Plugin naprawia deploy/redeploy produkcyjny, automatycznie ustawiając `OUTBOUND_ALLOWED_DOMAINS`
  podczas zapisu `deploy/.env.production` (domyślnie host publiczny `webPublicUrl`).
- Dodano opcjonalne pole konfiguracyjne `outboundAllowedDomains`, aby ręcznie wskazać
  dozwolone hosty dla ruchu wychodzącego API.

## 1.4.11 — 2026-08-12

- `minio-init` i `migrate` zakończone kodem `0` są oznaczane jako poprawne zadania jednorazowe.
- Panel otrzymał wspólny styl managerów Kitsune: hero ze zdrowiem, karty statusu i uporządkowane sekcje.

## 1.4.10 — 2026-08-12

- Runner obsługuje starsze PHP Pleska, przekazując do `proc_open` bezpiecznie złożony łańcuch polecenia.
- Zakładki działają natywnie przez HTML/CSS także po nawigacji AJAX panelu.
- Stan jest publikowany atomowo z prawami `0640` dla konta `psaadm`.

## 1.4.9 — 2026-08-12

- Profile Kitsune Suite są zapisywane do prywatnego pliku tymczasowego i
  atomowo publikowane. Pozwala to odzyskać instalację po starym pliku `0600`
  należącym do niewłaściwego użytkownika bez otwierania dostępu do sekretów.
- Plugin weryfikuje katalog, właściciela i tryb pliku przed oraz po podmianie,
  a symlinki i wpisy inne niż zwykły plik są nadal odrzucane.

## 1.4.8 — 2026-08-12

- Import konfiguracji z Huba bezpiecznie naprawia tryb bootstrapu na `0600`,
  jeśli Plesk podczas kopiowania wpisu ZIP zastosował własny `umask`. Przed
  odczytem plugin nadal wymaga prywatnego katalogu, dokładnej ścieżki, braku
  symlinków i tego samego właściciela pliku oraz katalogu.

## 1.4.7 — 2026-08-12

- Hook po instalacji normalizuje publiczne katalogi i pliki pluginu, gdy
  nadrzędny proces przekazał Pleskowi `umask 0077`. Przywraca to nazwę
  rozszerzenia, akcję Open, kontroler WWW oraz boczne menu.
- Katalog stanu i sekrety pozostają prywatne (`0700`/`0600`).
- Lista oraz dashboard oznaczają projekt synchronizowany z Hubem; jego nazwa,
  opis i usunięcie nadal są kontrolowane wyłącznie przez Hub.

## 1.4.6 — 2026-08-12

- Inicjalizacja, backup i restore MinIO kończą parsowanie opcji przed
  przekazaniem access key i secret key. Losowy sekret zaczynający się od `-`
  nie jest już traktowany przez `mc` jak flaga, więc `minio-init` poprawnie
  tworzy bucket, a API nie kończy wdrożenia odpowiedzią `502`.

## 1.4.5 — 2026-08-11

- Ponowna instalacja pluginu uzgadnia hasło istniejącej roli PostgreSQL z
  nowym sekretem Pleska przed migracją, zachowując wolumen i dane.
- Redis ładuje zachowany AOF przez chronionego hasłem użytkownika domyślnego;
  nie odrzuca już transakcji komunikatem `NOPERM` po zmianie ACL. Konto
  aplikacji i healthcheck nadal pozostają rozdzielone.
- Deploy, start, restart i ręczne migracje przygotowują infrastrukturę oraz
  dane uwierzytelniające przed uruchomieniem API, eliminując wynikowe `502`.
- Karta rozszerzenia korzysta z ikon Kitsune 32/64/128 px zamiast domyślnej
  ikony pakietu Pleska.
- Metadane rozszerzenia mają poprawną kategorię `developer` oraz rzeczywiste
  adresy repozytorium i zgłoszeń.

## 1.4.4 — 2026-08-11

- Wydanie naprawcze wymusza ponowne skopiowanie entrypointu WWW, kontrolera i
  hooka menu po niekompletnej instalacji wcześniejszego managera.
- Zachowano kanoniczny routing Pleska oraz widoczność w menu administratora i
  w trybie Power User.

## 1.4.3 — 2026-08-11

- Workspace Huba są tworzone jako zarządzane organizacje podrzędne, a projekty
  i role są synchronizowane bez odbierania samodzielności lokalnym zasobom.
- Rekordy pochodzące z Huba są oznaczone i chronione przed lokalną zmianą nazwy
  lub usunięciem.
- Przejście SSO kończy się bezpośrednio na dashboardzie bez mignięcia formularza
  logowania, a menu Pleska korzysta z kanonicznej trasy modułu.

## 1.4.2 — 2026-08-11

- Cookie sesji federacyjnej otrzymuje ścieżkę odpowiadającą publicznemu
  prefiksowi API, więc logowanie z Huba działa także za reverse proxy `/api`.
- Przycisk logowania nie tworzy podwójnego `/api/api` niezależnie od sposobu
  publikacji API.
- Manager rejestruje menu i adres panelu przez router akcji SDK Pleska, bez
  niezgodnego mieszania sekcji nawigacji.

## 1.4.1 — 2026-08-11

- Usunięto podwójne `/api/api` z callbacku logowania Kitsune Suite.
- Start i callback SSO wysyłają jednoznaczne odpowiedzi HTTP 302.
- Manifest Suite raportuje wersję aplikacji oraz dokładny wdrożony commit.
- Wejście managera uruchamia aplikację Pleska zamiast przekierowywać ponownie
  na ten sam adres, a skrót jest widoczny w obu trybach nawigacji i w
  Narzędziach i ustawieniach.

## 1.4.0 — 2026-08-11

- Dodano logowanie z KitsuneHub z kodem jednorazowym, PKCE i synchronizacją ról.
- Tożsamości hubowe nie mają lokalnego hasła i są wiązane po `(issuer, sub)`;
  lokalne konta KitsuneTest pozostają niezależne.
- Token dostępu nie jest umieszczany w URL: callback ustawia HttpOnly refresh
  cookie, a panel kończy sesję przez standardowy endpoint odświeżania.
- Przy pustym ID organizacji pierwszy login tworzy tenant `kitsune-suite`.

## 1.3.4-1 — 2026-08-11

- Entrypointy MinIO i API odczytują chronione pliki `0600` jako root, po czym bezwarunkowo zrzucają uprawnienia do dedykowanych użytkowników; Redis kopiuje ACL do prywatnego tmpfs przed zrzuceniem uprawnień.
- Błąd Compose dołącza stan i końcówkę logów kontenerów, zamiast zwracać wyłącznie ogólny status `unhealthy`.

## 1.3.3-1 — 2026-08-11

- Automatyczne wykrywanie zgodnego Node.js z Plesk Node.js Toolkit oraz fallback pnpm przez Corepack.
- Automatyczny wybór i zapamiętywanie rozłącznych portów produkcyjnego Docker Compose.
- Reguły proxy zarządzanego i ręcznego używają faktycznie przydzielonych portów.
- Deploy, start, restart, migracje i logi używają Docker Compose bezpośrednio i nie wymagają Node.js ani pnpm na hoście Pleska.
- Długie buildy Compose odczytują stdout i stderr równolegle, bez ryzyka zakleszczenia na pełnym buforze procesu.

## 1.3.2-2 — 2026-08-11

- Uprzywilejowany manager obsługuje ścisły tryb
  `--import-suite-bootstrap`, który ładuje SDK Pleska, inicjalizuje kontekst
  KitsuneTest i importuje oczekującą konfigurację niezależnie od lifecycle
  hooka aktualizacji rozszerzenia.
- Import zachowuje walidację czasu, produktu i praw pliku, zapisuje sekrety w
  magazynie Pleska, odświeża profile Suite i usuwa jednorazowy bootstrap.
- Launcher managera jest oznaczony w repozytorium jako wykonywalny, dzięki
  czemu instalacja nie zależy od `chmod` w lifecycle hooku Pleska.

## 1.3.1 — 2026-08-11

- Dodano trwały skrypt `import-suite-bootstrap.php`, uruchamiany przez Hub po
  aktualizacji wtedy, gdy jednorazowy lifecycle hook Pleska nie zachował się na
  serwerze.
- Importer działa w kontekście KitsuneTest, zapisuje ustawienia i sekrety przez
  magazyn Pleska, odświeża discovery i usuwa jednorazowy bootstrap.

## 1.3.0 — 2026-08-11

- Dodano pełne uwierzytelnianie repozytorium SSH (`known_hosts` i szyfrowany
  deploy key) oraz obsługę dedykowanych kopii w `/home`, `/srv`, `/var/lib` i
  `/var/backups`, nie tylko w `/opt`.
- Aktualizacja wykonywana przez Hub uzgadnia dane Git oraz wspólny sekret i
  zachowuje istniejące sekrety aplikacji.
- Jedna domena Pleska obsługuje panel, API pod `/api`, manifest Suite oraz
  readiness; plugin automatycznie utrzymuje bezkolizyjny vhost nginx.
- Tryb ręczny wyświetla równoważną konfigurację bez `location /`.

## 1.2.0 — 2026-08-09

- Dodano jednorazowy, chroniony import konfiguracji startowej z KitsuneHub dla
  instalacji repozytoryjnej.
- Plugin publikuje bezsekretowy profil wykrywania z informacją o repozytorium,
  branchu, publicznym API i stanie delegowania.
- Samodzielna konfiguracja pluginu pozostaje nadrzędna i nie jest nadpisywana
  podczas aktualizacji wykonywanej przez Hub.
- Poprawiono ścieżkę uprzywilejowanego managera wywoływanego po instalacji.

## 1.1.0 — 2026-08-09

- Dodano opcjonalny protokół Kitsune Suite v1 i publiczny manifest wykrywania.
- Projekty Huba są automatycznie provisionowane w skonfigurowanej organizacji.
- Zakończone przebiegi testowe trafiają przez trwałą kolejkę do Huba i Colaba;
  nieudany test może automatycznie utworzyć bug w Colabie.
- Samodzielny plugin Plesk udostępnia wyłączone domyślnie, chronione prawami
  `0600` delegowanie redeployu i backupu z KitsuneHub.
- Sekret integracyjny jest szyfrowany przez Pleska i maskowany w logach.

## 1.0.0 — 2026-07-16

- Pierwsze wydanie panelu administracyjnego i uprzywilejowanego runnera.
- Deploy/redeploy, start, stop, restart, migracje, logi i healthcheck.
- Pełny backup/restore przez centralny runner projektu, retencja, weryfikacja manifestu i SHA-256.
- Szyfrowane sekrety Pleska, blokada równoległych operacji, maskowanie logów i ochrona ścieżek.
