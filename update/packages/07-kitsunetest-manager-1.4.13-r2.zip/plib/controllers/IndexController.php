<?php

class IndexController extends pm_Controller_Action
{
    protected $_accessLevel = 'admin';

    public function init()
    {
        parent::init();
        $this->view->pageTitle = 'KitsuneTest Deployment Manager';
        $this->view->headLink()->appendStylesheet(pm_Context::getBaseUrl() . 'css/kitsunetest.css?v=1.4.13');
        $this->view->headLink()->appendStylesheet(pm_Context::getBaseUrl() . 'css/kitsune-suite.css?v=1.4.13');
        $this->view->headLink()->appendStylesheet(pm_Context::getBaseUrl() . 'css/kitsune-platform.css?v=1');
        $this->view->headScript()->appendFile(pm_Context::getBaseUrl() . 'js/kitsune-platform.js?v=1');
        $this->view->suiteProduct = 'KitsuneTest Manager';
        $this->view->suiteVersion = Modules_KitsunetestManager_Config::EXTENSION_VERSION;
        try { $this->view->suiteHubActive = pm_Extension::getById('kitsuneserv-bridge')->isActive(); }
        catch (Throwable $exception) { $this->view->suiteHubActive = false; }
    }

    public function indexAction()
    {
        Modules_KitsunetestManager_Config::importSuiteBootstrap();
        Modules_KitsunetestManager_Config::refreshSuiteDiscovery();
        if (!$this->getRequest()->isPost()) {
            $this->refreshState();
        }
        $configForm = $this->createConfigForm();
        $operationForm = $this->createOperationForm();
        if ($this->getRequest()->isPost()) {
            $post = $this->getRequest()->getPost();
            if ((string) ($post['formType'] ?? '') === 'config') {
                $this->processConfig($configForm, $post);
            } elseif ((string) ($post['formType'] ?? '') === 'operation') {
                $this->processOperation($operationForm, $post);
            }
        }
        $this->view->configForm = $configForm;
        $this->view->operationForm = $operationForm;
        $this->view->config = Modules_KitsunetestManager_Config::values();
        $this->view->state = Modules_KitsunetestManager_Config::readState();
        $this->view->hasGitToken = Modules_KitsunetestManager_Config::hasSecret('gitToken');
        $this->view->hasGitSshPrivateKey = Modules_KitsunetestManager_Config::hasSecret('gitSshPrivateKey');
        $this->view->hasSuiteSharedSecret = Modules_KitsunetestManager_Config::hasSecret('suiteSharedSecret');
    }

    private function createConfigForm()
    {
        $values = Modules_KitsunetestManager_Config::values();
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kitsune-config-form');
        $form->addElement('hidden', 'formType', ['value' => 'config']);
        $form->addElement('text', 'repositoryUrl', [
            'label' => 'Repozytorium Git', 'value' => $values['repositoryUrl'], 'required' => true,
            'description' => 'HTTPS lub SSH. Token HTTPS jest przechowywany oddzielnie i szyfrowany przez Pleska.',
            'validators' => [['StringLength', true, ['min' => 5, 'max' => 1000]]],
        ]);
        $form->addElement('text', 'repositoryBranch', [
            'label' => 'Branch', 'value' => $values['repositoryBranch'], 'required' => true,
            'validators' => [['Regex', true, ['pattern' => '/^(?![-.])(?!.*\.\.)(?!.*@\{)[A-Za-z0-9._\/-]+$/']]],
        ]);
        $form->addElement('text', 'repositoryPath', [
            'label' => 'Ścieżka instalacji', 'value' => $values['repositoryPath'], 'required' => true,
            'description' => 'Dedykowana kopia robocza, np. /opt/kitsunetest/source albo /home/kitsunetest/source.',
            'validators' => [['Regex', true, ['pattern' => '#^/(?:home|opt|srv|var/lib|var/backups)/[A-Za-z0-9._/-]+$#']]],
        ]);
        $form->addElement('text', 'gitUsername', [
            'label' => 'Użytkownik Git HTTPS', 'value' => $values['gitUsername'],
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 255]]],
        ]);
        $form->addElement('password', 'gitToken', [
            'label' => 'Token Git', 'value' => '',
            'description' => Modules_KitsunetestManager_Config::hasSecret('gitToken') ? 'Token jest zapisany i zaszyfrowany; puste pole zachowa wartość.' : 'Opcjonalny dla repozytorium publicznego.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 2000]]],
        ]);
        $form->addElement('textarea', 'gitSshKnownHosts', [
            'label' => 'SSH known_hosts', 'value' => $values['gitSshKnownHosts'], 'rows' => 4,
            'description' => 'Dla repozytorium SSH Hub uzupełnia to pole automatycznie. StrictHostKeyChecking pozostaje włączone.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 8000]]],
        ]);
        $form->addElement('textarea', 'gitSshPrivateKey', [
            'label' => 'Klucz SSH repozytorium', 'value' => '', 'rows' => 7,
            'description' => Modules_KitsunetestManager_Config::hasSecret('gitSshPrivateKey') ? 'Klucz jest zapisany i zaszyfrowany; puste pole zachowa wartość.' : 'Read-only deploy key bez hasła, wymagany dla prywatnego repozytorium SSH.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 8000]]],
        ]);
        foreach ([
            'jwtSecret' => ['Sekret JWT', 32],
            'masterKey' => ['Klucz główny szyfrowania', 32],
            'githubWebhookSecret' => ['Sekret webhooka GitHub', 32],
            'databasePassword' => ['Hasło PostgreSQL', 24],
            'redisPassword' => ['Hasło Redis', 24],
            'minioAccessKey' => ['Klucz dostępu MinIO', 16],
            'minioSecretKey' => ['Sekret MinIO', 32],
        ] as $name => $definition) {
            $saved = Modules_KitsunetestManager_Config::hasSecret($name);
            $form->addElement('password', $name, [
                'label' => $definition[0], 'value' => '',
                'description' => $saved ? 'Sekret jest zapisany i zaszyfrowany; puste pole zachowa wartość.' : 'Wymagany przed wdrożeniem produkcyjnym.',
                'validators' => [['Regex', true, ['pattern' => '/^$|^[A-Za-z0-9._~-]{' . $definition[1] . ',256}$/']]],
            ]);
        }
        $form->addElement('select', 'publicDomain', [
            'label' => 'Domena KitsuneTest', 'value' => $values['publicDomain'], 'required' => true,
            'multiOptions' => ['' => '— wybierz domenę Pleska —'] + $this->domainOptions($values['publicDomain']),
            'description' => 'Jedna domena obsługuje panel, API (/api) i readiness (/readyz).',
        ]);
        $form->addElement('select', 'proxyMode', [
            'label' => 'Konfiguracja vhosta', 'value' => $values['proxyMode'],
            'multiOptions' => ['managed' => 'Automatycznie przez plugin', 'manual' => 'Ręcznie w panelu Pleska'],
            'description' => 'Automatycznie: plugin utrzymuje reguły panelu i API. Ręcznie: pokaże bezpieczny kod bez location /.',
        ]);
        $form->addElement('text', 'outboundAllowedDomains', [
            'label' => 'Domeny wyjścia (OUTBOUND_ALLOWED_DOMAINS)', 'value' => $values['outboundAllowedDomains'],
            'description' => 'Lista domen oddzielonych przecinkiem dla ograniczenia połączeń wychodzących API; puste pole oznacza host strony web.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 500]]],
        ]);
        $form->addElement('simpleText', 'suiteHeader', [
            'label' => '', 'escape' => false,
            'value' => '<div class="kitsune-note"><strong>Kitsune Suite</strong><br>Połączenie jest opcjonalne; bez URL-i KitsuneTest pozostaje w pełni samodzielny.</div>',
        ]);
        foreach ([
            'suiteHubUrl' => ['URL API KitsuneHub', $values['suiteHubUrl']],
            'suiteColabUrl' => ['URL API KitsuneColab', $values['suiteColabUrl']],
        ] as $name => $definition) {
            $form->addElement('text', $name, [
                'label' => $definition[0], 'value' => $definition[1],
                'description' => 'Opcjonalny bazowy adres HTTPS bez ścieżki. Puste pole zachowuje tryb samodzielny.',
                'validators' => [['Regex', true, ['pattern' => '#^$|^https://[^\s/]+(?::\d+)?/?$#i']], ['StringLength', true, ['max' => 1000]]],
            ]);
        }
        $form->addElement('text', 'suiteOrganizationId', [
            'label' => 'ID nadrzędnej organizacji Suite', 'value' => $values['suiteOrganizationId'],
            'description' => 'Techniczne ID wspólnej ekipy. Workspace’y Huba będą pod nią osobnymi organizacjami.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 200]]],
        ]);
        $form->addElement('text', 'suiteOrganizationName', [
            'label' => 'Nazwa nadrzędnej organizacji Suite', 'value' => $values['suiteOrganizationName'],
            'description' => 'Widoczna nazwa wspólnej ekipy, np. Chaos Group Games. Nazwy organizacji podrzędnych są synchronizowane z Hubem.',
            'validators' => [['StringLength', true, ['min' => 1, 'max' => 120]]],
        ]);
        $form->addElement('password', 'suiteSharedSecret', [
            'label' => 'Wspólny sekret Suite', 'value' => '',
            'description' => Modules_KitsunetestManager_Config::hasSecret('suiteSharedSecret') ? 'Sekret jest zapisany; puste pole zachowa wartość.' : 'Minimum 32 losowe znaki, identyczne w trzech produktach.',
            'validators' => [['Regex', true, ['pattern' => '/^$|^.{32,512}$/s']]],
        ]);
        $form->addElement('checkbox', 'suiteControlEnabled', [
            'label' => 'Zezwól Hubowi na wdrożenie',
            'value' => $values['suiteControlEnabled'] === '1' ? '1' : '0',
            'description' => 'Eksportuje chroniony profil 0600, z którego plugin KitsuneHub może zlecić status, redeploy i backup.',
        ]);
        $form->addElement('text', 'backupRetentionCount', [
            'label' => 'Liczba zachowanych backupów', 'value' => $values['backupRetentionCount'], 'required' => true,
            'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 365]]],
        ]);
        $this->submitButton($form, 'Zapisz konfigurację');
        return $form;
    }

    private function createOperationForm()
    {
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kitsune-operation-form');
        $form->addElement('hidden', 'formType', ['value' => 'operation']);
        $form->addElement('select', 'operation', [
            'label' => 'Operacja', 'value' => 'status', 'required' => true,
            'multiOptions' => [
                'status' => 'Odśwież stan', 'sync' => 'Synchronizuj repozytorium', 'install' => 'Zainstaluj zależności',
                'build' => 'Build produkcyjny', 'migrate' => 'Zastosuj migracje',
                'deploy' => 'Deploy', 'redeploy' => 'Synchronizuj i redeploy', 'rollback' => 'Rollback do poprzedniego commita',
                'start' => 'Uruchom usługi', 'stop' => 'Zatrzymaj usługi', 'restart' => 'Restart usług', 'logs' => 'Odśwież logi',
                'backup' => 'Pełny backup', 'restore' => 'Restore backupu (wymaga RESTORE)',
            ],
        ]);
        $form->addElement('text', 'backupName', [
            'label' => 'Nazwa backupu dla restore', 'value' => '',
            'description' => 'Format kitsune-YYYYMMDDTHHMMSSZ; inne ścieżki są odrzucane.',
            'validators' => [['Regex', true, ['pattern' => '/^$|^kitsune-\d{8}T\d{6}Z$/']]],
        ]);
        $form->addElement('text', 'confirmation', [
            'label' => 'Potwierdzenie operacji destrukcyjnej', 'value' => '',
            'description' => 'Wpisz RESTORE dla operacji restore.',
            'validators' => [['Regex', true, ['pattern' => '/^$|^RESTORE$/']]],
        ]);
        $this->submitButton($form, 'Uruchom operację');
        return $form;
    }

    private function processConfig(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) {
            return;
        }
        $values = $form->getValues();
        $domain = strtolower(trim((string) ($values['publicDomain'] ?? '')));
        if (!isset($this->domainOptions()[$domain])) {
            $form->getElement('publicDomain')->addError('Wybierz aktywną domenę z listy Pleska.');
            return;
        }
        $values['publicDomain'] = $domain;
        $values['webPublicUrl'] = 'https://' . $domain;
        $values['apiPublicUrl'] = 'https://' . $domain;
        $values['healthUrl'] = 'https://' . $domain . '/readyz';
        $values['suiteControlEnabled'] = !empty($values['suiteControlEnabled']) ? '1' : '0';
        $suiteSecret = trim((string) ($values['suiteSharedSecret'] ?? $post['suiteSharedSecret'] ?? ''));
        $hasSuitePeer = trim((string) ($values['suiteHubUrl'] ?? '')) !== '' || trim((string) ($values['suiteColabUrl'] ?? '')) !== '';
        if ($hasSuitePeer && !Modules_KitsunetestManager_Config::hasSecret('suiteSharedSecret') && $suiteSecret === '') {
            $form->getElement('suiteSharedSecret')->addError('Ustaw wspólny sekret Suite o długości minimum 32 znaków.');
            $this->_status->addMessage('error', 'Nie zapisano konfiguracji Suite: brakuje wspólnego sekretu.');
            return;
        }
        Modules_KitsunetestManager_Config::save($values);
        $this->_status->addMessage('info', 'Konfiguracja została zapisana. Sekretów nie pokazano ponownie.');
        $this->respondWithRedirect();
    }

    private function processOperation(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) {
            return;
        }
        $operation = (string) $form->getValue('operation');
        $backupName = (string) $form->getValue('backupName');
        $confirmation = (string) $form->getValue('confirmation');
        if ($operation === 'restore' && ($confirmation !== 'RESTORE' || !preg_match('/^kitsune-\d{8}T\d{6}Z$/', $backupName))) {
            $this->_status->addMessage('error', 'Restore wymaga prawidłowej nazwy backupu i potwierdzenia RESTORE.');
            return;
        }
        try {
            $runtimeConfig = Modules_KitsunetestManager_Config::createRuntimeConfig($operation, ['backupName' => $backupName, 'confirmation' => $confirmation]);
            $task = new Modules_KitsunetestManager_Task_Operation();
            $task->setParam('runtimeConfig', $runtimeConfig);
            $task->setParam('operation', $operation);
            $manager = new pm_LongTask_Manager();
            $manager->start($task);
            $this->_status->addMessage('info', 'Operacja została dodana do kolejki Pleska.');
            $this->respondWithRedirect();
        } catch (Exception $exception) {
            $this->_status->addMessage('error', 'Nie udało się uruchomić operacji: ' . $exception->getMessage());
        }
    }

    private function domainOptions($saved = '')
    {
        $options = [];
        try {
            foreach ((array) pm_Domain::getAllDomains() as $domain) {
                if (!$domain instanceof pm_Domain || !$domain->hasHosting() || !$domain->isActive() || $domain->isSuspended() || $domain->isDisabled()) continue;
                $name = strtolower(trim((string) $domain->getName()));
                if (preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/', $name)) $options[$name] = $name;
            }
        } catch (Throwable $exception) { /* Plesk exposes no hosting domains yet. */ }
        natcasesort($options);
        return $options;
    }

    private function submitButton(pm_Form_Simple $form, $label)
    {
        $id = preg_replace('/[^A-Za-z0-9_-]/', '-', (string) $form->getAttrib('id')) . '-submit';
        $form->addElement('simpleText', $id, ['label' => '', 'escape' => false,
            'value' => '<div class="kitsune-action-row"><button type="submit" name="send" value="1" id="' . htmlspecialchars($id, ENT_QUOTES, 'UTF-8') . '" class="kitsune-primary-action">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</button></div>',
        ]);
    }

    private function respondWithRedirect()
    {
        $path = '/modules/kitsunetest-manager/index.php/index/index';
        if ($this->getRequest()->isXmlHttpRequest()) {
            $this->_helper->json(['redirect' => $path]);
            return;
        }
        $host = preg_replace('/[^A-Za-z0-9.:-]/', '', (string) ($_SERVER['HTTP_HOST'] ?? ''));
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $this->getResponse()->setRedirect($host !== '' ? $scheme . '://' . $host . $path : $path, 303);
        $this->_helper->viewRenderer->setNoRender(true);
    }

    private function refreshState()
    {
        $runtimeConfig = null;
        try {
            $runtimeConfig = Modules_KitsunetestManager_Config::createRuntimeConfig('status');
            $result = pm_ApiCli::callSbin('kitsunetest-manager', ['--config', $runtimeConfig], pm_ApiCli::RESULT_FULL);
            if ((int) ($result['code'] ?? 1) !== 0) {
                $this->_status->addMessage('warning', 'Nie udało się odświeżyć stanu usług. Sprawdź log rozszerzenia.');
            }
        } catch (Exception $exception) {
            $this->_status->addMessage('warning', 'Stan jest chwilowo niedostępny: ' . $exception->getMessage());
        } finally {
            if ($runtimeConfig && is_file($runtimeConfig)) {
                @unlink($runtimeConfig);
            }
        }
    }
}
