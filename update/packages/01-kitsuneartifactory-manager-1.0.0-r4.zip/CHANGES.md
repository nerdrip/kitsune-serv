# Changelog

## 1.0.0-4 — 2026-08-21

- Standalone self-update now synchronizes and packages the configured product repository instead of reading the KitsuneServ bundle manifest.

## 1.0.0-2 — 2026-08-20

- Added the shared Kitsune Plesk Suite shell and a direct route back to central management.
- The standalone menu entry is hidden only while an active Kitsune Hub owns navigation.

## 1.0.0 — 2026-07-17

- Initial production package for Kitsune Artifactory.
- Encrypted Plesk settings for Git and application secrets.
- Serialized long-running operations with masked logs and bounded history.
- Deploy, health check, rollback, full backup, verified restore, and retention controls.
