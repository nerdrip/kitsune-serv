(function () {
  'use strict';
  document.addEventListener('DOMContentLoaded', function () {
    var operation = document.querySelector('[name="operation"]');
    var confirmWrap = document.querySelector('[data-restore-confirm]');
    var backupWrap = document.querySelector('[data-backup-select]');
    function refresh() {
      var restore = operation && operation.value === 'restore';
      if (confirmWrap) confirmWrap.hidden = !restore;
      if (backupWrap) backupWrap.hidden = !restore;
    }
    if (operation) operation.addEventListener('change', refresh);
    refresh();
    var form = document.getElementById('kitsune-operation-form');
    if (form) form.addEventListener('submit', function (event) {
      if (operation && operation.value === 'restore') {
        var confirmation = form.querySelector('[name="confirmation"]');
        if (!confirmation || confirmation.value !== 'RESTORE') {
          event.preventDefault();
          window.alert('Type RESTORE exactly to confirm.');
          return;
        }
      }
      var button = form.querySelector('[type="submit"]');
      if (button) { button.disabled = true; button.textContent = 'Starting…'; }
    });
  });
}());
