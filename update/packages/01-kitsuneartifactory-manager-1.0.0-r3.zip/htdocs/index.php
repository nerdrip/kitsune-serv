<?php
pm_Context::init('kitsuneartifactory-manager');
echo '<!doctype html><html><head><meta charset="utf-8"><title>Kitsune Manager</title></head><body><p>Open the extension through the Plesk navigation panel.</p></body></html>';
