<?php

class IndexController extends pm_Controller_Action
{
    protected $_accessLevel = 'admin';

    public function init()
    {
        parent::init();
        $this->view->pageTitle = 'Kitsune Artifactory Manager';
        $this->view->headLink()->appendStylesheet(pm_Context::getBaseUrl() . 'css/kitsune.css?v=1.0.0');
        $this->view->headLink()->appendStylesheet(pm_Context::getBaseUrl() . 'css/kitsune-platform.css?v=2');
        $this->view->headScript()->appendFile(pm_Context::getBaseUrl() . 'js/kitsune.js?v=1.0.0');
        $this->view->headScript()->appendFile(pm_Context::getBaseUrl() . 'js/kitsune-platform.js?v=2');
        $this->view->suiteProduct = 'Kitsune Artifactory Manager';
        $this->view->suiteVersion = '1.0.0';
        try { $this->view->suiteHubActive = pm_Extension::getById('kitsuneserv-bridge')->isActive(); }
        catch (Throwable $exception) { $this->view->suiteHubActive = false; }
    }

    public function indexAction()
    {
        $configForm = $this->createConfigForm();
        $operationForm = $this->createOperationForm();
        if ($this->getRequest()->isPost()) {
            $post = $this->getRequest()->getPost();
            if (($post['formType'] ?? '') === 'config') $this->processConfig($configForm, $post);
            if (($post['formType'] ?? '') === 'operation') $this->processOperation($operationForm, $post);
        }
        $this->view->configForm = $configForm;
        $this->view->operationForm = $operationForm;
        $this->view->state = Modules_KitsuneArtifactoryManager_Config::state();
    }

    private function createConfigForm()
    {
        $v = Modules_KitsuneArtifactoryManager_Config::values();
        $form = new pm_Form_Simple();
        $form->addElement('hidden', 'formType', ['value' => 'config']);
        $text = function ($name, $label, $required = true) use ($form, $v) {
            $form->addElement('text', $name, ['label' => $label, 'value' => $v[$name], 'required' => $required, 'validators' => [['StringLength', true, ['min' => $required ? 1 : 0, 'max' => 1900]]]]);
        };
        $text('repositoryUrl', 'Git repository URL');
        $text('repositoryBranch', 'Git branch/tag');
        $text('installPath', 'Managed installation path');
        $text('publicUrl', 'Public HTTPS URL');
        $text('bindAddress', 'Bind address');
        $text('port', 'Application port');
        $text('adminEmail', 'Initial administrator email');
        $text('adminUsername', 'Initial administrator username');
        $text('databaseHost', 'PostgreSQL host');
        $text('databasePort', 'PostgreSQL port');
        $text('databaseName', 'PostgreSQL database');
        $text('databaseUser', 'PostgreSQL user');
        $form->addElement('select', 'storageDriver', ['label' => 'Storage driver', 'value' => $v['storageDriver'], 'multiOptions' => ['local' => 'Local persistent volume', 's3' => 'S3 / MinIO']]);
        $text('storageLocalPath', 'Local storage host path');
        $text('s3Endpoint', 'S3 endpoint (optional)', false);
        $text('s3Region', 'S3 region');
        $text('s3Bucket', 'S3 bucket');
        $text('backupDir', 'Backup directory');
        $text('backupRetention', 'Backup retention count');
        foreach ([
            'gitToken' => 'Git access token', 'jwtSecret' => 'JWT secret', 'adminPassword' => 'Initial administrator password',
            'databasePassword' => 'PostgreSQL password', 'metricsToken' => 'Prometheus metrics token',
            'encryptionKey' => 'Application secret-encryption key', 's3AccessKey' => 'S3 access key', 's3SecretKey' => 'S3 secret key',
        ] as $name => $label) {
            $form->addElement('password', $name, [
                'label' => $label, 'value' => '', 'required' => false,
                'description' => Modules_KitsuneArtifactoryManager_Config::hasSecret($name) ? 'Encrypted value is stored. Leave blank to keep it.' : 'No encrypted value is stored yet.',
                'validators' => [['StringLength', true, ['min' => 0, 'max' => 1900]]],
            ]);
        }
        $form->addElement('submit', 'save', ['label' => 'Save encrypted configuration']);
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function createOperationForm()
    {
        $state = Modules_KitsuneArtifactoryManager_Config::state();
        $backups = ['' => 'Select a backup'];
        foreach (($state['backups'] ?? []) as $backup) {
            if (!empty($backup['name'])) $backups[$backup['name']] = $backup['name'] . ' (' . (string) ($backup['size'] ?? 0) . ' bytes)';
        }
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kitsune-operation-form');
        $form->addElement('hidden', 'formType', ['value' => 'operation']);
        $form->addElement('select', 'operation', [
            'label' => 'Operation', 'value' => 'status', 'required' => true,
            'multiOptions' => [
                'status' => 'Check status', 'sync' => 'Synchronize Git repository', 'install' => 'Install locked dependencies',
                'build' => 'Build production artifacts', 'migrate' => 'Apply database migrations', 'seed' => 'Run idempotent seed',
                'deploy' => 'Sync and deploy', 'redeploy' => 'Rebuild and redeploy current checkout', 'start' => 'Start services',
                'stop' => 'Stop services', 'restart' => 'Restart services', 'healthcheck' => 'Run health/smoke check',
                'logs' => 'Capture recent logs', 'backup' => 'Create full verified backup', 'restore' => 'Restore verified backup',
                'rollback' => 'Rollback to previous deployed commit',
            ],
        ]);
        $form->addElement('select', 'backup', ['label' => 'Backup for restore', 'multiOptions' => $backups, 'decorators' => [['ViewHelper'], ['Description'], ['HtmlTag', ['tag' => 'div', 'data-backup-select' => '1']]]]);
        $form->addElement('text', 'confirmation', ['label' => 'Restore confirmation', 'description' => 'Type RESTORE exactly.', 'decorators' => [['ViewHelper'], ['Description'], ['HtmlTag', ['tag' => 'div', 'data-restore-confirm' => '1']]]]);
        $form->addElement('submit', 'run', ['label' => 'Run operation']);
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function processConfig(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) return;
        $values = $form->getValues();
        if (strpos((string) $values['publicUrl'], 'https://') !== 0) {
            $this->_status->addMessage('error', 'The public production URL must use HTTPS.');
            return;
        }
        Modules_KitsuneArtifactoryManager_Config::save($values);
        $this->_status->addMessage('info', 'Kitsune configuration was saved; secrets use Plesk encrypted settings.');
        $this->_helper->redirector('index');
    }

    private function processOperation(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) return;
        $operation = (string) $form->getValue('operation');
        $allowed = ['status', 'sync', 'install', 'build', 'migrate', 'seed', 'deploy', 'redeploy', 'start', 'stop', 'restart', 'healthcheck', 'logs', 'backup', 'restore', 'rollback'];
        if (!in_array($operation, $allowed, true)) throw new InvalidArgumentException('Unknown operation.');
        $parameters = [];
        if ($operation === 'restore') {
            if ((string) $form->getValue('confirmation') !== 'RESTORE') {
                $this->_status->addMessage('error', 'Restore requires the exact confirmation RESTORE.');
                return;
            }
            $parameters['confirmation'] = 'RESTORE';
            $parameters['backup'] = basename((string) $form->getValue('backup'));
            if ($parameters['backup'] === '') {
                $this->_status->addMessage('error', 'Choose a listed backup.');
                return;
            }
        }
        $runtime = Modules_KitsuneArtifactoryManager_Config::createRuntimeConfig($operation, $parameters);
        $task = new Modules_KitsuneArtifactoryManager_Task_Operation();
        $task->setParam('runtimeConfig', $runtime);
        $manager = new pm_LongTask_Manager();
        $manager->start($task);
        $this->_status->addMessage('info', 'The serialized operation was queued. Plesk will report its progress.');
        $this->_helper->redirector('index');
    }
}
