<?php
// Deployment data and backups deliberately remain in their configured locations.
// Plesk removes the extension-owned var directory itself.
