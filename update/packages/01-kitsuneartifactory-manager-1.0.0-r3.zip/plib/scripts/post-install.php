<?php
$dir = pm_Context::getVarDir();
if (!is_dir($dir)) @mkdir($dir, 0700, true);
@chmod($dir, 0700);
