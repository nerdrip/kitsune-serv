<?php
class Modules_KitsuneArtifactoryManager_LongTasks extends pm_Hook_LongTasks
{
    public function getLongTasks() { return [new Modules_KitsuneArtifactoryManager_Task_Operation()]; }
}
