<?php

class Modules_KitsuneArtifactoryManager_Config
{
    private const SECRET_FIELDS = [
        'gitToken' => 'secret_git_token',
        'jwtSecret' => 'secret_jwt',
        'adminPassword' => 'secret_admin_password',
        'databasePassword' => 'secret_database_password',
        'metricsToken' => 'secret_metrics_token',
        'encryptionKey' => 'secret_encryption_key',
        's3AccessKey' => 'secret_s3_access_key',
        's3SecretKey' => 'secret_s3_secret_key',
    ];

    public static function defaults()
    {
        return [
            'repositoryUrl' => '',
            'repositoryBranch' => 'main',
            'installPath' => '/opt/kitsune-artifactory',
            'publicUrl' => 'https://artifacts.example.com',
            'bindAddress' => '127.0.0.1',
            'port' => '4000',
            'adminEmail' => 'admin@example.com',
            'adminUsername' => 'admin',
            'databaseHost' => 'postgres',
            'databasePort' => '5432',
            'databaseName' => 'kitsune',
            'databaseUser' => 'kitsune',
            'storageDriver' => 'local',
            'storageLocalPath' => '/opt/kitsune-artifactory-data/storage',
            's3Endpoint' => '',
            's3Region' => 'us-east-1',
            's3Bucket' => 'kitsune-artifacts',
            'backupDir' => '/opt/kitsune-backups',
            'backupRetention' => '7',
        ];
    }

    public static function values()
    {
        $values = [];
        foreach (self::defaults() as $key => $default) {
            $values[$key] = (string) pm_Settings::get($key, $default);
        }
        return $values;
    }

    public static function save(array $values)
    {
        foreach (self::defaults() as $key => $default) {
            if (array_key_exists($key, $values)) {
                pm_Settings::set($key, trim((string) $values[$key]));
            }
        }
        foreach (self::SECRET_FIELDS as $field => $setting) {
            $value = trim((string) ($values[$field] ?? ''));
            if ($value !== '') {
                pm_Settings::setEncrypted($setting, $value);
            }
        }
    }

    public static function hasSecret($field)
    {
        return self::secret($field) !== '';
    }

    public static function createRuntimeConfig($action, array $parameters = [])
    {
        $varDir = rtrim((string) pm_Context::getVarDir(), '/\\');
        if (!is_dir($varDir) && !mkdir($varDir, 0700, true) && !is_dir($varDir)) {
            throw new RuntimeException('Cannot create the extension work directory.');
        }
        @chmod($varDir, 0700);
        $real = realpath($varDir);
        if ($real === false) {
            throw new RuntimeException('Cannot resolve the extension work directory.');
        }
        $config = self::values();
        foreach (self::SECRET_FIELDS as $field => $setting) {
            $config[$field] = self::secret($field);
        }
        $config['action'] = (string) $action;
        $config['parameters'] = $parameters;
        $config['varDir'] = $real;
        $config['requestedAt'] = gmdate('c');
        $file = $real . '/operation-' . bin2hex(random_bytes(16)) . '.json';
        $json = json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        $previous = umask(0077);
        try {
            if ($json === false || file_put_contents($file, $json, LOCK_EX) === false) {
                throw new RuntimeException('Cannot write the operation configuration.');
            }
            @chmod($file, 0600);
        } finally {
            umask($previous);
        }
        return $file;
    }

    public static function state()
    {
        $file = pm_Context::getVarDir() . '/state.json';
        if (!is_file($file)) {
            return ['updatedAt' => null, 'lastOperation' => null, 'lastSuccess' => null, 'lastError' => null, 'commit' => null, 'previousCommit' => null, 'services' => [], 'backups' => [], 'log' => []];
        }
        $decoded = json_decode((string) file_get_contents($file), true);
        return is_array($decoded) ? $decoded : [];
    }

    private static function secret($field)
    {
        $setting = self::SECRET_FIELDS[$field] ?? null;
        if ($setting === null) return '';
        try { return (string) pm_Settings::getDecrypted($setting); } catch (Exception $exception) { return ''; }
    }
}
