<?php

class Modules_KitsuneArtifactoryManager_Task_Operation extends pm_LongTask_Task
{
    public $trackProgress = true;

    public function run()
    {
        $config = (string) $this->getParam('runtimeConfig');
        if ($config === '') throw new RuntimeException('Missing runtime configuration.');
        $this->updateProgress(10);
        $result = pm_ApiCli::callSbin('kitsuneartifactory-manager', ['--config', $config], pm_ApiCli::RESULT_FULL);
        $this->updateProgress(95);
        $output = trim((string) ($result['stdout'] ?? '') . "\n" . (string) ($result['stderr'] ?? ''));
        $this->setParam('output', mb_substr($output, -16000));
        if ((int) ($result['code'] ?? 1) !== 0) throw new RuntimeException($output !== '' ? $output : 'Kitsune operation failed.');
        $this->updateProgress(100);
    }

    public function onError(Exception $exception) { $this->removeConfig(); }
    public function onDone() { $this->removeConfig(); }
    public function statusMessage()
    {
        if ($this->getStatus() === static::STATUS_RUNNING) return 'Kitsune Manager operation is running…';
        if ($this->getStatus() === static::STATUS_DONE) return 'Kitsune Manager operation completed.';
        if ($this->getStatus() === static::STATUS_ERROR) return 'Kitsune Manager operation failed.';
        return 'Kitsune Manager operation is queued.';
    }
    private function removeConfig()
    {
        $file = (string) $this->getParam('runtimeConfig');
        if ($file !== '' && is_file($file)) @unlink($file);
    }
}
