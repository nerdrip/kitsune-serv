# Kitsune Artifactory Manager

Plesk administrator extension for controlled Git synchronization, locked dependency installation, production builds, migrations, Docker lifecycle management, health checks, rollback, and integrity-checked database/storage backups.
