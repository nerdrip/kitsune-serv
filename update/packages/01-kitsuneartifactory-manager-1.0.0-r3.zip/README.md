# Kitsune Artifactory Manager for Plesk

## Requirements

- Plesk Obsidian 18.0.41 or newer on Linux.
- Git, Node.js 20.10+, npm 10+, Docker Engine with Compose v2, tar, and PostgreSQL client tools when an external PostgreSQL database is used.
- A dedicated HTTPS domain configured in Plesk as a reverse proxy to `127.0.0.1:4000`.

## Install

Build `release/plesk/kitsuneartifactory-manager-1.0.0.zip` with `npm run package:plesk`, verify the adjacent `.sha256`, then upload the ZIP in **Plesk → Extensions → My Extensions → Upload Extension**. The extension has only been locally linted and structurally validated unless an actual Plesk installation is explicitly reported.

Open **Kitsune Manager**, configure the repository, branch, managed installation path, public HTTPS URL, and secrets. The configured source/install path must be an absolute path below `/opt`, `/var/www/vhosts`, or `/srv` and must not be a filesystem root.

Use **Check status** first. **Deploy** synchronizes the managed clone, writes a mode-0600 `.env`, installs from `package-lock.json`, builds, applies migrations, starts the hardened Compose overlay, and runs a smoke test. Operations are mutually exclusive.

Backups are stored outside the source tree by default. Restore only accepts a basename listed from that configured backup directory, requires the literal confirmation `RESTORE`, verifies the archive sidecar and every manifest checksum, then restarts and smoke-tests the service.

Rollback returns the managed clone to the last successfully deployed commit, rebuilds, migrates forward, restarts, and health-checks. Database migrations must therefore remain backward-compatible for one release when rollback is required.
