<?php

class Modules_KitsunecolabManager_CustomButtons extends pm_Hook_CustomButtons
{
    public function getButtons()
    {
        if ($this->hubOwnsNavigation()) return [];
        return [[
            'place' => [
                self::PLACE_ADMIN_NAVIGATION,
                self::PLACE_HOSTING_PANEL_NAVIGATION,
            ],
            'section' => self::SECTION_NAV_SERVER_MANAGEMENT,
            'order' => 50,
            'title' => 'KitsuneColab Manager',
            'description' => 'Stan, aktualizacje, wdrożenia i kopie zapasowe',
            'icon' => pm_Context::getBaseUrl() . 'images/kitsune-menu.svg',
            'link' => pm_Context::getBaseUrl() . 'index.php/index/index',
            'newWindow' => false,
        ]];
    }

    private function hubOwnsNavigation()
    {
        try { return pm_Extension::getById('kitsuneserv-bridge')->isActive(); }
        catch (Throwable $exception) { return false; }
    }
}
