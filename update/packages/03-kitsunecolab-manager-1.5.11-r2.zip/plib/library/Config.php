<?php

class Modules_KitsunecolabManager_Config
{
    public const EXTENSION_VERSION = '1.5.11';

    private const SECRET_FIELDS = [
        'gitToken' => 'secret_git_token',
        'gitSshPrivateKey' => 'secret_git_ssh_private_key',
        'postgresPassword' => 'secret_postgres_password',
        'jwtSecret' => 'secret_jwt',
        'metricsToken' => 'secret_metrics_token',
        'smtpUrl' => 'secret_smtp_url',
        's3AccessKey' => 'secret_s3_access_key',
        's3SecretKey' => 'secret_s3_secret_key',
        'suiteSharedSecret' => 'secret_suite_shared_secret',
    ];

    public static function defaults()
    {
        return [
            'repositoryUrl' => '',
            'repositoryBranch' => 'main',
            'repositoryPath' => '/opt/kitsunecolab/source',
            'gitUsername' => 'x-access-token',
            'gitSshKnownHosts' => '',
            'deployPath' => '/opt/kitsunecolab/app',
            'backupPath' => '/opt/kitsunecolab/backups',
            'backupRetentionCount' => '14',
            'composeProject' => 'kitsunecolab',
            'bindAddress' => '127.0.0.1',
            'webPort' => '3000',
            'apiPort' => '4000',
            'minioPort' => '9000',
            'minioConsolePort' => '9001',
            'publicDomain' => '',
            'proxyMode' => 'managed',
            'publicWebUrl' => 'https://kitsune.example.com',
            'publicApiUrl' => 'https://kitsune.example.com',
            'suiteHubUrl' => '',
            'suiteTestUrl' => '',
            'suiteOrganizationId' => '',
            'suiteOrganizationName' => 'Kitsune Suite',
            'suiteOwnerId' => '',
            'suiteControlEnabled' => '0',
            'postgresUser' => 'kitsune',
            'postgresDatabase' => 'kitsune',
            's3Bucket' => 'kitsune',
            'smtpFrom' => 'noreply@kitsune.local',
            'pluginsAutoload' => 'scrum,github-integration,playtest-feedback,slack,discord,teams,steam-release,retrospective,daily-standup,anonymous-feedback,prince2,risk-score,ai-triage,unity-sync',
            'projectStorageQuotaBytes' => '10737418240',
            'apiBodyMaxBytes' => '262144',
            'pluginExecutionTimeoutMs' => '15000',
            'outboxRetentionDays' => '14',
            'failedEventRetentionDays' => '90',
            'automationRunRetentionDays' => '90',
            'webhookDeliveryRetentionDays' => '90',
            'readNotificationRetentionDays' => '90',
            'seedDemoData' => '0',
        ];
    }

    public static function values()
    {
        $values = [];
        foreach (self::defaults() as $key => $default) {
            $values[$key] = (string) pm_Settings::get($key, $default);
        }
        return $values;
    }

    public static function save(array $values)
    {
        foreach (self::defaults() as $key => $default) {
            if (array_key_exists($key, $values)) {
                pm_Settings::set($key, trim((string) $values[$key]));
            }
        }

        foreach (self::SECRET_FIELDS as $field => $setting) {
            $value = trim((string) ($values[$field] ?? ''));
            if ($field === 'gitSshPrivateKey') {
                $value = self::normalizeMultiline($value);
            }
            if ($value !== '') {
                pm_Settings::setEncrypted($setting, $value);
            }
        }
        self::writeSuiteControlProfile();
        self::writeSuiteDiscoveryProfile();
    }

    public static function importSuiteBootstrap()
    {
        $varDir = rtrim((string) pm_Context::getVarDir(), '/\\');
        $path = $varDir . '/suite-bootstrap.json';
        if (!is_file($path) || is_link($path)) return false;
        if (!self::hardenSuiteBootstrap($varDir, $path) || filesize($path) > 131072) {
            @unlink($path);
            throw new RuntimeException('Odrzucono niezabezpieczony bootstrap Kitsune Suite.');
        }
        try {
            $payload = json_decode((string) file_get_contents($path), true);
            if (!is_array($payload) || ($payload['protocol'] ?? '') !== 'kitsune-suite-bootstrap' || ($payload['product'] ?? '') !== 'colab') {
                throw new RuntimeException('Nieprawidłowy bootstrap KitsuneColab.');
            }
            $createdAt = strtotime((string) ($payload['createdAt'] ?? ''));
            if ($createdAt === false || abs(time() - $createdAt) > 3600) {
                throw new RuntimeException('Bootstrap KitsuneColab wygasł.');
            }
            $source = is_array($payload['config'] ?? null) ? $payload['config'] : [];
            $values = [];
            foreach (array_keys(self::defaults()) as $field) {
                if (array_key_exists($field, $source)) $values[$field] = (string) $source[$field];
            }
            foreach (array_keys(self::SECRET_FIELDS) as $field) {
                $reconciledByHub = in_array($field, ['gitToken', 'gitSshPrivateKey', 'suiteSharedSecret'], true);
                if (!empty($source[$field]) && ($reconciledByHub || !self::hasSecret($field))) {
                    $values[$field] = (string) $source[$field];
                }
            }
            self::save($values);
            return true;
        } finally {
            @unlink($path);
        }
    }

    private static function hardenSuiteBootstrap($varDir, $path)
    {
        clearstatcache(true, $varDir);
        clearstatcache(true, $path);
        if (!is_dir($varDir) || is_link($varDir) || !is_file($path) || is_link($path)) return false;

        $realVarDir = realpath($varDir);
        $realPath = realpath($path);
        if ($realVarDir === false || $realPath === false || dirname($realPath) !== $realVarDir) return false;

        $directoryOwner = @fileowner($realVarDir);
        $fileOwner = @fileowner($realPath);
        if ($directoryOwner === false || $fileOwner === false || $directoryOwner !== $fileOwner) return false;

        // Plesk filemng can recreate a ZIP entry with the installer's 0022
        // umask even when the archive records 0600. The enclosing var directory
        // is already private and has the same owner, so it is safe to harden
        // this exact regular file before reading any embedded secret.
        if (!@chmod($realVarDir, 0700) || !@chmod($realPath, 0600)) return false;
        clearstatcache(true, $realVarDir);
        clearstatcache(true, $realPath);
        $directoryMode = fileperms($realVarDir);
        $fileMode = fileperms($realPath);
        return $directoryMode !== false
            && $fileMode !== false
            && (($directoryMode & 0077) === 0)
            && (($fileMode & 0077) === 0);
    }

    public static function refreshSuiteDiscovery()
    {
        self::writeSuiteDiscoveryProfile();
    }

    public static function hasSecret($field)
    {
        return self::secret($field) !== '';
    }

    public static function readState()
    {
        $path = pm_Context::getVarDir() . '/state.json';
        if (!is_file($path) || is_link($path) || !is_readable($path)) {
            return self::emptyState();
        }
        $contents = @file_get_contents($path);
        if (!is_string($contents)) return self::emptyState();
        $decoded = json_decode($contents, true);
        return is_array($decoded)
            ? array_replace_recursive(self::emptyState(), $decoded)
            : self::emptyState();
    }

    public static function createRuntimeConfig($action)
    {
        $varDir = rtrim((string) pm_Context::getVarDir(), '/\\');
        if (!is_dir($varDir) && !mkdir($varDir, 0700, true) && !is_dir($varDir)) {
            throw new RuntimeException('Nie udało się utworzyć katalogu roboczego rozszerzenia.');
        }
        @chmod($varDir, 0700);
        $realVarDir = realpath($varDir);
        if ($realVarDir === false) {
            throw new RuntimeException('Nie udało się ustalić katalogu roboczego rozszerzenia.');
        }

        $config = self::values();
        $config['gitToken'] = self::secret('gitToken');
        $config['gitSshPrivateKey'] = self::normalizeMultiline(self::secret('gitSshPrivateKey'));
        $config['postgresPassword'] = self::secret('postgresPassword');
        $config['jwtSecret'] = self::secret('jwtSecret');
        $config['metricsToken'] = self::secret('metricsToken');
        $config['smtpUrl'] = self::secret('smtpUrl');
        $config['s3AccessKey'] = self::secret('s3AccessKey');
        $config['s3SecretKey'] = self::secret('s3SecretKey');
        $config['suiteSharedSecret'] = self::secret('suiteSharedSecret');
        $config['action'] = (string) $action;
        $config['requestedAt'] = gmdate('c');
        $config = self::withManagedVhostPath($config);

        $path = $realVarDir . '/operation-' . bin2hex(random_bytes(12)) . '.json';
        $json = json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $previousUmask = umask(0077);
        try {
            if ($json === false || file_put_contents($path, $json, LOCK_EX) === false) {
                throw new RuntimeException('Nie udało się zapisać konfiguracji operacji.');
            }
            @chmod($path, 0600);
        } finally {
            umask($previousUmask);
        }
        return $path;
    }

    private static function writeSuiteControlProfile()
    {
        $varDir = rtrim((string) pm_Context::getVarDir(), '/\\');
        if (!is_dir($varDir) && !mkdir($varDir, 0700, true) && !is_dir($varDir)) {
            throw new RuntimeException('Nie udało się utworzyć katalogu profilu Kitsune Suite.');
        }
        @chmod($varDir, 0700);
        $path = $varDir . '/suite-control-profile.json';
        $values = self::values();
        if (($values['suiteControlEnabled'] ?? '0') !== '1') {
            if (is_file($path)) @unlink($path);
            return;
        }
        foreach (array_keys(self::SECRET_FIELDS) as $field) {
            $values[$field] = self::secret($field);
        }
        $values['suiteProduct'] = 'colab';
        $values['suiteControlEnabled'] = '1';
        $values['action'] = 'status';
        $values['exportedAt'] = gmdate('c');
        $values = self::withManagedVhostPath($values);
        self::writeProtectedJson($path, $values, 'profilu sterowania Kitsune Suite');
    }

    private static function writeSuiteDiscoveryProfile()
    {
        $varDir = rtrim((string) pm_Context::getVarDir(), '/\\');
        if (!is_dir($varDir) && !mkdir($varDir, 0700, true) && !is_dir($varDir)) {
            throw new RuntimeException('Nie udało się utworzyć katalogu wykrywania Kitsune Suite.');
        }
        @chmod($varDir, 0700);
        $values = self::values();
        $repositoryUrl = trim((string) ($values['repositoryUrl'] ?? ''));
        $parts = $repositoryUrl !== '' ? parse_url($repositoryUrl) : false;
        if (is_array($parts) && (isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment']))) $repositoryUrl = '';
        $payload = [
            'protocol' => 'kitsune-suite-discovery',
            'protocolVersion' => 1,
            'product' => 'colab',
            'extensionVersion' => self::EXTENSION_VERSION,
            'repositoryConfigured' => trim((string) ($values['repositoryUrl'] ?? '')) !== '',
            'repositoryUrl' => $repositoryUrl,
            'repositoryBranch' => (string) ($values['repositoryBranch'] ?? 'main'),
            'repositoryPath' => (string) ($values['repositoryPath'] ?? ''),
            'publicApiUrl' => (string) ($values['publicApiUrl'] ?? ''),
            'controlEnabled' => ($values['suiteControlEnabled'] ?? '0') === '1',
            'updatedAt' => gmdate('c'),
        ];
        self::writeProtectedJson($varDir . '/suite-discovery.json', $payload, 'profilu wykrywania Kitsune Suite');
    }

    private static function writeProtectedJson($path, array $payload, $label)
    {
        $json = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($json === false) throw new RuntimeException('Nie udało się zakodować ' . $label . '.');
        $directory = dirname($path);
        $realDirectory = realpath($directory);
        if ($realDirectory === false || !is_dir($directory) || is_link($directory)) {
            throw new RuntimeException('Nieprawidłowy prywatny katalog ' . $label . '.');
        }
        $directoryMode = fileperms($realDirectory);
        $directoryOwner = @fileowner($realDirectory);
        if ($directoryMode === false || (($directoryMode & 0077) !== 0) || $directoryOwner === false) {
            throw new RuntimeException('Prywatny katalog ' . $label . ' ma niebezpieczne uprawnienia.');
        }
        $target = $realDirectory . '/' . basename($path);
        if (is_link($target) || (file_exists($target) && !is_file($target))) {
            throw new RuntimeException('Nieprawidłowy plik docelowy ' . $label . '.');
        }
        $temporary = $realDirectory . '/.' . basename($path) . '.tmp-' . bin2hex(random_bytes(12));
        $previousUmask = umask(0077);
        try {
            if (file_put_contents($temporary, $json . PHP_EOL, LOCK_EX) === false) {
                throw new RuntimeException('Nie udało się zapisać ' . $label . '.');
            }
            if (!@chmod($temporary, 0600)) throw new RuntimeException('Nie udało się zabezpieczyć ' . $label . '.');
            if (@fileowner($temporary) !== $directoryOwner && !@chown($temporary, $directoryOwner)) {
                throw new RuntimeException('Nie udało się uzgodnić właściciela ' . $label . '.');
            }
            clearstatcache(true, $temporary);
            $temporaryMode = fileperms($temporary);
            if ($temporaryMode === false || (($temporaryMode & 0077) !== 0) || @fileowner($temporary) !== $directoryOwner) {
                throw new RuntimeException('Nie udało się zweryfikować ochrony ' . $label . '.');
            }
            if (!@rename($temporary, $target)) throw new RuntimeException('Nie udało się opublikować ' . $label . '.');
            clearstatcache(true, $target);
            $targetMode = fileperms($target);
            if (!is_file($target) || is_link($target) || $targetMode === false || (($targetMode & 0077) !== 0) || @fileowner($target) !== $directoryOwner) {
                @unlink($target);
                throw new RuntimeException('Nie udało się zweryfikować zapisanego ' . $label . '.');
            }
        } finally {
            if (is_file($temporary) || is_link($temporary)) @unlink($temporary);
            umask($previousUmask);
        }
    }

    private static function secret($field)
    {
        $setting = self::SECRET_FIELDS[$field] ?? null;
        if ($setting === null) {
            return '';
        }
        try {
            return (string) pm_Settings::getDecrypted($setting);
        } catch (Exception $exception) {
            return '';
        }
    }

    private static function normalizeMultiline($value)
    {
        $value = str_replace(["\r\n", "\r"], "\n", (string) $value);
        if (strncmp($value, "\xEF\xBB\xBF", 3) === 0) {
            $value = substr($value, 3);
        }
        return trim($value);
    }

    private static function withManagedVhostPath(array $values)
    {
        if (($values['proxyMode'] ?? 'manual') !== 'managed') return $values;
        $domainName = strtolower(trim((string) ($values['publicDomain'] ?? '')));
        if ($domainName === '') return $values;
        try {
            $domain = pm_Domain::getByName($domainName);
            if (!$domain instanceof pm_Domain || !$domain->hasHosting() || !$domain->isActive() || $domain->isSuspended() || $domain->isDisabled()) {
                throw new RuntimeException('Wybrana domena nie ma aktywnego hostingu Pleska.');
            }
            $values['pleskVhostSystemPath'] = (string) $domain->getVhostSystemPath();
        } catch (Throwable $exception) {
            throw new RuntimeException('Nie można skonfigurować vhosta dla domeny ' . $domainName . '.', 0, $exception);
        }
        return $values;
    }

    private static function emptyState()
    {
        return [
            'updatedAt' => null,
            'lastOperation' => null,
            'lastSuccess' => null,
            'lastError' => null,
            'repository' => [
                'path' => null,
                'branch' => null,
                'localCommit' => null,
                'remoteCommit' => null,
                'localVersion' => null,
                'remoteVersion' => null,
                'updateAvailable' => null,
                'dirty' => null,
                'checkedAt' => null,
                'error' => null,
            ],
            'deployment' => [
                'path' => null,
                'version' => null,
                'commit' => null,
                'deployedAt' => null,
                'health' => 'unknown',
                'rollbackPath' => null,
                'lastBackup' => null,
            ],
            'services' => [],
            'docker' => [
                'available' => null,
                'composeVersion' => null,
                'checkedAt' => null,
                'error' => null,
            ],
            'log' => [],
        ];
    }
}
