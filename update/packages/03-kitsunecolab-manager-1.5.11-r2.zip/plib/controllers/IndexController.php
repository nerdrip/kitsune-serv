<?php

class IndexController extends pm_Controller_Action
{
    protected $_accessLevel = 'admin';

    public function init()
    {
        parent::init();
        $this->view->pageTitle = 'KitsuneColab Deployment Manager';
        $this->view->headLink()->appendStylesheet(pm_Context::getBaseUrl() . 'css/kitsune.css?v=1.5.11');
        $this->view->headLink()->appendStylesheet(pm_Context::getBaseUrl() . 'css/kitsune-platform.css?v=1');
        $this->view->headScript()->appendFile(pm_Context::getBaseUrl() . 'js/kitsune-platform.js?v=1');
        $this->view->suiteProduct = 'KitsuneColab Manager';
        $this->view->suiteVersion = Modules_KitsunecolabManager_Config::EXTENSION_VERSION;
        try { $this->view->suiteHubActive = pm_Extension::getById('kitsuneserv-bridge')->isActive(); }
        catch (Throwable $exception) { $this->view->suiteHubActive = false; }
    }

    public function indexAction()
    {
        Modules_KitsunecolabManager_Config::importSuiteBootstrap();
        Modules_KitsunecolabManager_Config::refreshSuiteDiscovery();
        $statusRefreshError = null;
        if (!$this->getRequest()->isPost()) {
            $statusRefreshError = $this->refreshRuntimeState();
        }

        $configForm = $this->createConfigForm();
        $operationForm = $this->createOperationForm();
        if ($this->getRequest()->isPost()) {
            $post = $this->getRequest()->getPost();
            $formType = (string) ($post['formType'] ?? '');
            if ($formType === 'config') {
                $this->processConfigForm($configForm, $post);
            } elseif ($formType === 'operation') {
                $this->processOperationForm($operationForm, $post);
            }
        }

        $this->view->configForm = $configForm;
        $this->view->operationForm = $operationForm;
        $this->view->statusRefreshError = $statusRefreshError;
        $this->view->state = Modules_KitsunecolabManager_Config::readState();
        $this->view->config = Modules_KitsunecolabManager_Config::values();
        foreach (['gitToken', 'gitSshPrivateKey', 'postgresPassword', 'jwtSecret', 'metricsToken', 'smtpUrl', 's3AccessKey', 's3SecretKey', 'suiteSharedSecret'] as $secret) {
            $property = 'has' . ucfirst($secret);
            $this->view->{$property} = Modules_KitsunecolabManager_Config::hasSecret($secret);
        }
    }

    private function createConfigForm()
    {
        $values = Modules_KitsunecolabManager_Config::values();
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kitsune-config-form');
        $form->addElement('hidden', 'formType', ['value' => 'config']);

        $this->addSection($form, 'repoSection', 'Repozytorium Git', 'Dedykowana kopia robocza jest synchronizowana niezależnie od działającego wdrożenia.');
        $form->addElement('text', 'repositoryUrl', [
            'label' => 'Adres repozytorium',
            'value' => $values['repositoryUrl'],
            'description' => 'HTTPS albo SSH, np. git@github.com:firma/kitsunecolab.git.',
            'required' => true,
            'validators' => [['StringLength', true, ['min' => 5, 'max' => 1000]]],
        ]);
        $form->addElement('text', 'repositoryBranch', [
            'label' => 'Gałąź',
            'value' => $values['repositoryBranch'],
            'required' => true,
            'validators' => [['Regex', true, ['pattern' => '/^(?![-.])(?!.*\.\.)(?!.*@\{)[A-Za-z0-9._\/-]+$/']]],
        ]);
        $form->addElement('text', 'repositoryPath', [
            'label' => 'Katalog kopii repozytorium',
            'value' => $values['repositoryPath'],
            'required' => true,
            'validators' => [['Regex', true, ['pattern' => '#^/[A-Za-z0-9._/-]+$#']]],
        ]);
        $form->addElement('text', 'gitUsername', [
            'label' => 'Użytkownik Git HTTPS',
            'value' => $values['gitUsername'],
            'description' => 'Dla tokenu GitHub zwykle x-access-token; przy SSH ignorowany.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 255]]],
        ]);
        $form->addElement('password', 'gitToken', [
            'label' => 'Token / hasło Git',
            'value' => '',
            'description' => Modules_KitsunecolabManager_Config::hasSecret('gitToken') ? 'Token jest zaszyfrowany. Puste pole zachowa obecną wartość.' : 'Opcjonalny dla repozytorium prywatnego HTTPS.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 1900]]],
        ]);
        $form->addElement('textarea', 'gitSshPrivateKey', [
            'label' => 'Prywatny klucz SSH',
            'value' => '',
            'rows' => 7,
            'class' => 'f-middle-size kitsune-secret-textarea',
            'description' => Modules_KitsunecolabManager_Config::hasSecret('gitSshPrivateKey') ? 'Klucz jest zaszyfrowany. Puste pole zachowa obecną wartość.' : 'Opcjonalny deploy key tylko do odczytu, bez hasła.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 8000]]],
        ]);
        $form->addElement('textarea', 'gitSshKnownHosts', [
            'label' => 'Znane hosty SSH',
            'value' => $values['gitSshKnownHosts'],
            'rows' => 4,
            'class' => 'f-middle-size',
            'description' => 'Opcjonalna, zweryfikowana zawartość known_hosts. StrictHostKeyChecking zawsze pozostaje włączone.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 8000]]],
        ]);

        $this->addSection($form, 'deploySection', 'Wdrożenie Docker Compose', 'Publiczne usługi są domyślnie dostępne wyłącznie z hosta i przeznaczone do reverse proxy Pleska.');
        $form->addElement('text', 'deployPath', [
            'label' => 'Katalog wdrożenia',
            'value' => $values['deployPath'],
            'required' => true,
            'validators' => [['Regex', true, ['pattern' => '#^/[A-Za-z0-9._/-]+$#']]],
        ]);
        $form->addElement('text', 'backupPath', [
            'label' => 'Katalog pełnych kopii',
            'value' => $values['backupPath'],
            'required' => true,
            'validators' => [['Regex', true, ['pattern' => '#^/[A-Za-z0-9._/-]+$#']]],
        ]);
        $form->addElement('text', 'backupRetentionCount', [
            'label' => 'Liczba zachowanych kopii',
            'value' => $values['backupRetentionCount'],
            'description' => 'Najstarsze kompletne kopie utworzone przez manager zostaną usunięte po udanym backupie.',
            'required' => true,
            'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 365]]],
        ]);
        $form->addElement('text', 'composeProject', [
            'label' => 'Nazwa projektu Compose',
            'value' => $values['composeProject'],
            'required' => true,
            'validators' => [['Regex', true, ['pattern' => '/^[a-z0-9][a-z0-9_-]{1,62}$/']]],
        ]);
        $form->addElement('text', 'bindAddress', [
            'label' => 'Adres nasłuchu',
            'value' => $values['bindAddress'],
            'description' => 'Zalecane: 127.0.0.1. Wystaw aplikację przez domeny i HTTPS Pleska.',
            'required' => true,
            'validators' => [['Ip', true]],
        ]);
        foreach ([
            'webPort' => 'Port panelu web',
            'apiPort' => 'Port API',
            'minioPort' => 'Port API MinIO',
            'minioConsolePort' => 'Port konsoli MinIO',
        ] as $field => $label) {
            $form->addElement('text', $field, [
                'label' => $label,
                'value' => $values[$field],
                'required' => true,
                'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 65535]]],
            ]);
        }
        $domains = $this->domainOptions($values['publicDomain']);
        $form->addElement('select', 'publicDomain', [
            'label' => 'Domena KitsuneColab', 'value' => $values['publicDomain'], 'required' => true,
            'multiOptions' => ['' => '— wybierz domenę Pleska —'] + $domains,
            'description' => 'Wybierz jedną aktywną domenę z Pleska. Panel będzie pod https://domena, a API pod https://domena/api.',
        ]);
        $form->addElement('select', 'proxyMode', [
            'label' => 'Konfiguracja vhosta', 'value' => $values['proxyMode'],
            'multiOptions' => ['managed' => 'Automatycznie przez plugin', 'manual' => 'Ręcznie w panelu Pleska'],
            'description' => 'Automatycznie: plugin utrzymuje reguły panelu i API. Ręcznie: pokaże bezpieczny kod bez location /.',
        ]);

        $this->addSection($form, 'suiteSection', 'Kitsune Suite', 'Opcjonalne połączenie z KitsuneHub i KitsuneTest. Puste adresy zachowują pełną samodzielność Colaba.');
        foreach ([
            'suiteHubUrl' => ['URL API KitsuneHub', $values['suiteHubUrl']],
            'suiteTestUrl' => ['URL API KitsuneTest', $values['suiteTestUrl']],
        ] as $field => $definition) {
            $form->addElement('text', $field, [
                'label' => $definition[0],
                'value' => $definition[1],
                'description' => 'Prosty bazowy adres HTTPS, bez ścieżki. Pole opcjonalne.',
                'validators' => [['Regex', true, ['pattern' => '#^$|^https://[^\s/]+(?::\d+)?/?$#i']], ['StringLength', true, ['max' => 1000]]],
            ]);
        }
        $form->addElement('text', 'suiteOrganizationId', [
            'label' => 'ID nadrzędnej organizacji Suite', 'value' => $values['suiteOrganizationId'],
            'description' => 'Techniczne ID wspólnej ekipy. Każdy aktywowany workspace Huba powstaje pod nią jako osobna organizacja.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 200]]],
        ]);
        $form->addElement('text', 'suiteOrganizationName', [
            'label' => 'Nazwa nadrzędnej organizacji Suite', 'value' => $values['suiteOrganizationName'],
            'description' => 'Widoczna nazwa wspólnej ekipy, np. Chaos Group Games. Nazwy organizacji podrzędnych pochodzą z workspace’ów Huba.',
            'validators' => [['StringLength', true, ['min' => 1, 'max' => 120]]],
        ]);
        $form->addElement('text', 'suiteOwnerId', [
            'label' => 'Właściciel projektów Suite', 'value' => $values['suiteOwnerId'],
            'description' => 'ID użytkownika Colab używanego jako właściciel i reporter automatycznych issue.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 200]]],
        ]);
        $this->addPassword($form, 'suiteSharedSecret', 'Wspólny sekret Suite', 'suiteSharedSecret', 512, 'Minimum 32 losowe znaki, identyczne w trzech produktach.', false);
        $form->addElement('checkbox', 'suiteControlEnabled', [
            'label' => 'Zezwól Hubowi na wdrożenie',
            'value' => $values['suiteControlEnabled'] === '1' ? '1' : '0',
            'description' => 'Tworzy chroniony 0600 profil, dzięki któremu plugin KitsuneHub może zlecić check, deploy i backup. Root serwera pozostaje granicą zaufania.',
        ]);

        $this->addSection($form, 'secretSection', 'Baza, sesje i magazyn obiektów', 'Wartości tajne są zapisywane przez szyfrowany magazyn Pleska i trafiają tylko do chronionego pliku .env wdrożenia.');
        $form->addElement('text', 'postgresUser', [
            'label' => 'Użytkownik PostgreSQL',
            'value' => $values['postgresUser'],
            'required' => true,
            'validators' => [['Regex', true, ['pattern' => '/^[A-Za-z_][A-Za-z0-9_-]{0,62}$/']]],
        ]);
        $form->addElement('text', 'postgresDatabase', [
            'label' => 'Nazwa bazy PostgreSQL',
            'value' => $values['postgresDatabase'],
            'required' => true,
            'validators' => [['Regex', true, ['pattern' => '/^[A-Za-z_][A-Za-z0-9_-]{0,62}$/']]],
        ]);
        $this->addPassword($form, 'postgresPassword', 'Hasło PostgreSQL', 'postgresPassword', 1900);
        $this->addPassword($form, 'jwtSecret', 'Sekret JWT', 'jwtSecret', 4096, 'Minimum 32 znaki; zmiana unieważnia aktywne sesje.');
        $this->addPassword($form, 'metricsToken', 'Token endpointu metryk', 'metricsToken', 4096, 'Minimum 24 losowe znaki; wymagany w produkcji.');
        $this->addPassword($form, 's3AccessKey', 'Klucz dostępu MinIO', 's3AccessKey', 1900);
        $this->addPassword($form, 's3SecretKey', 'Sekretny klucz MinIO', 's3SecretKey', 1900);
        $form->addElement('text', 's3Bucket', [
            'label' => 'Bucket MinIO',
            'value' => $values['s3Bucket'],
            'required' => true,
            'validators' => [['Regex', true, ['pattern' => '/^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$/']]],
        ]);

        $this->addSection($form, 'runtimeSection', 'Poczta, pluginy i limity', 'Limity chronią instancję przed niekontrolowanym wzrostem danych oraz zbyt ciężkimi żądaniami i pluginami.');
        $this->addPassword($form, 'smtpUrl', 'Adres SMTP', 'smtpUrl', 1900, 'Np. smtps://user:password@mail.example.com:465.', false);
        $form->addElement('text', 'smtpFrom', [
            'label' => 'Nadawca wiadomości',
            'value' => $values['smtpFrom'],
            'required' => true,
            'validators' => [['EmailAddress', true], ['StringLength', true, ['max' => 320]]],
        ]);
        $form->addElement('text', 'pluginsAutoload', [
            'label' => 'Automatycznie ładowane pluginy',
            'value' => $values['pluginsAutoload'],
            'description' => 'Identyfikatory rozdzielone przecinkami. Produkcyjny loader uruchomi wyłącznie tę listę z zaufanego katalogu.',
            'required' => true,
            'validators' => [['Regex', true, ['pattern' => '/^[a-z0-9][a-z0-9-]*(?:,[a-z0-9][a-z0-9-]*)*$/']], ['StringLength', true, ['max' => 1900]]],
        ]);
        foreach ([
            'projectStorageQuotaBytes' => ['Limit storage projektu (B)', 1048576, 1099511627776],
            'apiBodyMaxBytes' => ['Limit JSON API (B)', 16384, 10485760],
            'pluginExecutionTimeoutMs' => ['Timeout pluginu (ms)', 1000, 60000],
        ] as $field => $definition) {
            $form->addElement('text', $field, [
                'label' => $definition[0],
                'value' => $values[$field],
                'required' => true,
                'validators' => [['Digits', true], ['Between', true, ['min' => $definition[1], 'max' => $definition[2]]]],
            ]);
        }
        foreach ([
            'outboxRetentionDays' => 'Retencja zdarzeń zakończonych (dni)',
            'failedEventRetentionDays' => 'Retencja błędnych zdarzeń (dni)',
            'automationRunRetentionDays' => 'Retencja uruchomień automatyzacji (dni)',
            'webhookDeliveryRetentionDays' => 'Retencja dostaw webhooków (dni)',
            'readNotificationRetentionDays' => 'Retencja przeczytanych powiadomień (dni)',
        ] as $field => $label) {
            $form->addElement('text', $field, [
                'label' => $label,
                'value' => $values[$field],
                'required' => true,
                'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 3650]]],
            ]);
        }
        $form->addElement('checkbox', 'seedDemoData', [
            'label' => 'Dane demonstracyjne',
            'value' => $values['seedDemoData'] === '1' ? '1' : '0',
            'description' => 'Uruchom seed po migracjach. Nie włączaj na pustej instancji produkcyjnej, jeśli nie chcesz kont testowych.',
        ]);

        $this->addActionButton($form, 'configActions', 'Zapisz ustawienia', 'save');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function createOperationForm()
    {
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'kitsune-operation-form');
        $form->addElement('hidden', 'formType', ['value' => 'operation']);
        $form->addElement('select', 'operation', [
            'label' => 'Operacja',
            'multiOptions' => [
                'check' => 'Sprawdź repozytorium i wersję zdalną',
                'sync' => 'Zaktualizuj tylko lokalną kopię repozytorium',
                'deploy' => 'Wdróż obecną lokalną kopię',
                'sync-deploy' => 'Pobierz najnowszy kod i wdróż',
                'start' => 'Uruchom zatrzymane usługi',
                'restart' => 'Uruchom ponownie wszystkie usługi',
                'stop' => 'Zatrzymaj usługi bez kasowania danych',
                'backup' => 'Utwórz pełną kopię bazy i plików',
                'restore-latest' => 'Odtwórz najnowszą pełną kopię',
            ],
            'value' => 'check',
            'required' => true,
        ]);
        $form->addElement('checkbox', 'confirmRestore', [
            'label' => 'Potwierdzenie odtwarzania',
            'value' => '0',
            'description' => 'Wymagane tylko dla odtwarzania. Operacja zastąpi aktualną bazę i pliki najnowszą poprawną kopią po weryfikacji SHA-256.',
        ]);
        $this->addActionButton($form, 'operationActions', 'Sprawdź repozytorium i wersje', 'operation');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function processConfigForm(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) {
            return;
        }
        $values = $form->getValues();
        $domain = strtolower(trim((string) ($values['publicDomain'] ?? '')));
        if (!isset($this->domainOptions()[$domain])) {
            $form->getElement('publicDomain')->addError('Wybierz aktywną domenę z listy Pleska.');
            return;
        }
        $values['publicDomain'] = $domain;
        $values['publicWebUrl'] = 'https://' . $domain;
        $values['publicApiUrl'] = 'https://' . $domain;
        $values['suiteControlEnabled'] = !empty($values['suiteControlEnabled']) ? '1' : '0';
        $suiteSecret = trim((string) ($values['suiteSharedSecret'] ?? $post['suiteSharedSecret'] ?? ''));
        if ($suiteSecret !== '' && strlen($suiteSecret) < 32) {
            $form->getElement('suiteSharedSecret')->addError('Sekret Suite musi mieć co najmniej 32 znaki.');
            $this->_status->addMessage('error', 'Nie zapisano konfiguracji Kitsune Suite: sekret jest zbyt krótki.');
            return;
        }
        $hasSuitePeer = trim((string) ($values['suiteHubUrl'] ?? '')) !== '' || trim((string) ($values['suiteTestUrl'] ?? '')) !== '';
        if ($hasSuitePeer && !Modules_KitsunecolabManager_Config::hasSecret('suiteSharedSecret') && $suiteSecret === '') {
            $form->getElement('suiteSharedSecret')->addError('Ustaw wspólny sekret Suite.');
            $this->_status->addMessage('error', 'Nie zapisano konfiguracji Kitsune Suite: brakuje wspólnego sekretu.');
            return;
        }
        $values['seedDemoData'] = $form->getValue('seedDemoData') ? '1' : '0';
        Modules_KitsunecolabManager_Config::save($values);
        $this->_status->addMessage('info', 'Konfiguracja KitsuneColab została zapisana.');
        $this->respondWithRedirect();
    }

    private function domainOptions($saved = '')
    {
        $options = [];
        try {
            foreach ((array) pm_Domain::getAllDomains() as $domain) {
                if (!$domain instanceof pm_Domain || !$domain->hasHosting() || !$domain->isActive() || $domain->isSuspended() || $domain->isDisabled()) continue;
                $name = strtolower(trim((string) $domain->getName()));
                if (preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/', $name)) $options[$name] = $name;
            }
        } catch (Throwable $exception) { /* Plesk exposes no hosting domains yet. */ }
        natcasesort($options);
        return $options;
    }

    private function refreshRuntimeState()
    {
        $runtimeConfig = null;
        try {
            $runtimeConfig = Modules_KitsunecolabManager_Config::createRuntimeConfig('status');
            $result = pm_ApiCli::callSbin('kitsunecolab-manager', ['--config', $runtimeConfig], pm_ApiCli::RESULT_FULL);
            if ((int) ($result['code'] ?? 1) !== 0) {
                $detail = trim((string) (($result['stderr'] ?? '') ?: ($result['stdout'] ?? '')));
                return $detail !== '' ? mb_substr($detail, -2000) : 'Narzędzie statusu zakończyło się błędem.';
            }
            return null;
        } catch (Throwable $exception) {
            return mb_substr($exception->getMessage(), -2000);
        } finally {
            if ($runtimeConfig && is_file($runtimeConfig)) {
                @unlink($runtimeConfig);
            }
        }
    }

    private function processOperationForm(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) {
            return;
        }
        $operation = (string) $form->getValue('operation');
        $allowed = ['check', 'sync', 'deploy', 'sync-deploy', 'start', 'restart', 'stop', 'backup', 'restore-latest'];
        if (!in_array($operation, $allowed, true)) {
            $this->_status->addMessage('error', 'Nieznana operacja.');
            return;
        }

        $config = Modules_KitsunecolabManager_Config::values();
        if (in_array($operation, ['check', 'sync', 'deploy', 'sync-deploy'], true) && $config['repositoryUrl'] === '') {
            $this->_status->addMessage('error', 'Najpierw zapisz adres repozytorium.');
            return;
        }
        if ($operation === 'restore-latest' && !$form->getValue('confirmRestore')) {
            $this->_status->addMessage('error', 'Odtwarzanie wymaga zaznaczenia jawnego potwierdzenia.');
            return;
        }

        try {
            $runtimeConfig = Modules_KitsunecolabManager_Config::createRuntimeConfig($operation);
            $task = new Modules_KitsunecolabManager_Task_Deploy();
            $task->setParam('runtimeConfig', $runtimeConfig);
            $task->setParam('operation', $operation);
            $manager = new pm_LongTask_Manager();
            $manager->start($task);
            $this->_status->addMessage('info', 'Zadanie zostało dodane do kolejki. Postęp pokaże Plesk.');
            $this->respondWithRedirect();
        } catch (Exception $exception) {
            $this->_status->addMessage('error', 'Nie udało się uruchomić zadania: ' . $exception->getMessage());
        }
    }

    private function addPassword(pm_Form_Simple $form, $field, $label, $secretName, $maxLength, $extra = '', $required = true)
    {
        $saved = Modules_KitsunecolabManager_Config::hasSecret($secretName);
        $description = $saved
            ? 'Wartość jest zapisana i zaszyfrowana. Puste pole zachowa obecną wartość.'
            : ($required ? 'Wymagane przed pierwszym wdrożeniem.' : 'Opcjonalne; puste pole wyłącza tę integrację.');
        if ($extra !== '') {
            $description .= ' ' . $extra;
        }
        $form->addElement('password', $field, [
            'label' => $label,
            'value' => '',
            'description' => $description,
            'validators' => [['StringLength', true, ['min' => 0, 'max' => $maxLength]]],
        ]);
    }

    private function addActionButton(pm_Form_Simple $form, $name, $label, $kind)
    {
        $safeLabel = htmlspecialchars($label, ENT_QUOTES, 'UTF-8');
        $safeKind = htmlspecialchars($kind, ENT_QUOTES, 'UTF-8');
        $icon = $kind === 'save' ? '✓' : '▶';
        $form->addElement('simpleText', $name, [
            'label' => '',
            'escape' => false,
            'value' => '<div class="kitsune-action-row"><button type="submit" name="send" value="1" id="' . htmlspecialchars((string) $form->getAttrib('id') . '-' . $safeKind . '-submit', ENT_QUOTES, 'UTF-8') . '" class="kitsune-primary-action" data-kitsune-action="' . $safeKind . '" aria-label="' . $safeLabel . '"><span aria-hidden="true">' . $icon . '</span><span class="kitsune-action-label">' . $safeLabel . '</span></button></div>',
        ]);
    }

    private function respondWithRedirect()
    {
        $path = '/modules/kitsunecolab-manager/index.php/index/index';
        if ($this->getRequest()->isXmlHttpRequest()) {
            $this->_helper->json(['redirect' => $path]);
            return;
        }
        $host = preg_replace('/[^A-Za-z0-9.:-]/', '', (string) ($_SERVER['HTTP_HOST'] ?? ''));
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $this->getResponse()->setRedirect($host !== '' ? $scheme . '://' . $host . $path : $path, 303);
        $this->_helper->viewRenderer->setNoRender(true);
    }

    private function addSection(pm_Form_Simple $form, $name, $title, $description)
    {
        $form->addElement('simpleText', $name, [
            'label' => '',
            'escape' => false,
            'value' => '<div class="kitsune-form-section"><strong>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</strong><span>' . htmlspecialchars($description, ENT_QUOTES, 'UTF-8') . '</span></div>',
        ]);
    }
}
