# KitsuneColab Deployment Manager dla Pleska

Rozszerzenie działa na **Plesk Obsidian dla Linuxa** i udostępnia administratorowi panel do kontroli wersji, kontenerów, wdrożeń, migracji oraz kompletnych kopii PostgreSQL i MinIO.

## Wymagania

- Plesk Obsidian 18.0.41 lub nowszy,
- `git`, Docker Engine i Docker Compose v2,
- dostęp HTTPS lub SSH z serwera do repozytorium,
- dwie domeny lub subdomeny Pleska z HTTPS: panel web i API,
- co najmniej 4 GB RAM dla małego wdrożenia.

## Instalacja

Zbuduj paczkę w repozytorium KitsuneColab:

```bash
pnpm package:plesk
```

Wynik oraz suma SHA-256 trafią do `release/plesk`. ZIP można wysłać przez **Rozszerzenia → Moje rozszerzenia** albo zainstalować przez SSH:

```bash
plesk bin extension -i /root/KitsuneColab-Plesk-Manager-1.5.11-YYYYMMDD-HHMMSS.zip
```

Aktualizacja i usunięcie:

```bash
plesk bin extension -g /root/KitsuneColab-Plesk-Manager-1.5.11-YYYYMMDD-HHMMSS.zip
plesk bin extension -u kitsunecolab-manager
```

Odinstalowanie rozszerzenia nie usuwa repozytorium, wdrożenia, kontenerów, wolumenów ani kopii danych.

## Pierwsza konfiguracja

1. Otwórz **KitsuneColab Manager** w lewym menu administratora.
2. Podaj adres repozytorium i gałąź. Dla prywatnego HTTPS ustaw token; dla SSH wklej read-only deploy key bez hasła oraz zweryfikowane `known_hosts`.
3. Pozostaw oddzielne katalogi źródła, wdrożenia i kopii, np. `/opt/kitsunecolab/source`, `/opt/kitsunecolab/app`, `/opt/kitsunecolab/backups`.
4. Pozostaw `127.0.0.1` jako adres nasłuchu i ustaw wolne porty panelu, API i MinIO.
5. Wpisz publiczne adresy HTTPS panelu oraz API.
6. Ustaw silne, różne wartości: hasło PostgreSQL, JWT (minimum 32 znaki), token metryk (minimum 24 znaki), access key i secret key MinIO.
7. Skonfiguruj SMTP, limit storage, listę zaufanych pluginów i retencję. Puste SMTP wyłącza wysyłkę e-mail bez wpływu na powiadomienia w aplikacji.
8. Nie włączaj danych demonstracyjnych w czystej produkcji. Seed tworzy konta testowe ze znanym hasłem.
9. Zapisz ustawienia, uruchom **Sprawdź repozytorium**, następnie **Pobierz i wdróż**.

## Opcjonalna integracja Kitsune Suite

Ustaw URL-e KitsuneHub/KitsuneTest oraz wspólny
sekret, aby automatycznie provisionować projekty i tworzyć bugi z nieudanych
testów. Bez tych pól Colab działa dokładnie jak wcześniej i nie wymaga pozostałych
produktów. ID organizacji i właściciela możesz uzupełnić później, gdy chcesz
automatycznie tworzyć projekty i issue. Sterowanie deployem z Huba jest oddzielnym, domyślnie wyłączonym
uprawnieniem. Hub może także wykryć ten plugin albo, gdy go brakuje, zbudować go
z repozytorium i przekazać konfigurację pierwszego uruchomienia. Po instalacji
ustawienia pozostają własnością tego managera. Pełny opis znajduje się w
dołączonym `KITSUNE_SUITE.md`.

## Reverse proxy i HTTPS

Utwórz w Plesku dwie domeny z certyfikatami Let's Encrypt:

- `https://kitsune.example.com` → `http://127.0.0.1:3000`,
- `https://api.kitsune.example.com` → `http://127.0.0.1:4000`.

WebSockety Socket.IO wymagają przekazania nagłówków `Upgrade` i `Connection`. MinIO nie musi być publiczne; porty 9000 i 9001 pozostają na loopbacku, dopóki świadomie nie dodasz osobnego proxy.

Po konfiguracji sprawdź:

```bash
curl -fsS https://api.kitsune.example.com/health
curl -I https://kitsune.example.com/
```

## Operacje panelu

- **Sprawdź** — wykonuje `fetch` i porównuje wersję/commit, nie zmienia kontenerów.
- **Synchronizuj** — resetuje dedykowaną kopię roboczą do `origin/<gałąź>`, bez wdrażania.
- **Wdróż** — kopiuje źródła do katalogu tymczasowego, buduje obrazy, przełącza katalog, uruchamia migracje i healthcheck.
- **Pobierz i wdróż** — łączy synchronizację z wdrożeniem.
- **Start / restart / stop** — steruje usługami bez kasowania wolumenów.
- **Pełna kopia** — zapisuje katalog zawierający PostgreSQL, prywatne obiekty MinIO oraz manifest rozmiarów i SHA-256; po sukcesie stosuje skonfigurowaną retencję.
- **Odtwórz najnowszą kopię** — po dodatkowym potwierdzeniu weryfikuje wszystkie sumy, zatrzymuje aplikację, odtwarza bazę i MinIO, stosuje nowsze migracje i uruchamia healthcheck.

Obrazy są budowane przed zatrzymaniem bieżących kontenerów. Gdy nowa wersja nie przejdzie migracji, uruchomienia lub healthchecku, manager przywraca poprzedni katalog i ponownie uruchamia jego kontenery. Wolumeny nigdy nie są usuwane przez panel.

## Model bezpieczeństwa

- dostęp wyłącznie administratora Pleska,
- sekrety zapisane przez `pm_Settings::setEncrypted`,
- jednorazowy plik operacji i `.env` z prawami `0600`,
- token HTTPS podawany przez tymczasowy `GIT_ASKPASS`, nie w URL ani argumentach,
- klucz SSH istnieje na dysku tylko podczas Git; wymuszone `IdentitiesOnly` i `StrictHostKeyChecking`,
- wrapper root przyjmuje tylko nazwane operacje, walidowane katalogi i argumenty,
- `proc_open` otrzymuje osobno zabezpieczone argumenty, operacje są serializowane przez `flock`,
- brak `docker compose down -v`, `git clean` i kasowania nazwanych wolumenów.

## Odtwarzanie kopii

Przed odtwarzaniem zabezpiecz bieżący stan niezależnym snapshotem wolumenów, jeśli może być potrzebny. Następnie wybierz **Odtwórz najnowszą pełną kopię**, zaznacz jawne potwierdzenie i zaakceptuj ostrzeżenie przeglądarki. Manager przyjmuje wyłącznie katalogi utworzone przez siebie, nie podąża za linkami symbolicznymi i przed zmianą danych sprawdza manifest oraz każdą sumę SHA-256.

Odtwarzanie zastępuje bieżącą bazę i zawartość bucketu. Nie przerywaj zadania; po zakończeniu sprawdź healthcheck i wykonaj smoke test aplikacji.
