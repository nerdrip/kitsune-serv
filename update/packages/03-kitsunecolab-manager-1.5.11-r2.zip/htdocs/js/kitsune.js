(function () {
  "use strict";

  var root = document.querySelector("[data-kitsunecolab-manager]");
  if (!root) return;

  var labels = {
    check: "Sprawdź repozytorium i wersje",
    sync: "Zaktualizuj lokalną kopię",
    deploy: "Wdróż obecną wersję",
    "sync-deploy": "Pobierz i wdróż",
    start: "Uruchom usługi",
    restart: "Uruchom usługi ponownie",
    stop: "Zatrzymaj usługi",
    backup: "Utwórz pełną kopię bazy i plików",
    "restore-latest": "Odtwórz najnowszą pełną kopię",
  };

  function activateTab(name, updateHash) {
    root.querySelectorAll("[data-kitsune-tab]").forEach(function (tab) {
      var active = tab.getAttribute("data-kitsune-tab") === name;
      tab.setAttribute("aria-selected", active ? "true" : "false");
      tab.classList.toggle("is-active", active);
    });
    root.querySelectorAll("[data-kitsune-panel]").forEach(function (panel) {
      panel.hidden = panel.getAttribute("data-kitsune-panel") !== name;
    });
    if (updateHash && window.history && window.history.replaceState) {
      window.history.replaceState(null, "", "#" + name);
    }
  }

  root.querySelectorAll("[data-kitsune-tab]").forEach(function (tab) {
    tab.addEventListener("click", function () {
      activateTab(tab.getAttribute("data-kitsune-tab"), true);
    });
  });
  var requested = window.location.hash.replace(/^#/, "");
  activateTab(root.querySelector('[data-kitsune-tab="' + requested + '"]') ? requested : "status", false);

  var operationForm = document.getElementById("kitsune-operation-form");
  if (operationForm) {
    var select = operationForm.querySelector('[name="operation"]');
    var button = operationForm.querySelector("[data-kitsune-action=operation]");
    var buttonLabel = button && button.querySelector(".kitsune-action-label");
    function updateOperationLabel() {
      if (select && buttonLabel) buttonLabel.textContent = labels[select.value] || "Uruchom operację";
    }
    if (select) select.addEventListener("change", updateOperationLabel);
    updateOperationLabel();
    operationForm.addEventListener("submit", function (event) {
      if (select && select.value === "restore-latest") {
        var confirmation = operationForm.querySelector('[name="confirmRestore"]');
        if (!confirmation || !confirmation.checked || !window.confirm("Odtworzyć najnowszy backup? Aktualna baza i pliki zostaną zastąpione.")) {
          event.preventDefault();
          return;
        }
      }
      if (!button || button.disabled) return;
      button.disabled = true;
      button.classList.add("is-loading");
      if (buttonLabel) buttonLabel.textContent = "Uruchamianie…";
    });
  }

  var configForm = document.getElementById("kitsune-config-form");
  if (configForm) {
    var proxyMode = configForm.querySelector('[name="proxyMode"]');
    var manualVhost = root.querySelector("[data-kitsune-manual-vhost]");
    function updateVhostHelp() {
      if (manualVhost && proxyMode) manualVhost.hidden = proxyMode.value !== "manual";
    }
    if (proxyMode) proxyMode.addEventListener("change", updateVhostHelp);
    updateVhostHelp();
    configForm.addEventListener("submit", function () {
      var button = configForm.querySelector("[data-kitsune-action=save]");
      if (!button || button.disabled) return;
      button.disabled = true;
      var label = button.querySelector(".kitsune-action-label");
      if (label) label.textContent = "Zapisywanie…";
    });
  }
})();
