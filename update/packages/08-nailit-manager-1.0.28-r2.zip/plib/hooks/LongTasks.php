<?php

class Modules_NailitManager_LongTasks extends pm_Hook_LongTasks
{
    public function getLongTasks()
    {
        return [new Modules_NailitManager_Task_Deploy()];
    }
}
