<?php

class Modules_NailitManager_Task_Deploy extends pm_LongTask_Task
{
    public $trackProgress = true;

    public function run()
    {
        $runtimeConfig = (string) $this->getParam('runtimeConfig');
        if ($runtimeConfig === '') {
            throw new RuntimeException('Brak pliku konfiguracji operacji.');
        }

        $this->updateProgress(10);
        $result = pm_ApiCli::callSbin(
            'nailit-manager',
            ['--config', $runtimeConfig],
            pm_ApiCli::RESULT_FULL
        );
        $this->updateProgress(95);

        $stdout = trim((string) ($result['stdout'] ?? ''));
        $stderr = trim((string) ($result['stderr'] ?? ''));
        $this->setParam('output', mb_substr($stdout . ($stderr !== '' ? "\n" . $stderr : ''), -12000));

        if ((int) ($result['code'] ?? 1) !== 0) {
            throw new RuntimeException($stderr !== '' ? $stderr : 'Operacja NailIT zakończyła się błędem.');
        }

        $this->updateProgress(100);
    }

    public function onError(Exception $exception)
    {
        $this->removeRuntimeConfig();
    }

    public function onDone()
    {
        $this->removeRuntimeConfig();
    }

    public function statusMessage()
    {
        $operation = (string) $this->getParam('operation');
        switch ($this->getStatus()) {
            case static::STATUS_RUNNING:
                if ($operation === 'backup') {
                    return 'NailIT: trwa tworzenie pełnego backupu danych…';
                }
                if ($operation === 'restore') {
                    return 'NailIT: trwa weryfikacja i przywracanie danych…';
                }
                return 'NailIT: trwa praca z repozytorium lub wdrożeniem…';
            case static::STATUS_DONE:
                if ($operation === 'backup') {
                    return 'NailIT: pełny backup danych został utworzony.';
                }
                if ($operation === 'restore') {
                    return 'NailIT: dane zostały przywrócone.';
                }
                return 'NailIT: operacja zakończona.';
            case static::STATUS_ERROR:
                return 'NailIT: operacja zakończona błędem.';
            default:
                return 'NailIT: zadanie oczekuje na uruchomienie.';
        }
    }

    private function removeRuntimeConfig()
    {
        $path = (string) $this->getParam('runtimeConfig');
        if ($path !== '' && is_file($path)) {
            @unlink($path);
        }
    }
}
