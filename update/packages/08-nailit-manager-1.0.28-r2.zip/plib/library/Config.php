<?php

class Modules_NailitManager_Config
{
    public const EXTENSION_VERSION = '1.0.28';

    private const SECRET_FIELDS = [
        'gitToken' => 'secret_git_token',
        'gitSshPrivateKey' => 'secret_git_ssh_private_key',
        'databasePassword' => 'secret_database_password',
        'adminPassword' => 'secret_admin_password',
        'smtpPassword' => 'secret_smtp_password',
    ];

    public static function defaults()
    {
        return [
            'repositoryUrl' => '',
            'repositoryBranch' => 'main',
            'repositoryPath' => '/opt/nailit/source',
            'gitUsername' => 'x-access-token',
            'gitSshKnownHosts' => '',
            'licenseDeployPath' => '/opt/nailit/license-server',
            'webDeployPath' => '/opt/nailit/web',
            'siteDeployPath' => '/opt/nailit/site',
            'persistentDataPath' => '/opt/nailit/persistent',
            'backupPath' => '/opt/nailit/backups',
            'backupRetention' => '10',
            'databaseMode' => 'embedded',
            'databaseHost' => 'host.docker.internal',
            'databasePort' => '5432',
            'databaseName' => 'nailit',
            'databaseUser' => 'nailit',
            'bindAddress' => '127.0.0.1',
            'licensePort' => '47831',
            'adminerPort' => '8081',
            'webPort' => '8080',
            'sitePort' => '8090',
            'siteDomain' => 'nailit.ltd',
            'adminEmail' => 'admin@nailit.local',
            'publicUrl' => 'https://lic.nailit.ltd',
            'webLicenseServerUrl' => 'https://lic.nailit.ltd',
            'siteLicenseServerUrl' => 'https://lic.nailit.ltd',
            'smtpHost' => '',
            'smtpPort' => '587',
            'smtpSecurity' => 'starttls',
            'smtpUser' => '',
            'mailFrom' => 'NailIT <no-reply@nailit.ltd>',
        ];
    }

    public static function values()
    {
        $values = [];
        foreach (self::defaults() as $key => $default) {
            $values[$key] = (string) pm_Settings::get($key, $default);
        }
        $publicUrl = rtrim($values['publicUrl'], '/');
        foreach (['webLicenseServerUrl', 'siteLicenseServerUrl'] as $apiUrlField) {
            $apiUrl = rtrim($values[$apiUrlField], '/');
            $apiHost = strtolower((string) parse_url($apiUrl, PHP_URL_HOST));
            $publicHost = strtolower((string) parse_url($publicUrl, PHP_URL_HOST));
            if (preg_match('/(^|\.)example\.(com|net|org)$/', $apiHost) && $publicHost !== '' && !preg_match('/(^|\.)example\.(com|net|org)$/', $publicHost)) {
                // Migracja historycznego placeholdera. Dzięki temu istniejąca
                // konfiguracja korzysta z ustawionego publicznego API zamiast
                // generować niedziałający upstream nginx.
                $values[$apiUrlField] = $publicUrl;
            }
        }
        if (
            $values['bindAddress'] === '127.0.0.1'
            && preg_match('#^http://host\.docker\.internal(?::\d+)?$#i', rtrim($values['webLicenseServerUrl'], '/'))
            && preg_match('#^https?://#i', $values['publicUrl'])
        ) {
            // Port przypięty do loopback hosta nie jest osiągalny przez
            // host.docker.internal. W takim układzie kontener web powinien
            // korzystać z publicznej domeny obsługiwanej przez proxy Pleska.
            $values['webLicenseServerUrl'] = rtrim($values['publicUrl'], '/');
        }
        if (
            $values['bindAddress'] === '127.0.0.1'
            && preg_match('#^http://host\.docker\.internal(?::\d+)?$#i', rtrim($values['siteLicenseServerUrl'], '/'))
            && preg_match('#^https?://#i', $values['publicUrl'])
        ) {
            $values['siteLicenseServerUrl'] = rtrim($values['publicUrl'], '/');
        }
        return $values;
    }

    public static function save(array $values)
    {
        foreach (self::defaults() as $key => $default) {
            if (array_key_exists($key, $values)) {
                $value = trim((string) $values[$key]);
                pm_Settings::set($key, $value);
            }
        }

        foreach (self::SECRET_FIELDS as $field => $setting) {
            $value = trim((string) ($values[$field] ?? ''));
            if ($field === 'gitSshPrivateKey') {
                $value = self::normalizePrivateKey($value);
            }
            if ($value !== '') {
                pm_Settings::setEncrypted($setting, $value);
            }
        }
    }

    public static function hasSecret($field)
    {
        return self::secret($field) !== '';
    }

    public static function readState()
    {
        $path = pm_Context::getVarDir() . '/state.json';
        if (!is_file($path)) {
            return self::emptyState();
        }

        $decoded = json_decode((string) file_get_contents($path), true);
        return is_array($decoded) ? array_replace_recursive(self::emptyState(), $decoded) : self::emptyState();
    }

    public static function createRuntimeConfig($action, array $modules, array $parameters = [])
    {
        $varDir = rtrim((string) pm_Context::getVarDir(), '/\\');
        if (!is_dir($varDir) && !mkdir($varDir, 0700, true) && !is_dir($varDir)) {
            throw new RuntimeException('Nie udało się utworzyć katalogu roboczego rozszerzenia.');
        }
        @chmod($varDir, 0700);
        $realVarDir = realpath($varDir);
        if ($realVarDir === false) {
            throw new RuntimeException('Nie udało się ustalić katalogu roboczego rozszerzenia.');
        }
        $varDir = $realVarDir;

        $config = self::values();
        $config['gitToken'] = self::secret('gitToken');
        $config['gitSshPrivateKey'] = self::normalizePrivateKey(self::secret('gitSshPrivateKey'));
        $config['databasePassword'] = self::secret('databasePassword');
        $config['adminPassword'] = self::secret('adminPassword');
        $config['smtpPassword'] = self::secret('smtpPassword');
        $config['action'] = (string) $action;
        $config['modules'] = array_values($modules);
        $config['requestedAt'] = gmdate('c');
        if (array_key_exists('backupName', $parameters)) {
            $config['backupName'] = trim((string) $parameters['backupName']);
        }
        if (in_array($config['action'], ['deploy', 'sync-deploy'], true) && in_array('site', $config['modules'], true)) {
            $domain = self::hostedDomain($config['siteDomain']);
            $config['siteDocumentRoot'] = (string) $domain->getDocumentRoot();
            $config['siteVhostSystemPath'] = (string) $domain->getVhostSystemPath();
            $config['siteSystemUser'] = (string) $domain->getSysUserLogin();
        }

        $path = $varDir . '/operation-' . bin2hex(random_bytes(12)) . '.json';
        $json = json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $previousUmask = umask(0077);
        try {
            if ($json === false || file_put_contents($path, $json, LOCK_EX) === false) {
                throw new RuntimeException('Nie udało się zapisać konfiguracji operacji.');
            }
            @chmod($path, 0600);
        } finally {
            umask($previousUmask);
        }
        return $path;
    }

    private static function secret($field)
    {
        $setting = self::SECRET_FIELDS[$field] ?? null;
        if ($setting === null) {
            return '';
        }
        try {
            return (string) pm_Settings::getDecrypted($setting);
        } catch (Exception $exception) {
            return '';
        }
    }

    private static function normalizePrivateKey($value)
    {
        $value = str_replace(["\r\n", "\r"], "\n", (string) $value);
        if (strncmp($value, "\xEF\xBB\xBF", 3) === 0) {
            $value = substr($value, 3);
        }
        return trim($value);
    }

    private static function hostedDomain($name)
    {
        $name = strtolower(trim((string) $name));
        try {
            $domain = pm_Domain::getByName($name);
        } catch (Throwable $exception) {
            throw new RuntimeException('Wybrana domena Pleska nie istnieje albo nie jest dostępna: ' . $name, 0, $exception);
        }
        if (!$domain instanceof pm_Domain || !$domain->hasHosting() || !$domain->isActive() || $domain->isSuspended() || $domain->isDisabled()) {
            throw new RuntimeException('Wybrana domena musi być aktywna i posiadać hosting WWW: ' . $name);
        }
        return $domain;
    }

    private static function emptyState()
    {
        return [
            'updatedAt' => null,
            'lastOperation' => null,
            'lastSuccess' => null,
            'lastError' => null,
            'repository' => [
                'path' => null,
                'branch' => null,
                'localCommit' => null,
                'remoteCommit' => null,
                'updateAvailable' => null,
                'dirty' => null,
                'checkedAt' => null,
                'error' => null,
                'remoteManifestKnown' => false,
            ],
            'localModules' => [],
            'availableModules' => [],
            'deployedModules' => [],
            'services' => [],
            'statusErrors' => [
                'repository' => null,
                'docker' => null,
            ],
            'dockerInventory' => [
                'total' => 0,
                'matched' => 0,
                'unmatched' => [],
                'checkedAt' => null,
            ],
            'backups' => [],
            'lastBackup' => null,
            'lastRestore' => null,
            'log' => [],
        ];
    }
}
