<?php

class IndexController extends pm_Controller_Action
{
    protected $_accessLevel = 'admin';

    public function init()
    {
        parent::init();
        $this->view->pageTitle = 'NailIT Deployment Manager';
        $this->view->headLink()->appendStylesheet(pm_Context::getBaseUrl() . 'css/nailit.css?v=' . Modules_NailitManager_Config::EXTENSION_VERSION);
        $this->view->headLink()->appendStylesheet(pm_Context::getBaseUrl() . 'css/kitsune-platform.css?v=1');
        $this->view->headScript()->appendFile(pm_Context::getBaseUrl() . 'js/kitsune-platform.js?v=1');
        $this->view->suiteProduct = 'NailIT Manager';
        $this->view->suiteVersion = Modules_NailitManager_Config::EXTENSION_VERSION;
        try { $this->view->suiteHubActive = pm_Extension::getById('kitsuneserv-bridge')->isActive(); }
        catch (Throwable $exception) { $this->view->suiteHubActive = false; }
    }

    public function indexAction()
    {
        $statusRefreshError = null;
        if (!$this->getRequest()->isPost()) {
            $statusRefreshError = $this->refreshRuntimeState();
        }

        $configForm = $this->createConfigForm();
        $operationForm = $this->createOperationForm();
        $state = Modules_NailitManager_Config::readState();
        $maintenanceForm = $this->createMaintenanceForm($state);

        if ($this->getRequest()->isPost()) {
            $post = $this->getRequest()->getPost();
            $formType = (string) ($post['formType'] ?? '');
            if ($formType === 'config') {
                $this->processConfigForm($configForm, $post);
                return;
            } elseif ($formType === 'operation') {
                $this->processOperationForm($operationForm, $post);
                return;
            } elseif ($formType === 'maintenance') {
                $this->processMaintenanceForm($maintenanceForm, $post, $state);
                return;
            }
            $this->_status->addMessage('error', 'Nie rozpoznano wysłanego formularza. Odśwież stronę i spróbuj ponownie.');
            $this->respondWithRedirect();
            return;
        }

        $this->view->configForm = $configForm;
        $this->view->operationForm = $operationForm;
        $this->view->maintenanceForm = $maintenanceForm;
        $this->view->statusRefreshError = $statusRefreshError;
        $this->view->state = $state;
        $this->view->config = Modules_NailitManager_Config::values();
        $this->view->hasGitToken = Modules_NailitManager_Config::hasSecret('gitToken');
        $this->view->hasGitSshPrivateKey = Modules_NailitManager_Config::hasSecret('gitSshPrivateKey');
        $this->view->hasDatabasePassword = Modules_NailitManager_Config::hasSecret('databasePassword');
        $this->view->hasAdminPassword = Modules_NailitManager_Config::hasSecret('adminPassword');
        $this->view->hasSmtpPassword = Modules_NailitManager_Config::hasSecret('smtpPassword');
        $this->view->extensionVersion = Modules_NailitManager_Config::EXTENSION_VERSION;
    }

    private function createConfigForm()
    {
        $values = Modules_NailitManager_Config::values();
        $siteDomains = $this->siteDomainOptions($values['siteDomain']);
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'nailit-config-form');
        $form->addElement('hidden', 'formType', ['value' => 'config']);

        $this->addSection($form, 'repoSection', 'Repozytorium Git', 'Rozszerzenie używa własnej kopii roboczej. Aktualizacja repozytorium nie wdraża automatycznie modułów.');
        $form->addElement('text', 'repositoryUrl', [
            'label' => 'Adres repozytorium',
            'value' => $values['repositoryUrl'],
            'description' => 'HTTPS (zalecane z tokenem) albo SSH, np. git@github.com:firma/nailit.git.',
            'required' => true,
            'validators' => [['StringLength', true, ['min' => 5, 'max' => 1000]]],
        ]);
        $form->addElement('text', 'repositoryBranch', [
            'label' => 'Gałąź',
            'value' => $values['repositoryBranch'],
            'required' => true,
            'validators' => [['Regex', true, ['pattern' => '/^(?![-.])(?!.*\.\.)(?!.*@\{)[A-Za-z0-9._\/-]+$/']]],
        ]);
        $form->addElement('text', 'repositoryPath', [
            'label' => 'Katalog kopii repozytorium',
            'value' => $values['repositoryPath'],
            'required' => true,
            'validators' => [['Regex', true, ['pattern' => '#^/[A-Za-z0-9._/-]+$#']]],
        ]);
        $form->addElement('text', 'gitUsername', [
            'label' => 'Użytkownik Git HTTPS',
            'value' => $values['gitUsername'],
            'description' => 'Dla tokenu GitHub pozostaw x-access-token. Przy SSH pole jest ignorowane.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 255]]],
        ]);
        $form->addElement('password', 'gitToken', [
            'label' => 'Token / hasło Git',
            'value' => '',
            'description' => Modules_NailitManager_Config::hasSecret('gitToken') ? 'Token jest zapisany i zaszyfrowany. Puste pole zachowa obecną wartość.' : 'Puste pole oznacza repozytorium publiczne lub uwierzytelnianie kluczem SSH.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 1900]]],
        ]);
        $form->addElement('textarea', 'gitSshPrivateKey', [
            'label' => 'Prywatny klucz SSH repozytorium',
            'value' => '',
            'rows' => 7,
            'class' => 'f-middle-size nailit-secret-textarea',
            'description' => Modules_NailitManager_Config::hasSecret('gitSshPrivateKey') ? 'Klucz SSH jest zapisany i zaszyfrowany. Puste pole zachowa obecną wartość.' : 'Opcjonalny, najlepiej read-only deploy key bez hasła. Będzie używany wyłącznie dla adresu SSH tego repozytorium.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 4800]]],
        ]);
        $form->addElement('textarea', 'gitSshKnownHosts', [
            'label' => 'Znane hosty SSH',
            'value' => $values['gitSshKnownHosts'],
            'rows' => 4,
            'class' => 'f-middle-size',
            'description' => 'Opcjonalna zawartość known_hosts dla hosta Git. Gdy pusta, używany jest systemowy plik root/.ssh/known_hosts; weryfikacja hosta nie jest wyłączana.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 4800]]],
        ]);

        $this->addSection($form, 'deploySection', 'Wdrożenia Docker Compose', 'Porty domyślnie są przypięte do 127.0.0.1, aby wystawić je przez domenę i reverse proxy Pleska.');
        $form->addElement('text', 'licenseDeployPath', [
            'label' => 'Katalog serwera licencyjnego',
            'value' => $values['licenseDeployPath'],
            'required' => true,
            'validators' => [['Regex', true, ['pattern' => '#^/[A-Za-z0-9._/-]+$#']]],
        ]);
        $form->addElement('text', 'webDeployPath', [
            'label' => 'Katalog aplikacji webowej',
            'value' => $values['webDeployPath'],
            'required' => true,
            'validators' => [['Regex', true, ['pattern' => '#^/[A-Za-z0-9._/-]+$#']]],
        ]);
        $form->addElement('text', 'siteDeployPath', [
            'label' => 'Katalog strony głównej',
            'value' => $values['siteDeployPath'],
            'required' => true,
            'validators' => [['Regex', true, ['pattern' => '#^/[A-Za-z0-9._/-]+$#']]],
        ]);
        $this->addSection($form, 'persistenceSection', 'Dane trwałe i kopie zapasowe', 'Kod wdrożenia, dane systemu i archiwa są rozdzielone. Aktualizacja rozszerzenia ani produktu nie usuwa tych katalogów.');
        $form->addElement('text', 'persistentDataPath', [
            'label' => 'Katalog danych trwałych',
            'value' => $values['persistentDataPath'],
            'description' => 'Katalog nadrzędny dla danych PostgreSQL i storage CMS, np. /opt/nailit/persistent. Przy pierwszym wdrożeniu manager bezpiecznie przeniesie dane ze starszych wolumenów Dockera.',
            'required' => true,
            'validators' => [['Regex', true, ['pattern' => '#^/[A-Za-z0-9._/-]+$#']]],
        ]);
        $form->addElement('text', 'backupPath', [
            'label' => 'Katalog backupów',
            'value' => $values['backupPath'],
            'description' => 'Musi być oddzielony od danych trwałych i katalogów wdrożeń. Najlepiej umieścić go na innym dysku lub zasobie montowanym do serwera.',
            'required' => true,
            'validators' => [['Regex', true, ['pattern' => '#^/[A-Za-z0-9._/-]+$#']]],
        ]);
        $form->addElement('text', 'backupRetention', [
            'label' => 'Liczba przechowywanych backupów',
            'value' => $values['backupRetention'],
            'description' => 'Po udanej kopii usuwane są wyłącznie najstarsze archiwa utworzone przez NailIT ponad ten limit.',
            'required' => true,
            'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 100]]],
        ]);
        $form->addElement('text', 'bindAddress', [
            'label' => 'Adres nasłuchu',
            'value' => $values['bindAddress'],
            'description' => 'Zalecane: 127.0.0.1. Ustaw 0.0.0.0 tylko świadomie.',
            'required' => true,
            'validators' => [['Ip', true]],
        ]);
        $form->addElement('text', 'licensePort', [
            'label' => 'Port serwera licencyjnego',
            'value' => $values['licensePort'],
            'required' => true,
            'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 65535]]],
        ]);
        $form->addElement('text', 'adminerPort', [
            'label' => 'Awaryjny port Adminera',
            'value' => $values['adminerPort'],
            'required' => true,
            'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 65535]]],
        ]);
        $form->addElement('text', 'webPort', [
            'label' => 'Port aplikacji webowej',
            'value' => $values['webPort'],
            'required' => true,
            'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 65535]]],
        ]);
        $form->addElement('text', 'sitePort', [
            'label' => 'Port strony głównej',
            'value' => $values['sitePort'],
            'description' => 'Skieruj wybraną domenę Pleska przez reverse proxy na ten port.',
            'required' => true,
            'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 65535]]],
        ]);
        if ($siteDomains) {
            $form->addElement('select', 'siteDomain', [
                'label' => 'Domena Pleska dla strony głównej i CMS',
                'multiOptions' => $siteDomains,
                'value' => isset($siteDomains[$values['siteDomain']]) ? $values['siteDomain'] : array_key_first($siteDomains),
                'description' => 'Lista aktywnych domen i subdomen z hostingiem WWW. Publikacja plików i proxy /v1/ zostaną skonfigurowane automatycznie.',
                'required' => true,
            ]);
        } else {
            $form->addElement('text', 'siteDomain', [
                'label' => 'Domena Pleska dla strony głównej i CMS',
                'value' => $values['siteDomain'],
                'description' => 'Nie znaleziono aktywnej domeny z hostingiem WWW. Utwórz ją w Plesku, a następnie odśwież tę stronę.',
                'required' => true,
                'validators' => [['Regex', true, ['pattern' => '/^(?=.{1,253}$)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}$/']]],
            ]);
        }
        $form->addElement('text', 'publicUrl', [
            'label' => 'Publiczny URL serwera licencyjnego',
            'value' => $values['publicUrl'],
            'description' => 'Produkcyjnie użyj HTTPS, bez końcowego ukośnika.',
            'required' => true,
            'validators' => [['StringLength', true, ['min' => 8, 'max' => 1000]]],
        ]);
        $form->addElement('text', 'webLicenseServerUrl', [
            'label' => 'URL API widziany przez kontener web',
            'value' => $values['webLicenseServerUrl'],
            'description' => 'Przy porcie przypiętym do 127.0.0.1 użyj publicznej domeny serwera licencyjnego, np. https://lic.nailit.ltd.',
            'required' => true,
            'validators' => [['StringLength', true, ['min' => 8, 'max' => 1000]]],
        ]);
        $form->addElement('text', 'siteLicenseServerUrl', [
            'label' => 'URL API CMS widziany przez stronę',
            'value' => $values['siteLicenseServerUrl'],
            'description' => 'Zwykle ten sam publiczny adres serwera licencyjnego. Gdy wdrażasz serwer licencyjny razem ze stroną, proxy użyje automatycznie lokalnego portu.',
            'required' => true,
            'validators' => [['StringLength', true, ['min' => 8, 'max' => 1000]]],
        ]);
        $form->addElement('text', 'adminEmail', [
            'label' => 'E-mail administratora NailIT',
            'value' => $values['adminEmail'],
            'required' => true,
            'validators' => [['EmailAddress', true]],
        ]);
        $form->addElement('password', 'adminPassword', [
            'label' => 'Hasło administratora NailIT',
            'value' => '',
            'description' => Modules_NailitManager_Config::hasSecret('adminPassword') ? 'Hasło jest zapisane i zaszyfrowane. Wpisz nowe, aby je zmienić.' : 'Przy pierwszym wdrożeniu bez wartości zostanie użyte hasło admin — zmień je od razu po teście.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 1900]]],
        ]);

        $this->addSection($form, 'mailSection', 'Wysyłka e-mail i newsletter', 'SMTP obsługuje potwierdzenia newslettera, weryfikację kont i reset hasła. Sukces na stronie pojawi się dopiero po przyjęciu wiadomości przez serwer pocztowy.');
        $form->addElement('text', 'smtpHost', [
            'label' => 'Host SMTP',
            'value' => $values['smtpHost'],
            'description' => 'Np. smtp.nailit.ltd. Puste pole wyłącza SMTP; wtedy wymagany jest zewnętrzny webhook pocztowy.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 255]]],
        ]);
        $form->addElement('text', 'smtpPort', [
            'label' => 'Port SMTP',
            'value' => $values['smtpPort'],
            'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 65535]]],
        ]);
        $form->addElement('radio', 'smtpSecurity', [
            'label' => 'Szyfrowanie SMTP',
            'multiOptions' => [
                'starttls' => 'STARTTLS — zwykle port 587',
                'tls' => 'TLS od początku — zwykle port 465',
                'none' => 'Brak TLS — tylko zaufany lokalny relay',
            ],
            'value' => $values['smtpSecurity'],
            'required' => true,
        ]);
        $form->addElement('text', 'smtpUser', [
            'label' => 'Użytkownik SMTP',
            'value' => $values['smtpUser'],
            'description' => 'Najczęściej pełny adres skrzynki nadawczej. Może pozostać pusty wyłącznie dla zaufanego relaya.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 255]]],
        ]);
        $form->addElement('password', 'smtpPassword', [
            'label' => 'Hasło SMTP',
            'value' => '',
            'description' => Modules_NailitManager_Config::hasSecret('smtpPassword') ? 'Hasło SMTP jest zapisane i zaszyfrowane. Puste pole zachowa obecną wartość.' : 'Wymagane, jeżeli serwer SMTP wymaga logowania.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 1900]]],
        ]);
        $form->addElement('text', 'mailFrom', [
            'label' => 'Nadawca wiadomości',
            'value' => $values['mailFrom'],
            'description' => 'Np. NailIT <no-reply@nailit.ltd>. Adres powinien należeć do skonfigurowanej domeny pocztowej.',
            'required' => true,
            'validators' => [['StringLength', true, ['min' => 3, 'max' => 255]]],
        ]);

        $this->addSection($form, 'databaseSection', 'PostgreSQL serwera licencyjnego', 'Tryb wbudowany zachowuje dane w wolumenie Dockera. Tryb zewnętrzny nie tworzy kontenera bazy.');
        $form->addElement('radio', 'databaseMode', [
            'label' => 'Źródło bazy danych',
            'multiOptions' => [
                'embedded' => 'Własny PostgreSQL w Docker Compose',
                'external' => 'Istniejący PostgreSQL na serwerze / w sieci',
            ],
            'value' => $values['databaseMode'],
            'required' => true,
        ]);
        $form->addElement('text', 'databaseHost', [
            'label' => 'Host zewnętrznej bazy',
            'value' => $values['databaseHost'],
            'description' => 'Np. host.docker.internal albo prywatny adres IP. Używane tylko w trybie zewnętrznym.',
            'validators' => [['StringLength', true, ['min' => 1, 'max' => 255]]],
        ]);
        $form->addElement('text', 'databasePort', [
            'label' => 'Port bazy',
            'value' => $values['databasePort'],
            'validators' => [['Digits', true], ['Between', true, ['min' => 1, 'max' => 65535]]],
        ]);
        $form->addElement('text', 'databaseName', [
            'label' => 'Nazwa bazy',
            'value' => $values['databaseName'],
            'validators' => [['Regex', true, ['pattern' => '/^[A-Za-z0-9_-]{1,63}$/']]],
        ]);
        $form->addElement('text', 'databaseUser', [
            'label' => 'Użytkownik bazy',
            'value' => $values['databaseUser'],
            'validators' => [['Regex', true, ['pattern' => '/^[A-Za-z0-9_.-]{1,63}$/']]],
        ]);
        $form->addElement('password', 'databasePassword', [
            'label' => 'Hasło zewnętrznej bazy',
            'value' => '',
            'description' => Modules_NailitManager_Config::hasSecret('databasePassword') ? 'Hasło jest zapisane i zaszyfrowane. Puste pole zachowa obecną wartość.' : 'Wymagane przy pierwszym wdrożeniu z zewnętrzną bazą.',
            'validators' => [['StringLength', true, ['min' => 0, 'max' => 1900]]],
        ]);

        $this->addActionButton($form, 'configActions', 'Zapisz ustawienia', 'save');
        $form->addControlButtons([
            'sendHidden' => true,
            'cancelHidden' => true,
            'hideLegend' => true,
        ]);
        return $form;
    }

    private function createMaintenanceForm(array $state)
    {
        $backupOptions = ['' => '— wybierz backup do przywrócenia —'];
        foreach ((array) ($state['backups'] ?? []) as $backup) {
            $name = (string) ($backup['name'] ?? '');
            if (!preg_match('/^nailit-backup-[0-9]{8}-[0-9]{6}-[a-f0-9]{8}\.tar\.gz$/', $name)) {
                continue;
            }
            $created = !empty($backup['createdAt']) ? gmdate('Y-m-d H:i', strtotime((string) $backup['createdAt'])) . ' UTC' : $name;
            $size = !empty($backup['size']) ? $this->formatBytes((int) $backup['size']) : 'rozmiar nieznany';
            $backupOptions[$name] = $created . ' · ' . $size . (!empty($backup['verified']) ? ' · suma OK' : ' · wymaga weryfikacji');
        }

        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'nailit-maintenance-form');
        $form->addElement('hidden', 'formType', ['value' => 'maintenance']);
        $form->addElement('radio', 'maintenanceOperation', [
            'label' => 'Operacja na danych',
            'multiOptions' => [
                'backup' => 'Utwórz pełny backup teraz',
                'restore' => 'Przywróć bazę, storage i sekrety aplikacji',
            ],
            'value' => 'backup',
            'required' => true,
        ]);
        $form->addElement('select', 'backupName', [
            'label' => 'Backup do przywrócenia',
            'multiOptions' => $backupOptions,
            'value' => '',
            'description' => 'Lista zawiera archiwa znalezione w skonfigurowanym katalogu backupów. Suma SHA-256 i manifest są sprawdzane ponownie przed restore.',
            'required' => false,
        ]);
        $form->addElement('checkbox', 'confirmRestore', [
            'label' => 'Rozumiem, że restore zastąpi bieżące dane',
            'value' => '0',
            'description' => 'Przed zmianą manager automatycznie utworzy awaryjny backup aktualnego stanu i zatrzyma usługi na czas przywracania.',
        ]);
        $this->addActionButton($form, 'maintenanceActions', 'Utwórz pełny backup', 'maintenance');
        $form->addControlButtons([
            'sendHidden' => true,
            'cancelHidden' => true,
            'hideLegend' => true,
        ]);
        return $form;
    }

    private function createOperationForm()
    {
        $values = Modules_NailitManager_Config::values();
        $siteDomains = $this->siteDomainOptions($values['siteDomain']);
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'nailit-operation-form');
        $form->addElement('hidden', 'formType', ['value' => 'operation']);
        $form->addElement('select', 'operation', [
            'label' => 'Operacja',
            'multiOptions' => [
                'check' => 'Sprawdź repozytorium i dostępne wersje (bez wdrażania)',
                'sync' => 'Zaktualizuj tylko lokalną kopię repozytorium',
                'deploy' => 'Wdróż moduły z obecnej lokalnej kopii',
                'sync-deploy' => 'Pobierz najnowszy kod i wdróż wybrane moduły',
            ],
            'value' => 'check',
            'required' => true,
        ]);
        $this->addSection($form, 'siteTargetSection', 'Miejsce publikacji strony i CMS', 'Wybierz domenę bezpośrednio przed wdrożeniem. Manager opublikuje pliki w jej document root i automatycznie skonfiguruje proxy publicznego API CMS pod /v1/.');
        $form->addElement('select', 'siteDomainDeploy', [
            'label' => 'Domena docelowa strony/CMS',
            'multiOptions' => ['' => $siteDomains ? '— wybierz domenę Pleska —' : '— brak aktywnej domeny z hostingiem WWW —'] + $siteDomains,
            'value' => isset($siteDomains[$values['siteDomain']]) ? $values['siteDomain'] : '',
            'description' => 'Pole jest używane tylko przy zaznaczonym module „Strona główna i CMS”.',
            'required' => false,
        ]);
        $this->addSection($form, 'moduleSection', 'Moduły do wdrożenia', 'Strona główna i CMS jest pełnoprawnym modułem wydania, obok serwera licencyjnego i aplikacji webowej.');
        $form->addElement('checkbox', 'moduleLicense', [
            'label' => 'Serwer licencyjny',
            'value' => '1',
            'description' => 'Kod API, panel, Adminer SSO i wybrany wariant PostgreSQL.',
        ]);
        $form->addElement('checkbox', 'moduleWeb', [
            'label' => 'Aplikacja webowa',
            'value' => '1',
            'description' => 'Interfejs webowy i reverse proxy do API licencji.',
        ]);
        $form->addElement('checkbox', 'moduleSite', [
            'label' => 'Strona główna i CMS',
            'value' => '1',
            'description' => 'Responsywna strona nailit.ltd, newsletter, downloady i proxy do publicznego API CMS.',
        ]);
        $this->addActionButton($form, 'operationActions', 'Sprawdź repozytorium i wersje', 'operation');
        $form->addControlButtons([
            'sendHidden' => true,
            'cancelHidden' => true,
            'hideLegend' => true,
        ]);
        return $form;
    }

    private function processConfigForm(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) {
            $this->_status->addMessage('error', 'Sprawdź oznaczone pola konfiguracji i spróbuj ponownie.');
            $this->respondWithRedirect();
            return;
        }

        $values = $form->getValues();
        try {
            $this->validateConfiguredPaths($values);
        } catch (Throwable $exception) {
            $this->_status->addMessage('error', $exception->getMessage());
            $this->respondWithRedirect();
            return;
        }
        Modules_NailitManager_Config::save($values);
        $this->_status->addMessage('info', 'Konfiguracja NailIT została zapisana.');
        $this->respondWithRedirect();
    }

    private function processMaintenanceForm(pm_Form_Simple $form, array $post, array $state)
    {
        if (!$form->isValid($post)) {
            $this->_status->addMessage('error', 'Sprawdź pola operacji na danych i spróbuj ponownie.');
            $this->respondWithRedirect();
            return;
        }
        $operation = (string) $form->getValue('maintenanceOperation');
        if (!in_array($operation, ['backup', 'restore'], true)) {
            $this->_status->addMessage('error', 'Nieznana operacja na danych trwałych.');
            $this->respondWithRedirect();
            return;
        }
        $backupName = trim((string) $form->getValue('backupName'));
        if ($operation === 'restore') {
            $known = [];
            foreach ((array) ($state['backups'] ?? []) as $backup) {
                if (!empty($backup['name'])) {
                    $known[(string) $backup['name']] = true;
                }
            }
            if ($backupName === '' || empty($known[$backupName])) {
                $this->_status->addMessage('error', 'Wybierz istniejący backup z listy.');
                $this->respondWithRedirect();
                return;
            }
            if (!$form->getValue('confirmRestore')) {
                $this->_status->addMessage('error', 'Restore wymaga świadomego potwierdzenia zastąpienia bieżących danych.');
                $this->respondWithRedirect();
                return;
            }
        }

        try {
            $runtimeConfig = Modules_NailitManager_Config::createRuntimeConfig($operation, [], ['backupName' => $backupName]);
            $task = new Modules_NailitManager_Task_Deploy();
            $task->setParam('runtimeConfig', $runtimeConfig);
            $task->setParam('operation', $operation);
            $manager = new pm_LongTask_Manager();
            $manager->start($task);
            $message = $operation === 'backup'
                ? 'Tworzenie pełnego backupu zostało dodane do kolejki.'
                : 'Przywracanie danych zostało dodane do kolejki. Usługi zostaną chwilowo zatrzymane.';
            $this->_status->addMessage('info', $message);
        } catch (Throwable $exception) {
            $this->_status->addMessage('error', 'Nie udało się uruchomić operacji na danych: ' . $exception->getMessage());
        }
        $this->respondWithRedirect();
    }

    private function validateConfiguredPaths(array $values)
    {
        $names = ['repositoryPath', 'licenseDeployPath', 'webDeployPath', 'siteDeployPath', 'persistentDataPath', 'backupPath'];
        $paths = [];
        $forbiddenPrefixes = ['/bin', '/boot', '/dev', '/etc', '/proc', '/root', '/run', '/sbin', '/sys', '/usr', '/usr/local/psa', '/var/lib/psa'];
        foreach ($names as $name) {
            $path = rtrim(trim((string) ($values[$name] ?? '')), '/');
            $segments = array_values(array_filter(explode('/', $path), 'strlen'));
            if (!preg_match('#^/[A-Za-z0-9._/-]+$#', $path) || strpos($path, '//') !== false || count($segments) < 3 || in_array('..', $segments, true)) {
                throw new RuntimeException('Ścieżka „' . $name . '” jest zbyt ogólna albo niebezpieczna.');
            }
            foreach ($forbiddenPrefixes as $prefix) {
                if ($path === $prefix || strpos($path . '/', $prefix . '/') === 0) {
                    throw new RuntimeException('Ścieżka „' . $name . '” wskazuje niedozwolony katalog systemowy: ' . $path . '.');
                }
            }
            $paths[$name] = $path;
        }
        $keys = array_keys($paths);
        for ($i = 0; $i < count($keys); $i++) {
            for ($j = $i + 1; $j < count($keys); $j++) {
                $first = $paths[$keys[$i]];
                $second = $paths[$keys[$j]];
                if ($first === $second || strpos($first . '/', $second . '/') === 0 || strpos($second . '/', $first . '/') === 0) {
                    throw new RuntimeException('Katalogi managera muszą być od siebie oddzielone: ' . $first . ' oraz ' . $second . '.');
                }
            }
        }
    }

    private function formatBytes($bytes)
    {
        $bytes = max(0, (int) $bytes);
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $index = 0;
        $value = (float) $bytes;
        while ($value >= 1024 && $index < count($units) - 1) {
            $value /= 1024;
            $index++;
        }
        return number_format($value, $index === 0 ? 0 : 1, ',', ' ') . ' ' . $units[$index];
    }

    private function refreshRuntimeState()
    {
        $runtimeConfig = null;
        try {
            $runtimeConfig = Modules_NailitManager_Config::createRuntimeConfig('status', []);
            $result = pm_ApiCli::callSbin(
                'nailit-manager',
                ['--config', $runtimeConfig],
                pm_ApiCli::RESULT_FULL
            );
            if ((int) ($result['code'] ?? 1) !== 0) {
                $stderr = trim((string) ($result['stderr'] ?? ''));
                $stdout = trim((string) ($result['stdout'] ?? ''));
                $detail = $stderr !== '' ? $stderr : $stdout;
                return $detail !== '' ? mb_substr($detail, -2000) : 'Narzędzie statusu zakończyło się błędem.';
            }
            return null;
        } catch (Throwable $exception) {
            return mb_substr($exception->getMessage(), -2000);
        } finally {
            if ($runtimeConfig && is_file($runtimeConfig)) {
                @unlink($runtimeConfig);
            }
        }
    }

    private function processOperationForm(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) {
            $this->_status->addMessage('error', 'Sprawdź oznaczone pola operacji i spróbuj ponownie.');
            $this->respondWithRedirect();
            return;
        }

        $operation = (string) $form->getValue('operation');
        $allowed = ['check', 'sync', 'deploy', 'sync-deploy'];
        if (!in_array($operation, $allowed, true)) {
            $this->_status->addMessage('error', 'Nieznana operacja.');
            $this->respondWithRedirect();
            return;
        }

        $modules = [];
        if ($form->getValue('moduleLicense')) {
            $modules[] = 'license-server';
        }
        if ($form->getValue('moduleWeb')) {
            $modules[] = 'web';
        }
        if ($form->getValue('moduleSite')) {
            $modules[] = 'site';
        }
        if (in_array($operation, ['deploy', 'sync-deploy'], true) && !$modules) {
            $this->_status->addMessage('error', 'Wybierz co najmniej jeden moduł do wdrożenia.');
            $this->respondWithRedirect();
            return;
        }

        $config = Modules_NailitManager_Config::values();
        if ($config['repositoryUrl'] === '') {
            $this->_status->addMessage('error', 'Najpierw zapisz adres repozytorium.');
            $this->respondWithRedirect();
            return;
        }

        if (in_array('site', $modules, true)) {
            $siteDomain = strtolower(trim((string) $form->getValue('siteDomainDeploy')));
            $siteDomains = $this->siteDomainOptions($config['siteDomain']);
            if ($siteDomain === '' || !isset($siteDomains[$siteDomain])) {
                $this->_status->addMessage('error', 'Wybierz aktywną domenę Pleska z hostingiem WWW dla strony głównej i CMS.');
                $this->respondWithRedirect();
                return;
            }
            Modules_NailitManager_Config::save(['siteDomain' => $siteDomain]);
        }

        try {
            $runtimeConfig = Modules_NailitManager_Config::createRuntimeConfig($operation, $modules);
            $task = new Modules_NailitManager_Task_Deploy();
            $task->setParam('runtimeConfig', $runtimeConfig);
            $task->setParam('operation', $operation);
            $manager = new pm_LongTask_Manager();
            $manager->start($task);
            $this->_status->addMessage('info', 'Zadanie zostało dodane do kolejki. Postęp pokaże Plesk.');
        } catch (Throwable $exception) {
            $this->_status->addMessage('error', 'Nie udało się uruchomić zadania: ' . $exception->getMessage());
        }
        $this->respondWithRedirect();
    }

    private function respondWithRedirect()
    {
        $this->_helper->json(['redirect' => pm_Context::getActionUrl('index', 'index')]);
    }

    private function addActionButton(pm_Form_Simple $form, $name, $label, $kind)
    {
        $safeLabel = htmlspecialchars($label, ENT_QUOTES, 'UTF-8');
        $safeKind = htmlspecialchars($kind, ENT_QUOTES, 'UTF-8');
        $icon = $kind === 'save' ? '✓' : '▶';
        $form->addElement('simpleText', $name, [
            'label' => '',
            'escape' => false,
            'value' => '<div class="nailit-action-row"><button type="submit" class="nailit-primary-action" data-nailit-action="' . $safeKind . '" aria-label="' . $safeLabel . '"><span class="nailit-action-icon" aria-hidden="true">' . $icon . '</span><span class="nailit-action-label">' . $safeLabel . '</span></button></div>',
        ]);
    }

    private function addSection(pm_Form_Simple $form, $name, $title, $description)
    {
        $form->addElement('simpleText', $name, [
            'label' => '',
            'escape' => false,
            'value' => '<div class="nailit-form-section"><strong>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</strong><span>' . htmlspecialchars($description, ENT_QUOTES, 'UTF-8') . '</span></div>',
        ]);
    }

    private function siteDomainOptions($savedDomain = '')
    {
        $options = [];
        try {
            foreach ((array) pm_Domain::getAllDomains() as $domain) {
                if (!$domain instanceof pm_Domain || !$domain->hasHosting() || !$domain->isActive() || $domain->isSuspended() || $domain->isDisabled()) {
                    continue;
                }
                $name = strtolower(trim((string) $domain->getName()));
                if (preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/', $name)) {
                    $options[$name] = $name;
                }
            }
        } catch (Throwable $exception) {
            // Formularz nadal ma się otworzyć; właściwe wdrożenie ponownie
            // zweryfikuje domenę przez pm_Domain::getByName().
        }
        natcasesort($options);
        $savedDomain = strtolower(trim((string) $savedDomain));
        if (!$options && preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/', $savedDomain)) {
            $options[$savedDomain] = $savedDomain . ' (zapisana konfiguracja)';
        }
        return $options;
    }
}
