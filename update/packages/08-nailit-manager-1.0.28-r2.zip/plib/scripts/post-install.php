<?php

pm_Context::init('nailit-manager');

$configLibrary = dirname(__DIR__) . '/library/Config.php';
if (!class_exists('Modules_NailitManager_Config', false)) {
    require_once $configLibrary;
}

$varDir = pm_Context::getVarDir();
if (!is_dir($varDir)) {
    mkdir($varDir, 0700, true);
}
@chmod($varDir, 0700);

$productRoot = defined('PRODUCT_ROOT_D') ? PRODUCT_ROOT_D : '/usr/local/psa';
$utility = $productRoot . '/admin/bin/modules/nailit-manager/nailit-manager';
if (is_file($utility)) {
    @chmod($utility, 0750);
}

foreach (Modules_NailitManager_Config::defaults() as $key => $value) {
    if (pm_Settings::get($key) === null) {
        pm_Settings::set($key, (string) $value);
    }
}
