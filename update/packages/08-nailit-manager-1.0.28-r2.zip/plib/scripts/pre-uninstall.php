<?php

pm_Context::init('nailit-manager');

try {
    $manager = new pm_LongTask_Manager();
    $manager->cancelAllTasks();
} catch (Exception $exception) {
    // Odinstalowanie nie może usuwać wdrożeń ani zostać zablokowane przez starą kolejkę.
}

foreach (glob(pm_Context::getVarDir() . '/operation-*.json') ?: [] as $path) {
    @unlink($path);
}
