# Historia zmian

## 1.0.28-2 — 2026-08-20

- Dodano wspólny wygląd Kitsune Plesk Suite oraz centralne przejście do konfiguracji rozszerzeń.
- Osobny wpis menu pozostaje w trybie samodzielnym i znika po wykryciu aktywnego Kitsune Hub.

## 1.0.28-1

- Dodano konfigurację SMTP dla newslettera, weryfikacji kont i resetowania haseł.
- Hasło SMTP jest przechowywane w szyfrowanych ustawieniach Pleska i przekazywane do kontenera jako Docker secret.
- Publiczna strona nie obiecuje już wiadomości, gdy wysyłka nie jest skonfigurowana albo serwer SMTP odrzucił próbę.
- Zachowano zgodność z istniejącym adapterem webhookowym poczty.

## 1.0.27-1

- Dodano konfigurowalny katalog danych trwałych z oddzielnymi podkatalogami PostgreSQL i storage CMS.
- Starsze nazwane wolumeny są migrowane po zatrzymaniu kontenerów; źródłowe dane pozostają nietknięte jako punkt awaryjny.
- Dodano osobny katalog backupów i retencję od 1 do 100 pełnych kopii.
- Pełny backup zawiera logiczny dump PostgreSQL, storage CMS, sekrety szyfrujące, referencyjny `.env`, manifest i sumy SHA-256.
- Restore weryfikuje archiwum przed zatrzymaniem usług, wykonuje backup awaryjny i automatycznie wycofuje nieudaną próbę.
- Obsługiwane są zarówno wbudowany, jak i zewnętrzny PostgreSQL; aktywne hasło połączenia i konfiguracja infrastruktury nie są nadpisywane przez restore.
- Współpracuje z wydaniem produktu 1.2.5.

## 1.0.26-1

- Aktualizacja kodu wykonuje automatyczny backup wbudowanego PostgreSQL i zostaje przerwana, jeżeli kopia nie powstanie prawidłowo.
- Zwykły update nie importuje już starego pliku JSON, dlatego usunięte instalatory i inne rekordy CMS nie mogą zostać przywrócone ze starej kopii.
- Wolumeny PostgreSQL i uploadów CMS mają stałe nazwy, niezależne od katalogu wdrożenia.
- Manager blokuje przypadkowe przełączenie rodzaju bazy podczas aktualizacji kodu.
- Proxy CMS obsługuje strumieniowe uploady instalatorów do 100 MB bez buforowania całego pliku.
- Panel CMS ma wizualny kreator bloków z kolejnością, widocznością, edycją modalną, czytelnym diffem oraz bezpiecznym usuwaniem rewizji historycznych.
- Współpracuje z wydaniem produktu 1.2.4.

## 1.0.25-1

- Naprawiono wdrożenie serwera licencyjnego 1.2.4: manager dołącza teraz moduł analityczny `site-analytics.js`, wymagany przy starcie kontenera.
- Dodano test kontraktu, który wykrywa każdy moduł wymagany przez `server.js`, ale pominięty podczas wdrożenia z Pleska.
- Współpracuje z wydaniem produktu 1.2.4.

## 1.0.24-1

- Wdrożono nowy, wygenerowany znak NailIT przedstawiający falę dźwiękową układającą się w literę N i iskierkę odpowiedzi.
- Menu Pleska korzysta z lekkiego PNG zgodnego z ikoną aplikacji, strony głównej, CMS i instalatora Windows.
- Współpracuje z wydaniem produktu 1.2.3.

## 1.0.23-1

- Ujednolicono ikonę NailIT w panelu Pleska z aplikacją desktopową, stroną i panelem CMS.
- Współpracuje z wydaniem produktu 1.2.2 zawierającym kontrolę widoczności aplikacji webowej i obsługę wielu instalatorów desktopowych.

## 1.0.22-1

- Historyczny placeholder `licencje.example.com` jest automatycznie migrowany do skonfigurowanego publicznego URL serwera licencyjnego.
- Przy wspólnym wdrożeniu serwera licencyjnego i strony proxy `/v1/` korzysta bezpośrednio z lokalnego portu API, bez zależności od publicznego DNS.
- Wdrożenie samej strony odrzuca placeholder lub nierozwiązywalny host API przed podmianą plików domeny.

## 1.0.21-1

- Naprawiono wybieranie checkboxa strony/CMS w DOM: ukryte pole wartości `0` nie wyłącza już listy domen, gdy właściwy checkbox jest zaznaczony.
- Każdy wynik formularza AJAX zwraca teraz odpowiedź JSON z przekierowaniem, również przy walidacji i wyjątkach.
- Rozszerzono obsługę błędów uruchamiania zadania z `Exception` do wszystkich `Throwable`.

## 1.0.20-1

- Naprawiono paczkowanie na Windowsie: wszystkie wpisy ZIP używają teraz wymaganych przez Linux i Plesk separatorów `/`.
- Walidator wydania odrzuca archiwum zawierające ścieżki z `\\`, aby Plesk nie aktualizował samych metadanych bez plików `plib` i `htdocs`.
- Uzupełniono opis rozszerzenia o publikowanie strony głównej i CMS do wybranej domeny.

## 1.0.19-1

- Wersja zainstalowanego rozszerzenia jest zawsze widoczna w nagłówku i komunikacie diagnostycznym panelu.
- Rozróżniono aktualizację produktu NailIT od aktualizacji samego rozszerzenia, aby status repozytorium nie sugerował aktualizacji pluginu.
- Utrzymano jawny wybór domeny strony/CMS bezpośrednio nad listą wdrażanych modułów.

## 1.0.18-1

- Dodano widoczny wybór aktywnej domeny lub subdomeny Pleska bezpośrednio w formularzu wdrożenia.
- Strona główna i CMS są publikowane atomowo do document root wybranej domeny zamiast kończyć pracę na uruchomieniu niepodpiętego kontenera.
- Manager automatycznie konfiguruje zarządzaną trasę nginx `/v1/` do publicznego API CMS i rekonfiguruje vhost przez `httpdmng`.
- Publikacja zachowuje `.well-known`, właściciela katalogu i wcześniejsze dyrektywy nginx; konflikt lub błąd uruchamia pełny rollback plików oraz vhosta.
- Panel rozpoznaje natywne wdrożenie domenowe jako aktywne i pokazuje domenę oraz document root.

## 1.0.17-1

- Dodano wybór i walidację domeny Pleska dla wdrożenia strony głównej i CMS.
- Domena trafia do bezpiecznej konfiguracji oraz metadanych modułu i jest widoczna w logu wdrożenia.
- Wdrożenie serwera obejmuje moduł prywatnych, agregatowych metryk jakości produktu.

## 1.0.16-1

- Dodano niezależne wdrażanie responsywnej strony głównej i CMS jako modułu Docker Compose.
- Dodano konfigurację katalogu, portu i adresu API CMS oraz stan kontenera strony w panelu.
- Serwer licencyjny zachowuje pliki wydań CMS w trwałym wolumenie.

## 1.0.15-1

- Przebudowano panel na zakładki: stan i wersje, aktualizacja i wdrożenie, konfiguracja oraz dziennik.
- Dodano jednoznaczne porównanie wersji wdrożonej, lokalnej kopii i wersji z `origin/<gałąź>`.
- Naprawiono prawa pliku `state.json`, dzięki czemu panel Pleska odczytuje stan zapisany przez narzędzie `sbin`.
- Stan repozytorium jest odtwarzany przy każdym otwarciu panelu, bez konieczności wykonywania nowego wdrożenia.
- Rozszerzono wykrywanie istniejących wdrożeń oraz prezentację aktywności i zdrowia kontenerów.

## 1.0.14-1

- proxy aplikacji webowej przekazuje domenę upstream jako `Host` i włącza SNI, dzięki czemu publiczny URL serwera licencyjnego działa za proxy Pleska bez pętli do domeny aplikacji,
- konfiguracja migruje stary adres `host.docker.internal` na publiczny URL, gdy API nasłuchuje wyłącznie na `127.0.0.1`,
- healthcheck webu sprawdza również trasę `/health` serwera licencyjnego i przerywa niesprawne wdrożenie zamiast pokazywać timeout przy logowaniu,
- Adminer otrzymuje hasło PostgreSQL bezpośrednio jako Docker secret oraz nadal wymaga jednorazowego biletu administratora.

## 1.0.13-1

- pakowanie rozszerzenia odbywa się z katalogu tymczasowego i wymusza linuksowe końce linii LF w `sbin/nailit-manager`,
- gotowe archiwum jest odczytywane po zbudowaniu i odrzucane, jeśli shebang zawiera `php\r` albo plik ma znaki CR,
- repozytorium wymusza LF dla uprzywilejowanego skryptu Pleska przez `.gitattributes`.

## 1.0.12-1

- status Dockera używa osobnej blokady i odświeża się również podczas operacji repozytorium lub wdrożenia,
- kontenery są dodatkowo rozpoznawane po katalogu projektu Compose, pliku Compose i skonfigurowanych portach,
- panel pokazuje liczbę oraz nazwy nierozpoznanych kontenerów zamiast ogólnego pustego statusu,
- Adminer otrzymuje hasło bazy wyłącznie przez chronione, jednorazowe wywołanie SSO,
- istniejący i nowy administrator otrzymuje stałą licencję systemową umożliwiającą logowanie do aplikacji,
- aplikacja webowa ma limit czasu połączenia, wyświetla błędy logowania i nie pokazuje interfejsu przed sprawdzeniem sesji.

## 1.0.11-1

- automatyczna naprawa praw istniejącego bind-mountu `nailit-sso.php` dla Adminera,
- nowe wdrożenia ustawiają katalog Adminera na `0755`, a plik wtyczki na `0644`,
- publiczny URL serwera licencyjnego jest przekazywany do aplikacji webowej niezależnie od wewnętrznego adresu proxy,
- ekran logowania pokazuje skonfigurowany adres, np. `https://lic.nailit.ltd`, zamiast domeny aplikacji webowej,
- wykrywanie kontenerów korzysta z pełnego `docker inspect` i grupuje wszystkie usługi według etykiet projektu Compose.

## 1.0.10-1

- automatyczne odświeżenie statusu nie blokuje uruchomienia właściwej operacji,
- zajęte odświeżenie statusu kończy się bez błędu i pozostawia ostatni zapisany stan,
- operacja wdrożeniowa czeka do 15 sekund na zakończenie krótkiego odczytu statusu,
- przycisk operacji blokuje wielokrotne wysłanie formularza i pokazuje stan „Uruchamianie…”.

## 1.0.9-1

- wykrywanie skanuje wszystkie kontenery i rozpoznaje NailIT po projekcie, usłudze, nazwie kontenera oraz obrazie,
- usunięta zależność od dokładnej nazwy projektu `nailit-web` lub `nailit-license`,
- panel pokazuje rzeczywisty błąd uprzywilejowanego odczytu Dockera zamiast udawać, że nie ma kontenerów,
- nagłówek rozróżnia zapisaną konfigurację od niesklonowanego jeszcze repozytorium,
- karty modułów nie pokazują „Niewdrożony”, kiedy kontenery danego modułu zostały wykryte.

## 1.0.8-1

- naprawione prawa odczytu statycznych plików aplikacji webowej dla workera Nginx,
- dodana lokalna ikona NailIT do pozycji w lewym menu Pleska,
- stan kontenerów jest odczytywany przy każdym wejściu do panelu i awaryjnie wykrywany po etykietach Docker Compose,
- wdrożenia zapisują metadane wersji, dzięki czemu panel odtwarza stan również po aktualizacji rozszerzenia,
- aktualizacja jawnie zatrzymuje poprzednie kontenery przed podmianą, następnie buduje, uruchamia i sprawdza nową wersję,
- rollback przywraca katalog oraz ponownie uruchamia kontenery poprzedniej wersji bez usuwania wolumenów.

## 1.0.7-1

- dodana pozycja „NailIT Manager” w lewym menu administratora Pleska,
- skrót działa zarówno w widoku Service Provider, jak i Power User,
- pozycja prowadzi bezpośrednio do głównego panelu wdrożeń rozszerzenia.

## 1.0.6-1

- klucze prywatne SSH i wpisy `known_hosts` są normalizowane z końców linii Windows CRLF do linuksowego LF,
- wcześniej zapisany klucz jest normalizowany podczas każdej operacji, bez potrzeby ponownego wklejania,
- przed uruchomieniem Git klucz jest sprawdzany przez `ssh-keygen`, a panel zwraca czytelny błąd dla złego formatu lub klucza chronionego hasłem.

## 1.0.5-1

- przyciski zapisu i operacji są renderowane bezpośrednio w formularzu i nie mogą pozostać bez etykiety,
- systemowy pusty przycisk Pleska jest ukryty przez `sendHidden`,
- skrypt przycisków jest ładowany bezpośrednio pod formularzami z wersjonowanym adresem omijającym cache.

## 1.0.4-1

- zgodne ze starszym PHP Pleska uruchamianie `proc_open()` z poleceniem tekstowym,
- każdy argument polecenia jest osobno zabezpieczany przez `escapeshellarg()`,
- zachowane bezpieczne przekazywanie środowiska i przechwytywanie wyjścia procesów Git oraz Docker.

## 1.0.3-1

- ścieżka pliku operacji jest kanonizowana przez `realpath()` przed użyciem,
- katalog danych i `state.json` są wyznaczane przez uprzywilejowane narzędzie zamiast przyjmowania ich z konfiguracji operacji,
- usunięte fałszywe odrzucenie poprawnej ścieżki zwracanej przez Pleska z końcowym ukośnikiem,
- odświeżony przycisk zapisu oraz dynamiczne nazwy przycisku klonowania, aktualizacji i wdrożenia.

## 1.0.2-1

- poprawione opcje `min` i `max` walidatorów pól portów dla Pleska 18.0.78,
- poprawione nazwane limity walidatorów długości tekstu,
- usunięty angielski podpis „Required fields” z formularzy.

## 1.0.1-1

- poprawiony zgodny z Pleskiem prefiks klas `Modules_NailitManager`,
- instalator jawnie ładuje bibliotekę konfiguracji przed zapisaniem ustawień domyślnych.

## 1.0.0-1

- konfiguracja repozytorium HTTPS lub SSH,
- szyfrowane przechowywanie tokenu Git i haseł,
- klonowanie, sprawdzanie i aktualizacja dedykowanej kopii repozytorium,
- niezależne wdrażanie serwera licencyjnego i aplikacji webowej,
- PostgreSQL w Docker Compose albo zewnętrzny PostgreSQL,
- zadania w tle, blokada równoległych operacji, stan usług i dziennik operacji.
