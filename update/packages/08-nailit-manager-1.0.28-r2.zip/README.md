# NailIT Deployment Manager dla Pleska

Rozszerzenie jest przeznaczone dla **Plesk Obsidian na Linuxie**. Po instalacji administrator wskazuje repozytorium NailIT, a następnie osobno decyduje, czy tylko pobrać nowy kod, czy również wdrożyć serwer licencyjny, aplikację webową i/lub publiczną stronę CMS.

## Wymagania

- Plesk Obsidian 18.0.41 lub nowszy,
- dostęp administratora Pleska i root przez SSH do instalacji z CLI,
- `git`, `tar`, `cp`, Docker Engine i wtyczka Docker Compose v2 (`docker compose`),
- wyjście HTTPS/SSH z serwera do wybranego repozytorium,
- dla zewnętrznej bazy: PostgreSQL dostępny z sieci kontenerów Docker.

Przykład przygotowania Ubuntu/Debian (Docker najlepiej instalować z oficjalnego repozytorium Dockera):

```bash
apt update
apt install -y git
git --version
docker --version
docker compose version
```

## Instalacja

Archiwum musi zawierać `meta.xml` bezpośrednio w swoim katalogu głównym. Gotowa paczka tworzona w repozytorium NailIT spełnia ten warunek.

### Z panelu Plesk

1. Zaloguj się jako administrator.
2. Otwórz **Rozszerzenia → Moje rozszerzenia**.
3. Wybierz instalację/wysłanie rozszerzenia z pliku ZIP.
4. Wskaż `NailIT-Plesk-Manager-1.0.28-<timestamp>.zip`.
5. Otwórz **NailIT Manager** bezpośrednio z lewego menu Pleska.

### Z SSH

```bash
plesk bin extension -i /root/NailIT-Plesk-Manager-1.0.28-20260726-120000.zip
```

Aktualizacja samego rozszerzenia Plesk do nowszej paczki:

```bash
plesk bin extension -g /root/NailIT-Plesk-Manager-1.0.28-20260726-120000.zip
```

Po aktualizacji otwórz manager ponownie. Nad zakładkami musi być widoczny napis **Rozszerzenie Plesk 1.0.28**. Przycisk aktualizacji w samym managerze aktualizuje repozytorium produktu NailIT, a nie kod rozszerzenia Plesk.

Usunięcie rozszerzenia:

```bash
plesk bin extension -u nailit-manager
```

Usunięcie rozszerzenia nie kasuje repozytorium, kontenerów, wolumenów ani wdrożonych katalogów NailIT.

## Pierwsza konfiguracja

1. Wklej adres repozytorium HTTPS lub SSH i nazwę gałęzi.
2. Dla prywatnego HTTPS wpisz użytkownika oraz token. Token nie trafia do adresu `origin` ani argumentów procesu — rozszerzenie podaje go jednorazowo przez `GIT_ASKPASS` i zapisuje zaszyfrowany przez Plesk.
3. Dla SSH możesz wkleić prywatny, najlepiej read-only **deploy key bez hasła**. Rozszerzenie zapisuje go zaszyfrowanego, a podczas każdej operacji tworzy plik tymczasowy `0600`, wymusza `IdentitiesOnly=yes` i usuwa plik po zakończeniu. Jeżeli podasz zawartość `known_hosts`, użyta zostanie wyłącznie ona; w przeciwnym razie obowiązuje systemowy plik roota. `StrictHostKeyChecking` zawsze pozostaje włączone.
4. Zachowaj oddzielne katalogi kodu, np. `/opt/nailit/source`, `/opt/nailit/license-server`, `/opt/nailit/web` i `/opt/nailit/site`.
5. Wskaż osobny katalog danych trwałych, np. `/opt/nailit/persistent`, oraz katalog backupów, np. `/opt/nailit/backups`. Nie mogą się pokrywać z katalogami kodu ani ze sobą. Ustaw retencję od 1 do 100 kopii.
6. Ustaw publiczny URL serwera licencyjnego oraz różne porty lokalne. Gdy port API jest przypięty do `127.0.0.1`, jako URL widziany przez kontener web podaj tę samą publiczną domenę HTTPS, np. `https://lic.nailit.ltd`; `host.docker.internal` nie ma dostępu do loopback hosta.
7. Wybierz aktywną domenę strony głównej i CMS z listy domen Pleska. Manager opublikuje pliki do jej document root i skonfiguruje `/v1/` automatycznie.
8. Wybierz wariant PostgreSQL.
9. Skonfiguruj SMTP: host, port, szyfrowanie, użytkownika, hasło oraz nadawcę z domeny obsługiwanej przez serwer pocztowy. Najczęstszy wariant to port `587` i `STARTTLS`; port `465` używa TLS od początku. Brak TLS wybieraj wyłącznie dla zaufanego lokalnego relaya.
10. Ustaw hasło administratora NailIT. Bez wartości pierwsze wdrożenie użyje `admin`; jest to tylko wartość startowa i trzeba je zmienić przed wystawieniem usługi do Internetu.
11. Zapisz konfigurację, przejdź do zakładki **Aktualizacja i wdrożenie** i uruchom **Sprawdź repozytorium i wersje**.

Publiczną część deploy key dodaj w ustawieniach repozytorium u dostawcy Git. Dla GitHuba będzie to **Settings → Deploy keys**; zazwyczaj wystarcza dostęp tylko do odczytu. Znany host możesz przygotować na serwerze poleceniem `ssh-keyscan -H nazwa-hosta`, ale przed zapisaniem porównaj fingerprint z dokumentacją dostawcy Git.

Repozytorium jest dedykowaną kopią wdrożeniową. Operacja aktualizacji wykonuje reset do `origin/<gałąź>` i odrzuca lokalne zmiany śledzonych plików w tej kopii. Nie używaj tego katalogu do ręcznej pracy programistycznej.

## Sposób aktualizacji

Panel jest podzielony na pięć niezależnych zakładek:

- **Stan i wersje** — pokazuje osobno wersję wdrożoną, wersję w lokalnej kopii oraz wersję z `origin/<gałąź>`, a także kontenery i natywną publikację domenową strony,
- **Aktualizacja i wdrożenie** — zawiera operacje Git i Docker; samo sprawdzenie lub aktualizacja repozytorium nie zmienia działających usług,
- **Konfiguracja** — zawiera repozytorium, katalogi, domeny, bazę danych i zaszyfrowane sekrety,
- **Dane i backup** — pokazuje aktywne ścieżki, dostępne kopie oraz uruchamia pełny backup lub kontrolowany restore,
- **Dziennik** — pokazuje ostatnie operacje bez ujawniania sekretów.

- **Sprawdź repozytorium i wersje** — klonuje brakujące repo, wykonuje `fetch` i porównuje commit oraz `nailit-release.json`; niczego nie wdraża.
- **Zaktualizuj tylko repozytorium** — przełącza całą dedykowaną kopię na najnowszy commit; działające moduły pozostają bez zmian.
- **Wdróż zaznaczone moduły** — buduje wyłącznie zaznaczony serwer licencyjny, aplikację webową i/lub publiczną stronę z aktualnej kopii.
- **Zaktualizuj i wdróż** — najpierw aktualizuje kopię, potem wdraża tylko zaznaczone moduły.

Każde wydanie powinno podnosić wspólną wersję produktu w `nailit-release.json`. Dzięki temu panel może pokazać, że np. serwer licencyjny `1.2.0` działa, a w repozytorium jest już `1.2.1`, bez wymuszania jego wdrożenia. Rozszerzenie Plesk ma oddzielną numerację.

Wdrożenie powstaje w katalogu tymczasowym. Panel przy każdym wejściu odczytuje bieżący stan kontenerów i publikacji domenowej. Serwer oraz aplikacja webowa używają Docker Compose z rollbackiem. Strona i CMS są atomowo publikowane do document root wybranej domeny; manager zachowuje `.well-known`, dodaje zarządzane proxy `/v1/` i przy błędzie przywraca poprzednie pliki oraz konfigurację vhosta. Sekrety, dane trwałe i kopie nie są kasowane podczas aktualizacji kodu.

## Baza w Docker Compose

Wariant **Własny PostgreSQL** uruchamia `postgres:17-alpine`, API i Adminera. Dane znajdują się w podkatalogu `database/` skonfigurowanej ścieżki danych trwałych, a uploady CMS w `storage/`. Podczas pierwszej aktualizacji z wersji używającej nazwanych wolumenów manager zatrzymuje kontenery, kopiuje dane i pozostawia stare wolumeny bez zmian jako punkt awaryjny. Rozszerzenie zachowuje oddzielne hasła bazy wbudowanej i zewnętrznej.

## Backup i restore danych trwałych

Zakładka **Dane i backup** tworzy jedno archiwum zawierające dump PostgreSQL w formacie custom, storage CMS, sekrety aplikacji, referencyjny `.env` oraz manifest z sumami SHA-256. Dotyczy to również zewnętrznego PostgreSQL — manager używa tymczasowego klienta `postgres:17-alpine` i nie zapisuje hasła w argumentach procesu.

Restore zawsze sprawdza sumę całego archiwum i każdego składnika. Następnie wykonuje awaryjny backup aktualnego stanu, zatrzymuje API i Adminera, przywraca dane oraz czeka na health check. Gdy którykolwiek etap się nie powiedzie, manager próbuje automatycznie odtworzyć kopię awaryjną. Bieżące hasło połączenia z bazą i aktywny `.env` nie są nadpisywane danymi ze starego środowiska.

Retencja usuwa wyłącznie najstarsze pliki pasujące do nazwy archiwów utworzonych przez NailIT. Nie zastępuje to kopii off-site: katalog backupów powinien być dodatkowo replikowany poza serwer Plesk.

Przykładowy eksport:

```bash
cd /opt/nailit/license-server
docker compose exec -T database pg_dump -U nailit -d nailit -Fc > nailit.dump
```

Przykładowy import:

```bash
cd /opt/nailit/license-server
docker compose exec -T database pg_restore -U nailit -d nailit --clean --if-exists < nailit.dump
```

## Istniejący PostgreSQL

Utwórz wcześniej użytkownika i bazę, np. jako administrator PostgreSQL:

```sql
CREATE ROLE nailit LOGIN PASSWORD 'silne-haslo';
CREATE DATABASE nailit OWNER nailit;
```

Jeżeli PostgreSQL działa bezpośrednio na hoście, jako host w panelu użyj `host.docker.internal`. Rozszerzenie dodaje mapowanie `host-gateway`, ale sam PostgreSQL nadal musi nasłuchiwać na odpowiednim interfejsie i zezwalać sieci Docker w `pg_hba.conf`. Nie wystawiaj portu 5432 publicznie; ogranicz regułę do prywatnej sieci/bridge Dockera.

W tym wariancie Compose uruchamia tylko API oraz Adminera. Hasło zewnętrznej bazy jest przechowywane zaszyfrowane przez Plesk, a do kontenerów trafia przez plik Docker secret. Admin w panelu licencyjnym nadal otwiera Adminera przez jednorazowy bilet SSO.

## Domeny i HTTPS

Usługi domyślnie nasłuchują wyłącznie na `127.0.0.1`:

- serwer licencyjny: `127.0.0.1:47831`,
- Adminer awaryjnie: `127.0.0.1:8081`,
- aplikacja webowa: `127.0.0.1:8080`,
- publiczna strona CMS: `127.0.0.1:8090`.

W konfiguracji rozszerzenia wskaż domenę Pleska przeznaczoną dla strony głównej. Wybór jest walidowany, zapisywany w metadanych wdrożenia i pokazywany w logu. Podepnij tę domenę oraz domeny aplikacji i licencji z certyfikatami Let's Encrypt jako reverse proxy do portów 8090, 8080 i 47831. Adminera nie wystawiaj osobną domeną — jest dostępny pod `${PUBLIC_URL}/adminer/` przez uwierzytelniony panel serwera licencyjnego. Po ustawieniu proxy sprawdź:

```bash
curl -fsS https://licencje.twoja-domena.pl/health
curl -I https://app.twoja-domena.pl/
curl -I https://twoja-domena.pl/
```

## Diagnostyka

Stan usług i ostatnie 300 wierszy dziennika są widoczne w rozszerzeniu. Dodatkowo przez SSH:

```bash
cd /opt/nailit/license-server
docker compose ps
docker compose logs --tail=200

cd /opt/nailit/web
docker compose ps
docker compose logs --tail=200

cd /opt/nailit/site
docker compose ps
docker compose logs --tail=200
```

Przy trybie zewnętrznym dodaj `-f docker-compose.external.yml` do poleceń dotyczących serwera licencyjnego.
