<?php

pm_Context::init('nailit-manager');

$application = new pm_Application();
$application->run();
