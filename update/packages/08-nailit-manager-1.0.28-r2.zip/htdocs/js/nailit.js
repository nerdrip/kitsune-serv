(function () {
  'use strict';

  var operationLabels = {
    check: 'Sprawdź repozytorium i wersje',
    sync: 'Zaktualizuj lokalne repozytorium',
    deploy: 'Wdróż wybrane moduły',
    'sync-deploy': 'Pobierz i wdróż wybrane moduły'
  };

  function initializeTabs() {
    var tabs = Array.prototype.slice.call(document.querySelectorAll('[data-nailit-tab]'));
    var panels = Array.prototype.slice.call(document.querySelectorAll('[data-nailit-panel]'));
    if (!tabs.length || !panels.length) return;

    var activate = function (name, focus) {
      var selected = tabs.some(function (tab) { return tab.getAttribute('data-nailit-tab') === name; }) ? name : 'status';
      tabs.forEach(function (tab) {
        var active = tab.getAttribute('data-nailit-tab') === selected;
        tab.classList.toggle('is-active', active);
        tab.setAttribute('aria-selected', active ? 'true' : 'false');
        tab.setAttribute('tabindex', active ? '0' : '-1');
        if (active && focus) tab.focus();
      });
      panels.forEach(function (panel) {
        var active = panel.getAttribute('data-nailit-panel') === selected;
        panel.classList.toggle('is-active', active);
        panel.hidden = !active;
      });
      try { window.sessionStorage.setItem('nailit-manager-tab', selected); } catch (error) {}
      if (window.history && window.history.replaceState) {
        window.history.replaceState(null, '', '#nailit-' + selected);
      }
    };

    tabs.forEach(function (tab, index) {
      tab.addEventListener('click', function () { activate(tab.getAttribute('data-nailit-tab'), false); });
      tab.addEventListener('keydown', function (event) {
        if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].indexOf(event.key) === -1) return;
        event.preventDefault();
        var next = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1
          : (index + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
        activate(tabs[next].getAttribute('data-nailit-tab'), true);
      });
    });

    var requested = window.location.hash.indexOf('#nailit-') === 0 ? window.location.hash.slice(8) : '';
    if (!requested) {
      try { requested = window.sessionStorage.getItem('nailit-manager-tab') || ''; } catch (error) {}
    }
    activate(requested || 'status', false);

    var refresh = document.querySelector('[data-nailit-refresh]');
    if (refresh) {
      refresh.addEventListener('click', function () {
        refresh.disabled = true;
        refresh.textContent = 'Odświeżanie…';
        activate('status', false);
        window.location.reload();
      });
    }
  }

  function findSubmitButton(form) {
    if (!form) return null;
    return form.querySelector('[data-nailit-action], button[type="submit"], input[type="submit"], button[name="send"], input[name="send"], button, input[type="button"]');
  }

  function setButtonLabel(button, label) {
    if (!button) return;
    if (button.tagName === 'INPUT') {
      button.value = label;
    } else {
      var labelNode = button.querySelector('.nailit-action-label');
      if (labelNode) {
        labelNode.textContent = label;
      } else {
        button.textContent = label;
      }
    }
    button.setAttribute('aria-label', label);
    button.classList.add('nailit-primary-action');
  }

  function initializeButtons() {
    var configForm = document.getElementById('nailit-config-form');
    setButtonLabel(findSubmitButton(configForm), 'Zapisz ustawienia');

    var operationForm = document.getElementById('nailit-operation-form');
    var operationSelect = operationForm && operationForm.querySelector('[name="operation"]');
    var operationButton = findSubmitButton(operationForm);
    if (!operationSelect || !operationButton) return;

    var updateOperationLabel = function () {
      setButtonLabel(operationButton, operationLabels[operationSelect.value] || 'Uruchom operację');
    };
    operationSelect.addEventListener('change', updateOperationLabel);
    var operationSubmitting = false;
    operationForm.addEventListener('submit', function (event) {
      if (operationSubmitting) {
        event.preventDefault();
        event.stopImmediatePropagation();
        return;
      }
      operationSubmitting = true;
      try { window.sessionStorage.setItem('nailit-manager-tab', 'deploy'); } catch (error) {}
      operationButton.disabled = true;
      setButtonLabel(operationButton, 'Uruchamianie…');
    });
    updateOperationLabel();

    if (configForm) {
      configForm.addEventListener('submit', function () {
        try { window.sessionStorage.setItem('nailit-manager-tab', 'config'); } catch (error) {}
      });
    }

    initializeMaintenanceForm();
  }

  function checkedRadio(form, name) {
    return form ? form.querySelector('input[type="radio"][name="' + name + '"]:checked') : null;
  }

  function initializeMaintenanceForm() {
    var form = document.getElementById('nailit-maintenance-form');
    if (!form) return;
    var radios = Array.prototype.slice.call(form.querySelectorAll('input[type="radio"][name="maintenanceOperation"]'));
    var backupSelect = form.querySelector('[name="backupName"]');
    var confirmation = form.querySelector('input[type="checkbox"][name="confirmRestore"]');
    var button = findSubmitButton(form);
    var submitting = false;

    var synchronize = function () {
      var selected = checkedRadio(form, 'maintenanceOperation');
      var restoring = selected && selected.value === 'restore';
      if (backupSelect) {
        backupSelect.disabled = !restoring;
        backupSelect.required = !!restoring;
        backupSelect.setAttribute('aria-disabled', restoring ? 'false' : 'true');
      }
      if (confirmation) {
        confirmation.disabled = !restoring;
        confirmation.required = !!restoring;
        confirmation.setAttribute('aria-disabled', restoring ? 'false' : 'true');
      }
      setButtonLabel(button, restoring ? 'Przywróć wybrany backup' : 'Utwórz pełny backup');
    };
    radios.forEach(function (radio) { radio.addEventListener('change', synchronize); });
    form.addEventListener('submit', function (event) {
      if (submitting) {
        event.preventDefault();
        event.stopImmediatePropagation();
        return;
      }
      var selected = checkedRadio(form, 'maintenanceOperation');
      var restoring = selected && selected.value === 'restore';
      if (restoring && !window.confirm('Przywrócić wybraną kopię? Bieżąca baza i storage zostaną zastąpione po wykonaniu awaryjnego backupu.')) {
        event.preventDefault();
        return;
      }
      submitting = true;
      try { window.sessionStorage.setItem('nailit-manager-tab', 'data'); } catch (error) {}
      if (button) button.disabled = true;
      setButtonLabel(button, restoring ? 'Przywracanie…' : 'Tworzenie backupu…');
    });
    synchronize();
  }

  function initializeSiteTarget() {
    var form = document.getElementById('nailit-operation-form');
    if (!form) return;
    // Zend/Plesk renders a hidden `moduleSite=0` immediately before the
    // checkbox. Selecting by name alone returns that hidden field and makes
    // the domain select look disabled even while the checkbox is checked.
    var moduleSite = form.querySelector('input[type="checkbox"][name="moduleSite"]');
    var siteDomain = form.querySelector('[name="siteDomainDeploy"]');
    if (!moduleSite || !siteDomain) return;
    var synchronize = function () {
      var enabled = !!moduleSite.checked;
      siteDomain.disabled = !enabled;
      siteDomain.required = enabled;
      siteDomain.setAttribute('aria-disabled', enabled ? 'false' : 'true');
    };
    moduleSite.addEventListener('change', synchronize);
    synchronize();
  }

  function initialize() {
    initializeTabs();
    initializeButtons();
    initializeSiteTarget();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
  } else {
    initialize();
  }
})();
