# NailIT Deployment Manager

Rozszerzenie administratora Plesk do bezpiecznego klonowania repozytorium NailIT, sprawdzania nowych wersji oraz niezależnego wdrażania serwera licencyjnego, aplikacji webowej i strony głównej z CMS.

Obsługuje PostgreSQL uruchamiany razem z serwerem licencyjnym albo istniejącą bazę PostgreSQL wskazaną w konfiguracji. Pozwala wskazać katalog danych trwałych i katalog backupów, ustawić retencję oraz tworzyć i przywracać pełne kopie bazy, storage i sekretów. Stronę i CMS publikuje bezpośrednio do document root wybranej domeny Pleska oraz konfiguruje publiczne API pod `/v1/`.
