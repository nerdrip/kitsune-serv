# Changelog

## 1.1.1-5 — 2026-08-21

- Aktualizator automatycznie zapisuje klucz hosta SSH przy pierwszym połączeniu i później wymusza ścisłą weryfikację.

## 1.1.1-4 — 2026-08-21

- Self-update synchronizuje repozytorium WPKit i buduje rozszerzenie z jego własnego przypiętego commitu.

## 1.1.1-2 — 2026-08-20

- Dodano wspólny wygląd Kitsune Plesk Suite i odnośnik do centralnego zarządzania w Hubie.
- Osobny wpis menu WPKit pozostaje w trybie samodzielnym, a znika po wykryciu aktywnego Kitsune Hub.

## 1.1.1

- Fixed Plesk form label-column styles constraining service controls to half of the card width.
- Service buttons now use the full card width, equal columns, non-wrapping labels and a single-column mobile layout.
- Displays separate local, deployed and remote version sets for Parse Server and Parse Dashboard, using each service's own `package.json`.

## 1.1.0

- Replaced commit hashes on the status page with local, last successfully deployed and remote package versions.
- Records deployed versions independently for Parse Server and Parse Dashboard after a successful health check.
- Added per-service Start, Restart and Stop controls to the main status cards and removed lifecycle actions from the repository operation selector.

## 1.0.9

- Removed the obsolete `encodeParseObjectInCloudFunction` option, which Parse Server 9 rejects because object encoding is now always enabled.
- Removed the corresponding environment override and Plesk form field so future deployments cannot regenerate the invalid configuration key.

## 1.0.8

- Fixed systemd `203/EXEC` for Node.js selected from root-owned NVM/FNM installations by placing the managed service binary in `/usr/local/bin` instead of the runtime data directory.
- Restores the SELinux context when available and verifies Node execution as the actual service user before starting either service.
- Regenerated units declare `ConditionPathIsExecutable` and remove the obsolete runtime copy after a successful migration.

## 1.0.7

- Fixed installation-time helper verification to execute the privileged helper through the Plesk API instead of reading its protected file directly.
- Makes the installation check non-fatal and leaves strict version enforcement to the panel and queued tasks, avoiding another partial update when Plesk temporarily cannot invoke the helper.

## 1.0.6

- Added an explicit version protocol between the Plesk UI, queued tasks and the privileged `sbin` helper.
- Blocks operations when Plesk retained an older helper and reports the exact installed path instead of executing stale deployment code.
- Verifies the copied privileged helper during extension installation so a partial update cannot appear successful.

## 1.0.5

- Changed the canonical public Parse URL from the retired `bzt.nerd.rip` endpoint to `https://api.nerd.rip/gildia/` and migrates that exact legacy override.
- Extended service startup health checks to 60 seconds, validates the returned service identity and reports systemd state plus recent journal entries on failure.
- Split diagnostics into manager, Parse Server and Parse Dashboard log views backed by separate systemd journals.

## 1.0.4

- Added a guarded workaround for npm 11 falsely reporting dependency entries that already exist in `package-lock.json`.
- The manager temporarily refreshes lock metadata, reruns deterministic `npm ci`, then restores the repository lockfile byte-for-byte.
- Real package/lock mismatches remain blocking errors.

## 1.0.3

- Added persistent trust-on-first-use SSH host pinning when the custom `known_hosts` field is empty.
- Kept strict host verification for manually supplied host keys and blocked changed host keys after automatic enrollment.

## 1.0.2

- Added automatic discovery and selection of system, Plesk, NVM and FNM Node.js runtimes with a custom-path fallback.
- Fixed npm launched through `#!/usr/bin/env node` by including the selected runtime directories in the restricted execution path.
- Services now use a protected runtime copy of Node.js instead of executing a root-owned NVM/FNM binary directly.

## 1.0.1

- Fixed tab initialization in the Plesk view and made browser storage optional.
- Matched tab navigation, focus states and keyboard controls with the other deployment managers.
- Scoped all browser behavior to the extension view and added a resilient log-copy fallback.

## 1.0.0

- Initial Parse Server and Parse Dashboard deployment manager.
- Full environment configuration with encrypted secrets.
- Source-backed default reload, systemd lifecycle controls and managed nginx proxy support.
