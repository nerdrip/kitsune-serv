<?php

class IndexController extends pm_Controller_Action
{
    protected $_accessLevel = 'admin';
    private $nodeRuntimePairs = [];

    public function init()
    {
        parent::init();
        $this->view->pageTitle = 'WPKit Parse Manager';
        $this->view->headLink()->appendStylesheet(
            pm_Context::getBaseUrl() . 'css/wpkit-parse.css?v=' . Modules_WpkitParseManager_Config::EXTENSION_VERSION
        );
        $this->view->headLink()->appendStylesheet(pm_Context::getBaseUrl() . 'css/kitsune-platform.css?v=2');
        $this->view->headScript()->appendFile(pm_Context::getBaseUrl() . 'js/kitsune-platform.js?v=2');
        $this->view->suiteProduct = 'WPKit Parse Manager';
        $this->view->suiteVersion = Modules_WpkitParseManager_Config::EXTENSION_VERSION;
        try { $this->view->suiteHubActive = pm_Extension::getById('kitsuneserv-bridge')->isActive(); }
        catch (Throwable $exception) { $this->view->suiteHubActive = false; }
    }

    public function indexAction()
    {
        $statusRefreshError = null;
        $backendInfo = null;
        if (!$this->getRequest()->isPost()) {
            $backendInfo = Modules_WpkitParseManager_Config::managerBackendInfo();
            if ($backendInfo['compatible']) $statusRefreshError = $this->refreshStatus();
        }
        $deploymentForm = $this->deploymentForm();
        $runtimeForm = $this->runtimeForm();
        $operationForm = $this->operationForm();
        $serviceForms = $this->serviceControlForms();
        $resetForm = $this->resetForm();

        if ($this->getRequest()->isPost()) {
            $post = (array) $this->getRequest()->getPost();
            $type = (string) ($post['formType'] ?? '');
            if ($type === 'deployment') return $this->saveDeployment($deploymentForm, $post);
            if ($type === 'runtime') return $this->saveRuntime($runtimeForm, $post);
            if ($type === 'operation') return $this->startOperation($operationForm, $post);
            if ($type === 'service') return $this->startServiceOperation($serviceForms, $post);
            if ($type === 'reset') return $this->resetRuntime($resetForm, $post);
        }

        $this->view->statusRefreshError = $statusRefreshError;
        $this->view->deploymentForm = $deploymentForm;
        $this->view->runtimeForm = $runtimeForm;
        $this->view->operationForm = $operationForm;
        $this->view->serviceForms = $serviceForms;
        $this->view->resetForm = $resetForm;
        $this->view->deployment = Modules_WpkitParseManager_Config::deploymentValues();
        $this->view->runtime = Modules_WpkitParseManager_Config::runtimeValues();
        $this->view->state = Modules_WpkitParseManager_Config::readState();
        $this->view->extensionVersion = Modules_WpkitParseManager_Config::EXTENSION_VERSION;
        $this->view->backendInfo = $backendInfo ?: Modules_WpkitParseManager_Config::managerBackendInfo();
    }

    private function deploymentForm()
    {
        $v = Modules_WpkitParseManager_Config::deploymentValues();
        $domains = $this->domainOptions();
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'wppm-deployment-form');
        $form->addElement('hidden', 'formType', ['value' => 'deployment']);

        $this->section($form, 'repoSection', 'Repozytorium i procesy', 'Kod jest synchronizowany wyłącznie przez bezpieczny fast-forward. Dane uruchomieniowe i pliki środowiska pozostają poza repozytorium.');
        $this->text($form, 'repositoryUrl', 'Repozytorium Git', $v['repositoryUrl'], true, 'HTTPS, ssh:// albo git@.');
        $this->text($form, 'repositoryBranch', 'Gałąź', $v['repositoryBranch'], true, 'Domyślnie develop.');
        foreach ([
            'repositoryPath' => ['Katalog repozytorium', 'Np. /opt/wpkit/source.'],
            'parsePath' => ['Katalog Parse Servera', 'Musi wskazywać folder parse-server wewnątrz repozytorium.'],
            'runtimePath' => ['Katalog danych uruchomieniowych', 'Pliki .env oraz techniczny stan wdrożenia.'],
        ] as $name => $meta) $this->text($form, $name, $meta[0], $v[$name], true, $meta[1]);

        $runtimeChoices = $this->nodeRuntimeChoices($v);
        $form->addElement('select', 'nodeRuntimePreset', [
            'label' => 'Środowisko Node.js',
            'value' => $runtimeChoices['selected'],
            'multiOptions' => $runtimeChoices['options'],
            'description' => 'Manager wykrywa instalacje systemowe, Plesk Node, NVM i FNM oraz automatycznie paruje binarki node i npm.',
        ]);
        $form->addElement('text', 'nodeBinaryCustom', [
            'label' => 'Własna binarka Node.js',
            'value' => $v['nodeBinary'],
            'description' => 'Używane wyłącznie po wybraniu opcji „Własne ścieżki”.',
            'class' => 'wppm-runtime-custom',
        ]);
        $form->addElement('text', 'npmBinaryCustom', [
            'label' => 'Własna binarka npm',
            'value' => $v['npmBinary'],
            'description' => 'Używane wyłącznie po wybraniu opcji „Własne ścieżki”.',
            'class' => 'wppm-runtime-custom',
        ]);
        foreach ([
            'serviceUser' => ['Użytkownik systemowy', 'Tworzony automatycznie, bez powłoki logowania.'],
            'parseService' => ['Usługa Parse Server', 'Nazwa jednostki systemd bez końcówki .service.'],
            'dashboardService' => ['Usługa Parse Dashboard', 'Nazwa jednostki systemd bez końcówki .service.'],
            'gitUsername' => ['Użytkownik Git HTTPS', 'Używany razem z tokenem dla prywatnego repozytorium.'],
        ] as $name => $meta) $this->text($form, $name, $meta[0], $v[$name], true, $meta[1]);
        $form->addElement('password', 'gitToken', [
            'label' => 'Token Git', 'value' => '',
            'description' => Modules_WpkitParseManager_Config::hasDeploymentSecret('gitToken') ? 'Zaszyfrowany; puste pole zachowuje wartość.' : 'Opcjonalny dla publicznego repozytorium.',
        ]);
        $form->addElement('textarea', 'gitSshKnownHosts', [
            'label' => 'SSH known_hosts', 'value' => $v['gitSshKnownHosts'], 'rows' => 4,
            'description' => 'Opcjonalne ręczne przypięcie. Gdy pole jest puste, manager utworzy własny plik i bezpiecznie zapamięta klucz hosta przy pierwszym połączeniu.',
        ]);
        $form->addElement('textarea', 'gitSshPrivateKey', [
            'label' => 'Klucz prywatny SSH', 'value' => '', 'rows' => 6,
            'description' => Modules_WpkitParseManager_Config::hasDeploymentSecret('gitSshPrivateKey') ? 'Zaszyfrowany; puste pole zachowuje wartość.' : 'Opcjonalny klucz deploy tylko do odczytu.',
        ]);

        $this->section($form, 'proxySection', 'Publikacja w Plesku', 'Tryb zarządzany zapisuje oznaczony blok reverse proxy nginx na dwóch oddzielnych domenach. TLS nadal obsługuje Plesk.');
        $form->addElement('select', 'proxyMode', [
            'label' => 'Reverse proxy', 'value' => $v['proxyMode'],
            'multiOptions' => ['manual' => 'Konfiguruję ręcznie', 'managed' => 'Zarządzaj automatycznie przez Plesk'],
        ]);
        foreach (['parseDomain' => 'Domena Parse API', 'dashboardDomain' => 'Domena Parse Dashboard'] as $name => $label) {
            if ($domains) {
                $options = $domains;
                if (!isset($options[$v[$name]])) $options[$v[$name]] = $v[$name] . ' (zapisana)';
                $form->addElement('select', $name, ['label' => $label, 'value' => $v[$name], 'multiOptions' => $options]);
            } else {
                $this->text($form, $name, $label, $v[$name], true, 'Aktywna domena z hostingiem WWW.');
            }
        }
        $this->actionButton($form, 'deploymentSubmit', 'Zapisz ustawienia wdrożenia', 'save');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function runtimeForm()
    {
        $v = Modules_WpkitParseManager_Config::runtimeValues();
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'wppm-runtime-form');
        $form->addElement('hidden', 'formType', ['value' => 'runtime']);

        $sections = $this->runtimeDefinition();
        foreach ($sections as $section) {
            $this->section($form, $section['id'], $section['title'], $section['description']);
            foreach ($section['fields'] as $name => $field) {
                $value = $v[$name] ?? '';
                if (!empty($field['secret'])) {
                    $type = !empty($field['textarea']) ? 'textarea' : 'password';
                    $options = [
                        'label' => $field['label'], 'value' => '',
                        'description' => Modules_WpkitParseManager_Config::hasRuntimeSecret($name)
                            ? 'Wartość dostępna (plik domyślny lub szyfrowane nadpisanie). Puste pole jej nie zmienia.'
                            : 'Brak wartości. Wprowadź sekret przed wdrożeniem.',
                    ];
                    if ($type === 'textarea') $options['rows'] = 7;
                    $form->addElement($type, $name, $options);
                } elseif (($field['type'] ?? 'text') === 'boolean') {
                    $form->addElement('select', $name, [
                        'label' => $field['label'], 'value' => $value,
                        'multiOptions' => ['false' => 'Nie', 'true' => 'Tak'],
                    ]);
                } elseif (($field['type'] ?? 'text') === 'textarea') {
                    $form->addElement('textarea', $name, ['label' => $field['label'], 'value' => $value, 'rows' => 3]);
                } else {
                    $options = ['label' => $field['label'], 'value' => $value];
                    if (($field['type'] ?? '') === 'integer') $options['validators'] = [['Digits', true]];
                    $form->addElement('text', $name, $options);
                }
            }
        }
        $this->actionButton($form, 'runtimeSubmit', 'Zapisz wszystkie nadpisania', 'save');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function runtimeDefinition()
    {
        return [
            ['id' => 'parseProcess', 'title' => 'Proces i połączenie Parse', 'description' => 'Podstawowe ustawienia procesu, MongoDB i adresów publicznych.', 'fields' => [
                'nodeEnvironment' => ['label' => 'NODE_ENV'], 'parseHost' => ['label' => 'Adres nasłuchu Parse'], 'parsePort' => ['label' => 'Port Parse', 'type' => 'integer'],
                'parseMountPath' => ['label' => 'Ścieżka montowania API'], 'parseTrustProxy' => ['label' => 'Ufaj reverse proxy', 'type' => 'boolean'],
                'databaseURI' => ['label' => 'MongoDB URI', 'secret' => true], 'appId' => ['label' => 'Parse App ID'],
                'serverURL' => ['label' => 'Wewnętrzny Server URL'], 'publicServerURL' => ['label' => 'Publiczny Server URL'],
                'appName' => ['label' => 'Nazwa aplikacji'],
            ]],
            ['id' => 'parseKeys', 'title' => 'Klucze Parse i operacje', 'description' => 'Sekrety są przechowywane przez Pleska w postaci szyfrowanej.', 'fields' => [
                'masterKey' => ['label' => 'Master key', 'secret' => true], 'javascriptKey' => ['label' => 'JavaScript key', 'secret' => true],
                'restAPIKey' => ['label' => 'REST API key', 'secret' => true], 'dotNetKey' => ['label' => '.NET key', 'secret' => true],
                'clientKey' => ['label' => 'Client key', 'secret' => true], 'opsToken' => ['label' => 'Token endpointów /ops', 'secret' => true],
                'masterKeyIps' => ['label' => 'Dozwolone IP master key (CSV)', 'type' => 'textarea'],
            ]],
            ['id' => 'parseUsers', 'title' => 'Konta, Cloud Code i LiveQuery', 'description' => 'Pełny zestaw ustawień odczytywanych przez config/env.js.', 'fields' => [
                'verifyUserEmails' => ['label' => 'Weryfikuj e-maile', 'type' => 'boolean'],
                'emailVerifyTokenValidityDuration' => ['label' => 'Ważność tokenu e-mail (sekundy)', 'type' => 'integer'],
                'liveQueryClassNames' => ['label' => 'Klasy LiveQuery (CSV)', 'type' => 'textarea'],
                'cloudPasswordKeyHex' => ['label' => 'AES key hex dla haseł WP', 'secret' => true],
                'cloudPasswordIvHex' => ['label' => 'AES IV hex dla haseł WP', 'secret' => true],
            ]],
            ['id' => 'parseMail', 'title' => 'SMTP', 'description' => 'Konfiguracja adaptera wiadomości Parse.', 'fields' => [
                'smtpSecure' => ['label' => 'SMTP TLS od połączenia', 'type' => 'boolean'], 'smtpPort' => ['label' => 'Port SMTP', 'type' => 'integer'],
                'smtpHost' => ['label' => 'Host SMTP'], 'smtpUser' => ['label' => 'Użytkownik SMTP'],
                'smtpPassword' => ['label' => 'Hasło SMTP', 'secret' => true], 'smtpFromAddress' => ['label' => 'Adres nadawcy'],
            ]],
            ['id' => 'parseProtection', 'title' => 'Limity, readiness i push', 'description' => 'Ochrona endpointów oraz routing Firebase dla wielu aplikacji.', 'fields' => [
                'rateLimitEnabled' => ['label' => 'Włącz rate limit', 'type' => 'boolean'],
                'rateLimitWindowMs' => ['label' => 'Okno rate limit (ms)', 'type' => 'integer'], 'rateLimitMax' => ['label' => 'Limit żądań', 'type' => 'integer'],
                'rateLimitPaths' => ['label' => 'Chronione ścieżki (CSV)', 'type' => 'textarea'],
                'readinessTimeoutMs' => ['label' => 'Timeout readiness (ms)', 'type' => 'integer'],
                'pushAppsJson' => ['label' => 'Mapa aplikacji push (JSON)', 'secret' => true, 'textarea' => true],
                'pushDefaultApp' => ['label' => 'Domyślna aplikacja push'],
            ]],
            ['id' => 'dashboardProcess', 'title' => 'Parse Dashboard', 'description' => 'Wszystkie ustawienia dashboardu, dostępu i bezpiecznego cookie.', 'fields' => [
                'dashboardEnvironment' => ['label' => 'Dashboard NODE_ENV'], 'dashboardHost' => ['label' => 'Adres nasłuchu'],
                'dashboardPort' => ['label' => 'Port dashboardu', 'type' => 'integer'], 'dashboardMountPath' => ['label' => 'Ścieżka montowania'],
                'dashboardTrustProxy' => ['label' => 'Ufaj reverse proxy', 'type' => 'boolean'],
                'dashboardServerURL' => ['label' => 'URL Parse Servera'], 'dashboardAppId' => ['label' => 'Parse App ID'],
                'dashboardMasterKey' => ['label' => 'Parse master key', 'secret' => true], 'dashboardAppName' => ['label' => 'Nazwa aplikacji'],
                'dashboardAccessKey' => ['label' => 'Klucz wejściowy dashboardu', 'secret' => true],
                'dashboardCookieName' => ['label' => 'Nazwa cookie'], 'dashboardCookieSecret' => ['label' => 'Sekret podpisu cookie', 'secret' => true],
                'dashboardCookieMaxAgeMs' => ['label' => 'Ważność cookie (ms)', 'type' => 'integer'],
                'dashboardCookieSecure' => ['label' => 'Cookie tylko przez HTTPS', 'type' => 'boolean'],
                'dashboardUser' => ['label' => 'Dodatkowy login dashboardu'], 'dashboardPassword' => ['label' => 'Dodatkowe hasło dashboardu', 'secret' => true],
                'dashboardAllowInsecureHTTP' => ['label' => 'Zezwól dashboardowi na HTTP do Parse', 'type' => 'boolean'],
            ]],
        ];
    }

    private function operationForm()
    {
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'wppm-operation-form');
        $form->addElement('hidden', 'formType', ['value' => 'operation']);
        $form->addElement('select', 'operation', [
            'label' => 'Operacja', 'value' => 'check', 'required' => true,
            'multiOptions' => [
                'check' => 'Sprawdź repozytorium i wymagania', 'sync' => 'Zaktualizuj lokalny kod',
                'deploy' => 'Wdróż z lokalnego kodu', 'sync-deploy' => 'Pobierz i wdróż',
                'migrate' => 'Uruchom migracje schematu Parse',
            ],
        ]);
        $form->addElement('checkbox', 'moduleParse', ['label' => 'Parse Server', 'value' => '1']);
        $form->addElement('checkbox', 'moduleDashboard', ['label' => 'Parse Dashboard', 'value' => '1']);
        $this->actionButton($form, 'operationSubmit', 'Uruchom operację', 'operation');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function serviceControlForms()
    {
        $forms = [];
        foreach (['parse' => 'Parse Server', 'dashboard' => 'Parse Dashboard'] as $module => $label) {
            $form = new pm_Form_Simple();
            $form->setAttrib('id', 'wppm-service-form-' . $module);
            $form->addElement('hidden', 'formType', ['value' => 'service']);
            $form->addElement('hidden', 'module', ['value' => $module]);
            $form->addElement('simpleText', 'serviceControls', [
                'label' => '', 'escape' => false,
                'value' => '<div class="wppm-service-actions" role="group" aria-label="Sterowanie usługą ' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '">'
                    . '<button type="submit" name="serviceAction" value="start" class="wppm-service-button wppm-service-start" data-wppm-action="service-start">Uruchom</button>'
                    . '<button type="submit" name="serviceAction" value="restart" class="wppm-service-button wppm-service-restart" data-wppm-action="service-restart">Restart</button>'
                    . '<button type="submit" name="serviceAction" value="stop" class="wppm-service-button wppm-service-stop" data-wppm-action="service-stop">Zatrzymaj</button>'
                    . '</div>',
            ]);
            $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
            $forms[$module] = $form;
        }
        return $forms;
    }

    private function resetForm()
    {
        $form = new pm_Form_Simple();
        $form->setAttrib('id', 'wppm-reset-form');
        $form->addElement('hidden', 'formType', ['value' => 'reset']);
        $form->addElement('checkbox', 'confirmReset', ['label' => 'Potwierdzam usunięcie wszystkich nadpisań', 'value' => '0']);
        $this->actionButton($form, 'resetSubmit', 'Przywróć wartości z plików', 'reset');
        $form->addControlButtons(['sendHidden' => true, 'cancelHidden' => true, 'hideLegend' => true]);
        return $form;
    }

    private function saveDeployment(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) return $this->fail('Sprawdź pola ustawień wdrożenia.');
        try {
            $values = $this->resolveNodeRuntime($form->getValues());
            $this->validateDeployment($values);
            Modules_WpkitParseManager_Config::saveDeployment($values);
            $this->_status->addMessage('info', 'Ustawienia wdrożenia zostały zapisane.');
        } catch (Throwable $exception) { $this->_status->addMessage('error', $exception->getMessage()); }
        return $this->redirectResponse();
    }

    private function saveRuntime(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) return $this->fail('Sprawdź pola konfiguracji Parse i Dashboard.');
        try {
            Modules_WpkitParseManager_Config::saveRuntime($form->getValues());
            $this->_status->addMessage('info', 'Nadpisania zostały zapisane. Zastosuje je następne wdrożenie lub restart po wdrożeniu.');
        } catch (Throwable $exception) { $this->_status->addMessage('error', $exception->getMessage()); }
        return $this->redirectResponse();
    }

    private function resetRuntime(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post) || !$form->getValue('confirmReset')) return $this->fail('Przywrócenie wymaga jawnego potwierdzenia.');
        $runtimeConfig = null;
        try {
            Modules_WpkitParseManager_Config::assertManagerBackendCompatible();
            $runtimeConfig = Modules_WpkitParseManager_Config::createRuntimeConfig('defaults');
            $result = pm_ApiCli::callSbin('wpkit-parse-manager', ['--config', $runtimeConfig], pm_ApiCli::RESULT_FULL);
            if ((int) ($result['code'] ?? 1) !== 0) throw new RuntimeException(trim((string) ($result['stderr'] ?? 'Nie udało się odczytać plików domyślnych.')));
            Modules_WpkitParseManager_Config::resetRuntimeOverrides();
            $this->_status->addMessage('info', 'Usunięto nadpisania i ponownie odczytano wartości z plików źródłowych. Uruchom wdrożenie lub restart, aby zastosować je w usługach.');
        } catch (Throwable $exception) { $this->_status->addMessage('error', 'Nie przywrócono ustawień: ' . $exception->getMessage()); }
        finally { if ($runtimeConfig && is_file($runtimeConfig)) @unlink($runtimeConfig); }
        return $this->redirectResponse();
    }

    private function startOperation(pm_Form_Simple $form, array $post)
    {
        if (!$form->isValid($post)) return $this->fail('Sprawdź pola operacji.');
        $operation = (string) $form->getValue('operation');
        if (!in_array($operation, ['check', 'sync', 'deploy', 'sync-deploy', 'migrate'], true)) return $this->fail('Nieznana operacja.');
        $modules = [];
        if ($form->getValue('moduleParse')) $modules[] = 'parse';
        if ($form->getValue('moduleDashboard')) $modules[] = 'dashboard';
        if (in_array($operation, ['deploy', 'sync-deploy'], true) && !$modules) return $this->fail('Wybierz co najmniej jedną usługę.');
        try {
            Modules_WpkitParseManager_Config::assertManagerBackendCompatible();
            $runtimeConfig = Modules_WpkitParseManager_Config::createRuntimeConfig($operation, ['modules' => $modules]);
            $task = new Modules_WpkitParseManager_Task_Operate();
            $task->setParam('runtimeConfig', $runtimeConfig);
            $task->setParam('operation', $operation);
            (new pm_LongTask_Manager())->start($task);
            $this->_status->addMessage('info', 'Operacja została dodana do kolejki Pleska.');
        } catch (Throwable $exception) { $this->_status->addMessage('error', 'Nie udało się uruchomić operacji: ' . $exception->getMessage()); }
        return $this->redirectResponse();
    }

    private function startServiceOperation(array $forms, array $post)
    {
        $module = (string) ($post['module'] ?? '');
        $action = (string) ($post['serviceAction'] ?? '');
        if (!isset($forms[$module]) || !$forms[$module]->isValid($post)) return $this->fail('Nieprawidłowa usługa.');
        if (!in_array($action, ['start', 'restart', 'stop'], true)) return $this->fail('Nieprawidłowa akcja usługi.');
        try {
            Modules_WpkitParseManager_Config::assertManagerBackendCompatible();
            $runtimeConfig = Modules_WpkitParseManager_Config::createRuntimeConfig($action, ['modules' => [$module]]);
            $task = new Modules_WpkitParseManager_Task_Operate();
            $task->setParam('runtimeConfig', $runtimeConfig);
            $task->setParam('operation', $action . ' ' . $module);
            (new pm_LongTask_Manager())->start($task);
            $this->_status->addMessage('info', 'Akcja usługi została dodana do kolejki Pleska.');
        } catch (Throwable $exception) {
            $this->_status->addMessage('error', 'Nie udało się uruchomić akcji usługi: ' . $exception->getMessage());
        }
        return $this->redirectResponse();
    }

    private function refreshStatus()
    {
        $runtimeConfig = null;
        try {
            $runtimeConfig = Modules_WpkitParseManager_Config::createRuntimeConfig('status');
            $result = pm_ApiCli::callSbin('wpkit-parse-manager', ['--config', $runtimeConfig], pm_ApiCli::RESULT_FULL);
            if ((int) ($result['code'] ?? 1) !== 0) return trim((string) ($result['stderr'] ?? $result['stdout'] ?? 'Błąd odświeżania.'));
            return null;
        } catch (Throwable $exception) { return $exception->getMessage(); }
        finally { if ($runtimeConfig && is_file($runtimeConfig)) @unlink($runtimeConfig); }
    }

    private function validateDeployment(array $values)
    {
        if (!preg_match('/^(https:\/\/|ssh:\/\/|git@)/', (string) ($values['repositoryUrl'] ?? ''))) throw new RuntimeException('Repozytorium musi używać HTTPS albo SSH.');
        if (!preg_match('/^(?![-.])(?!.*\.\.)(?!.*@\{)[A-Za-z0-9._\/-]+$/', (string) ($values['repositoryBranch'] ?? ''))) throw new RuntimeException('Nieprawidłowa nazwa gałęzi.');
        foreach (['repositoryPath', 'parsePath', 'runtimePath', 'nodeBinary', 'npmBinary'] as $field) {
            $path = rtrim((string) ($values[$field] ?? ''), '/');
            if (!preg_match('#^/[A-Za-z0-9._/-]+$#', $path) || strpos($path, '..') !== false || substr_count($path, '/') < 2) throw new RuntimeException('Niebezpieczna ścieżka: ' . $field . '.');
        }
        $repository = rtrim((string) $values['repositoryPath'], '/');
        $parse = rtrim((string) $values['parsePath'], '/');
        $runtime = rtrim((string) $values['runtimePath'], '/');
        if (strpos($parse . '/', $repository . '/') !== 0) throw new RuntimeException('Katalog Parse Servera musi znajdować się wewnątrz repozytorium.');
        if ($runtime === $repository || strpos($runtime . '/', $repository . '/') === 0) throw new RuntimeException('Katalog uruchomieniowy musi znajdować się poza repozytorium.');
        foreach (['serviceUser', 'parseService', 'dashboardService'] as $field) {
            if (!preg_match('/^[a-zA-Z_][a-zA-Z0-9_.@-]{0,63}$/', (string) ($values[$field] ?? ''))) throw new RuntimeException('Nieprawidłowa nazwa systemowa: ' . $field . '.');
        }
        if (($values['parseService'] ?? '') === ($values['dashboardService'] ?? '')) throw new RuntimeException('Usługi muszą mieć różne nazwy.');
        if (($values['proxyMode'] ?? '') === 'managed' && ($values['parseDomain'] ?? '') === ($values['dashboardDomain'] ?? '')) throw new RuntimeException('API i dashboard wymagają dwóch różnych domen.');
    }

    private function domainOptions()
    {
        $options = [];
        try {
            foreach ((array) pm_Domain::getAllDomains() as $domain) {
                if (!$domain instanceof pm_Domain || !$domain->hasHosting() || !$domain->isActive() || $domain->isSuspended() || $domain->isDisabled()) continue;
                $name = strtolower(trim((string) $domain->getName()));
                if ($name !== '') $options[$name] = $name;
            }
        } catch (Throwable $exception) {}
        natcasesort($options);
        return $options;
    }

    private function nodeRuntimeChoices(array $values)
    {
        $runtimes = [];
        try {
            $result = pm_ApiCli::callSbin('wpkit-parse-manager', ['--discover-node'], pm_ApiCli::RESULT_FULL);
            if ((int) ($result['code'] ?? 1) === 0) {
                $decoded = json_decode((string) ($result['stdout'] ?? ''), true);
                if (is_array($decoded)) $runtimes = $decoded;
            }
        } catch (Throwable $exception) {}

        $options = [];
        $selected = '';
        foreach ($runtimes as $runtime) {
            if (!is_array($runtime)) continue;
            $node = (string) ($runtime['node'] ?? '');
            $npm = (string) ($runtime['npm'] ?? '');
            if (!$this->isSafeToolPath($node) || !$this->isSafeToolPath($npm)) continue;
            $key = 'runtime_' . substr(hash('sha256', $node . "\n" . $npm), 0, 16);
            $this->nodeRuntimePairs[$key] = ['nodeBinary' => $node, 'npmBinary' => $npm];
            $options[$key] = (string) ($runtime['label'] ?? ($node . ' + ' . $npm));
            if ($node === (string) $values['nodeBinary'] && $npm === (string) $values['npmBinary']) $selected = $key;
        }

        if ($selected === '' && $this->isSafeToolPath($values['nodeBinary']) && $this->isSafeToolPath($values['npmBinary'])) {
            $key = 'runtime_' . substr(hash('sha256', $values['nodeBinary'] . "\n" . $values['npmBinary']), 0, 16);
            $this->nodeRuntimePairs[$key] = ['nodeBinary' => (string) $values['nodeBinary'], 'npmBinary' => (string) $values['npmBinary']];
            $options[$key] = 'Aktualnie zapisane — ' . $values['nodeBinary'];
            $selected = $key;
        }

        $options['custom'] = 'Własne ścieżki…';
        if ($selected === '') $selected = 'custom';
        return ['options' => $options, 'selected' => $selected];
    }

    private function resolveNodeRuntime(array $values)
    {
        $preset = (string) ($values['nodeRuntimePreset'] ?? 'custom');
        if ($preset === 'custom') {
            $values['nodeBinary'] = trim((string) ($values['nodeBinaryCustom'] ?? ''));
            $values['npmBinary'] = trim((string) ($values['npmBinaryCustom'] ?? ''));
            return $values;
        }
        if (!isset($this->nodeRuntimePairs[$preset])) throw new RuntimeException('Wybrane środowisko Node.js nie jest już dostępne. Odśwież listę albo wybierz własne ścieżki.');
        return array_merge($values, $this->nodeRuntimePairs[$preset]);
    }

    private function isSafeToolPath($path)
    {
        $path = rtrim(trim((string) $path), '/');
        return (bool) preg_match('#^/[A-Za-z0-9._/-]+$#', $path)
            && strpos($path, '//') === false
            && !in_array('..', explode('/', $path), true)
            && substr_count($path, '/') >= 2;
    }

    private function text(pm_Form_Simple $form, $name, $label, $value, $required, $description)
    {
        $form->addElement('text', $name, ['label' => $label, 'value' => $value, 'required' => $required, 'description' => $description]);
    }

    private function section(pm_Form_Simple $form, $name, $title, $description)
    {
        $form->addElement('simpleText', $name, ['label' => '', 'escape' => false, 'value' => '<div class="wppm-form-section"><strong>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</strong><span>' . htmlspecialchars($description, ENT_QUOTES, 'UTF-8') . '</span></div>']);
    }

    private function actionButton(pm_Form_Simple $form, $name, $label, $kind)
    {
        $form->addElement('simpleText', $name, ['label' => '', 'escape' => false, 'value' => '<button type="submit" class="wppm-primary" data-wppm-action="' . htmlspecialchars($kind, ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</button>']);
    }

    private function fail($message)
    {
        $this->_status->addMessage('error', $message);
        return $this->redirectResponse();
    }

    private function redirectResponse()
    {
        $this->_helper->json(['redirect' => pm_Context::getActionUrl('index', 'index')]);
    }
}
